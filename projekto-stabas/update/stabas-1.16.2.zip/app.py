#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Projekto Štabas — lokali projektų vadovo darbo vieta."""

import csv
import base64
import html
import io
import ipaddress
import json
import logging
from contextlib import contextmanager
import mimetypes
import os
import re
import secrets
import shutil
import socket
import sqlite3
import subprocess
import sys
import hashlib
import tempfile
import threading
import time
import traceback
import unicodedata
import urllib.request
import webbrowser
import zipfile
from datetime import date, datetime, timedelta
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlencode, urlparse
from xml.etree import ElementTree as ET

import assistant
import updater

APP_NAME = "Projekto Štabas"
VERSION = "1.16.2"
LAN_ENABLED = os.environ.get("STABAS_LAN", "1") != "0"
BIND_HOST = "0.0.0.0" if LAN_ENABLED else "127.0.0.1"

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
STATIC_DIR = BASE_DIR / "static"
CACHE_DIR = DATA_DIR / "cache"
BACKUP_DIR = DATA_DIR / "backups"
DWG_CACHE_DIR = CACHE_DIR / "dwg"
DWG_TEXT_DIR = CACHE_DIR / "dwgtext"
DWG_CACHE_MAX_BYTES = 400 * 1024 * 1024
DWG_SVG_MAX_BYTES = 64 * 1024 * 1024
DWG_TEXT_MAX_CHARS = 250_000
DWG_CONVERT_TIMEOUT = 300
for _d in (DATA_DIR, CACHE_DIR, BACKUP_DIR, DWG_CACHE_DIR, DWG_TEXT_DIR):
    _d.mkdir(parents=True, exist_ok=True)

DB_PATH = DATA_DIR / "app.db"
PROJECTS_DIR = DATA_DIR / "projects"
PROJECTS_PATH = DATA_DIR / "projects.json"
GLOBAL_PATH = DATA_DIR / "global.json"
PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
LOG_PATH = DATA_DIR / "server.log"

logger = logging.getLogger("stabas")
logger.setLevel(logging.INFO)
try:
    if LOG_PATH.exists() and LOG_PATH.stat().st_size > 2_000_000:
        try:
            LOG_PATH.replace(DATA_DIR / "server.old.log")
        except OSError:
            pass
    _fh = logging.FileHandler(LOG_PATH, encoding="utf-8")
    _fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(_fh)
except OSError:
    pass

DISCIPLINES = {
    "BD": "Bendroji dalis",
    "SP": "Sklypo sutvarkymo dalis",
    "SA": "Architektūra",
    "SK": "Konstrukcijos",
    "E": "Elektra",
    "ET": "Elektros tinklai",
    "ŠVOK": "Šildymas, vėdinimas, kondicionavimas",
    "VN": "Vandentiekis ir nuotekos",
    "LVN": "Lauko vandentiekis ir nuotekos",
    "TOPO": "Topografija",
    "NTR": "Nekilnojamojo turto registras",
    "SLD": "Statybos leidimas ir dokumentai",
}
DISC_ORDER = list(DISCIPLINES)
DISC_STATUSES = ["Nepažymėta", "Rengiama", "Pateikta derinti", "Derinama", "Patvirtinta"]

DEFAULT_PROJECT = {
    "name": "Vytauto Didžiojo g. 29A daugiabutis",
    "full_name": "Gyvenamosios paskirties (trijų ir daugiau butų (daugiabučiai)) pastato (6.3) Vytauto Didžiojo g. 29A, Šilalėje, naujos statybos projektas",
    "address": "Vytauto Didžiojo g. 29A, Šilalė",
    "client": "UAB „BRAVO VITA“",
    "designer": "MB „Pastatų projektai“ / MB „Archihauzas“",
    "project_no": "22/17-TP; SK 26-659-DP",
    "permit_no": "LSNS-72-240327-00012",
    "permit_date": "2024-03-27",
    "permit_authority": "Šilalės rajono savivaldybės administracija",
    "stage": "Techninis projektas (TP) / Darbo projektas (DP)",
    "plotis": "24,94",
    "gylis": "15,44",
    "aukstis": "+12,85",
    "langai": "96",
    "fasadopoz": "36",
}
# Visi projekto rekvizitų laukai. Naujiems projektams jie sukuriami tušti,
# kad iš Šilalės objekto neliktų svetimų duomenų.
PROJECT_FIELDS = list(DEFAULT_PROJECT)

# Mano įmonės rekvizitai – bendri visiems projektams (sąskaitoms ir dokumentams).
DEFAULT_COMPANY = {
    "name": "UAB „BALTIC BLOCK CENTRUM“",
    "code": "306077259",
    "vat": "LT100015967013",
    "address": "Įmonių g. 5D-3, LT-35101 Panevėžys",
    "bank": "Šiaulių bankas",
    "iban": "LT32718990051467802",
    "director": "Viktoras Pocius",
    "phone": "+370 606 13512",
    "email": "viktorasbazilas@gmail.com",
    "invoice_note": "",
}
COMPANY_FIELDS = list(DEFAULT_COMPANY)

DEFAULT_CHECKLIST = [
    ("1. Parengiamieji darbai", "Sutartis su projektuotoju pasirašyta"),
    ("1. Parengiamieji darbai", "Techninė užduotis (TDP) parengta ir suderinta"),
    ("1. Parengiamieji darbai", "Topografinė nuotrauka atlikta"),
    ("1. Parengiamieji darbai", "Nekilnojamojo turto registro duomenys surinkti"),
    ("1. Parengiamieji darbai", "Statybos leidimo paraiška pateikta"),
    ("2. Projektavimas", "Bendroji dalis (BD) parengta"),
    ("2. Projektavimas", "Sklypo sutvarkymo dalis (SP) parengta"),
    ("2. Projektavimas", "Architektūros dalis (SA) parengta"),
    ("2. Projektavimas", "Konstrukcijų dalis (SK) parengta"),
    ("2. Projektavimas", "Elektros dalis (E) parengta"),
    ("2. Projektavimas", "Šildymo, vėdinimo ir kondicionavimo dalis (ŠVOK) parengta"),
    ("2. Projektavimas", "Vandentiekio ir nuotekų dalis (VN) parengta"),
    ("2. Projektavimas", "Lauko tinklų dalis (LVN) parengta"),
    ("2. Projektavimas", "Energinio naudingumo sertifikatas gautas"),
    ("3. Derinimas ir leidimai", "Projektas suderintas su savivaldybe"),
    ("3. Derinimas ir leidimai", "Projektas suderintas su tinklų savininkais"),
    ("3. Derinimas ir leidimai", "Statybos leidimas gautas"),
    ("3. Derinimas ir leidimai", "Sutikimai su trečiaisiais asmenimis gauti"),
    ("4. Pirkimai ir sutartys", "Rangovo viešasis pirkimas paskelbtas"),
    ("4. Pirkimai ir sutartys", "Rangovas parinktas"),
    ("4. Pirkimai ir sutartys", "Statybos rangos sutartis pasirašyta"),
    ("4. Pirkimai ir sutartys", "Techninės priežiūros sutartis pasirašyta"),
    ("4. Pirkimai ir sutartys", "Projekto vadovas / FIDIC inžinierius paskirtas"),
    ("5. Statyba", "Statybos pradžios deklaracija pateikta"),
    ("5. Statyba", "Statybos žurnalas pildomas"),
    ("5. Statyba", "Savaitiniai statybos susitikimai vykdomi"),
    ("5. Statyba", "Medžiagų atitikties dokumentai surenkami"),
    ("5. Statyba", "Tarpiniai darbų aktai pasirašomi"),
    ("5. Statyba", "Statybos eigos ataskaitos teikiamos užsakovui"),
    ("6. Užbaigimas", "Baigtumo deklaracija pateikta"),
    ("6. Užbaigimas", "Kadastriniai matavimai atlikti"),
    ("6. Užbaigimas", "Statinys priimtas eksploatuoti"),
    ("6. Užbaigimas", "Dokumentacija suarchyvuota"),
    ("6. Užbaigimas", "Galutinis atsiskaitymas atliktas"),
]

WORK_SECTIONS = {
    "elektra": {"label": "Elektra", "disc": "E", "view": "elektra"},
    "apdaila": {"label": "Apdaila", "disc": "SA", "view": "apdaila"},
    "santechnika": {"label": "Santechnika", "disc": "VN", "view": "santechnika"},
    "fasadas": {"label": "Fasadas", "disc": "BD", "view": "fasadas"},
}

WORK_UNITS = ["m", "m²", "m³", "vnt.", "kompl.", "ltr", "kg", "t"]


def _work(section, stage, code, title, unit, qty, kind, basis, src, page, note=""):
    return {
        "section": section, "stage": stage, "code": code, "title": title,
        "unit": unit, "qty": qty, "kind": kind, "basis": basis,
        "src": src, "page": page, "note": note,
    }


# Sąmatos pozicijos iš projekto kiekių žiniaraščių ir skaičiuojamos pozicijos.
# Kiekviena pozicija turi aiškų pagrindimą: dokumento lapą arba skaičiavimo formulę.
DEFAULT_WORKS = [
    # ---------- ELEKTRA ----------
    _work("elektra", "Transformatorinės pertvarkymas", "E-01",
          "Kirtiklių-saugiklių bloko NH-2 montavimas", "kompl.", 1, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 1", "25-E", 66),
    _work("elektra", "Transformatorinės pertvarkymas", "E-02",
          "Lydžiųjų įdėklų 315A NH-2 montavimas", "vnt.", 3, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 2", "25-E", 66),
    _work("elektra", "Lauko 0,4 kV kabelių linija", "E-03",
          "Tranšėjų kasimas ir užkasimas mechanizuotu būdu", "m", 192, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 3a", "25-E", 66),
    _work("elektra", "Lauko 0,4 kV kabelių linija", "E-04",
          "Tranšėjų kasimas ir užkasimas rankiniu būdu", "m", 20, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 3b", "25-E", 66),
    _work("elektra", "Lauko 0,4 kV kabelių linija", "E-05",
          "Signalinės juostos paklojimas tranšėjoje", "m", 212, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 4", "25-E", 66),
    _work("elektra", "Lauko 0,4 kV kabelių linija", "E-06",
          "Duobių kasimas vamzdžio prakalimui", "m³", 15, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 5 (5 duobės / 15 m³)", "25-E", 66,
          "Projekte nurodyta 5 vnt./15 m³; kiekis perskaičiuotas į m³."),
    _work("elektra", "Lauko 0,4 kV kabelių linija", "E-07",
          "PE Ø110 mm vamzdžių paklojimas tranšėjoje", "m", 212, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 6a", "25-E", 66),
    _work("elektra", "Lauko 0,4 kV kabelių linija", "E-08",
          "HDPE Ø110 mm vamzdžių paklojimas kryptiniu gręžimu", "m", 95, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 6b", "25-E", 66),
    _work("elektra", "Lauko 0,4 kV kabelių linija", "E-09",
          "Vamzdžių galų užsandarinimas", "vnt.", 4, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 6c", "25-E", 66),
    _work("elektra", "Lauko 0,4 kV kabelių linija", "E-10",
          "0,4 kV kabelio Al 4x240 mm² tiesimas", "m", 315, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 7", "25-E", 66),
    _work("elektra", "Lauko 0,4 kV kabelių linija", "E-11",
          "0,4 kV kabelio Al 4x95 mm² tiesimas", "m", 4, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 8", "25-E", 66),
    _work("elektra", "Lauko 0,4 kV kabelių linija", "E-12",
          "Galinės movos 240 mm² montavimas", "kompl.", 2, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 9", "25-E", 66),
    _work("elektra", "Lauko 0,4 kV kabelių linija", "E-13",
          "Galinės movos 95 mm² montavimas", "kompl.", 2, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 10", "25-E", 66),
    _work("elektra", "Lauko 0,4 kV kabelių linija", "E-14",
          "Duobių kasimas KAS, KS/KAS pamatams", "m³", 0.75, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 11", "25-E", 66),
    _work("elektra", "Lauko 0,4 kV kabelių linija", "E-15",
          "Duobių užpylimas", "m³", 0.75, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 12", "25-E", 66),
    _work("elektra", "Lauko 0,4 kV kabelių linija", "E-16",
          "Spintų pamatų pagrindo betonavimas", "m³", 0.30, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 13", "25-E", 66),
    _work("elektra", "Lauko 0,4 kV kabelių linija", "E-17",
          "Kabelio markiruočių uždėjimas", "vnt.", 4, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 14", "25-E", 66),
    _work("elektra", "Lauko 0,4 kV kabelių linija", "E-18",
          "Kabelio izoliacijos varžos matavimas", "vnt.", 2, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 15", "25-E", 66),
    _work("elektra", "Apskaitos spintos ir įžeminimas", "E-19",
          "Apskaitos spintų montavimas ant pamato", "kompl.", 2, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 66, eil. 16", "25-E", 66,
          "KS/KAS-7 – 1 kompl., KAS-8 – 1 kompl."),
    _work("elektra", "Apskaitos spintos ir įžeminimas", "E-20",
          "Grandinės patikrinimas tarp įžemiklių ir įžemintų elementų", "vnt.", 20, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 67, eil. 17 (0,2 × 100 vnt.)", "25-E", 67,
          "Projekte nurodyta 100 vnt. vienetų; perskaičiuota į 20 vnt."),
    _work("elektra", "Apskaitos spintos ir įžeminimas", "E-21",
          "Įžeminimo vertikalių strypų Ø14, L=1,5 m montavimas", "vnt.", 6, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 68, eil. 11", "25-E", 68),
    _work("elektra", "Apskaitos spintos ir įžeminimas", "E-22",
          "Įžeminimo kontūro įrengimas R≤10 Ω", "kompl.", 1, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 67, eil. 18", "25-E", 67),
    _work("elektra", "Apskaitos spintos ir įžeminimas", "E-23",
          "Įžeminimo kontūro varžos matavimas", "kompl.", 2, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 67, eil. 19", "25-E", 67),
    _work("elektra", "Apskaitos spintos ir įžeminimas", "E-24",
          "KAS skydų prijungimas prie įžeminimo kontūro", "kompl.", 1, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 67, eil. 20", "25-E", 67),
    _work("elektra", "Apskaitos spintos ir įžeminimas", "E-25",
          "Grunto išlyginimas", "m²", 212, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 67, eil. 21 (2,12 × 100 m²)", "25-E", 67,
          "Projekte nurodyta 2,12 × 100 m²; perskaičiuota į 212 m²."),
    _work("elektra", "Apskaitos spintos ir įžeminimas", "E-26",
          "Grunto tankinimas vibroplokštėmis", "m³", 64, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 67, eil. 22 (0,64 × 100 m³)", "25-E", 67,
          "Projekte nurodyta 0,64 × 100 m³; perskaičiuota į 64 m³."),
    _work("elektra", "Apskaitos spintos ir įžeminimas", "E-27",
          "Žolės užsėjimas rankiniu būdu", "m²", 212, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 67, eil. 23 (2,12 × 100 m²)", "25-E", 67,
          "Projekte nurodyta 2,12 × 100 m²; perskaičiuota į 212 m²."),
    _work("elektra", "Geodezija ir leidimai", "E-28",
          "Geodezinis trasos nužymėjimas", "vnt.", 23, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 69, eil. 1", "25-E", 69),
    _work("elektra", "Geodezija ir leidimai", "E-29",
          "Kontrolinė topografinė nuotrauka", "kompl.", 1, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 69, eil. 2", "25-E", 69),
    _work("elektra", "Geodezija ir leidimai", "E-30",
          "Leidimas kasimo darbams", "vnt.", 1, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 69, eil. 3", "25-E", 69),
    _work("elektra", "Geodezija ir leidimai", "E-31",
          "Telia atstovo iškvietimas", "vnt.", 1, "Sąmata",
          "25-E-5269-TDP-E.SŽ, l. 69, eil. 4", "25-E", 69),
    _work("elektra", "Vidaus elektros instaliacija", "E-32",
          "Buto elektros instaliacijos įrengimas (kabeliai, lizdai, jungikliai, šviestuvai)", "kompl.", 20, "Skaičiuojama",
          "Skaičiuojama: 20 butų × 1 kompl. (12 dviejų ir 8 trijų kambarių butai; 1-BD l. 7)", "BD", 7,
          "Orientacinis kiekis. Detalūs kiekiai tikslinami pagal ET projektą."),
    _work("elektra", "Vidaus elektros instaliacija", "E-33",
          "Bendrųjų patalpų elektros instaliacija (laiptinės, rūsys, lauko apšvietimas)", "kompl.", 1, "Skaičiuojama",
          "Skaičiuojama pagal ET brėžinius; patikslinti pagal techninį projektą", "25-E", 66,
          "Orientacinis kiekis. Apima bendrąsias patalpas ir lauko apšvietimą."),
    _work("elektra", "Vidaus elektros instaliacija", "E-34",
          "Elektros instaliacijos bandymai ir paleidimas", "kompl.", 1, "Skaičiuojama",
          "Skaičiuojama: 1 kompl. visam pastatui (pagal 25-E reikalavimus)", "25-E", 67),

    # ---------- APDAILA ----------
    _work("apdaila", "Sienos ir lubos", "A-01",
          "Sienų paviršių glaistymas", "m²", 3063.33, "Skaičiuojama",
          "Skaičiuojama: 1 225,33 m² × 2,5 (sienų/grindų koeficientas)", "BD", 18,
          "Orientacinis kiekis. Patikslinti pagal išklotines."),
    _work("apdaila", "Sienos ir lubos", "A-02",
          "Sienų dažymas (2 sluoksniai)", "m²", 3063.33, "Skaičiuojama",
          "Skaičiuojama: 1 225,33 m² × 2,5 (sienų/grindų koeficientas)", "BD", 18,
          "Orientacinis kiekis. Patikslinti pagal išklotines."),
    _work("apdaila", "Sienos ir lubos", "A-03",
          "Lubų paviršių glaistymas", "m²", 1225.33, "Skaičiuojama",
          "Skaičiuojama: 1 225,33 m² (bendrasis pastato plotas)", "BD", 18,
          "Orientacinis kiekis. Patikslinti pagal išklotines."),
    _work("apdaila", "Sienos ir lubos", "A-04",
          "Lubų dažymas (2 sluoksniai)", "m²", 1225.33, "Skaičiuojama",
          "Skaičiuojama: 1 225,33 m² (bendrasis pastato plotas)", "BD", 18,
          "Orientacinis kiekis. Patikslinti pagal išklotines."),
    _work("apdaila", "Sienos ir lubos", "A-05",
          "Paviršių gruntavimas prieš dažymą", "m²", 4288.66, "Skaičiuojama",
          "Skaičiuojama: 3 063,33 m² sienų + 1 225,33 m² lubų", "BD", 18,
          "Orientacinis kiekis. Patikslinti pagal išklotines."),
    _work("apdaila", "Grindys", "A-06",
          "Grindų išlyginimo sluoksnis", "m²", 1225.33, "Skaičiuojama",
          "Skaičiuojama: 1 225,33 m² (bendrasis pastato plotas)", "BD", 18,
          "Orientacinis kiekis. Patikslinti pagal išklotines."),
    _work("apdaila", "Sanitarinės patalpos", "A-07",
          "Keraminių plytelių klojimas sanitarinių patalpų grindyse", "m²", 120, "Skaičiuojama",
          "Skaičiuojama: 20 butų × 6 m² (vidutinė vonios patalpa)", "SA", 7,
          "Orientacinis kiekis. Patikslinti pagal išklotines."),
    _work("apdaila", "Sanitarinės patalpos", "A-08",
          "Keraminių plytelių klojimas sanitarinių patalpų sienose", "m²", 360, "Skaičiuojama",
          "Skaičiuojama: 20 butų × 18 m² (sienų plotas vonioje)", "SA", 7,
          "Orientacinis kiekis. Patikslinti pagal išklotines."),
    _work("apdaila", "Sanitarinės patalpos", "A-09",
          "Hidroizoliacijos įrengimas sanitarinėse patalpose", "m²", 160, "Skaičiuojama",
          "Skaičiuojama: 20 butų × 8 m² (grindys + 300 mm užvedimas ant sienų)", "SA", 42,
          "Orientacinis kiekis. Patikslinti pagal išklotines."),
    _work("apdaila", "Grindys", "A-10",
          "Vinilo grindų danga gyvenamosiose patalpose", "m²", 1105.33, "Skaičiuojama",
          "Skaičiuojama: 1 225,33 m² − 120 m² sanitarinių patalpų", "BD", 18,
          "Orientacinis kiekis. Patikslinti pagal išklotines."),
    _work("apdaila", "Lubos", "A-11",
          "Gipso kartono pakabinamos lubos drėgnose patalpose ir koridoriuose", "m²", 160, "Skaičiuojama",
          "Skaičiuojama: 20 butų × 8 m² (vonia + koridorius)", "SA", 38,
          "Orientacinis kiekis. Patikslinti pagal išklotines."),
    _work("apdaila", "Virtuvės", "A-12",
          "Virtuvės sienų plytelių klojimas (backsplash)", "m²", 60, "Skaičiuojama",
          "Skaičiuojama: 20 butų × 3 m²", "SA", 7,
          "Orientacinis kiekis. Patikslinti pagal išklotines."),
    _work("apdaila", "Durys", "A-13",
          "Vidaus durų montavimas", "vnt.", 60, "Skaičiuojama",
          "Skaičiuojama: 20 butų × 3 durys", "SA", 23,
          "Orientacinis kiekis. Patikslinti pagal durų specifikaciją."),
    _work("apdaila", "Durys", "A-14",
          "Buto įėjimo durų montavimas", "vnt.", 20, "Skaičiuojama",
          "Skaičiuojama: 20 butų × 1 įėjimo durys", "SA", 23,
          "Orientacinis kiekis. Patikslinti pagal durų specifikaciją."),
    _work("apdaila", "Balkonai ir terasos", "A-15",
          "Balkonų ir terasų grindų danga", "m²", 80, "Skaičiuojama",
          "Skaičiuojama: 20 butų × 4 m²", "BD", 7,
          "Orientacinis kiekis. Patikslinti pagal balkonų planus."),
    _work("apdaila", "Bendrosios patalpos", "A-16",
          "Bendrųjų patalpų apdaila (laiptinės, koridoriai)", "m²", 184, "Skaičiuojama",
          "Skaičiuojama: 1 225,33 m² × 15 % bendrosioms patalpoms", "BD", 18,
          "Orientacinis kiekis. Patikslinti pagal architektūros planus."),

    # ---------- SANTECHNIKA ----------
    _work("santechnika", "Lauko vandentiekis (V1)", "S-01",
          "PE100 d110 mm vamzdžio klojimas", "m", 233.50, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 29, eil. 1", "LVN", 29),
    _work("santechnika", "Lauko vandentiekis (V1)", "S-02",
          "PE100 d63 mm vamzdžio klojimas", "m", 121.50, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 29, eil. 2", "LVN", 29),
    _work("santechnika", "Lauko vandentiekis (V1)", "S-03",
          "Vandentiekio tinklų plovimas, dezinfekcija ir bandymas", "m", 355, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 29, eil. 3", "LVN", 29),
    _work("santechnika", "Lauko vandentiekis (V1)", "S-04",
          "G/B šulinys d1500 mm, H~2,00 m", "kompl.", 1, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 29, eil. 4 (V1-1)", "LVN", 29),
    _work("santechnika", "Lauko vandentiekis (V1)", "S-05",
          "Šulinio V1-1 komplektas (sklendės, keturšakis, adapteriai)", "kompl.", 1, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 29, eil. 5", "LVN", 29),
    _work("santechnika", "Lauko vandentiekis (V1)", "S-06",
          "Esamo šulinio Nr. 41 komplektas", "kompl.", 1, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 29, eil. 6", "LVN", 29),
    _work("santechnika", "Lauko vandentiekis (V1)", "S-07",
          "Balnas d110×2\" su sriegine jungtimi", "kompl.", 4, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 29, eil. 7", "LVN", 29),
    _work("santechnika", "Lauko vandentiekis (V1)", "S-08",
          "Įvadinė požeminė sklendė d63 mm su prailginimo velenu", "kompl.", 4, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 29, eil. 8", "LVN", 29),
    _work("santechnika", "Lauko vandentiekis (V1)", "S-09",
          "Išpildomoji geodezinė nuotrauka (vandentiekis)", "kompl.", 1, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 29, eil. 9", "LVN", 29),
    _work("santechnika", "Buitinės nuotekos (F1)", "S-10",
          "PVC beslėgis nuotekų vamzdis d200 mm", "m", 197, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 30, eil. 1", "LVN", 30),
    _work("santechnika", "Buitinės nuotekos (F1)", "S-11",
          "PE100-RC d200 mm klojimas uždaru būdu", "m", 6, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 30, eil. 2", "LVN", 30),
    _work("santechnika", "Buitinės nuotekos (F1)", "S-12",
          "Prisijungimas prie esamo lietaus nuotekų šulinio Nr. 248", "kompl.", 1, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 30, eil. 3", "LVN", 30),
    _work("santechnika", "Buitinės nuotekos (F1)", "S-13",
          "PVC beslėgis nuotekų vamzdis d160 mm", "m", 37.20, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 30, eil. 4", "LVN", 30),
    _work("santechnika", "Buitinės nuotekos (F1)", "S-14",
          "G/B šulinys d1000 mm, H 1,20–2,20 m", "kompl.", 5, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 30, eil. 5 (F1-1–F1-5)", "LVN", 30),
    _work("santechnika", "Buitinės nuotekos (F1)", "S-15",
          "Esamo šulinio Nr. 161 remontas", "kompl.", 1, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 30, eil. 6", "LVN", 30),
    _work("santechnika", "Buitinės nuotekos (F1)", "S-16",
          "Buitinių nuotekų tinklų TV diagnostika", "kompl.", 1, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 30, eil. 7", "LVN", 30),
    _work("santechnika", "Buitinės nuotekos (F1)", "S-17",
          "Išpildomoji geodezinė nuotrauka (buitinės nuotekos)", "kompl.", 1, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 30, eil. 8", "LVN", 30),
    _work("santechnika", "Lietaus nuotekos (L1)", "S-18",
          "PVC beslėgis nuotekų vamzdis d200 mm (lietaus)", "m", 445.60, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 30, eil. 1", "LVN", 30),
    _work("santechnika", "Lietaus nuotekos (L1)", "S-19",
          "PE100-RC d200 mm klojimas uždaru būdu (lietaus)", "m", 17, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 30, eil. 2", "LVN", 30),
    _work("santechnika", "Lietaus nuotekos (L1)", "S-20",
          "Prisijungimas prie esamų lietaus šulinių KL-01 ir KL-02", "kompl.", 1, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 30, eil. 3", "LVN", 30),
    _work("santechnika", "Lietaus nuotekos (L1)", "S-21",
          "G/B šulinys d1000 mm, H 1,50–2,00 m (lietaus)", "kompl.", 14, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 30, eil. 4 (T1-1, L1-2–L1-14)", "LVN", 30),
    _work("santechnika", "Lietaus nuotekos (L1)", "S-22",
          "G/B šulinys d700 mm su lietaus surinkimo grotelėmis", "vnt.", 11, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 31, eil. 5 (T1-1–T1-11)", "LVN", 31),
    _work("santechnika", "Lietaus nuotekos (L1)", "S-23",
          "Lietaus nuotekų tinklų TV diagnostika", "kompl.", 1, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 31, eil. 6", "LVN", 31),
    _work("santechnika", "Lietaus nuotekos (L1)", "S-24",
          "Išpildomoji geodezinė nuotrauka (lietaus nuotekos)", "kompl.", 1, "Sąmata",
          "LVN sąnaudų žiniaraštis, l. 31, eil. 7", "LVN", 31),
    _work("santechnika", "Vidaus vandentiekis ir nuotekos", "S-25",
          "Vandens apskaitos mazgai (VAM)", "kompl.", 4, "Projektas",
          "VN brėžiniai, l. 5 (VAM1–VAM4); LVN l. 31", "VN", 5),
    _work("santechnika", "Vidaus vandentiekis ir nuotekos", "S-26",
          "Butų vandens apskaitos mazgai (2 skaitikliai d15)", "kompl.", 20, "Skaičiuojama",
          "Skaičiuojama: 20 butų × 1 kompl. (VN l. 5, 20 butų)", "VN", 5,
          "Komplekte: karšto ir šalto vandens skaitikliai d15, ventiliai, filtras, nuorintojas."),
    _work("santechnika", "Vidaus vandentiekis ir nuotekos", "S-27",
          "Vandentiekio stovai Ø50 PPR (šaltas, karštas, cirkuliacija)", "vnt.", 3, "Projektas",
          "VN brėžiniai, l. 1 (ST-V1-1, ST-T3-1, ST-T4-1)", "VN", 1),
    _work("santechnika", "Vidaus vandentiekis ir nuotekos", "S-28",
          "Buitinių nuotekų stovai Ø110", "vnt.", 5, "Projektas",
          "VN brėžiniai, l. 6 (ST-F1–ST-F5)", "VN", 6),
    _work("santechnika", "Vidaus vandentiekis ir nuotekos", "S-29",
          "Buitinių nuotekų stovai Ø75", "vnt.", 2, "Projektas",
          "VN brėžiniai, l. 6 (ST-F6, ST-F7)", "VN", 6),
    _work("santechnika", "Vidaus vandentiekis ir nuotekos", "S-30",
          "Lietaus nuotekų stovai Ø110", "vnt.", 4, "Projektas",
          "VN brėžiniai, l. 6 (ST-L1–ST-L4)", "VN", 6),
    _work("santechnika", "Vidaus vandentiekis ir nuotekos", "S-31",
          "Ugnį sulaikančios movos d110/d75", "vnt.", 44, "Skaičiuojama",
          "Skaičiuojama: 11 stovų × 4 perdangos = 44 vnt. (VN l. 6)", "VN", 6,
          "5 buitiniai Ø110 + 2 buitiniai Ø75 + 4 lietaus Ø110 stovai."),
    _work("santechnika", "Vidaus vandentiekis ir nuotekos", "S-32",
          "Buto vandentiekio ir nuotekų atšakų įrengimas", "kompl.", 20, "Skaičiuojama",
          "Skaičiuojama: 20 butų × 1 kompl. (VN l. 1, tipinis buto mazgas)", "VN", 1,
          "Šalto, karšto, cirkuliacijos vandentiekio ir buitinių nuotekų atšakos bute."),
    _work("santechnika", "Vidaus vandentiekis ir nuotekos", "S-33",
          "Grindų trapai d50", "vnt.", 20, "Skaičiuojama",
          "Skaičiuojama: 20 butų × 1 vnt. (VN l. 1, 18 pastaba)", "VN", 1),
    _work("santechnika", "Vidaus vandentiekis ir nuotekos", "S-34",
          "Techninis trapas d110", "vnt.", 1, "Projektas",
          "VN brėžiniai, l. 1 (18 pastaba)", "VN", 1),
    _work("santechnika", "Vidaus vandentiekis ir nuotekos", "S-35",
          "Automatinis atbulinis vožtuvas nuotekų išvadui", "kompl.", 1, "Projektas",
          "VN brėžiniai, l. 1 (19 pastaba)", "VN", 1),
    _work("santechnika", "Vidaus vandentiekis ir nuotekos", "S-36",
          "Vandentiekio ir nuotekų tinklų bandymai", "kompl.", 1, "Skaičiuojama",
          "Skaičiuojama: 1 kompl. visam pastatui (LVN l. 29; VN l. 1)", "VN", 1),
    _work("santechnika", "Sanitariniai prietaisai", "S-37",
          "Praustuvai", "vnt.", 20, "Skaičiuojama",
          "Skaičiuojama: 20 butų × 1 praustuvas (3-SA l. 7; VN l. 1)", "SA", 7),
    _work("santechnika", "Sanitariniai prietaisai", "S-38",
          "Unitazai", "vnt.", 20, "Skaičiuojama",
          "Skaičiuojama: 20 butų × 1 unitazas (3-SA l. 7; VN l. 1)", "SA", 7),
    _work("santechnika", "Sanitariniai prietaisai", "S-39",
          "Dušo komplektai", "vnt.", 20, "Skaičiuojama",
          "Skaičiuojama: 20 butų × 1 dušo komplektas (3-SA l. 7; VN l. 1)", "SA", 7),
    _work("santechnika", "Sanitariniai prietaisai", "S-40",
          "Virtuvės kriauklės", "vnt.", 20, "Skaičiuojama",
          "Skaičiuojama: 20 butų × 1 kriauklė (3-SA l. 7; VN l. 1)", "SA", 7),

    # ---------- FASADAS ----------
    _work("fasadas", "Paruošimas ir pastoliai", "F-01",
          "Pastolių įrengimas, nuoma ir demontavimas", "m²", 1037.8, "Skaičiuojama",
          "Skaičiuojama: (24,94 + 15,44) × 2 × 12,85 m = 1037,8 m² (3-SA l. 55–56 planai, l. 65–68 fasadai)", "TP", 65,
          "Pastato matmenys 24 940 × 15 440 mm patvirtinti DWG „Silale - SA - brez - 2026-04-14“."),
    _work("fasadas", "Paruošimas ir pastoliai", "F-02",
          "Fasado paviršiaus plovimas ir gruntavimas", "m²", 644.7, "Skaičiuojama",
          "Skaičiuojama: 1037,8 m² fasado − 393,1 m² 96 langų angų = 644,7 m² (3-SA l. 69)", "TP", 69,
          "Langų plotas pagal 2023 m. TP specifikaciją (96 vnt.). PP stadijos 1-BD l. 114 (79 vnt.) nebenaudojama."),
    _work("fasadas", "Fasado šiltinimas ir apdaila", "F-03",
          "EPS 70 Neo šilumos izoliacijos plokščių klijavimas ir mechaninis tvirtinimas", "m²", 644.7, "Projektas",
          "1-BD l. 108 sienos detalė: klinkeris 10 + klijai 10 + EPS 70 Neo + klijai 10 + keraminis mūras 250; 644,7 m²", "BD", 108,
          "Plotas sutampa su F-02; plokščių storį tikslinti pagal energinio naudingumo skaičiavimą."),
    _work("fasadas", "Fasado šiltinimas ir apdaila", "F-04",
          "Armuotojo tinklelio įgilinimas ir išlyginamasis sluoksnis", "m²", 644.7, "Projektas",
          "1-BD l. 108 sienos detalė: armuoti tinkleliu klinkerio klijai 10 mm; plotas 644,7 m²", "BD", 108),
    _work("fasadas", "Fasado šiltinimas ir apdaila", "F-05",
          "Klijuoto klinkerio plytelių (smėlinės spalvos) fasado apdaila", "m²", 604.3, "Projektas",
          "1-BD l. 108–113, fasadai F-01–F-04: klijuoto klinkerio apdaila, smėlinė spalva", "BD", 110,
          "604,3 m² = 644,7 m² šiltinamo fasado − 40,4 m² cokolio."),
    _work("fasadas", "Fasado šiltinimas ir apdaila", "F-06",
          "Cokolio apdaila su apsauginiu profiliuočiu", "m²", 40.4, "Skaičiuojama",
          "Skaičiuojama: perimetras 80,76 m × 0,5 m cokolio aukštis = 40,4 m² (3-SA l. 55–56; 1-BD l. 108)", "TP", 56),
    _work("fasadas", "Langai ir lauko durys", "F-07",
          "Lauko durų D-01 montavimas (1000 × 2100)", "vnt.", 1, "Sąmata",
          "3-SA l. 70, durų specifikacija, D-01 (lauko durys): 1 vnt.", "TP", 70),
]

# 2023 m. TP (3-SA l. 69) langų specifikacija: 24 tipai, 96 langai, 187,49 m pločio, 393,054 m².
_FASADAS_WINDOWS = [
    ("L-01", 750, 1200, 1), ("L-02", 1010, 2100, 1), ("L-02*", 1010, 2100, 13),
    ("L-03", 1010, 2100, 1), ("L-03*", 1010, 2100, 5), ("L-04", 1010, 2100, 2),
    ("L-05", 1010, 2100, 6), ("L-06", 2010, 2100, 1), ("L-06*", 2010, 2100, 9),
    ("L-07*", 2010, 2100, 6), ("L-08", 2010, 2100, 4), ("L-09", 2010, 2100, 4),
    ("L-10*", 3010, 2100, 2), ("L-11", 3010, 2100, 4), ("L-12a", 2030, 2100, 2),
    ("L-12a*", 2030, 2100, 6), ("L-12b", 2030, 2100, 8), ("L-13a", 2030, 2100, 8),
    ("L-13b", 2030, 2100, 2), ("L-13b*", 2030, 2100, 6), ("L-14", 7440, 2100, 1),
    ("L-15", 4940, 2100, 1), ("L-16", 4940, 2100, 1), ("L-16*", 4940, 2100, 2),
]

DEFAULT_WORKS += [
    _work("fasadas", "Langai ir lauko durys", f"F-{i:02d}",
          f"Langų {wt} montavimas ({w} × {h})", "vnt.", qty, "Sąmata",
          f"3-SA l. 69, langų specifikacija, {wt}: {qty} vnt.", "TP", 69,
          "Angų matmenys pagal 2023 m. TP; prieš užsakant patikslinti vietoje (3-SA l. 69, pastaba 2).")
    for i, (wt, w, h, qty) in enumerate(_FASADAS_WINDOWS, start=8)
]

DEFAULT_WORKS += [
    _work("fasadas", "Palangės, parapetai ir balkonai", "F-32",
          "Išorinių palangių (cinkuotos skardos) montavimas", "m", 187.5, "Skaičiuojama",
          "Skaičiuojama: visų 96 langų pločių suma 187,49 m (3-SA l. 69)", "TP", 69),
    _work("fasadas", "Palangės, parapetai ir balkonai", "F-33",
          "Parapetų apskardinimas", "m", 80.8, "Skaičiuojama",
          "Skaičiuojama: pastato perimetras (24,94 + 15,44) × 2 = 80,76 m (3-SA l. 55–56; DWG 2026)", "TP", 56),
    _work("fasadas", "Palangės, parapetai ir balkonai", "F-34",
          "Balkonų plokščių šiltinimas iš apačios", "m²", 79.6, "Skaičiuojama",
          "Skaičiuojama: 21 plokštė × 1,66 m: 3×3,01 + 12×2,24 + 6×2,005 = 47,94 m × 1,66 = 79,58 m² (6-SK l. 5; IFC 21 montavimo mazgas)", "SK", 5,
          "Balkonų plokštės apšiltinamos polistireniniu putplasčiu (1-BD l. 12)."),
    _work("fasadas", "Palangės, parapetai ir balkonai", "F-35",
          "Balkonų turėklų montavimas", "m", 47.9, "Skaičiuojama",
          "Skaičiuojama: 21 balkono plokštės priekinė briauna 3×3,01 + 12×2,24 + 6×2,005 = 47,94 m (6-SK l. 5)", "SK", 5,
          "Terasų turėklus ir tvirtinimo detales tikslinti pagal fasadų brėžinius F-01–F-04."),
    _work("fasadas", "Palangės, parapetai ir balkonai", "F-36",
          "Langų ir lauko durų angų siūlių hermetizavimas", "m", 782.6, "Skaičiuojama",
          "Skaičiuojama: 2×187,49 (pločiai) + 95×2×2,1 + 1×2×1,2 (L-01) + 6,2 (D-01) = 782,58 m (3-SA l. 69–70)", "TP", 69),
]

WORK_SOURCE_KEYS = {
    "25-E": ("25-E-5269-TDP-E", ".pdf"),
    "LVN": ("LVN Vytauto", ".pdf"),
    "VN": ("VN brėžiniai", ".pdf"),
    "BD": ("1-BD", ".pdf"),
    "SA": ("3-SA", ".pdf"),
    "SK": ("26-659-DP-SK", ".pdf"),
    "TP": ("3-SA", ".pdf"),
}

SUPPORTED_TEXT = {".pdf", ".txt", ".ifc", ".adoc", ".dwg", ".docx", ".xlsx", ".doc"}
# Skenuoti dokumentai ir paveikslėliai: tekstas išgaunamas OCR (Windows OCR, veikia be interneto)
OCR_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
INDEX_EXTS = SUPPORTED_TEXT | OCR_EXTS
OCR_MAX_PAGES = 60
WINOCR_SCRIPT = BASE_DIR / "winocr.ps1"
WINDOC_SCRIPT = BASE_DIR / "windoc.ps1"
SKIP_FILES = {"desktop.ini", "thumbs.db", "thumbs.db:encryptable"}
SKIP_DIRS = {"__pycache__", "$recycle.bin", "system volume information", ".git"}

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS docs(
    id INTEGER PRIMARY KEY,
    root TEXT NOT NULL,
    rel TEXT NOT NULL,
    path TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    ext TEXT NOT NULL,
    disc TEXT NOT NULL,
    disc_lock INTEGER NOT NULL DEFAULT 0,
    size INTEGER NOT NULL DEFAULT 0,
    mtime REAL NOT NULL DEFAULT 0,
    pages INTEGER,
    text_state TEXT NOT NULL DEFAULT 'pending',
    text_len INTEGER NOT NULL DEFAULT 0,
    meta TEXT NOT NULL DEFAULT '{}',
    added REAL NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_docs_disc ON docs(disc);
CREATE INDEX IF NOT EXISTS idx_docs_name ON docs(name);
CREATE TABLE IF NOT EXISTS pages(doc_id INTEGER NOT NULL, page INTEGER NOT NULL, text TEXT NOT NULL, PRIMARY KEY(doc_id, page));
CREATE VIRTUAL TABLE IF NOT EXISTS pages_fts USING fts5(text, doc_id UNINDEXED, page UNINDEXED, tokenize='unicode61 remove_diacritics 2');
CREATE VIRTUAL TABLE IF NOT EXISTS doc_name_fts USING fts5(name, doc_id UNINDEXED, tokenize='unicode61 remove_diacritics 2');
CREATE TABLE IF NOT EXISTS tasks(
    id INTEGER PRIMARY KEY, title TEXT NOT NULL, desc TEXT DEFAULT '', status TEXT DEFAULT 'todo',
    priority TEXT DEFAULT 'Normali', due TEXT DEFAULT '', assignee TEXT DEFAULT '',
    created TEXT DEFAULT '', done_at TEXT DEFAULT '', sort REAL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS issues(
    id INTEGER PRIMARY KEY, num INTEGER NOT NULL, kind TEXT DEFAULT 'Pastaba', title TEXT NOT NULL,
    desc TEXT DEFAULT '', disc TEXT DEFAULT '', status TEXT DEFAULT 'Atvira', priority TEXT DEFAULT 'Normali',
    due TEXT DEFAULT '', assignee TEXT DEFAULT '', created TEXT DEFAULT '', closed_at TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS notes(
    id INTEGER PRIMARY KEY, date TEXT DEFAULT '', title TEXT NOT NULL, attendees TEXT DEFAULT '',
    body TEXT DEFAULT '', created TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS checklist(
    id INTEGER PRIMARY KEY, stage TEXT NOT NULL, title TEXT NOT NULL, done INTEGER DEFAULT 0,
    due TEXT DEFAULT '', note TEXT DEFAULT '', ord REAL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS disc_status(
    disc TEXT PRIMARY KEY, status TEXT NOT NULL DEFAULT 'Nepažymėta', owner TEXT DEFAULT '',
    note TEXT DEFAULT '', updated TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS works(
    id INTEGER PRIMARY KEY, section TEXT NOT NULL, stage TEXT DEFAULT '',
    code TEXT DEFAULT '', title TEXT NOT NULL, unit TEXT DEFAULT '',
    qty REAL DEFAULT 0, done REAL DEFAULT 0, price REAL DEFAULT 0,
    kind TEXT DEFAULT 'Sąmata', basis TEXT DEFAULT '',
    source_doc INTEGER DEFAULT 0, source_page INTEGER DEFAULT 0, source_name TEXT DEFAULT '',
    note TEXT DEFAULT '', ord REAL DEFAULT 0, created TEXT DEFAULT '', updated TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_works_section ON works(section);
CREATE TABLE IF NOT EXISTS decisions(
    key TEXT PRIMARY KEY, type TEXT DEFAULT '', section TEXT DEFAULT '',
    title TEXT DEFAULT '', method TEXT DEFAULT 'PV sprendimas',
    status TEXT DEFAULT 'Priimta', basis TEXT DEFAULT '', note TEXT DEFAULT '',
    owner TEXT DEFAULT 'Projekto vadovas', codes TEXT DEFAULT '[]',
    snapshot TEXT DEFAULT '{}', created TEXT DEFAULT '', updated TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS contracts(
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL DEFAULT '', customer TEXT DEFAULT '', contractor TEXT DEFAULT '',
    number TEXT DEFAULT '', signed TEXT DEFAULT '', address TEXT DEFAULT '',
    vat REAL DEFAULT 21, retention REAL DEFAULT 5, advance REAL DEFAULT 0,
    terms INTEGER DEFAULT 30, buyer_code TEXT DEFAULT '', buyer_vat TEXT DEFAULT '',
    buyer_address TEXT DEFAULT '',
    rep_contractor TEXT DEFAULT '', rep_technical TEXT DEFAULT '', rep_customer TEXT DEFAULT '',
    note TEXT DEFAULT '', created TEXT DEFAULT '', updated TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS act_groups(
    id INTEGER PRIMARY KEY, contract_id INTEGER NOT NULL, name TEXT NOT NULL,
    unit TEXT DEFAULT 'Kompl.', qty REAL DEFAULT 1, price REAL DEFAULT 0,
    ord REAL DEFAULT 0, active INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_act_groups_contract ON act_groups(contract_id);
CREATE TABLE IF NOT EXISTS acts(
    id INTEGER PRIMARY KEY, contract_id INTEGER NOT NULL, num INTEGER NOT NULL DEFAULT 1,
    date TEXT DEFAULT '', period_from TEXT DEFAULT '', period_to TEXT DEFAULT '',
    status TEXT DEFAULT 'Juodraštis', received REAL DEFAULT 0, debt REAL DEFAULT 0,
    invoice_no TEXT DEFAULT '', invoice_date TEXT DEFAULT '', due_date TEXT DEFAULT '',
    invoice_note TEXT DEFAULT '',
    rep_contractor TEXT DEFAULT '', rep_technical TEXT DEFAULT '', rep_customer TEXT DEFAULT '',
    note TEXT DEFAULT '', created TEXT DEFAULT '', updated TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_acts_contract ON acts(contract_id);
CREATE TABLE IF NOT EXISTS act_items(
    id INTEGER PRIMARY KEY, act_id INTEGER NOT NULL, group_id INTEGER NOT NULL,
    amount REAL DEFAULT 0, UNIQUE(act_id, group_id)
);
CREATE INDEX IF NOT EXISTS idx_act_items_act ON act_items(act_id);
CREATE TABLE IF NOT EXISTS act_payments(
    id INTEGER PRIMARY KEY, act_id INTEGER NOT NULL, date TEXT DEFAULT '',
    amount REAL DEFAULT 0, note TEXT DEFAULT '', created TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_act_payments_act ON act_payments(act_id);
CREATE TABLE IF NOT EXISTS act_files(
    id INTEGER PRIMARY KEY AUTOINCREMENT, act_id INTEGER NOT NULL,
    name TEXT NOT NULL DEFAULT '', file TEXT NOT NULL DEFAULT '',
    ext TEXT DEFAULT '', size INTEGER DEFAULT 0, created TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_act_files_act ON act_files(act_id);
CREATE TABLE IF NOT EXISTS photos(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL DEFAULT '',
    name TEXT NOT NULL,
    file TEXT NOT NULL,
    size INTEGER NOT NULL DEFAULT 0,
    caption TEXT NOT NULL DEFAULT '',
    created TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_photos_date ON photos(date);
"""

SCAN_STATE = {"scanning": False, "last_scan": "", "files_seen": 0}
INDEX_STATE = {"indexing": False, "current": "", "done": 0, "total": 0, "last_result": ""}
scan_event = threading.Event()
index_event = threading.Event()
lock = threading.Lock()


@contextmanager
def db():
    conn = sqlite3.connect(str(DB_PATH), timeout=20)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        yield conn
    finally:
        conn.close()


def now_iso():
    return datetime.now().isoformat(timespec="seconds")


def today_iso():
    return date.today().isoformat()


def disc_name(code):
    return DISCIPLINES.get(code, code)


def iso_from_ts(ts):
    try:
        return datetime.fromtimestamp(float(ts)).isoformat(timespec="seconds")
    except Exception:
        return ""


def parse_pdf_date(value):
    if not value:
        return ""
    m = re.match(r"D:(\d{4})(\d{2})(\d{2})", str(value).strip())
    if m:
        return f"{m.group(1)}-{m.group(2)}-{m.group(3)}"
    return ""


def default_roots():
    desktop = Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Desktop"
    if not desktop.exists():
        desktop = Path.home() / "Desktop"
    roots = []
    for code in DISC_ORDER:
        p = desktop / code
        if p.exists():
            roots.append(str(p))
    return roots


def new_lan_code():
    return "%06d" % secrets.randbelow(1000000)


def lan_code():
    code = get_setting("lan_code")
    if not code:
        code = new_lan_code()
        set_setting("lan_code", code)
    return str(code)


def lan_addresses():
    ips = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ips.add(s.getsockname()[0])
        finally:
            s.close()
    except OSError:
        pass
    clean = [ip for ip in ips if not ip.startswith("127.") and not ip.startswith("169.254.")]
    clean.sort(key=lambda ip: (not ipaddress.ip_address(ip).is_private, ip))
    return clean


def network_info(port):
    local = f"http://127.0.0.1:{port}/"
    urls = [f"http://{ip}:{port}/" for ip in lan_addresses()] if LAN_ENABLED else []
    return {
        "enabled": LAN_ENABLED,
        "local": local,
        "lan": urls,
        "code": lan_code(),
        "port": port,
    }


LOGIN_HTML = """<!doctype html>
<html lang="lt"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#5b63d3">
<title>Projekto Štabas – prisijungimas</title>
<style>
:root{--bg:#f6f7f9;--panel:#fff;--ink:#14151a;--muted:#61666f;--faint:#969aa5;--line:#e7e8ec;--accent:#5b63d3;--accent-2:#4a52c4;--soft:#eef0fd;--ring:rgba(91,99,211,.22);--err-bg:#fdeceb;--err-ink:#bf3b32;color-scheme:light}
@media (prefers-color-scheme:dark){:root{--bg:#0b0c0f;--panel:#141518;--ink:#e7e8ee;--muted:#9ba0ad;--faint:#6b7080;--line:#24262c;--accent:#7c85f4;--accent-2:#99a1fa;--soft:#1d2040;--ring:rgba(124,133,244,.28);--err-bg:#331917;--err-ink:#f0796f;color-scheme:dark}}
*{box-sizing:border-box}
body{margin:0;min-height:100vh;display:grid;place-items:center;background:radial-gradient(120% 120% at 50% -20%,var(--soft),transparent 62%),var(--bg);font-family:"Segoe UI Variable Text","Segoe UI",system-ui,-apple-system,sans-serif;color:var(--ink);padding:20px;-webkit-font-smoothing:antialiased}
.card{width:100%;max-width:380px;background:var(--panel);border:1px solid var(--line);border-radius:18px;padding:28px 24px;box-shadow:0 28px 60px -28px rgba(16,18,28,.35),0 2px 8px rgba(16,18,28,.05)}
.mark{width:44px;height:44px;border-radius:12px;background:linear-gradient(145deg,#5b63d3 0%,#7c85f4 55%,#8f8cf0 100%);color:#fff;display:grid;place-items:center;font-size:20px;font-weight:650;margin-bottom:14px;box-shadow:0 6px 16px -6px rgba(91,99,211,.65),inset 0 1px 0 rgba(255,255,255,.25)}
h1{margin:0 0 6px;font-size:19px;letter-spacing:-.2px}
p{margin:0 0 16px;font-size:13px;line-height:1.5;color:var(--muted)}
label{display:block;font-size:11px;font-weight:650;letter-spacing:.04em;text-transform:uppercase;margin-bottom:6px;color:var(--muted)}
input{width:100%;padding:12px 14px;border:1px solid var(--line);border-radius:10px;background:var(--panel);color:var(--ink);font-size:18px;letter-spacing:6px;text-align:center;outline:none;transition:border-color .15s,box-shadow .15s}
input:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--ring)}
button{width:100%;margin-top:12px;padding:12px;border:1px solid var(--accent);border-radius:10px;background:var(--accent);color:#fff;font-size:14px;font-weight:600;cursor:pointer;transition:background .15s,border-color .15s}
button:hover{background:var(--accent-2);border-color:var(--accent-2)}
.err{margin:0 0 14px;padding:9px 12px;border-radius:9px;background:var(--err-bg);color:var(--err-ink);font-size:12.5px}
small{display:block;margin-top:14px;color:var(--faint);font-size:11.5px;line-height:1.45}
</style></head>
<body><main class="card">
<div class="mark" aria-hidden="true">Š</div>
<h1>Projekto Štabas</h1>
<p>Įveskite prieigos kodą. Jį rasite programos skiltyje „Nustatymai“ → „Prieiga iš kitų įrenginių“.</p>
{error}
<form method="post" action="/auth">
<label for="k">Prieigos kodas</label>
<input id="k" name="k" inputmode="numeric" autocomplete="one-time-code" maxlength="6" pattern="[0-9]*" required autofocus placeholder="000000">
<button type="submit">Prisijungti</button>
</form>
<small>Veikia vietiniame tinkle, be interneto. Dokumentai niekur nesiunčiami.</small>
</main></body></html>"""


def login_page(error=False):
    msg = '<div class="err">Neteisingas kodas arba per daug bandymų. Palaukite kelias minutes ir bandykite dar kartą.</div>' if error else ""
    return LOGIN_HTML.replace("{error}", msg)


def migrate_db(path):
    """Sukuria trūkstamas lenteles ir stulpelius bet kurio projekto duomenų bazėje."""
    conn = sqlite3.connect(str(path), timeout=20)
    try:
        conn.row_factory = sqlite3.Row
        conn.executescript(SCHEMA)
        doc_cols = {r["name"] for r in conn.execute("PRAGMA table_info(docs)").fetchall()}
        if "disc_lock" not in doc_cols:
            conn.execute("ALTER TABLE docs ADD COLUMN disc_lock INTEGER NOT NULL DEFAULT 0")
        act_cols = {r["name"] for r in conn.execute("PRAGMA table_info(acts)").fetchall()}
        for col in ("rep_contractor", "rep_technical", "rep_customer",
                    "invoice_no", "invoice_date", "due_date", "invoice_note"):
            if col not in act_cols:
                conn.execute(f"ALTER TABLE acts ADD COLUMN {col} TEXT DEFAULT ''")
        contract_cols = {r["name"] for r in conn.execute("PRAGMA table_info(contracts)").fetchall()}
        for col, ddl in (("terms", "INTEGER DEFAULT 30"), ("buyer_code", "TEXT DEFAULT ''"),
                         ("buyer_vat", "TEXT DEFAULT ''"), ("buyer_address", "TEXT DEFAULT ''")):
            if col not in contract_cols:
                conn.execute(f"ALTER TABLE contracts ADD COLUMN {col} {ddl}")
        conn.commit()
    finally:
        conn.close()


def init_db(seed_content=True):
    migrate_db(DB_PATH)
    with db() as conn:
        if "company" not in global_read():
            global_write(company=dict(DEFAULT_COMPANY))
        cur = conn.execute("SELECT v FROM settings WHERE k='project'").fetchone()
        if not cur:
            conn.execute("INSERT INTO settings(k,v) VALUES('project',?)", (json.dumps(DEFAULT_PROJECT, ensure_ascii=False),))
        cur = conn.execute("SELECT v FROM settings WHERE k='roots'").fetchone()
        if not cur:
            conn.execute("INSERT INTO settings(k,v) VALUES('roots',?)", (json.dumps(default_roots(), ensure_ascii=False),))
        cur = conn.execute("SELECT v FROM settings WHERE k='theme'").fetchone()
        if not cur:
            conn.execute("INSERT OR IGNORE INTO settings(k,v) VALUES('theme','light')")
        cur = conn.execute("SELECT v FROM settings WHERE k='lan_code'").fetchone()
        if not cur:
            conn.execute("INSERT OR IGNORE INTO settings(k,v) VALUES('lan_code',?)", (json.dumps(new_lan_code()),))
        for code in DISC_ORDER:
            conn.execute("INSERT OR IGNORE INTO disc_status(disc) VALUES(?)", (code,))
        cnt = conn.execute("SELECT COUNT(*) c FROM checklist").fetchone()["c"]
        if not cnt:
            for i, (stage, title) in enumerate(DEFAULT_CHECKLIST):
                conn.execute(
                    "INSERT INTO checklist(stage,title,ord) VALUES(?,?,?)",
                    (stage, title, i + 1),
                )
        for key in (WORK_SECTIONS if seed_content else []):
            cnt = conn.execute("SELECT COUNT(*) c FROM works WHERE section=?", (key,)).fetchone()["c"]
            if key == "fasadas":
                ver = conn.execute("SELECT v FROM settings WHERE k='works_seed_fasadas'").fetchone()
                try:
                    ver = int(json.loads(ver["v"])) if ver else 1
                except Exception:
                    ver = 1
                if ver < 2:
                    touched = conn.execute(
                        "SELECT COUNT(*) c FROM works WHERE section='fasadas' AND (done<>0 OR price<>0)"
                    ).fetchone()["c"]
                    if not touched:
                        conn.execute("DELETE FROM works WHERE section='fasadas'")
                        cnt = 0
                    conn.execute(
                        "INSERT INTO settings(k,v) VALUES('works_seed_fasadas','2') "
                        "ON CONFLICT(k) DO UPDATE SET v='2'")
            if cnt:
                continue
            ords = 0
            for item in DEFAULT_WORKS:
                if item["section"] != key:
                    continue
                needle, ext = WORK_SOURCE_KEYS.get(item["src"], ("", ""))
                doc_id, source_name = 0, needle
                if needle:
                    row = conn.execute(
                        "SELECT id, name FROM docs WHERE name LIKE ? AND ext=? ORDER BY id LIMIT 1",
                        (f"%{needle}%", ext),
                    ).fetchone()
                    if row:
                        doc_id, source_name = row["id"], row["name"]
                ords += 1
                conn.execute(
                    "INSERT INTO works(section,stage,code,title,unit,qty,done,price,kind,basis,"
                    "source_doc,source_page,source_name,note,ord,created,updated) "
                    "VALUES(?,?,?,?,?,?,0,0,?,?,?,?,?,?,?,?,?)",
                    (item["section"], item["stage"], item["code"], item["title"],
                     item["unit"], item["qty"], item["kind"], item["basis"],
                     doc_id, item["page"], source_name, item["note"],
                     ords, now_iso(), now_iso()),
                )
        if seed_content:
            seed_decisions(conn)
        conn.commit()
    logger.info("DB paruošta: %s", DB_PATH)


GLOBAL_KEYS = {"lan_code", "auto_update", "company"}
_GLOBAL_LOCK = threading.RLock()
_GLOBAL_CACHE = {"mtime": -1.0, "data": {}}


def global_read():
    """Bendri nustatymai, nepriklausantys nuo pasirinkto projekto (prieigos kodas, atnaujinimai)."""
    with _GLOBAL_LOCK:
        try:
            mt = GLOBAL_PATH.stat().st_mtime
        except OSError:
            return {}
        if _GLOBAL_CACHE["mtime"] == mt:
            return dict(_GLOBAL_CACHE["data"])
        try:
            data = json.loads(GLOBAL_PATH.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                data = {}
        except Exception:
            data = {}
        _GLOBAL_CACHE["mtime"] = mt
        _GLOBAL_CACHE["data"] = data
        return dict(data)


def global_write(**changes):
    with _GLOBAL_LOCK:
        data = global_read()
        data.update(changes)
        tmp = GLOBAL_PATH.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, GLOBAL_PATH)
        try:
            _GLOBAL_CACHE["mtime"] = GLOBAL_PATH.stat().st_mtime
        except OSError:
            _GLOBAL_CACHE["mtime"] = -1.0
        _GLOBAL_CACHE["data"] = dict(data)
        return data


def get_setting(key, default=None):
    if key in GLOBAL_KEYS:
        g = global_read()
        if key in g:
            return g[key]
        legacy = None
        try:
            with db() as conn:
                row = conn.execute("SELECT v FROM settings WHERE k=?", (key,)).fetchone()
            if row:
                try:
                    legacy = json.loads(row["v"])
                except Exception:
                    legacy = row["v"]
        except Exception:
            legacy = None
        if legacy is not None:
            global_write(**{key: legacy})
            return legacy
        return default
    with db() as conn:
        row = conn.execute("SELECT v FROM settings WHERE k=?", (key,)).fetchone()
    if not row:
        return default
    try:
        return json.loads(row["v"])
    except Exception:
        return row["v"]


def set_setting(key, value):
    if key in GLOBAL_KEYS:
        global_write(**{key: value})
        return
    with db() as conn:
        conn.execute("INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",
                     (key, json.dumps(value, ensure_ascii=False)))
        conn.commit()


# --- keli atskiri projektai: kiekvienas turi savo duomenų bazę, katalogus ir dokumentus ---

_PROJECTS_LOCK = threading.RLock()
PROJECTS_STATE = {"active": 1, "projects": []}


def project_db_path(project):
    db_name = str(project.get("db") or "app.db")
    path = Path(db_name)
    return path if path.is_absolute() else DATA_DIR / path


def _read_projects_file():
    try:
        data = json.loads(PROJECTS_PATH.read_text(encoding="utf-8"))
        if isinstance(data, dict) and isinstance(data.get("projects"), list):
            return data
    except Exception:
        pass
    return None


def _save_projects():
    projects = [{k: v for k, v in p.items() if not str(k).startswith("_")}
                for p in (PROJECTS_STATE.get("projects") or [])]
    data = {"active": int(PROJECTS_STATE.get("active") or 1), "projects": projects}
    tmp = PROJECTS_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, PROJECTS_PATH)


def _peek_project_meta(path):
    meta = {k: "" for k in PROJECT_FIELDS}
    try:
        conn = sqlite3.connect(str(path), timeout=5)
        try:
            row = conn.execute("SELECT v FROM settings WHERE k='project'").fetchone()
            if row:
                loaded = json.loads(row[0])
                if isinstance(loaded, dict):
                    meta.update({k: str(v) for k, v in loaded.items()})
        finally:
            conn.close()
    except Exception:
        pass
    return meta


def _apply_active_project():
    global DB_PATH
    projects = PROJECTS_STATE.get("projects") or []
    active = next((p for p in projects if int(p.get("id") or 0) == int(PROJECTS_STATE.get("active") or 0)), None)
    if not active and projects:
        active = projects[0]
        PROJECTS_STATE["active"] = int(active["id"])
    if active:
        DB_PATH = project_db_path(active)
    _SIG_MEMO["ts"] = 0.0


def load_projects():
    with _PROJECTS_LOCK:
        data = _read_projects_file()
        if not data:
            meta = _peek_project_meta(DB_PATH)
            data = {
                "active": 1,
                "projects": [{
                    "id": 1,
                    "name": meta.get("name") or DEFAULT_PROJECT["name"],
                    "address": meta.get("address") or DEFAULT_PROJECT["address"],
                    "db": "app.db",
                    "created": now_iso(),
                }],
            }
        fixed = []
        used = set()
        for p in data.get("projects") or []:
            try:
                pid = int(p.get("id") or 0)
            except (TypeError, ValueError):
                continue
            if pid <= 0 or pid in used:
                continue
            used.add(pid)
            db_name = str(p.get("db") or f"projects/p{pid}.db")
            path = Path(db_name) if Path(db_name).is_absolute() else DATA_DIR / db_name
            exists = path.exists()
            meta = _peek_project_meta(path) if exists else {}
            fixed.append({
                "id": pid,
                "name": str(p.get("name") or meta.get("name") or f"Projektas {pid}"),
                "address": str(p.get("address") or meta.get("address") or ""),
                "client": str(p.get("client") or meta.get("client") or ""),
                "db": str(db_name).replace("\\", "/"),
                "created": str(p.get("created") or now_iso()),
                "_exists": exists,
            })
        if not fixed:
            meta = _peek_project_meta(DB_PATH)
            fixed = [{
                "id": 1, "name": meta.get("name") or DEFAULT_PROJECT["name"],
                "address": meta.get("address") or DEFAULT_PROJECT["address"],
                "db": "app.db", "created": now_iso(), "_exists": DB_PATH.exists(),
            }]
        active = int(data.get("active") or fixed[0]["id"])
        if not any(p["id"] == active and p.get("_exists", True) for p in fixed):
            active = next((p["id"] for p in fixed if p.get("_exists", True)), fixed[0]["id"])
        PROJECTS_STATE["active"] = active
        PROJECTS_STATE["projects"] = fixed
        _apply_active_project()
        try:
            _save_projects()
        except OSError:
            logger.warning("Nepavyko įrašyti projektų sąrašo: %s", traceback.format_exc())


def projects_public():
    items = []
    for p in PROJECTS_STATE.get("projects") or []:
        if not (p.get("address") and p.get("client")):
            # Rekvizitai gali būti įrašyti vėliau (pvz., atpažinus sutartį) – perskaitome iš DB.
            try:
                meta = _peek_project_meta(project_db_path(p))
            except Exception:
                meta = {}
            for k in ("name", "address", "client"):
                if not p.get(k) and meta.get(k):
                    p[k] = meta[k]
        items.append({
            "id": int(p["id"]),
            "name": p.get("name") or f"Projektas {p['id']}",
            "address": p.get("address") or "",
            "client": p.get("client") or "",
            "created": p.get("created") or "",
            "active": int(p["id"]) == int(PROJECTS_STATE.get("active") or 0),
        })
    return {"active": int(PROJECTS_STATE.get("active") or 0), "projects": items}


def active_project_entry():
    pid = int(PROJECTS_STATE.get("active") or 0)
    return next((p for p in PROJECTS_STATE.get("projects") or [] if int(p["id"]) == pid), None)


def init_project_db(path, meta, roots=None):
    """Sukuria naujo projekto duomenų bazę su bendru sąrašu, be Šilalės sąmatos duomenų."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=20)
    try:
        conn.row_factory = sqlite3.Row
        conn.executescript(SCHEMA)
        conn.execute("INSERT INTO settings(k,v) VALUES('project',?)",
                     (json.dumps(meta, ensure_ascii=False),))
        conn.execute("INSERT INTO settings(k,v) VALUES('roots',?)",
                     (json.dumps(roots or [], ensure_ascii=False),))
        for code in DISC_ORDER:
            conn.execute("INSERT OR IGNORE INTO disc_status(disc) VALUES(?)", (code,))
        for i, (stage, title) in enumerate(DEFAULT_CHECKLIST):
            conn.execute("INSERT INTO checklist(stage,title,ord) VALUES(?,?,?)",
                         (stage, title, i + 1))
        conn.commit()
    finally:
        conn.close()


def create_project(body):
    name = str((body or {}).get("name") or "").strip()
    if not name:
        raise ValueError("Įrašykite projekto pavadinimą")
    address = str(body.get("address") or "").strip()
    client = str(body.get("client") or "").strip()
    roots = body.get("roots")
    if not isinstance(roots, list):
        roots = []
    roots = [str(r).strip() for r in roots if str(r).strip()]
    with _PROJECTS_LOCK:
        used = [int(p["id"]) for p in PROJECTS_STATE.get("projects") or []]
        pid = max(used or [0]) + 1
        rel = f"projects/p{pid}.db"
        path = DATA_DIR / rel
        meta = {k: "" for k in PROJECT_FIELDS}
        meta.update({"name": name, "full_name": name, "address": address, "client": client})
        for k in PROJECT_FIELDS:
            if k in body:
                meta[k] = str(body.get(k) or "").strip()
        meta["name"] = name
        if not meta.get("full_name"):
            meta["full_name"] = name
        init_project_db(path, meta, roots)
        entry = {"id": pid, "name": name, "address": address, "client": client, "db": rel,
                 "created": now_iso(), "_exists": True}
        PROJECTS_STATE["projects"].append(entry)
        PROJECTS_STATE["active"] = pid
        _apply_active_project()
        _save_projects()
    scan_event.set()
    index_event.set()
    data_touch()
    logger.info("Sukurtas projektas #%s: %s", pid, name)
    return {"id": pid, "name": name, "address": address, "created": entry["created"]}


def switch_project(pid):
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        raise ValueError("Neteisingas projekto numeris")
    with _PROJECTS_LOCK:
        entry = next((p for p in PROJECTS_STATE.get("projects") or [] if int(p["id"]) == pid), None)
        if not entry:
            raise ValueError("Projektas nerastas")
        if not project_db_path(entry).exists():
            raise ValueError("Projekto duomenų failas nerastas")
        PROJECTS_STATE["active"] = pid
        _apply_active_project()
        _save_projects()
    SCAN_STATE.update({"last_scan": "", "files_seen": 0})
    INDEX_STATE.update({"done": 0, "total": 0, "current": "", "last_result": ""})
    scan_event.set()
    index_event.set()
    data_touch()
    logger.info("Perjungtas projektas #%s", pid)
    return entry


def update_project_meta(pid, fields):
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        raise ValueError("Neteisingas projekto numeris")
    with _PROJECTS_LOCK:
        entry = next((p for p in PROJECTS_STATE.get("projects") or [] if int(p["id"]) == pid), None)
        if not entry:
            raise ValueError("Projektas nerastas")
        path = project_db_path(entry)
        if not path.exists():
            raise ValueError("Projekto duomenų failas nerastas")
        conn = sqlite3.connect(str(path), timeout=20)
        try:
            conn.row_factory = sqlite3.Row
            row = conn.execute("SELECT v FROM settings WHERE k='project'").fetchone()
            project = dict(DEFAULT_PROJECT) if pid == 1 else {k: "" for k in PROJECT_FIELDS}
            if row:
                try:
                    loaded = json.loads(row["v"])
                    if isinstance(loaded, dict):
                        project.update({k: str(v) for k, v in loaded.items()})
                except Exception:
                    pass
            for k in PROJECT_FIELDS:
                if k in fields:
                    project[k] = str(fields.get(k) or "").strip()
            conn.execute("INSERT INTO settings(k,v) VALUES('project',?) "
                         "ON CONFLICT(k) DO UPDATE SET v=excluded.v",
                         (json.dumps(project, ensure_ascii=False),))
            conn.commit()
        finally:
            conn.close()
        entry["name"] = project.get("name") or entry["name"]
        entry["address"] = project.get("address") or ""
        entry["client"] = project.get("client") or ""
        _save_projects()
    data_touch()
    return project


def delete_project(pid):
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        raise ValueError("Neteisingas projekto numeris")
    with _PROJECTS_LOCK:
        projects = PROJECTS_STATE.get("projects") or []
        entry = next((p for p in projects if int(p["id"]) == pid), None)
        if not entry:
            raise ValueError("Projektas nerastas")
        if int(PROJECTS_STATE.get("active") or 0) == pid:
            raise ValueError("Negalima ištrinti atidaryto projekto – pirmiausia perjunkite kitą")
        if len(projects) <= 1:
            raise ValueError("Turi likti bent vienas projektas")
        path = project_db_path(entry)
        PROJECTS_STATE["projects"] = [p for p in projects if int(p["id"]) != pid]
        _save_projects()
    for suffix in ("", "-wal", "-shm"):
        try:
            Path(str(path) + suffix).unlink(missing_ok=True)
        except OSError:
            pass
    shutil.rmtree(upload_dir(pid), ignore_errors=True)
    shutil.rmtree(photo_dir(pid), ignore_errors=True)
    shutil.rmtree(act_files_root(pid), ignore_errors=True)
    data_touch()
    logger.info("Ištrintas projektas #%s", pid)
    return True



# --- automatiniai atnaujinimai iš interneto (veikia tik prisijungus) ---

_UPDATE_LOCK = threading.RLock()
UPDATE_STATE = {
    "checking": False,
    "applying": False,
    "available": False,
    "latest": "",
    "notes": "",
    "lastCheck": "",
    "error": "",
    "manifest": None,
}


def update_payload():
    with _UPDATE_LOCK:
        data = dict(UPDATE_STATE)
    data["current"] = VERSION
    data["auto"] = bool(global_read().get("auto_update", True))
    installed = updater.installed_state(BASE_DIR)
    if installed:
        data["installed"] = installed
    return data


def update_check(auto=False):
    with _UPDATE_LOCK:
        if UPDATE_STATE["checking"]:
            return update_payload()
        UPDATE_STATE["checking"] = True
        UPDATE_STATE["error"] = ""
    try:
        try:
            result = updater.check(VERSION, timeout=6)
        except Exception as exc:
            result = {"up_to_date": None, "error": str(exc)}
        with _UPDATE_LOCK:
            UPDATE_STATE["lastCheck"] = now_iso()
            UPDATE_STATE["available"] = result.get("up_to_date") is False
            UPDATE_STATE["latest"] = result.get("latest") or ""
            UPDATE_STATE["manifest"] = result.get("manifest") if result.get("up_to_date") is False else None
            UPDATE_STATE["notes"] = (result.get("manifest") or {}).get("notes", "")
            UPDATE_STATE["error"] = result.get("error") or ""
        logger.info("Atnaujinimų patikra: %s", result.get("latest") or result.get("error"))
    finally:
        with _UPDATE_LOCK:
            UPDATE_STATE["checking"] = False
    return update_payload()


def update_apply():
    with _UPDATE_LOCK:
        if UPDATE_STATE["applying"]:
            raise ValueError("Atnaujinimas jau vykdomas")
        manifest = UPDATE_STATE.get("manifest")
        if not manifest:
            raise ValueError("Nėra paruošto atnaujinimo – pirmiausia patikrinkite versiją")
        UPDATE_STATE["applying"] = True
        UPDATE_STATE["error"] = ""
    try:
        copied = updater.apply_update(manifest, BASE_DIR)
        logger.info("Įdiegta versija %s (%s failų), paleidžiama iš naujo", manifest.get("version"), copied)
        return {"ok": True, "version": manifest.get("version"), "files": copied}
    except Exception as exc:
        with _UPDATE_LOCK:
            UPDATE_STATE["applying"] = False
            UPDATE_STATE["error"] = str(exc)
        raise
    finally:
        with _UPDATE_LOCK:
            if not UPDATE_STATE.get("error"):
                UPDATE_STATE["applying"] = False


def restart_program():
    script = BASE_DIR / "restart.vbs"
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
    try:
        if script.is_file():
            subprocess.Popen(["wscript.exe", str(script)], creationflags=flags,
                             cwd=str(BASE_DIR))
        else:
            subprocess.Popen([sys.executable, str(BASE_DIR / "app.py")], cwd=str(BASE_DIR),
                             creationflags=flags)
    except OSError:
        logger.warning("Nepavyko paleisti programos iš naujo: %s", traceback.format_exc())
        return False
    threading.Timer(1.2, lambda: os._exit(0)).start()
    return True


def update_auto_worker():
    time.sleep(6)
    if os.environ.get("STABAS_NO_UPDATE") == "1":
        return
    try:
        result = updater.check(VERSION, timeout=6)
    except Exception:
        logger.info("Atnaujinimų patikra nepavyko (nėra interneto?)")
        return
    manifest = result.get("manifest") or {}
    if result.get("up_to_date") is True:
        with _UPDATE_LOCK:
            UPDATE_STATE.update({
                "lastCheck": now_iso(), "latest": str(manifest.get("version") or VERSION),
                "notes": manifest.get("notes", ""), "available": False, "error": "",
                "manifest": manifest,
            })
        return
    if result.get("up_to_date") is None:
        with _UPDATE_LOCK:
            UPDATE_STATE.update({"lastCheck": now_iso(), "error": result.get("error") or ""})
        return
    version = str(manifest.get("version") or "")
    with _UPDATE_LOCK:
        UPDATE_STATE.update({
            "available": True, "latest": version, "manifest": manifest,
            "notes": manifest.get("notes", ""), "lastCheck": now_iso(),
        })
    if not global_read().get("auto_update", True):
        return
    last = str(global_read().get("auto_update_tried") or "")
    if last == version:
        logger.warning("Automatinis atnaujinimas į %s jau bandytas – praleidžiama", version)
        return
    global_write(auto_update_tried=version)
    with _UPDATE_LOCK:
        UPDATE_STATE["applying"] = True
    try:
        copied = updater.apply_update(manifest, BASE_DIR)
        logger.info("Automatiškai įdiegta %s (%s failų). Paleidžiama iš naujo.", version, copied)
        restart_program()
    except Exception as exc:
        logger.warning("Automatinis atnaujinimas nepavyko: %s", exc)
        with _UPDATE_LOCK:
            UPDATE_STATE["applying"] = False
            UPDATE_STATE["error"] = str(exc)


# --- projekto vadovo sprendimai dėl nesutapimų ---

def decision_key(ptype, section, title):
    return f"{ptype or ''}|{section or ''}|{title or ''}"


def _decision_row(row):
    d = dict(row)
    try:
        d["codes"] = json.loads(d.get("codes") or "[]")
    except Exception:
        d["codes"] = []
    try:
        d["snapshot"] = json.loads(d.get("snapshot") or "{}")
    except Exception:
        d["snapshot"] = {}
    return d


def decisions_map():
    try:
        with db() as conn:
            rows = conn.execute("SELECT * FROM decisions").fetchall()
    except sqlite3.Error:
        return {}
    return {r["key"]: _decision_row(r) for r in rows}


def list_decisions():
    with db() as conn:
        rows = conn.execute(
            "SELECT * FROM decisions ORDER BY updated DESC, title").fetchall()
    return [_decision_row(r) for r in rows]


DECISION_PACK = [
    {
        "type": "Kvadratūra", "section": "apdaila",
        "title": "Bendrasis plotas sąmatoje nesutampa su BD rodikliais",
        "basis": "STR 1.04.04:2017 „Statinio projektavimas, projekto ekspertizė“; 1-BD l. 7 ir l. 18",
        "note": ("Apdailos kiekis 1 225,33 m² paimtas iš 1-BD l. 18 patalpų plotų suvestinės. "
                 "BD l. 7 bendrasis rodiklis 1 222,11 m² naudojamas pastato tūriui ir bendriesiems "
                 "rodikliams. Skirtumas 3,22 m² (0,26 %) yra skaičiavimo metodikos, o ne kiekio "
                 "klaida – apdailos sąmata nekeičiama, BD rodiklis laikomas orientaciniu."),
        "codes": ["A-03", "A-04", "A-06"],
    },
    {
        "type": "Kiekis", "section": "santechnika",
        "title": "S-22: žiniaraštyje nurodytas kitas matavimo vienetas",
        "basis": ("STR 2.07.01:2003 „Vandentiekis ir nuotekų šalintuvas. Pastato inžinerinės "
                  "sistemos. Lauko inžineriniai tinklai“; 26-01-01-TDP-LVN.SŽ l. 31"),
        "note": ("S-22 „G/B šulinys d700 mm su lietaus surinkimo grotelėmis“ skaičiuojamas vnt. – "
                 "11 vnt. LVN l. 31 matavimo vienetas „m“ laikomas žiniaraščio rašybos klaida, nes "
                 "šuliniai sąmatoje ir specifikacijose skaičiuojami vnt. Kiekis sutampa, paliekamas "
                 "11 vnt."),
        "codes": ["S-22"],
    },
    {
        "type": "Kvadratūra", "section": "fasadas",
        "title": "Fasado aukštis: BD 12 m, sąmatoje 12,85 m",
        "basis": ("STR 2.04.01:2018 „Pastatų atitvaros. Sienos, stogai, langai ir išorinės įėjimo "
                  "durys“; 3-SA l. 65–68; 1-BD l. 7"),
        "note": ("Projektinis pastato aukštis pagal DWG +12,850 m laikomas tiksliu; BD l. 7 12 m yra "
                 "suapvalintas rodiklis. F-01 pastolių plotas 1 037,80 m² skaičiuotas pagal DWG "
                 "aukštį ir paliekamas."),
        "codes": ["F-01"],
    },
    {
        "type": "Kiekis", "section": "apdaila",
        "title": "Durų kiekis sąmatoje skiriasi nuo specifikacijos",
        "status": "Su sąlyga",
        "basis": ("STR 2.04.01:2018 „Pastatų atitvaros. Sienos, stogai, langai ir išorinės įėjimo "
                  "durys“; 3-SA l. 70; butų skaičius – 20"),
        "note": ("A-13 60 vnt. (20 butų × 3 vidaus durys) ir A-14 20 vnt. (20 butų × 1 įėjimo durys) "
                 "atitinka butų skaičių. Specifikacijoje 70 vidaus + 1 lauko durys; skirtumas 9 vnt. "
                 "laikomas laiptinių ir rūsio durų rezervu. Sąlyga: 3-SA l. 70 specifikaciją "
                 "papildyti laiptinių ir rūsio durimis iki statybos užbaigimo deklaracijos."),
        "codes": ["A-13", "A-14"],
    },
    {
        "type": "Kiekis", "section": "elektra",
        "title": "E.SŽ kiekių žiniaraštis: eilučių be sąmatos pozicijų",
        "basis": "STR 1.04.04:2017; 25-E-5269-TDP-E.SŽ l. 66",
        "note": ("E.SŽ l. 66 eilutė „Duobių vamzdžio prakalimui, gręžimui kasimas ir užpylimas“ "
                 "(5 vnt.) įtraukta į E-01–E-08 žemės darbų apimtį ir atskira sąmatos pozicija "
                 "nevedama."),
        "codes": [],
    },
    {
        "type": "Kiekis", "section": "",
        "title": "Sklypo kiekių žiniaraštis neturi sąmatos pozicijų",
        "basis": "LR Statybos įstatymas; STR 1.04.04:2017; 2-SP l. 26",
        "note": ("2-SP l. 26 sklypo sutvarkymo darbai (20 eilučių) priklauso atskiram sklypo "
                 "tvarkymo etapui ir į pastato darbų sąmatą neįtraukti. Šiame etape "
                 "nefinansuojami."),
        "codes": [],
    },
]
for _sec in ("elektra", "apdaila", "santechnika", "fasadas"):
    DECISION_PACK.append({
        "type": "Kaina", "section": _sec,
        "title": "Nenurodytos kainos",
        "status": "Su sąlyga",
        "basis": "LR Statybos įstatymas; STR 1.04.04:2017 „Statinio projektavimas, projekto ekspertizė“",
        "note": ("Sąmata šiame etape rengiama be įkainių: kainos nustatomos pagal rangovo "
                 "komercinius pasiūlymus ir įkeliamos prieš rangos sutarties pasirašymą. "
                 "Neįkainotos pozicijos nelaikomos klaida. Sąlyga: kainas įkelti iki rangos "
                 "sutarties."),
        "codes": [],
    })
for _sec in ("elektra", "apdaila", "santechnika", "fasadas"):
    DECISION_PACK.append({
        "type": "Reikalavimas", "section": _sec,
        "title": "Kiekiai apskaičiuoti orientaciniu būdu",
        "basis": ("STR 1.04.04:2017 „Statinio projektavimas, projekto ekspertizė“; techninio "
                  "projekto stadija"),
        "note": ("Pažymėti „Skaičiuojama“ kiekiai yra techninio projekto orientaciniai kiekiai, "
                 "patvirtinti pagal 3-SA, 1-BD ir LVN duomenis. Galutiniai kiekiai tikslinami "
                 "rengiant darbo projektą ir prieš rangos sutartį."),
        "codes": [],
    })


def seed_decisions(conn):
    if conn.execute("SELECT v FROM settings WHERE k='decisions_seed'").fetchone():
        return
    now = now_iso()
    for item in DECISION_PACK:
        key = decision_key(item["type"], item.get("section", ""), item["title"])
        conn.execute(
            "INSERT OR IGNORE INTO decisions(key,type,section,title,method,status,basis,note,"
            "owner,codes,snapshot,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (key, item["type"], item.get("section", ""), item["title"],
             "PV sprendimas", item.get("status", "Priimta"), item["basis"], item["note"],
             "Projekto vadovas", json.dumps(item.get("codes", []), ensure_ascii=False),
             "{}", now, now),
        )
    conn.execute("INSERT INTO settings(k,v) VALUES('decisions_seed','2026-11-14') "
                 "ON CONFLICT(k) DO UPDATE SET v=excluded.v")


def save_decision(body):
    action = str(body.get("action") or "save")
    key = str(body.get("key") or decision_key(body.get("type"), body.get("section"),
                                               body.get("title"))).strip()
    if not key or key.count("|") < 2:
        raise ValueError("Nenurodytas sprendimo raktas")
    with db() as conn:
        if action == "reopen":
            conn.execute("DELETE FROM decisions WHERE key=?", (key,))
            conn.commit()
            problems_invalidate()
            return {"ok": True, "reopened": True, "key": key}
        row = conn.execute("SELECT * FROM decisions WHERE key=?", (key,)).fetchone()
        title = body.get("title") or (row["title"] if row else "")
        ptype = body.get("type") or (row["type"] if row else "")
        section = body.get("section", row["section"] if row else "")
        note = str(body.get("note") or (row["note"] if row else "")).strip()
        basis = str(body.get("basis") or (row["basis"] if row else "")).strip()
        if not note:
            raise ValueError("Įrašykite sprendimo tekstą")
        now = now_iso()
        conn.execute(
            "INSERT INTO decisions(key,type,section,title,method,status,basis,note,owner,codes,"
            "snapshot,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET method=excluded.method,status=excluded.status,"
            "basis=excluded.basis,note=excluded.note,owner=excluded.owner,codes=excluded.codes,"
            "updated=excluded.updated",
            (key, ptype, section, title,
             str(body.get("method") or (row["method"] if row else "PV sprendimas")),
             str(body.get("status") or (row["status"] if row else "Priimta")),
             basis, note, str(body.get("owner") or (row["owner"] if row else "Projekto vadovas")),
             json.dumps(body.get("codes") or (json.loads(row["codes"] or "[]") if row else []),
                        ensure_ascii=False),
             str(body.get("snapshot") or (row["snapshot"] if row else "{}")), now, now),
        )
        conn.commit()
        saved = conn.execute("SELECT * FROM decisions WHERE key=?", (key,)).fetchone()
    problems_invalidate()
    return {"ok": True, "decision": _decision_row(saved)}


def get_roots():
    roots = get_setting("roots", [])
    return [r for r in roots if r]


def repair_roots(roots):
    """Jei katalogas buvo perkeltas, suranda to paties pavadinimo aplanką Desktop gylyje ir atnaujina sąrašą."""
    desktop = Path.home() / "Desktop"
    changed = False
    out = []
    for root in roots:
        p = Path(root)
        if p.is_dir():
            out.append(root)
            continue
        name = p.name
        cands = []
        if desktop.is_dir():
            try:
                for child in desktop.iterdir():
                    if not child.is_dir():
                        continue
                    c = child / name
                    if c.is_dir():
                        cands.append(c)
            except OSError:
                pass
        uniq = []
        seen = set()
        for c in cands:
            key = str(c).lower()
            if key not in seen:
                seen.add(key)
                uniq.append(c)
        if len(uniq) == 1:
            out.append(str(uniq[0]))
            changed = True
            logger.info("Katalogas perkeltas: %s -> %s", root, uniq[0])
        else:
            out.append(root)
    if changed:
        set_setting("roots", out)
    return out


def root_disc(root):
    name = Path(root).name
    return name if name in DISCIPLINES else name


UPLOAD_MAX_BYTES = 300 * 1024 * 1024
UPLOAD_DISC = "Įkelti"

# Įkeltų failų priskyrimas daliai pagal pavadinimą. Tvarka svarbi:
# konkretesnės taisyklės tikrinamos pirmiau (LVN prieš VN, ET prieš E).
_DISC_HINTS = (
    ("TOPO", ("topograf", "geodezij", "geodez", "gnss")),
    ("NTR", ("nekilnojamojo turto", "nt registr", "kadastr", "registru centr")),
    ("LVN", ("lauko vandentiek", "lauko nuotek", "lauko tinkl", "lauko inziner")),
    ("VN", ("vandentiek", "nuotek", "santechnik", "sanitarin", "vamzdyn")),
    ("ŠVOK", ("svok", "sildym", "vedinim", "kondicionav", "rekuperac")),
    ("ET", ("elektros tinkl", "elektros linij", "kabeli", "transformator", "skirstykl")),
    ("E", ("elektr", "apsvietim", "signalizacij", "silpnu sroviu", "rysiu", "rysi")),
    ("SK", ("konstruk", "stogo", "stogas", "pamat", "perdang", "sienu", "metalin",
            "gelzbeton", "monolit", "kolon", "sij", "rostverk")),
    ("SA", ("architekt", "fasad", "planas", "planai", "maket", "vizualizacij",
            "cokoli", "plytel", "apdail")),
    ("SP", ("sklyp", "statybviet", "statiebviet", "sutvarkym", "perd-priem")),
    ("BD", ("bendrastatyb", "bendroji", "projekt", "sutart", "susitarim", "saskait",
            "aktas", "akto", "akta", "pazym", "samat", "kieki", "priedas",
            "reikalavim", "forma", "pvm")),
)

# Teksto atveju pirmiausia atpažįstame dokumento tipą (sutartis, sąskaita...),
# nes tokiuose dokumentuose dažnai minimos ir kitos dalys.
_DISC_TEXT_HINTS = (
    ("BD", ("saskait", "pvm", "sutart", "susitarim", "aktas", "akto", "akta",
            "pazym", "samat", "priedas", "forma", "reikalavim")),
) + tuple(x for x in _DISC_HINTS if x[0] != "BD")


def _fold_text(s):
    s = unicodedata.normalize("NFKD", str(s or ""))
    return s.encode("ascii", "ignore").decode("ascii").lower()


def _match_hints(text, table):
    for code, hints in table:
        for hint in hints:
            if hint in text:
                return code
    return None


def guess_disc(name, text=None):
    """Grąžina dalies kodą pagal failo pavadinimą (ir, jei reikia, tekstą)."""
    t = _fold_text(Path(str(name or "")).stem)
    code = _match_hints(t, _DISC_HINTS)
    if code:
        return code
    if text:
        code = _match_hints(_fold_text(text)[:8000], _DISC_TEXT_HINTS)
        if code:
            return code
    return UPLOAD_DISC


def _doc_head_text(conn, doc_id, limit=8000):
    row = conn.execute("SELECT text FROM pages WHERE doc_id=? ORDER BY page LIMIT 1",
                       (doc_id,)).fetchone()
    return (row["text"] or "")[:limit] if row else ""
_UPLOAD_NAME_RE = re.compile(r'[\x00-\x1f<>:"/\\|?*]')
_WIN_RESERVED = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}


def upload_dir(pid=None):
    """Projekto įkeltų failų katalogas."""
    try:
        pid = int(pid if pid is not None else (PROJECTS_STATE.get("active") or 1))
    except (TypeError, ValueError):
        pid = 1
    return DATA_DIR / "files" / f"p{pid}"


def safe_upload_name(name):
    base = Path(str(name or "").replace("\\", "/")).name.strip()
    base = _UPLOAD_NAME_RE.sub("", base).strip(" .")
    if not base or base in (".", ".."):
        raise ValueError("Netinkamas failo pavadinimas")
    if base.split(".")[0].upper() in _WIN_RESERVED:
        base = "_" + base
    return base


def unique_upload_path(folder, name):
    path = folder / name
    if not path.exists():
        return path
    stem, suffix = Path(name).stem, Path(name).suffix
    for i in range(2, 1000):
        candidate = folder / f"{stem} ({i}){suffix}"
        if not candidate.exists():
            return candidate
    raise ValueError("Per daug failų tuo pačiu pavadinimu")


# --- fotofiksacija ---
PHOTO_SCHEMA = """
CREATE TABLE IF NOT EXISTS photos(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL DEFAULT '',
    name TEXT NOT NULL,
    file TEXT NOT NULL,
    size INTEGER NOT NULL DEFAULT 0,
    caption TEXT NOT NULL DEFAULT '',
    created TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_photos_date ON photos(date);
"""
PHOTO_MAX_BYTES = 40 * 1024 * 1024
PHOTO_EXTS = {".jpg", ".jpeg", ".jfif", ".png", ".webp", ".gif", ".bmp"}
PHOTO_TYPES = {
    ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".jfif": "image/jpeg",
    ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif",
    ".bmp": "image/bmp",
}
_PHOTO_READY = set()


def photo_dir(pid=None):
    """Projekto fotofiksacijos katalogas."""
    try:
        pid = int(pid if pid is not None else (PROJECTS_STATE.get("active") or 1))
    except (TypeError, ValueError):
        pid = 1
    return DATA_DIR / "photos" / f"p{pid}"


def ensure_photos_table():
    key = str(DB_PATH)
    if key in _PHOTO_READY:
        return
    with db() as conn:
        conn.executescript(PHOTO_SCHEMA)
        conn.commit()
    _PHOTO_READY.add(key)


def photo_public(row):
    return {
        "id": int(row["id"]),
        "date": row["date"] or "",
        "name": row["name"] or "",
        "caption": row["caption"] or "",
        "size": int(row["size"] or 0),
        "created": row["created"] or "",
        "url": f"/api/photo/{int(row['id'])}",
    }


def list_photos():
    ensure_photos_table()
    with db() as conn:
        rows = conn.execute(
            "SELECT * FROM photos ORDER BY date DESC, id DESC").fetchall()
    return [photo_public(r) for r in rows]


def add_photo(date_iso, name, file_name, size, caption):
    ensure_photos_table()
    created = now_iso()
    with db() as conn:
        cur = conn.execute(
            "INSERT INTO photos(date,name,file,size,caption,created) VALUES(?,?,?,?,?,?)",
            (date_iso, name, file_name, int(size), caption, created))
        conn.commit()
        row = conn.execute("SELECT * FROM photos WHERE id=?", (cur.lastrowid,)).fetchone()
    data_touch()
    return photo_public(row)


def update_photo(photo_id, fields):
    ensure_photos_table()
    with db() as conn:
        row = conn.execute("SELECT * FROM photos WHERE id=?", (int(photo_id),)).fetchone()
        if not row:
            raise ValueError("Nuotrauka nerasta")
        date_iso = row["date"] or ""
        if "date" in fields:
            date_iso = str(fields.get("date") or "").strip()
            if date_iso:
                try:
                    date.fromisoformat(date_iso)
                except ValueError:
                    raise ValueError("Neteisinga data")
        caption = str(fields.get("caption", row["caption"]) or "").strip()[:500]
        conn.execute("UPDATE photos SET date=?, caption=? WHERE id=?",
                     (date_iso, caption, int(photo_id)))
        conn.commit()
        row = conn.execute("SELECT * FROM photos WHERE id=?", (int(photo_id),)).fetchone()
    data_touch()
    return photo_public(row)


def delete_photo(photo_id):
    ensure_photos_table()
    with db() as conn:
        row = conn.execute("SELECT * FROM photos WHERE id=?", (int(photo_id),)).fetchone()
        if not row:
            raise ValueError("Nuotrauka nerasta")
        conn.execute("DELETE FROM photos WHERE id=?", (int(photo_id),))
        conn.commit()
    folder = photo_dir().resolve()
    path = (folder / (row["file"] or "")).resolve()
    if path.parent == folder:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
    data_touch()
    return True


def photo_magic_ok(head, ext):
    if not head:
        return False
    if ext in (".jpg", ".jpeg", ".jfif"):
        return head.startswith(b"\xff\xd8\xff")
    if ext == ".png":
        return head.startswith(b"\x89PNG\r\n\x1a\n")
    if ext == ".gif":
        return head.startswith(b"GIF87a") or head.startswith(b"GIF89a")
    if ext == ".webp":
        return len(head) >= 12 and head[:4] == b"RIFF" and head[8:12] == b"WEBP"
    if ext == ".bmp":
        return head.startswith(b"BM")
    return False


# --- prie aktų pridedami failai (pasirašyti skenai, PDF, nuotraukos) ---

ACT_FILE_MAX_BYTES = 60 * 1024 * 1024
ACT_FILE_EXTS = {".pdf", ".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif",
                 ".docx", ".xlsx", ".doc", ".xls", ".dwg", ".zip", ".txt"}
ACT_FILE_TYPES = {
    ".pdf": "application/pdf", ".png": "image/png", ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg", ".webp": "image/webp", ".bmp": "image/bmp",
    ".gif": "image/gif",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".doc": "application/msword", ".xls": "application/vnd.ms-excel",
    ".dwg": "application/acad", ".zip": "application/zip", ".txt": "text/plain; charset=utf-8",
}
ACT_FILE_INLINE = {".pdf", ".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"}


def act_files_root(pid=None):
    try:
        pid = int(pid if pid is not None else (PROJECTS_STATE.get("active") or 1))
    except (TypeError, ValueError):
        pid = 1
    return DATA_DIR / "act-files" / f"p{pid}"


def act_files_dir(act_id, pid=None):
    try:
        aid = int(act_id)
    except (TypeError, ValueError):
        aid = 0
    return act_files_root(pid) / f"a{aid}"


def act_file_public(row):
    return {
        "id": int(row["id"]), "act_id": int(row["act_id"]),
        "name": row["name"] or "", "size": int(row["size"] or 0),
        "ext": row["ext"] or "", "created": row["created"] or "",
        "url": f"/api/act-file/{int(row['id'])}",
    }


def list_act_files(act_id):
    with db() as conn:
        rows = conn.execute("SELECT * FROM act_files WHERE act_id=? ORDER BY id",
                            (int(act_id),)).fetchall()
    return [act_file_public(r) for r in rows]


def add_act_file(act_id, name, file_name, size):
    created = now_iso()
    ext = Path(name).suffix.lower()
    with db() as conn:
        if not conn.execute("SELECT 1 FROM acts WHERE id=?", (int(act_id),)).fetchone():
            raise ValueError("Aktas nerastas")
        cur = conn.execute(
            "INSERT INTO act_files(act_id,name,file,ext,size,created) VALUES(?,?,?,?,?,?)",
            (int(act_id), name, file_name, ext, int(size), created))
        conn.commit()
        row = conn.execute("SELECT * FROM act_files WHERE id=?", (cur.lastrowid,)).fetchone()
    data_touch()
    return act_file_public(row)


def delete_act_file(file_id):
    with db() as conn:
        row = conn.execute("SELECT * FROM act_files WHERE id=?", (int(file_id),)).fetchone()
        if not row:
            raise ValueError("Failas nerastas")
        conn.execute("DELETE FROM act_files WHERE id=?", (int(file_id),))
        conn.commit()
    folder = act_files_dir(row["act_id"]).resolve()
    path = (folder / (row["file"] or "")).resolve()
    if path.parent == folder:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
    data_touch()
    return {"ok": True, "act_id": int(row["act_id"])}


def purge_act_files(act_ids):
    for act_id in act_ids:
        shutil.rmtree(act_files_dir(act_id), ignore_errors=True)


def act_file_magic_ok(head, ext):
    if ext in (".jpg", ".jpeg"):
        return head.startswith(b"\xff\xd8\xff")
    if ext == ".png":
        return head.startswith(b"\x89PNG\r\n\x1a\n")
    if ext == ".gif":
        return head.startswith(b"GIF87a") or head.startswith(b"GIF89a")
    if ext == ".webp":
        return len(head) >= 12 and head[:4] == b"RIFF" and head[8:12] == b"WEBP"
    if ext == ".bmp":
        return head.startswith(b"BM")
    if ext == ".pdf":
        return head.startswith(b"%PDF")
    if ext in (".docx", ".xlsx", ".zip"):
        return head.startswith(b"PK\x03\x04") or head.startswith(b"PK\x05\x06")
    if ext in (".doc", ".xls"):
        return head.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1")
    if ext == ".dwg":
        return head.startswith(b"AC10")
    if ext == ".txt":
        return True
    return False




# --- bendras duomenų parašas: visi išvestiniai skaičiai persiskaičiuoja patys ---

_DATA_REV = 0
_DATA_REV_LOCK = threading.Lock()
_SIG_MEMO = {"ts": 0.0, "sig": ""}


def data_touch():
    global _DATA_REV
    with _DATA_REV_LOCK:
        _DATA_REV += 1
    _SIG_MEMO["ts"] = 0.0


def data_signature():
    """Pigus DB ir procesų pakeitimų parašas; keičiasi ir po failų perindeksavimo."""
    if time.time() - _SIG_MEMO["ts"] < 1.0 and _SIG_MEMO["sig"]:
        return _SIG_MEMO["sig"]
    with _DATA_REV_LOCK:
        rev = _DATA_REV
    with db() as conn:
        d = conn.execute(
            "SELECT COUNT(*) n, COALESCE(MAX(mtime),0) mm, COALESCE(SUM(size),0) sz, "
            "COALESCE(SUM(text_len),0) tl, "
            "COALESCE(SUM(CASE WHEN text_state='done' THEN 1 ELSE 0 END),0) td "
            "FROM docs").fetchone()
        w = conn.execute(
            "SELECT COUNT(*) n, COALESCE(MAX(updated),'') mu, COALESCE(SUM(qty),0) q, "
            "COALESCE(SUM(done),0) dn, COALESCE(SUM(price),0) p "
            "FROM works").fetchone()
        dec = conn.execute(
            "SELECT COUNT(*) n, COALESCE(MAX(updated),'') mu FROM decisions").fetchone()
        pg = conn.execute("SELECT COUNT(*) n FROM pages").fetchone()
    raw = "|".join(str(x) for x in (
        rev, d["n"], d["mm"], d["sz"], d["tl"], d["td"],
        w["n"], w["mu"], round(w["q"], 6), round(w["dn"], 6), round(w["p"], 2),
        dec["n"], dec["mu"], pg["n"]))
    sig = hashlib.sha1(raw.encode("utf-8")).hexdigest()[:16]
    _SIG_MEMO["sig"] = sig
    _SIG_MEMO["ts"] = time.time()
    return sig


def scan_files():
    if SCAN_STATE["scanning"]:
        return
    SCAN_STATE["scanning"] = True
    started = time.time()
    seen = 0
    changed = False
    try:
        roots = repair_roots(get_roots())
        targets = [(root, root_disc(root)) for root in roots]
        uploaded = upload_dir()
        if uploaded.is_dir():
            targets.append((str(uploaded), UPLOAD_DISC))
        with db() as conn:
            existing = {r["path"]: dict(r) for r in conn.execute("SELECT * FROM docs")}
            for root, disc in targets:
                rp = Path(root)
                if not rp.exists():
                    continue
                for dirpath, dirnames, filenames in os.walk(root):
                    dirnames[:] = [d for d in dirnames if d.lower() not in SKIP_DIRS and not d.startswith(".")]
                    for fn in filenames:
                        if fn.lower() in SKIP_FILES or fn.startswith("~$"):
                            continue
                        full = os.path.join(dirpath, fn)
                        try:
                            st = os.stat(full)
                        except OSError:
                            continue
                        seen += 1
                        ext = Path(fn).suffix.lower()
                        rel = os.path.relpath(full, root)
                        old = existing.get(full)
                        if old:
                            if abs(old["size"] - st.st_size) > 0 or abs(old["mtime"] - st.st_mtime) > 1:
                                conn.execute(
                                    "UPDATE docs SET size=?, mtime=?, text_state=?, text_len=0, pages=NULL WHERE id=?",
                                    (st.st_size, st.st_mtime, "pending" if ext in INDEX_EXTS else "skipped", old["id"]),
                                )
                                conn.execute("DELETE FROM pages WHERE doc_id=?", (old["id"],))
                                conn.execute("DELETE FROM pages_fts WHERE doc_id=?", (old["id"],))
                                index_event.set()
                                changed = True
                            continue
                        cur = conn.execute(
                            "INSERT INTO docs(root,rel,path,name,ext,disc,size,mtime,text_state,meta,added) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                            (root, rel, full, fn, ext,
                             disc if disc != UPLOAD_DISC else guess_disc(fn),
                             st.st_size, st.st_mtime,
                             "pending" if ext in INDEX_EXTS else "skipped", "{}", time.time()),
                        )
                        conn.execute("INSERT INTO doc_name_fts(name, doc_id) VALUES(?,?)", (fn, cur.lastrowid))
                        index_event.set()
                        changed = True
            # remove documents whose files disappeared
            gone = []
            for path, row in existing.items():
                if not os.path.exists(path):
                    gone.append(row["id"])
            for doc_id in gone:
                conn.execute("DELETE FROM docs WHERE id=?", (doc_id,))
                conn.execute("DELETE FROM pages WHERE doc_id=?", (doc_id,))
                conn.execute("DELETE FROM pages_fts WHERE doc_id=?", (doc_id,))
                conn.execute("DELETE FROM doc_name_fts WHERE doc_id=?", (doc_id,))
                changed = True
            # Įkeltus failus išskirstome į dalis pagal pavadinimą ir tekstą
            # (rankinių priskyrimų neliečiame)
            for doc_path, row in existing.items():
                if row.get("disc") != UPLOAD_DISC or row.get("disc_lock"):
                    continue
                if not os.path.exists(doc_path):
                    continue
                guessed = guess_disc(row.get("name"), _doc_head_text(conn, row["id"]))
                if guessed != UPLOAD_DISC:
                    conn.execute("UPDATE docs SET disc=? WHERE id=?", (guessed, row["id"]))
                    changed = True
            doc_queued = conn.execute(
                "UPDATE docs SET text_state='pending' WHERE text_state='skipped' AND ext IN ('.docx','.xlsx','.doc')"
            ).rowcount
            if doc_queued:
                index_event.set()
                changed = True
            if ocr_supported():
                ext_list = ",".join("'%s'" % e for e in sorted(INDEX_EXTS))
                img_list = ",".join("'%s'" % e for e in sorted(OCR_EXTS))
                queued = conn.execute(
                    "UPDATE docs SET text_state='pending' WHERE text_state='skipped' AND ext IN (%s)" % img_list
                ).rowcount
                # PDF be teksto sluoksnio – vieną kartą bandoma atpažinti OCR
                queued += conn.execute(
                    "UPDATE docs SET text_state='pending' WHERE text_state='done' AND COALESCE(text_len,0)=0 "
                    "AND COALESCE(meta,'') NOT LIKE '%%\"ocr\"%%' AND ext IN (%s)" % ext_list
                ).rowcount
                if queued:
                    index_event.set()
                    changed = True
            if find_oda_converter():
                changed_oda = conn.execute(
                    "UPDATE docs SET text_state='pending' WHERE ext='.dwg' AND text_state='skipped'"
                ).rowcount
                if changed_oda:
                    index_event.set()
                    changed = True
            conn.commit()
        if changed:
            data_touch()
        SCAN_STATE["last_scan"] = now_iso()
        SCAN_STATE["files_seen"] = seen
        logger.info("Skenavimas baigtas: %s failų, %.1fs", seen, time.time() - started)
    except Exception:
        logger.error("Skenavimo klaida: %s", traceback.format_exc())
    finally:
        SCAN_STATE["scanning"] = False
        index_event.set()


def _save_pages(conn, doc_id, rows):
    conn.execute("DELETE FROM pages WHERE doc_id=?", (doc_id,))
    conn.execute("DELETE FROM pages_fts WHERE doc_id=?", (doc_id,))
    if rows:
        conn.executemany("INSERT OR REPLACE INTO pages(doc_id,page,text) VALUES(?,?,?)",
                         [(doc_id, p, t) for p, t in rows])
        conn.executemany("INSERT INTO pages_fts(text,doc_id,page) VALUES(?,?,?)",
                         [(t, doc_id, p) for p, t in rows])


def _extract_pdf(path, conn, doc_id, meta, max_chars=180_000):
    from pypdf import PdfReader
    reader = PdfReader(str(path), strict=False)
    try:
        if reader.is_encrypted:
            reader.decrypt("")
    except Exception:
        pass
    try:
        info = reader.metadata or {}
        meta.setdefault("pdf_title", str(info.get("/Title") or ""))
        meta.setdefault("author", str(info.get("/Author") or ""))
        created = parse_pdf_date(info.get("/CreationDate")) or parse_pdf_date(info.get("/ModDate"))
        if created:
            meta.setdefault("date", created)
    except Exception:
        pass
    rows = []
    total = 0
    for i, page in enumerate(reader.pages):
        try:
            text = page.extract_text() or ""
        except Exception:
            text = ""
        text = " ".join(text.split())
        if text and total < 6_000_000:
            text = text[:max_chars]
            rows.append((i + 1, text))
            total += len(text)
    pages = len(reader.pages)
    return pages, rows


_OCR_STATE = {"checked": False, "ok": False}


def powershell_exe():
    exe = shutil.which("powershell")
    if exe:
        return exe
    cand = Path(os.environ.get("SystemRoot") or r"C:\Windows") / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    return str(cand) if cand.is_file() else ""


def ocr_supported():
    """Ar yra Windows OCR variklis (veikia be interneto ir be administratoriaus)."""
    if not _OCR_STATE["checked"]:
        _OCR_STATE["checked"] = True
        _OCR_STATE["ok"] = bool(WINOCR_SCRIPT.is_file() and powershell_exe())
    return _OCR_STATE["ok"]


def _winocr_pages(path, max_pages=OCR_MAX_PAGES):
    """Perskaito skenuotą PDF ar paveikslėlį Windows OCR varikliu.

    Grąžina [(lapas, tekstas), ...] arba [].
    """
    if not ocr_supported():
        return []
    fd, out = tempfile.mkstemp(prefix="stabas-ocr-", suffix=".txt")
    os.close(fd)
    try:
        cmd = [
            powershell_exe(), "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
            "-File", str(WINOCR_SCRIPT), "-Path", str(path), "-OutFile", out,
            "-Width", "2000", "-MaxPages", str(max(1, int(max_pages))),
        ]
        started = time.time()
        proc = subprocess.run(cmd, capture_output=True, timeout=900,
                              creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if proc.returncode != 0:
            err = (proc.stderr or b"").decode("utf-8", "replace").strip()
            raise RuntimeError(err[-400:] or f"OCR kodas {proc.returncode}")
        raw = Path(out).read_text(encoding="utf-8", errors="replace")
        logger.info("OCR %s: %.1fs", Path(path).name, time.time() - started)
    except Exception as e:
        logger.warning("OCR nepavyko %s: %s", Path(path).name, e)
        return []
    finally:
        try:
            os.unlink(out)
        except OSError:
            pass
    rows = []
    for m in re.finditer(r"===PAGE (\d+)===\s*(.*?)(?====PAGE |\Z)", raw, re.S):
        body = " ".join(m.group(2).split())
        if body:
            rows.append((int(m.group(1)), body))
    if not rows and raw.strip():
        rows.append((1, " ".join(raw.split())))
    return rows


def _winocr_words(path, max_pages=4, width=2600):
    """Windows OCR su žodžių koordinatėmis.

    Grąžina [(lapas, [(tekstas, x, y, plotis, aukštis), ...]), ...].
    """
    if not ocr_supported():
        return []
    fd, out = tempfile.mkstemp(prefix="stabas-ocrw-", suffix=".txt")
    os.close(fd)
    try:
        cmd = [
            powershell_exe(), "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
            "-File", str(WINOCR_SCRIPT), "-Path", str(path), "-OutFile", out,
            "-Width", str(int(width)), "-MaxPages", str(max(1, int(max_pages))), "-Words",
        ]
        started = time.time()
        proc = subprocess.run(cmd, capture_output=True, timeout=900,
                              creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if proc.returncode != 0:
            err = (proc.stderr or b"").decode("utf-8", "replace").strip()
            raise RuntimeError(err[-400:] or f"OCR kodas {proc.returncode}")
        raw = Path(out).read_text(encoding="utf-8", errors="replace")
        logger.info("OCR žodžiai %s: %.1fs", Path(path).name, time.time() - started)
    except Exception as e:
        logger.warning("OCR žodžių nepavyko %s: %s", Path(path).name, e)
        return []
    finally:
        try:
            os.unlink(out)
        except OSError:
            pass
    pages = []
    for m in re.finditer(r"===PAGE (\d+)===\s*(.*?)(?====PAGE |\Z)", raw, re.S):
        words = []
        for ln in m.group(2).splitlines():
            parts = ln.split("\t")
            if len(parts) < 5:
                continue
            try:
                words.append((parts[0].strip(), int(parts[1]), int(parts[2]),
                              int(parts[3]), int(parts[4])))
            except ValueError:
                continue
        if words:
            pages.append((int(m.group(1)), words))
    return pages


def _windoc_pages(path):
    """Ištraukia tekstą iš seno Word .doc per įdiegtą Word programą (be administratoriaus)."""
    if not (WINDOC_SCRIPT.is_file() and powershell_exe()):
        return []
    fd, out = tempfile.mkstemp(prefix="stabas-doc-", suffix=".txt")
    os.close(fd)
    try:
        cmd = [
            powershell_exe(), "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
            "-File", str(WINDOC_SCRIPT), "-Path", str(path), "-OutFile", out,
        ]
        started = time.time()
        proc = subprocess.run(cmd, capture_output=True, timeout=300,
                              creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if proc.returncode != 0:
            err = (proc.stderr or b"").decode("utf-8", "replace").strip()
            raise RuntimeError(err[-400:] or f"Word kodas {proc.returncode}")
        raw = Path(out).read_text(encoding="utf-8", errors="replace")
        logger.info("Word .doc %s: %.1fs", Path(path).name, time.time() - started)
    except Exception as e:
        logger.warning("Word .doc nepavyko %s: %s", Path(path).name, e)
        return []
    finally:
        try:
            os.unlink(out)
        except OSError:
            pass
    text = " ".join(raw.replace("\r", "\n").split())
    return [(1, text)] if text.strip() else []


def _docx_pages(path):
    """Ištraukia tekstą iš Word .docx (be papildomų bibliotekų)."""
    try:
        with zipfile.ZipFile(path) as z:
            names = set(z.namelist())
            if "word/document.xml" not in names:
                return []
            root = ET.fromstring(z.read("word/document.xml"))
            chunks = []
            for p in root.iter():
                if not p.tag.endswith("}p"):
                    continue
                text = "".join(t.text or "" for t in p.iter() if t.tag.endswith("}t"))
                text = " ".join(text.split())
                if text:
                    chunks.append(text)
            body = " ".join(chunks)[:400_000]
            return [(1, body)] if body else []
    except Exception:
        return []


def _xlsx_pages(path):
    """Ištraukia tekstą iš Excel .xlsx (be papildomų bibliotekų)."""
    try:
        sheets = _xlsx_parse(Path(path).read_bytes())
    except Exception:
        return []
    chunks = []
    for sh in sheets:
        rows = sh.get("rows") or {}
        for rn in sorted(rows):
            line = _xlsx_text(rows[rn])
            if line:
                chunks.append(line)
    body = " ".join(chunks)[:400_000]
    return [(1, body)] if body else []


def _adoc_meta(path):
    meta = {}
    try:
        with zipfile.ZipFile(path) as z:
            for name in z.namelist():
                if not re.search(r"metadata/signableMetadata\d+\.xml$", name):
                    continue
                try:
                    root = ET.fromstring(z.read(name))
                except Exception:
                    continue
                for el in root.iter():
                    tag = el.tag.split("}")[-1]
                    val = (el.text or "").strip()
                    if not val:
                        continue
                    if tag == "title" and "title" not in meta:
                        meta["title"] = val
                    elif tag == "name" and "signer" not in meta:
                        meta["signer"] = val
                    elif tag == "individualName" and "signer" not in meta:
                        meta["signer"] = val
                    elif tag == "signingTime" and "signed" not in meta:
                        meta["signed"] = val
                    elif tag == "number" and "reg_no" not in meta:
                        meta["reg_no"] = val
                    elif tag == "date" and "reg_date" not in meta:
                        meta["reg_date"] = val
                if meta.get("title"):
                    break
    except Exception:
        logger.warning("ADOC metaduomenų klaida %s", path)
    if meta.get("signed"):
        meta["date"] = meta["signed"][:10]
    elif meta.get("reg_date"):
        meta["date"] = meta["reg_date"][:10]
    return meta


def _adoc_inner_pdf(path, doc_id, mtime):
    pid = int(PROJECTS_STATE.get("active") or 1)
    cache = CACHE_DIR / f"adoc_p{pid}_{doc_id}_{int(mtime)}.pdf"
    if cache.exists() and cache.stat().st_size > 0:
        return cache
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        member = "pagrindinis_dokumentas.pdf"
        if member not in names:
            pdfs = [n for n in names if n.lower().endswith(".pdf")]
            if not pdfs:
                raise RuntimeError("ADOC faile nėra PDF dokumento")
            member = pdfs[0]
        data = z.read(member)
    tmp = cache.with_suffix(".tmp")
    tmp.write_bytes(data)
    os.replace(tmp, cache)
    return cache


def find_oda_converter():
    candidates = []
    env = os.environ.get("STABAS_ODA_CONVERTER")
    if env:
        candidates.append(Path(env))
    local = os.environ.get("LOCALAPPDATA")
    if local:
        base = Path(local) / "Programs"
        candidates.append(base / "ODADrawingsExplorer" / "OdaFileConverter.exe")
        candidates.append(base / "ODAFileConverter" / "OdaFileConverter.exe")
        try:
            for exe in sorted(base.glob("*/OdaFileConverter.exe")):
                candidates.append(exe)
        except OSError:
            pass
    for var in ("ProgramFiles", "ProgramFiles(x86)"):
        root = os.environ.get(var)
        if not root:
            continue
        try:
            for exe in sorted(Path(root).glob("ODA/*/OdaFileConverter.exe"), reverse=True):
                candidates.append(exe)
        except OSError:
            pass
    for exe in candidates:
        try:
            if exe.is_file():
                return exe
        except OSError:
            continue
    return None


_DXF_TEXT_ENTITIES = {"TEXT", "MTEXT", "ATTRIB", "ATTDEF"}


def _clean_cad_text(value):
    text = re.sub(r"\\U\+([0-9A-Fa-f]{4})", lambda m: chr(int(m.group(1), 16)), value)
    text = text.replace("\\P", "\n").replace("\\~", " ")
    text = text.replace("^I", " ").replace("^J", "\n").replace("^M", "")
    text = re.sub(r"\\[A-Za-z][^;\\{}]*;", "", text)
    text = text.replace("\\{", "{").replace("\\}", "}").replace("\\\\", "\\")
    for src, dst in (("%%d", "°"), ("%%D", "°"), ("%%c", "Ø"), ("%%C", "Ø"), ("%%p", "±"), ("%%P", "±")):
        text = text.replace(src, dst)
    text = text.replace("{", "").replace("}", "")
    text = "".join(ch for ch in text if ch in "\n\t" or not unicodedata.category(ch).startswith("C"))
    return " ".join(part.strip() for part in text.splitlines() if part.strip())


def _dxf_text(path):
    section = ""
    entity = ""
    buffer = []
    found = []
    seen = set()

    def flush():
        if entity not in _DXF_TEXT_ENTITIES:
            return
        for raw in buffer:
            clean = _clean_cad_text(raw)
            if clean and clean not in seen:
                seen.add(clean)
                found.append(clean)

    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        while True:
            code = fh.readline()
            if not code:
                break
            value = fh.readline()
            if value == "":
                break
            code = code.strip()
            value = value.rstrip("\r\n")
            if code == "0":
                flush()
                entity = value.strip()
                buffer = []
                continue
            if entity == "SECTION" and code == "2":
                section = value.strip()
                continue
            if section in ("BLOCKS", "ENTITIES") and entity in _DXF_TEXT_ENTITIES and code in ("1", "3"):
                buffer.append(value)
    flush()
    return "\n".join(found)


def _dwg_extract_text(path, doc_id, mtime):
    pid = int(PROJECTS_STATE.get("active") or 1)
    cache = DWG_TEXT_DIR / f"dwgtext_p{pid}_{int(doc_id)}_{int(mtime)}.txt"
    if cache.exists():
        try:
            return cache.read_text(encoding="utf-8")
        except OSError:
            pass
    converter = find_oda_converter()
    if not converter:
        raise RuntimeError("Nerastas ODA File Converter (OdaFileConverter.exe)")
    with tempfile.TemporaryDirectory(prefix="dwgtxt_", dir=str(DWG_TEXT_DIR)) as tmp:
        src = Path(tmp) / "in"
        out = Path(tmp) / "out"
        src.mkdir()
        out.mkdir()
        target = src / path.name
        try:
            os.link(path, target)
        except OSError:
            shutil.copy2(path, target)
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
        proc = subprocess.run(
            [str(converter), str(src), str(out), "ACAD2018", "DXF", "0", "0", "*.dwg"],
            capture_output=True, timeout=DWG_CONVERT_TIMEOUT, creationflags=flags,
        )
        dxfs = sorted(out.glob("*.dxf"))
        if not dxfs:
            detail = (proc.stderr or proc.stdout or b"").decode("utf-8", "replace").strip()
            raise RuntimeError("DWG konvertavimas nepavyko" + (": " + detail[:200] if detail else ""))
        text = _dxf_text(dxfs[0])[:DWG_TEXT_MAX_CHARS]
    tmp_file = cache.with_suffix(".tmp")
    tmp_file.write_text(text, encoding="utf-8")
    os.replace(tmp_file, cache)
    for old in DWG_TEXT_DIR.glob(f"dwgtext_{int(doc_id)}_*.txt"):
        if old.name != cache.name:
            try:
                old.unlink()
            except OSError:
                pass
    return text


def dwg_cache_path(doc):
    pid = int(PROJECTS_STATE.get("active") or 1)
    return DWG_CACHE_DIR / f"dwg_p{pid}_{int(doc['id'])}_{int(doc['mtime'])}.svg"


def dwg_cache_cleanup(keep=None):
    files = []
    for f in list(DWG_CACHE_DIR.glob("dwg_*.svg")) + list(DWG_CACHE_DIR.glob("dwg_*.thumb.*")):
        try:
            st = f.stat()
        except OSError:
            continue
        files.append((st.st_mtime, st.st_size, f))
    total = sum(size for _, size, _ in files)
    if total <= DWG_CACHE_MAX_BYTES:
        return
    for _, size, f in sorted(files):
        if keep is not None and f == keep:
            continue
        try:
            f.unlink()
            total -= size
        except OSError:
            continue
        if total <= DWG_CACHE_MAX_BYTES:
            break


def index_doc(row):
    doc_id = row["id"]
    path = Path(row["path"])
    ext = row["ext"]
    meta = {}
    try:
        meta = json.loads(row["meta"] or "{}")
    except Exception:
        meta = {}
    INDEX_STATE["current"] = row["name"]
    try:
        with db() as conn:
            text_rows = []
            if not path.exists():
                raise FileNotFoundError(str(path))
            if ext == ".pdf":
                pages, text_rows = _extract_pdf(path, conn, doc_id, meta)
                if not any(t.strip() for _, t in text_rows):
                    ocr_text = _ocr_pdf_text(path.read_bytes(), OCR_MAX_PAGES)
                    text_rows = [(1, ocr_text)] if ocr_text.strip() else []
                    meta["ocr"] = True if text_rows else "none"
                _save_pages(conn, doc_id, text_rows)
                text_len = sum(len(t) for _, t in text_rows)
            elif ext == ".adoc":
                adoc = _adoc_meta(path)
                meta.update({k: v for k, v in adoc.items() if v})
                inner = _adoc_inner_pdf(path, doc_id, row["mtime"])
                pages, text_rows = _extract_pdf(inner, conn, doc_id, meta)
                if not any(t.strip() for _, t in text_rows):
                    ocr_rows = _winocr_pages(inner, OCR_MAX_PAGES)
                    text_rows = ocr_rows
                    meta["ocr"] = True if ocr_rows else "none"
                _save_pages(conn, doc_id, text_rows)
                text_len = sum(len(t) for _, t in text_rows)
            elif ext in OCR_EXTS:
                ocr_rows = _winocr_pages(path, 1)
                _save_pages(conn, doc_id, ocr_rows)
                text_len = sum(len(t) for _, t in ocr_rows)
                pages = 1
                meta["ocr"] = True if ocr_rows else "none"
                if "date" not in meta:
                    meta["date"] = iso_from_ts(row["mtime"])[:10]
            elif ext in (".docx", ".xlsx", ".doc"):
                if ext == ".docx":
                    text_rows = _docx_pages(path)
                elif ext == ".doc":
                    text_rows = _windoc_pages(path)
                else:
                    text_rows = _xlsx_pages(path)
                _save_pages(conn, doc_id, text_rows)
                text_len = sum(len(t) for _, t in text_rows)
                pages = 1
                if "date" not in meta:
                    meta["date"] = iso_from_ts(row["mtime"])[:10]
            elif ext in (".txt", ".ifc"):
                text = path.read_text(encoding="utf-8", errors="replace")[:2_000_000]
                text = " ".join(text.split())
                _save_pages(conn, doc_id, [(1, text)] if text else [])
                text_len = len(text)
                pages = 1
                if "date" not in meta:
                    meta["date"] = iso_from_ts(row["mtime"])[:10]
            elif ext == ".dwg":
                text = _dwg_extract_text(path, doc_id, row["mtime"])
                _save_pages(conn, doc_id, [(1, text)] if text else [])
                text_len = len(text)
                pages = None
                meta["dwg_text"] = text_len
                if "date" not in meta:
                    meta["date"] = iso_from_ts(row["mtime"])[:10]
            else:
                pages, text_len = None, 0
            conn.execute(
                "UPDATE docs SET pages=?, text_state='done', text_len=?, meta=? WHERE id=?",
                (pages, text_len, json.dumps(meta, ensure_ascii=False), doc_id),
            )
            # Kai tekstas jau išgautas, „Įkelti“ dokumentą galima tiksliau priskirti daliai.
            if row["disc"] == UPLOAD_DISC and not row["disc_lock"]:
                code = guess_disc(row["name"], _doc_head_text(conn, doc_id))
                if code != UPLOAD_DISC:
                    conn.execute("UPDATE docs SET disc=? WHERE id=?", (code, doc_id))
            conn.commit()
        data_touch()
        INDEX_STATE["last_result"] = f"{row['name']}: {pages or 0} p."
        if ext in (".xlsx", ".pdf", ".docx", ".doc") and text_rows:
            _auto_import_f2(path, ext, row, text_rows, meta)
        if ext in (".pdf", ".docx", ".doc") and text_rows:
            try:
                info = _parse_contract_text("\n".join(t for _, t in text_rows))
                if info:
                    _auto_contract(info, row["name"])
            except Exception as e:
                logger.warning("Sutarties atpažinimas %s nepavyko: %s", row["name"], e)
    except Exception as e:
        logger.warning("Indeksavimo klaida %s: %s", row["name"], e)
        try:
            meta["error"] = str(e)[:300]
            with db() as conn:
                conn.execute("UPDATE docs SET text_state='error', meta=? WHERE id=?",
                             (json.dumps(meta, ensure_ascii=False), doc_id))
                conn.commit()
            data_touch()
        except Exception:
            pass


def indexer_loop():
    while True:
        index_event.wait(timeout=3)
        index_event.clear()
        try:
            with db() as conn:
                pending = conn.execute(
                    "SELECT * FROM docs WHERE text_state='pending' AND ext IN ('.pdf','.txt','.ifc','.adoc','.dwg','.docx','.xlsx','.doc','.jpg','.jpeg','.png','.bmp','.tif','.tiff') ORDER BY size ASC"
                ).fetchall()
            if not pending:
                if INDEX_STATE["indexing"]:
                    INDEX_STATE["indexing"] = False
                    INDEX_STATE["current"] = ""
                    INDEX_STATE["done"] = INDEX_STATE["total"] = 0
                continue
            with lock:
                INDEX_STATE["indexing"] = True
                INDEX_STATE["total"] = len(pending)
                INDEX_STATE["done"] = 0
            for row in pending:
                with db() as conn:
                    still = conn.execute("SELECT text_state FROM docs WHERE id=?", (row["id"],)).fetchone()
                if not still or still["text_state"] != "pending":
                    continue
                index_doc(row)
                with lock:
                    INDEX_STATE["done"] += 1
            with lock:
                INDEX_STATE["indexing"] = False
                INDEX_STATE["current"] = ""
        except Exception:
            logger.error("Indeksuotojo klaida: %s", traceback.format_exc())
            INDEX_STATE["indexing"] = False


def scanner_loop():
    while True:
        scan_event.wait(timeout=60)
        scan_event.clear()
        try:
            scan_files()
        except Exception:
            logger.error("Skenerio ciklo klaida: %s", traceback.format_exc())


def serialize_doc(row):
    meta = {}
    try:
        meta = json.loads(row["meta"] or "{}")
    except Exception:
        meta = {}
    mtime = row["mtime"]
    date = meta.get("date") or ""
    return {
        "id": row["id"],
        "name": row["name"],
        "ext": row["ext"],
        "disc": row["disc"],
        "discName": disc_name(row["disc"]),
        "rel": row["rel"],
        "path": row["path"],
        "size": row["size"],
        "mtime": iso_from_ts(mtime),
        "fileDate": iso_from_ts(mtime)[:10],
        "date": date,
        "pages": row["pages"],
        "textState": row["text_state"],
        "textLen": row["text_len"],
        "meta": meta,
    }


def set_doc_disc(doc_id, disc):
    """Rankinis dokumento priskyrimas daliai; tokio priskyrimo skenavimas nekeičia."""
    code = str(disc or "").strip()
    if code not in DISCIPLINES and code != UPLOAD_DISC:
        raise ValueError("Nepalaikoma dalis")
    with db() as conn:
        row = conn.execute("SELECT id FROM docs WHERE id=?", (doc_id,)).fetchone()
        if not row:
            return None
        conn.execute("UPDATE docs SET disc=?, disc_lock=1 WHERE id=?", (code, doc_id))
        conn.commit()
    data_touch()
    return code


def classify_uploaded_docs():
    """Išskirsto „Įkelti“ dokumentus į dalis pagal pavadinimą ir tekstą."""
    moved = 0
    with db() as conn:
        rows = conn.execute(
            "SELECT id,name FROM docs WHERE disc=? AND COALESCE(disc_lock,0)=0",
            (UPLOAD_DISC,)).fetchall()
        for r in rows:
            code = guess_disc(r["name"], _doc_head_text(conn, r["id"]))
            if code != UPLOAD_DISC:
                conn.execute("UPDATE docs SET disc=? WHERE id=?", (code, r["id"]))
                moved += 1
        if moved:
            conn.commit()
    if moved:
        data_touch()
    return moved


def all_docs():
    with db() as conn:
        rows = conn.execute("SELECT * FROM docs ORDER BY name COLLATE NOCASE").fetchall()
    return [serialize_doc(r) for r in rows]


def _page_text_by_name(needle, ext, page):
    with db() as conn:
        row = conn.execute(
            "SELECT p.text FROM pages p JOIN docs d ON d.id=p.doc_id "
            "WHERE d.name LIKE ? AND d.ext=? AND p.page=? ORDER BY d.id LIMIT 1",
            (f"%{needle}%", ext, page)).fetchone()
    return (row["text"] if row else "") or ""


def _doc_row(needle, ext):
    with db() as conn:
        row = conn.execute(
            "SELECT id,name,path FROM docs WHERE name LIKE ? AND ext=? ORDER BY id LIMIT 1",
            (f"%{needle}%", ext)).fetchone()
    return dict(row) if row else None


def parse_schedule(text, marker):
    """Iš PDF specifikacijos teksto ištraukia tipą, plotį, aukštį ir kiekį."""
    out = []
    for m in re.finditer(marker + r"\s+((?:[A-Z]+-[\w*]+\s*)+)", text):
        types = re.findall(r"[A-Z]+-[\w*]+", m.group(1))
        block = text[m.end():]
        kq = block.find("Kiekis")
        if kq < 0:
            continue
        body = block[:kq]
        ah = re.search(r"Aukštis,\s*mm\s+([\d\s]+)", body)
        pw = re.search(r"Plotis,\s*mm\s+([\d\s]+)", body)
        qm = re.match(r"Kiekis\s+([\d\s]+)", block[kq:])
        if not (ah and pw and qm):
            continue
        h = [int(x) for x in ah.group(1).split()]
        w = [int(x) for x in pw.group(1).split()]
        q = [int(x) for x in qm.group(1).split()]
        for i, t in enumerate(types):
            if i < len(h) and i < len(w) and i < len(q):
                out.append({"type": t, "w": w[i], "h": h[i], "qty": q[i]})
    return out


def _verify_check(checks, name, expected, actual, unit="", tol=0.01, source="", detail="", ok=None,
                  resolved=False):
    if ok is None:
        try:
            ok = abs(float(expected) - float(actual)) <= tol
        except Exception:
            ok = str(expected) == str(actual)
    checks.append({"name": name, "expected": expected, "actual": actual,
                   "unit": unit, "ok": ok, "resolved": bool(resolved),
                   "source": source, "detail": detail})


_VERIFY_CACHE = {}
_VERIFY_LOCK = threading.Lock()


def _verify_cached(key, sig):
    with _VERIFY_LOCK:
        hit = _VERIFY_CACHE.get(key)
        return hit[1] if hit and hit[0] == sig else None


def _verify_store(key, sig, data):
    with _VERIFY_LOCK:
        if len(_VERIFY_CACHE) > 16:
            _VERIFY_CACHE.clear()
        _VERIFY_CACHE[key] = (sig, data)


def verify_fasadas():
    """Lyginа fasado sąmatos kiekius su PDF, DWG ir IFC duomenimis."""
    sig = data_signature()
    cached = _verify_cached("fasadas", sig)
    if cached is not None:
        return cached
    checks = []
    tp69 = _page_text_by_name("3-SA", ".pdf", 69)
    tp70 = _page_text_by_name("3-SA", ".pdf", 70)
    sk5 = _page_text_by_name("26-659-DP-SK", ".pdf", 5)
    dwg_doc = _doc_row("Silale - SA - brez", ".dwg")
    dwg_text = _page_text_by_name("Silale - SA - brez", ".dwg", 1)
    ifc_doc = _doc_row("653_modelis", ".ifc")

    windows = parse_schedule(tp69, "Langų tipas")
    doors = parse_schedule(tp70, "Durų tipas")
    tp_qty = sum(x["qty"] for x in windows)
    tp_area = sum(x["w"] * x["h"] * x["qty"] / 1e6 for x in windows)
    tp_width = sum(x["w"] * x["qty"] / 1000 for x in windows)
    door_qty = next((x["qty"] for x in doors if x["type"] == "D-01"), 0)

    balconies = [{"len": int(m.group(1)), "qty": int(m.group(2))} for m in re.finditer(
        r"BP/\d+\s+Balkono plokšt\s*ė\s+100\*1660\s+(\d+)\s+(\d+)", sk5)]
    bal_qty = sum(b["qty"] for b in balconies)
    bal_len = sum(b["len"] * b["qty"] / 1000 for b in balconies)
    bal_area = bal_len * 1.66
    ifc_count = 0
    if ifc_doc:
        try:
            data = Path(ifc_doc["path"]).read_text(encoding="utf-8", errors="replace")
            ifc_count = len(re.findall(
                r"IFCELEMENTASSEMBLY\('[^']*',#\d+,'Balkono plokste'", data))
        except OSError:
            ifc_count = 0

    with db() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM works WHERE section='fasadas' ORDER BY ord, id").fetchall()]
    by_code = {r["code"]: r for r in rows}
    win_rows = {}
    for r in rows:
        parts = str(r["title"] or "").split()
        if len(parts) > 1 and parts[0] == "Langų" and parts[1].startswith("L-"):
            win_rows[parts[1]] = r
    works_win_qty = sum(float(r["qty"] or 0) for r in win_rows.values())

    def q(code):
        return float((by_code.get(code) or {}).get("qty") or 0)

    gross = (24.94 + 15.44) * 2 * 12.85
    perimeter = (24.94 + 15.44) * 2
    net = gross - tp_area
    cokolis = perimeter * 0.5

    dwg_marks = set(re.findall(r"L-\d+[ab]?\*?", dwg_text))
    dwg_ok = bool(dwg_doc) and "24940" in dwg_text and "15440" in dwg_text and "+12,850" in dwg_text
    missing_marks = sorted({"L-15", "L-16", "L-16*"} - dwg_marks)
    extra_marks = sorted(dwg_marks - {x["type"] for x in windows})

    mismatches = []
    for x in windows:
        got = float((win_rows.get(x["type"]) or {}).get("qty") or 0)
        if abs(got - x["qty"]) > 1e-9:
            mismatches.append(f"{x['type']}: TP {x['qty']} → sąmata {got:g}")

    _verify_check(checks, "Langų skaičius", tp_qty, int(works_win_qty), "vnt.",
                  source="3-SA l. 69 ↔ sąmata F-08–F-31",
                  detail=f"TP langų specifikacijoje {len(windows)} tipai.")
    _verify_check(checks, "Langų tipų kiekiai", "24 tipai sutampa",
                  "sutampa" if not mismatches else f"{len(mismatches)} neatitikimai",
                  source="3-SA l. 69 ↔ sąmata", detail="; ".join(mismatches) or "Visų tipų kiekiai sutampa.",
                  ok=not mismatches)
    _verify_check(checks, "Langų plotas", round(tp_area, 2),
                  round(q("F-01") - q("F-02"), 2), "m²", tol=0.1,
                  source="3-SA l. 69 ↔ F-01 − F-02",
                  detail="Fasado bendras plotas − nelanginė dalis.")
    _verify_check(checks, "Langų plotis (palangės)", round(tp_width, 2), q("F-32"), "m", tol=0.1,
                  source="3-SA l. 69 ↔ F-32")
    _verify_check(checks, "Lauko durys D-01", door_qty, int(q("F-07")), "vnt.",
                  source="3-SA l. 70 ↔ F-07",
                  detail="D-01 1000 × 2100, lauko durys.")
    _verify_check(checks, "Balkonų plokštės", bal_qty, ifc_count, "vnt.", tol=0,
                  source="6-SK l. 5 ↔ IFC 21 montavimo mazgas")
    _verify_check(checks, "Balkonų ilgis", round(bal_len, 2), q("F-35"), "m", tol=0.1,
                  source="6-SK l. 5 ↔ F-35")
    _verify_check(checks, "Balkonų šiltinimo plotas", round(bal_area, 2), q("F-34"), "m²", tol=0.1,
                  source="6-SK l. 5 ↔ F-34")
    _verify_check(checks, "Pastato matmenys (DWG)", "24 940 × 15 440 mm",
                  "sutampa" if dwg_ok else "nesutampa", source="DWG 2026-04-14",
                  detail="DWG plane rasti 24940, 15440 ir +12,850 žymėjimai.", ok=dwg_ok)
    _verify_check(checks, "DWG langų žymos", "L-15, L-16, L-16*",
                  "rastos" if not missing_marks and not extra_marks else "neatitinka",
                  source="DWG 2026-04-14 ↔ 3-SA l. 69",
                  detail=("Trūksta: " + ", ".join(missing_marks) if missing_marks else
                          "Žymos atitinka TP" + (f"; svetimos: {', '.join(extra_marks)}" if extra_marks else "")),
                  ok=bool(dwg_doc) and not missing_marks and not extra_marks)
    _verify_check(checks, "Pastato perimetras (parapetas)", round(perimeter, 2), q("F-33"), "m", tol=0.1,
                  source="DWG matmenys ↔ F-33")
    _verify_check(checks, "Fasado bendras plotas", round(gross, 2), q("F-01"), "m²", tol=0.1,
                  source="DWG matmenys × 12,85 m ↔ F-01")
    _verify_check(checks, "Fasado neto plotas", round(net, 2), q("F-02"), "m²", tol=0.1,
                  source="F-01 − langų plotas ↔ F-02")
    _verify_check(checks, "Cokolis", round(cokolis, 2), q("F-06"), "m²", tol=0.1,
                  source="Perimetras × 0,5 m ↔ F-06")
    _verify_check(checks, "Klinkerio apdaila", round(net - cokolis, 2), q("F-05"), "m²", tol=0.1,
                  source="Neto plotas − cokolis ↔ F-05")
    door_perim = 2 * (1.0 + 2.1) * door_qty
    joints = 2 * tp_width + sum(x["h"] * x["qty"] * 2 / 1000 for x in windows) + door_perim
    _verify_check(checks, "Angų siūlių ilgis", round(joints, 2), q("F-36"), "m", tol=0.1,
                  source="3-SA l. 69–70 ↔ F-36")
    _verify_check(checks, "Sąmatos pozicijų skaičius", 36, len(rows), "vnt.", tol=0,
                  source="Sąmata")

    decisions = decisions_map()
    for c in checks:
        if c["ok"] or c.get("resolved"):
            continue
        ptype = "Kvadratūra" if (c.get("unit") or "") == "m²" else "Kiekis"
        if decision_key(ptype, "fasadas", c.get("name") or "") in decisions:
            c["resolved"] = True

    ok_count = sum(1 for c in checks if c["ok"] or c.get("resolved"))
    resolved_count = sum(1 for c in checks if c.get("resolved") and not c["ok"])
    result = {
        "section": "fasadas",
        "generated": now_iso(),
        "summary": {"total": len(checks), "ok": ok_count, "bad": len(checks) - ok_count,
                    "resolved": resolved_count},
        "checks": checks,
        "sources": [
            {"label": "3-SA.pdf (TP 2023)", "info": "Langų specifikacija l. 69; durų specifikacija l. 70"},
            {"label": "Silale - SA - brez - 2026-04-14.dwg", "info": "Fasadų išklotinės, matmenys 24 940 × 15 440, +12,850"},
            {"label": "26-659-DP-SK.pdf (2026)", "info": "Balkonų plokščių žiniaraštis l. 5"},
            {"label": "653_modelis.ifc", "info": "21 balkono plokštės montavimo mazgas"},
        ],
    }
    _verify_store("fasadas", sig, result)
    return result


# --- kiekių žiniaraščių nuskaitymas ---

SCHEDULE_UNIT_MAP = {
    "m²": "m2", "m2": "m2", "m³": "m3", "m3": "m3", "m": "m",
    "kompl": "kompl", "kompl.": "kompl", "vnt": "vnt", "vnt.": "vnt",
    "kg": "kg", "t": "t", "ltr": "ltr",
}
SCHEDULE_PAIR_RE = re.compile(
    r"(?:(?P<u100>100)\s*)?"
    r"(?P<unit>vnt\.?\s*/\s*m3|vnt\.?\s*/\s*m2|m2|m3|m²|m³|kompl\.?|vnt\.?|kg|t|ltr|m)\s+"
    r"(?P<qty>\d+(?:[ \u00a0]\d{3})*(?:[,.]\d+)?(?:\s*/\s*\d+(?:[,.]\d+)?)?)",
    re.I)
SCHEDULE_MARK_RE = re.compile(
    r"(?<!TS )(?<!TS\u00a0)(?<![A-Za-zĄČĘĖĮŠŲŪŽąčęėįšųūž0-9,.\-])"
    r"(\d{1,2})\.(?!\d)\s+")

SCHEDULE_SOURCES = [
    {
        "key": "santechnika", "section": "santechnika",
        "label": "LVN kiekių žiniaraštis",
        "doc": "LVN Vytauto Didziojo", "doc_label": "26-01-01-TDP-LVN.SŽ",
        "pages": [29, 30, 31], "page_label": "l. 29–31",
        "note": "Vandentiekio, buitinių ir lietaus nuotekų tinklai, vandens apskaitos mazgas",
    },
    {
        "key": "elektra", "section": "elektra",
        "label": "E.SŽ kiekių žiniaraštis",
        "doc": "5269-TDP-E", "doc_label": "25-E-5269-TDP-E.SŽ",
        "pages": [66, 67, 68, 69], "page_label": "l. 66–69",
        "note": "0,4 kV kabelių linijų darbai, transformatorinės pertvarkymas ir kitos išlaidos",
    },
    {
        "key": "sklypas", "section": "",
        "label": "Sklypo kiekių žiniaraštis",
        "doc": "2-SP", "doc_label": "2-SP Sąnaudų kiekių žiniaraštis",
        "pages": [26], "page_label": "l. 26",
        "note": "Sklypo sutvarkymo darbai; sąmatoje atskiros sklypo sekcijos nėra",
    },
]

SCHEDULE_STOP = set("""su visomis reikalingomis jungtimis ir deta lemis detalėmis įvertinant gerbūvio dangų ardymą
atstatymą žemės darbus smėlio pagrindo įrengimą po vamzdžiais bei užpylimą smėliu sutankinimą
skersmens slėgio klasės klojamas jo įrengimas projektuojamo esamo sudaro visa reikalinga izoliacija
protarpiais armatūra reikiamos paskirties dangčiu nužymėjimo ženklu žymėjimas plane viso
apvalaus lietus surinkimo grotelėmis plaukiojančio tipo dangčiu komplekta komplektą
planuojama sutvarkyti remonto apimtis nustatoma vietoje įvertinus techninę būklę poreikio
atliekami šie darbai naujų latakų išbetonavimas tekėjimui sienelių hidroizoliacija perdangų
paaukštinimo žiedų liukų keitimas atviru uždaru būdu požeminė kryptiniu gręžimu
mechanizuotu rankiniu būdu mm ts""".split())


def _sched_norm(text):
    return re.sub(r"\s+", " ", (text or "").replace("\u00a0", " ")).strip()


def _sched_num(raw):
    raw = raw.replace(" ", "").replace("\u00a0", "").replace(",", ".")
    try:
        return float(raw)
    except ValueError:
        return 0.0


def _sched_unit(unit):
    unit = (unit or "").strip().lower()
    return SCHEDULE_UNIT_MAP.get(unit, unit.rstrip("."))


def _sched_is_heading(title):
    low = title.lower()
    if "žiniaraštis" in low:
        return True
    if len(title) > 32:
        return False
    return "tinklai" in low or "mazgas" in low or "kitos išlaidos" in low


def _sched_pairs(body):
    return [p for p in SCHEDULE_PAIR_RE.finditer(body)
            if not re.search(r"[-–−]\s*$", body[max(0, p.start() - 2):p.start()])]


def _sched_emit(rows, head, num, label, title, pair, page):
    unit = pair.group("unit").lower().replace(" ", "")
    qraw = pair.group("qty")
    mult = 100.0 if pair.group("u100") else 1.0
    title = _sched_norm(title).strip(" .;:-,")
    title = re.sub(r"^(?:[a-z]\)\s*)", "", title)
    if not title:
        return
    kind = "materials" if "medžiag" in (head + " " + title).lower() else "work"
    base = {"head": head, "num": num, "label": label, "title": title,
            "page": page, "kind": kind, "parent": "viso" in title.lower()}
    if "/" in qraw:
        first, second = [x.strip() for x in qraw.split("/", 1)]
        unit1 = "vnt" if unit.startswith("vnt") else SCHEDULE_UNIT_MAP.get(unit, unit)
        for u, q in ((unit1, _sched_num(first)), ("m3", _sched_num(second))):
            rows.append({**base, "unit": u, "qty": q})
        return
    unit = "vnt" if unit.startswith("vnt/") else SCHEDULE_UNIT_MAP.get(unit, unit)
    rows.append({**base, "unit": unit, "qty": _sched_num(qraw) * mult})


def _parse_schedule_pages(page_texts, first_page):
    """Nuskaito sąnaudų žiniaraščio eilutes iš PDF puslapių teksto."""
    texts = [_sched_norm(t) for t in page_texts]
    offsets, pos = [], 0
    for t in texts:
        offsets.append(pos)
        pos += len(t) + 1
    text = " ".join(texts)
    marks = list(SCHEDULE_MARK_RE.finditer(text))

    def page_of(at):
        idx = 0
        for i, off in enumerate(offsets):
            if at >= off:
                idx = i
        return first_page + idx

    rows, head = [], ""
    expected, comp_next, pending = 1, 1, None

    def finalize():
        nonlocal pending
        if pending and pending.get("pair"):
            _sched_emit(rows, pending["head"], pending["num"], None,
                        pending["title"], pending["pair"], pending["page"])
        pending = None

    for i, mark in enumerate(marks):
        end = marks[i + 1].start() if i + 1 < len(marks) else len(text)
        body = text[mark.end():end].strip()
        num = int(mark.group(1))
        page = page_of(mark.start())
        pairs = _sched_pairs(body)
        if pending is not None:
            if num == comp_next:
                comp_next += 1
                if pairs:
                    pending["pair"] = pairs[-1]
                continue
            if num == expected:
                finalize()
            else:
                comp_next = max(comp_next, num + 1)
                if pairs:
                    pending["pair"] = pairs[-1]
                continue
        if "sudaro" in body.lower() and not pairs and num == expected:
            pending = {"head": head, "num": num, "page": page,
                       "title": body.split(" sudaro")[0].strip(" .;:-,"), "pair": None}
            comp_next, expected = 1, num + 1
            continue
        if not pairs:
            head_txt = body.split(" Eil. Nr.")[0].strip(" .;:-")
            if _sched_is_heading(head_txt):
                head = head_txt
                expected = 1
            continue
        if num == expected:
            expected = num + 1
        elif num < expected:
            continue
        else:
            expected = num + 1
        labels = [(lm.start(), lm.group(1)) for lm in
                  re.finditer(r"(?<![A-Za-zĄČĘĖĮŠŲŪŽąčęėįšųūž])([a-z])\)", body)]
        if labels:
            used, last_end = set(), 0
            for pair in pairs:
                lab, lpos = None, None
                for lp, lt in labels:
                    if lp < pair.start() and lt not in used:
                        lab, lpos = lt, lp
                if lab:
                    used.add(lab)
                    _sched_emit(rows, head, num, lab, body[lpos + 2:pair.start()], pair, page)
                elif lpos is None:
                    _sched_emit(rows, head, num, None, body[:pair.start()], pair, page)
                else:
                    _sched_emit(rows, head, num, None, body[last_end:pair.start()], pair, page)
                last_end = pair.end()
        else:
            pair = pairs[-1]
            _sched_emit(rows, head, num, None, body[:pair.start()], pair, page)
    finalize()
    return rows


def _sched_tokens(title):
    text = unicodedata.normalize("NFKD", (title or "").lower())
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = re.sub(r"\(.*?\)", " ", text)
    text = re.sub(r"([A-Za-z])\s*/\s*([A-Za-z])", r"\1\2", text)
    text = re.sub(r"(\d)\s*(mm2|mm|m2|m3|kv)\b", r"\1 \2", text)
    text = text.replace("ø", " d").replace("φ", " d").replace("~", " ")
    return {x for x in re.findall(r"[a-z0-9]+", text)
            if len(x) >= 2 and x not in SCHEDULE_STOP}


def _sched_tok_eq(a, b):
    if a == b:
        return True
    if len(a) >= 5 and len(b) >= 5 and (a in b or b in a):
        return True
    common = 0
    for x, y in zip(a, b):
        if x != y:
            break
        common += 1
    return common >= 4


def _sched_sim(a, b):
    left, right = _sched_tokens(a), _sched_tokens(b)
    if not left or not right:
        return 0.0
    inter = sum(1 for x in left if any(_sched_tok_eq(x, y) for y in right))
    return inter / (len(left) * len(right)) ** 0.5


def _sched_unit_ok(work_unit, row_unit):
    return work_unit == row_unit or {work_unit, row_unit} <= {"vnt", "kompl"}


def _schedule_works(rows, source):
    """Atrenka sąmatos pozicijas, kurių kiekis paimtas iš šio žiniaraščio."""
    pages = {str(p) for p in source["pages"]}
    picked = []
    for row in rows:
        if (row.get("kind") or "") == "Skaičiuojama":
            continue
        if source["section"] == "santechnika":
            src = row.get("source_name") or ""
            basis = row.get("basis") or ""
            by_src = "LVN" in src and str(row.get("source_page") or "") in pages
            by_basis = "LVN" in basis and "l. 31" in basis
            if by_src or by_basis:
                picked.append(row)
        elif source["section"] == "elektra":
            if "5269-TDP-E" in (row.get("source_name") or ""):
                picked.append(row)
    return picked


def _match_schedules(works, parsed):
    candidates = []
    for wi, work in enumerate(works):
        work_unit = _sched_unit(work.get("unit"))
        work_page = str(work.get("source_page") or "")
        title = str(work.get("title") or "").lower()
        for ri, row in enumerate(parsed):
            if not _sched_unit_ok(work_unit, row["unit"]):
                continue
            score = _sched_sim(work.get("title") or "", row["title"] + " " + row["head"])
            if "lietaus" in title and "Lietaus" in row["head"]:
                score += 0.18
            if "buitin" in title and "Buitini" in row["head"]:
                score += 0.18
            if work_page and work_page == str(row["page"]):
                score += 0.12
            if score >= 0.28:
                candidates.append((score, wi, ri))
    candidates.sort(key=lambda item: -item[0])
    matched, used = {}, set()
    for score, wi, ri in candidates:
        if wi in matched or ri in used:
            continue
        if score < 0.38:
            break
        matched[wi] = {"score": score, "row": ri}
        used.add(ri)
    for wi, work in enumerate(works):
        if wi in matched:
            continue
        work_unit = _sched_unit(work.get("unit"))
        work_page = str(work.get("source_page") or "")
        best = None
        for ri, row in enumerate(parsed):
            if ri in used or _sched_unit_ok(work_unit, row["unit"]):
                continue
            if not ({work_unit, row["unit"]} & {"vnt", "kompl"}):
                continue
            score = _sched_sim(work.get("title") or "", row["title"] + " " + row["head"])
            if work_page and work_page == str(row["page"]):
                score += 0.12
            if score >= 0.5 and abs(float(work.get("qty") or 0) - row["qty"]) < 0.005:
                if best is None or score > best[0]:
                    best = (score, ri)
        if best:
            matched[wi] = {"score": best[0], "row": best[1]}
            used.add(best[1])
    return matched, used


def _sched_row_payload(row):
    return {"page": row["page"], "num": row["num"], "label": row["label"],
            "head": row["head"], "unit": row["unit"], "qty": row["qty"],
            "title": row["title"], "kind": row["kind"]}


def _sched_extra_row(row):
    return not row["label"] and not row["parent"] and row["kind"] != "materials" and row["qty"] > 0


def build_schedule_coverage(rows):
    """Susieja žiniaraščių eilutes su sąmatos pozicijomis ir grąžina dangą."""
    result = []
    decisions = decisions_map()
    for source in SCHEDULE_SOURCES:
        doc = _doc_row(source["doc"], ".pdf")
        entry = {
            "key": source["key"], "section": source["section"],
            "label": source["label"], "doc": source["doc_label"],
            "docId": doc["id"] if doc else None, "docName": doc["name"] if doc else "",
            "pages": source["pages"], "pageLabel": source["page_label"],
            "note": source["note"], "kind": "sched", "status": "missing",
            "summary": {"rows": 0, "works": 0, "matched": 0, "ok": 0, "diff": 0,
                        "unit": 0, "missingWorks": 0, "ignored": 0, "extra": 0,
                        "resolvedIssues": 0},
            "matches": [], "byCode": {}, "extras": [], "extrasResolved": False,
            "resolved": False,
        }
        if not doc:
            result.append(entry)
            continue
        with db() as conn:
            texts = []
            for page in source["pages"]:
                row = conn.execute("SELECT text FROM pages WHERE doc_id=? AND page=?",
                                   (doc["id"], page)).fetchone()
                texts.append((row["text"] if row else "") or "")
        parsed = _parse_schedule_pages(texts, source["pages"][0])
        works = _schedule_works(rows, source) if source["section"] else []
        matched, used = _match_schedules(works, parsed) if works else ({}, set())
        entry["summary"]["rows"] = len(parsed)
        entry["summary"]["works"] = len(works)
        for wi, work in enumerate(works):
            code = str(work.get("code") or "")
            payload = {"code": code, "workId": work.get("id"), "title": work.get("title") or "",
                       "unit": _sched_unit(work.get("unit")), "qty": float(work.get("qty") or 0)}
            if wi in matched:
                score, ri = matched[wi]["score"], matched[wi]["row"]
                row = parsed[ri]
                same_unit = _sched_unit_ok(payload["unit"], row["unit"])
                if not same_unit:
                    status = "unit"
                elif abs(payload["qty"] - row["qty"]) < 0.005:
                    status = "ok"
                else:
                    status = "diff"
                payload.update({"status": status, "sim": round(score, 2), "row": _sched_row_payload(row)})
                if status == "unit":
                    title = f"{code}: žiniaraštyje nurodytas kitas matavimo vienetas"
                elif status == "diff":
                    title = f"{code}: kiekis nesutampa su kiekių žiniaraščiu"
                else:
                    title = ""
                payload["resolved"] = bool(title) and decision_key("Kiekis", source["section"], title) in decisions
            else:
                payload.update({"status": "missing", "sim": 0, "row": None})
                payload["resolved"] = decision_key(
                    "Reikalavimas", source["section"],
                    f"{code}: kiekių žiniaraštyje nėra tiesioginės eilutės") in decisions
            entry["summary"][payload["status"] if payload["status"] != "missing" else "missingWorks"] += 1
            entry["matches"].append(payload)
            entry["byCode"][code] = {"status": payload["status"], "row": payload["row"],
                                     "qty": payload["qty"], "unit": payload["unit"],
                                     "resolved": payload.get("resolved", False)}
        entry["summary"]["matched"] = len(matched)
        entry["summary"]["ignored"] = (len(parsed) - len(used)) if works else 0
        extras = [row for i, row in enumerate(parsed) if i not in used and _sched_extra_row(row)]
        entry["summary"]["extra"] = len(extras)
        entry["extras"] = [_sched_row_payload(row) for row in extras[:8]]
        entry["extrasResolved"] = bool(extras) and decision_key(
            "Kiekis", source["section"],
            f"{source['label']}: eilučių be sąmatos pozicijų") in decisions
        bad = entry["summary"]["diff"] + entry["summary"]["unit"] + entry["summary"]["missingWorks"]
        entry["summary"]["resolvedIssues"] = sum(
            1 for m in entry["matches"] if m.get("resolved")) + (1 if entry["extrasResolved"] else 0)
        if not works:
            entry["status"] = "no-works"
            entry["resolved"] = decision_key(
                "Kiekis", "", "Sklypo kiekių žiniaraštis neturi sąmatos pozicijų") in decisions
            entry["summary"]["resolvedIssues"] = 1 if entry["resolved"] else 0
        elif bad:
            entry["status"] = "bad"
        else:
            entry["status"] = "ok"
        entry["summary"]["bad"] = bad
        result.append(entry)

    doors = _door_spec(rows)
    if doors:
        doors["resolved"] = decision_key(
            "Kiekis", "apdaila", "Durų kiekis sąmatoje skiriasi nuo specifikacijos") in decisions
        doors["summary"]["resolvedIssues"] = 1 if doors["resolved"] else 0
        result.append(doors)
    return result


def _door_spec(rows):
    text = _page_text_by_name("3-SA", ".pdf", 70)
    doors = parse_schedule(text, "Durų tipas")
    if not doors:
        return None
    doc = _doc_row("3-SA", ".pdf")
    by_code = {str(r.get("code") or ""): float(r.get("qty") or 0) for r in rows}
    spec_total = sum(d["qty"] for d in doors)
    spec_inner = sum(d["qty"] for d in doors if d["type"] != "D-01")
    works_total = by_code.get("A-13", 0.0) + by_code.get("A-14", 0.0)
    works_inner = by_code.get("A-13", 0.0)
    diff = works_total - spec_total
    return {
        "key": "durys", "section": "apdaila", "kind": "spec",
        "label": "Durų specifikacija", "doc": "3-SA.pdf",
        "docId": doc["id"] if doc else None, "docName": doc["name"] if doc else "",
        "pages": [70], "pageLabel": "l. 70",
        "note": f"D-01–D-08 tipai; D-01 lauko durys, D-02–D-08 vidaus durys",
        "status": "bad" if abs(diff) > 0.5 else "ok",
        "summary": {"rows": len(doors), "works": 2, "matched": 2,
                    "specTotal": spec_total, "specInner": spec_inner,
                    "worksTotal": works_total, "worksInner": works_inner,
                    "diff": diff, "extra": 0, "ignored": 0,
                    "ok": 1 if abs(diff) <= 0.5 else 0,
                    "diffQty": 0 if abs(diff) <= 0.5 else 1,
                    "unit": 0, "missingWorks": 0},
        "matches": [], "byCode": {}, "extras": [],
        "types": [{"type": d["type"], "w": d["w"], "h": d["h"], "qty": d["qty"]} for d in doors],
    }


def verify_quantities(section):
    """Kiekių žiniaraščio patikra vienai sąmatos sekcijai."""
    sig = data_signature()
    cached = _verify_cached("q:" + section, sig)
    if cached is not None:
        return cached
    with db() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM works WHERE section=? ORDER BY ord, id", (section,)).fetchall()]
    coverage = build_schedule_coverage(rows)
    entry = next((c for c in coverage if c["section"] == section), None)
    checks = []
    if not entry:
        empty = {"section": section, "generated": now_iso(),
                 "summary": {"total": 0, "ok": 0, "bad": 0}, "checks": [], "sources": []}
        _verify_store("q:" + section, sig, empty)
        return empty
    if entry.get("kind") == "spec":
        summary = entry["summary"]
        _verify_check(checks, "Bendras durų kiekis (specifikacija)", summary["specTotal"],
                      summary["worksTotal"], "vnt.",
                      source="3-SA l. 70 ↔ A-13 + A-14",
                      detail=(f"D-01 1 vnt. + D-02–D-08 {summary['specInner']} vnt.; "
                              f"sąmatoje A-13 {summary['worksInner']:g} + A-14 "
                              f"{summary['worksTotal'] - summary['worksInner']:g} vnt."),
                      resolved=entry.get("resolved", False))
        _verify_check(checks, "Vidaus durų kiekis D-02–D-08", summary["specInner"],
                      summary["worksInner"], "vnt.", source="3-SA l. 70 ↔ A-13",
                      detail="Skirtumas gali būti butų įėjimo durų A-14 įtraukimas.",
                      resolved=entry.get("resolved", False))
    else:
        for item in entry["matches"]:
            row = item.get("row") or {}
            if item["status"] == "ok":
                _verify_check(checks, f"{item['code']} · {item['title']}", item["qty"],
                              item["qty"], item["unit"], tol=0,
                              source=f"l. {row.get('page')}",
                              detail=row.get("title") or "")
            elif item["status"] == "diff":
                _verify_check(checks, f"{item['code']} · {item['title']}", row.get("qty"),
                              item["qty"], item["unit"], tol=0,
                              source=f"l. {row.get('page')}",
                              detail="Kiekis žiniaraštyje nesutampa su sąmata.",
                              resolved=item.get("resolved", False))
            elif item["status"] == "unit":
                _verify_check(checks, f"{item['code']} · {item['title']}",
                              f"{row.get('qty'):g} {row.get('unit')}",
                              f"{item['qty']:g} {item['unit']}",
                              source=f"l. {row.get('page')}",
                              detail="Matavimo vienetas žiniaraštyje skiriasi nuo sąmatos.",
                              resolved=item.get("resolved", False))
            else:
                _verify_check(checks, f"{item['code']} · {item['title']}", "Eilutė žiniaraštyje",
                              "Nerasta", source=entry["doc"],
                              detail="Kiekis sąmatoje neturi tiesioginės žiniaraščio eilutės.",
                              resolved=item.get("resolved", False))
        if entry["extras"]:
            _verify_check(checks, "Žiniaraščio eilutės be sąmatos pozicijos", "Visos eilutės susietos",
                          f"{entry['summary']['extra']} nesusietos", source=entry["doc"],
                          detail="; ".join(f"l. {r['page']}: {r['title'][:60]} ({r['qty']:g} {r['unit']})"
                                           for r in entry["extras"][:4]),
                          ok=False, resolved=entry.get("extrasResolved", False))
    sources = [{"label": entry["doc"], "info": f"{entry['pageLabel']} · {entry['note']}"}]
    ok_count = sum(1 for c in checks if c["ok"] or c["resolved"])
    resolved_count = sum(1 for c in checks if c["resolved"] and not c["ok"])
    result = {"section": section, "generated": now_iso(),
              "title": "Kiekių patikra pagal žiniaraštį",
              "summary": {"total": len(checks), "ok": ok_count, "bad": len(checks) - ok_count,
                          "resolved": resolved_count},
              "checks": checks, "sources": sources}
    _verify_store("q:" + section, sig, result)
    return result


# --- viso pastato nesutapimų registras ---

PROBLEM_TYPES = ["Kvadratūra", "Kiekis", "Kaina", "Reikalavimas", "Normatyvas"]
PROBLEM_SEVERITY_ORDER = {"high": 0, "medium": 1, "info": 2}

NORM_REFERENCES = [
    ("STR 1.01.03", "Statinio projektavimas, projekto ekspertizė", '"STR 1.01.03"'),
    ("STR 2.01.01", "Architektūriniai sprendiniai", '"STR 2.01.01"'),
    ("STR 2.05.13", "Statinių konstrukcijos. Grindys", '"STR 2.05.13"'),
    ("RSN 26-90", "Vandens vartojimo normos", '"RSN 26-90"'),
    ("LST EN 1090", "Plieno konstrukcijų atlikimo klasė EXC2", '"EN 1090"'),
    ("Gaisrinė sauga", "Gaisrinės saugos reikalavimai", '"Gaisrin*"'),
]

_PROBLEMS_CACHE = {"ts": 0.0, "data": None, "sig": ""}
_PROBLEMS_LOCK = threading.Lock()
_PROBLEMS_BUILD_LOCK = threading.Lock()


def problems_invalidate():
    with _PROBLEMS_LOCK:
        _PROBLEMS_CACHE["ts"] = 0.0
        _PROBLEMS_CACHE["data"] = None
        _PROBLEMS_CACHE["sig"] = ""
    data_touch()


def _lt_num(value, dec=2):
    try:
        v = float(value)
    except (TypeError, ValueError):
        return str(value)
    return f"{v:,.{dec}f}".replace(",", " ").replace(".", ",")


def build_problems(force=False):
    sig = data_signature()
    with _PROBLEMS_LOCK:
        cached = _PROBLEMS_CACHE["data"]
        if cached and not force and _PROBLEMS_CACHE["sig"] == sig:
            return cached
    with _PROBLEMS_BUILD_LOCK:
        with _PROBLEMS_LOCK:
            cached = _PROBLEMS_CACHE["data"]
            if cached and not force and _PROBLEMS_CACHE["sig"] == sig:
                return cached
        return _build_problems_now(force)


def _build_problems_now(force=False):
    """Agreguoja viso pastato nesutapimus iš sąmatų, BD rodiklių, DWG ir dokumentų."""
    sig = data_signature()
    items, resolved_items, checks = [], [], []
    decisions = decisions_map()
    labels = {k: v["label"] for k, v in WORK_SECTIONS.items()}

    def check(ok, *, ptype, severity, section, title, detail,
              expected="", actual="", source="", action="", codes=None):
        checks.append(bool(ok))
        if ok:
            return
        item = {
            "id": f"p{len(items) + 1}", "type": ptype, "severity": severity,
            "section": section, "sectionLabel": labels.get(section, "Visas pastatas"),
            "title": title, "detail": detail, "expected": expected, "actual": actual,
            "source": source, "action": action, "codes": codes or [],
        }
        dec = decisions.get(decision_key(ptype, section, title))
        if dec:
            item["id"] = f"r{len(resolved_items) + 1}"
            item["resolved"] = True
            item["decision"] = dec
            resolved_items.append(item)
        else:
            items.append(item)

    with db() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM works ORDER BY section, ord, id").fetchall()]
    by_code = {str(r.get("code") or ""): r for r in rows}

    def qty(code):
        try:
            return float((by_code.get(code) or {}).get("qty") or 0)
        except (TypeError, ValueError):
            return 0.0

    base = qty("A-03") or qty("A-04") or qty("A-06")
    a01, a03, a04, a05 = qty("A-01"), qty("A-03"), qty("A-04"), qty("A-05")
    a06, a07, a10, a16 = qty("A-06"), qty("A-07"), qty("A-10"), qty("A-16")

    bd_text = _page_text_by_name("1-BD", ".pdf", 7)
    official = 0.0
    m_area = re.search(r"Antžeminis plotas\s*m²\s*([\d\s]+[,.]\d+)", bd_text)
    if m_area:
        try:
            official = float(m_area.group(1).replace(" ", "").replace("\u00a0", "").replace(",", "."))
        except ValueError:
            official = 0.0
    bd_height = 0.0
    m_height = re.search(r"pastato aukštis\s*m\s*(\d+(?:[,.]\d+)?)", bd_text)
    if m_height:
        try:
            bd_height = float(m_height.group(1).replace(",", "."))
        except ValueError:
            bd_height = 0.0

    base_codes = [c for c in ("A-03", "A-04", "A-06") if qty(c)]
    if base and official:
        diff = base - official
        check(abs(diff) < 0.05, ptype="Kvadratūra", severity="medium", section="apdaila",
              title="Bendrasis plotas sąmatoje nesutampa su BD rodikliais",
              detail=(f"Sąmatoje naudojama {_lt_num(base)} m², BD l. 7 nurodyta "
                      f"{_lt_num(official)} m². Skirtumas "
                      f"{'+' if diff > 0 else '−'}{_lt_num(abs(diff))} m²."),
              expected=f"{_lt_num(official)} m²", actual=f"{_lt_num(base)} m²",
              source="1-BD l. 7 (Bendrieji statinio rodikliai) ↔ apdaila A-03/A-04/A-06",
              action="Perskaičiuoti apdailos kiekius pagal patvirtintą bendrąjį plotą arba paaiškinti skirtumą.",
              codes=base_codes)
    elif base and not official:
        check(False, ptype="Reikalavimas", severity="info", section="apdaila",
              title="BD bendrasis plotas neperskaitytas",
              detail="Nepavyko rasti 1-BD l. 7 bendrojo ploto – kvadratūros patikra atlikta tik tarp sąmatos eilučių.",
              expected="1-BD l. 7 rodikliai", actual="Nerasta",
              source="1-BD l. 7", action="Patikrinti, ar BD dokumentas suindeksuotas.",
              codes=[])

    if a03 and a04:
        check(abs(a03 - a04) < 0.05, ptype="Kvadratūra", severity="medium", section="apdaila",
              title="Lubų glaistymo ir dažymo plotai nesutampa",
              detail=f"A-03 {_lt_num(a03)} m², A-04 {_lt_num(a04)} m².",
              expected=f"{_lt_num(a03)} m²", actual=f"{_lt_num(a04)} m²",
              source="Apdaila A-03 ↔ A-04", action="Sulyginti lubų plotus.",
              codes=["A-03", "A-04"])
    if a04 and a06:
        check(abs(a04 - a06) < 0.05, ptype="Kvadratūra", severity="medium", section="apdaila",
              title="Lubų ir grindų plotai nesutampa",
              detail=f"A-04 lubos {_lt_num(a04)} m², A-06 grindys {_lt_num(a06)} m².",
              expected=f"{_lt_num(a04)} m²", actual=f"{_lt_num(a06)} m²",
              source="Apdaila A-04 ↔ A-06", action="Sulyginti lubų ir grindų plotus.",
              codes=["A-04", "A-06"])
    if a01 and a03:
        wall_exp = a03 * 2.5
        check(abs(a01 - wall_exp) < 0.05, ptype="Kvadratūra", severity="medium", section="apdaila",
              title="Sienų plotas neatitinka 2,5 × grindų ploto",
              detail=f"A-01 {_lt_num(a01)} m², pagal 2,5 koeficientą turėtų būti {_lt_num(wall_exp)} m².",
              expected=f"{_lt_num(wall_exp)} m²", actual=f"{_lt_num(a01)} m²",
              source="Apdaila A-01 ↔ A-03 × 2,5", action="Perskaičiuoti sienų plotą.",
              codes=["A-01", "A-03"])
    if a01 and a03 and a05:
        grunt = a01 + a03
        check(abs(a05 - grunt) < 0.05, ptype="Kvadratūra", severity="medium", section="apdaila",
              title="Gruntavimo plotas neatitinka sienų ir lubų sumos",
              detail=f"A-05 {_lt_num(a05)} m², A-01 + A-03 = {_lt_num(grunt)} m².",
              expected=f"{_lt_num(grunt)} m²", actual=f"{_lt_num(a05)} m²",
              source="Apdaila A-05 ↔ A-01 + A-03", action="Perskaičiuoti gruntavimo plotą.",
              codes=["A-05"])
    if a03 and a07 and a10:
        vinyl = a03 - a07
        check(abs(a10 - vinyl) < 0.05, ptype="Kvadratūra", severity="medium", section="apdaila",
              title="Vinilo grindų plotas neatitinka bendrojo ploto atėmus sanitarines patalpas",
              detail=f"A-10 {_lt_num(a10)} m², A-03 − A-07 = {_lt_num(vinyl)} m².",
              expected=f"{_lt_num(vinyl)} m²", actual=f"{_lt_num(a10)} m²",
              source="Apdaila A-10 ↔ A-03 − A-07", action="Perskaičiuoti vinilo dangos plotą.",
              codes=["A-10"])
    if a03 and a16:
        corr = a03 * 0.15
        check(abs(a16 - corr) <= 0.5, ptype="Kvadratūra", severity="medium", section="apdaila",
              title="Bendrųjų patalpų plotas neatitinka 15 % bendrojo ploto",
              detail=f"A-16 {_lt_num(a16)} m², 15 % nuo A-03 = {_lt_num(corr)} m².",
              expected=f"{_lt_num(corr)} m²", actual=f"{_lt_num(a16)} m²",
              source="Apdaila A-16 ↔ 15 % × A-03", action="Suderinti bendrųjų patalpų plotą.",
              codes=["A-16"])

    f01 = qty("F-01")
    if f01 and bd_height:
        gross_bd = (24.94 + 15.44) * 2 * bd_height
        diff = f01 - gross_bd
        check(abs(diff) < 0.5, ptype="Kvadratūra", severity="info", section="fasadas",
              title="Fasado aukštis: BD 12 m, sąmatoje 12,85 m",
              detail=(f"BD l. 7 nurodytas pastato aukštis {_lt_num(bd_height, 0)} m, DWG – +12,850 m. "
                      f"Pagal BD aukštį bendras fasado plotas būtų {_lt_num(gross_bd)} m², "
                      f"t. y. {_lt_num(abs(diff))} m² mažiau nei F-01."),
              expected=f"{_lt_num(gross_bd)} m²", actual=f"{_lt_num(f01)} m²",
              source="1-BD l. 7 ↔ DWG 2026-04-14 ↔ fasadas F-01",
              action="Suderinti aukštį su architektu; jei 12 m – galutinis, perskaičiuoti fasado kiekius.",
              codes=["F-01"])

    for key in WORK_SECTIONS:
        secrows = [r for r in rows if r["section"] == key]
        if not secrows:
            continue
        unpriced = [r for r in secrows
                    if float(r["qty"] or 0) > 0 and float(r["price"] or 0) <= 0]
        check(not unpriced, ptype="Kaina", severity="medium", section=key,
              title="Nenurodytos kainos",
              detail=(f"{len(unpriced)} iš {len(secrows)} pozicijų neturi kainos – "
                      "sąmatos vertė neskaičiuojama."),
              expected="Visos pozicijos įkainotos", actual=f"{len(unpriced)} be kainos",
              source="Darbų sąmata", action="Įrašyti rangovo kainas (€/vnt.) sąmatos lentelėje.",
              codes=[r["code"] for r in unpriced[:8]])

        calc = [r for r in secrows if r.get("kind") == "Skaičiuojama"]
        check(not calc, ptype="Reikalavimas", severity="info", section=key,
              title="Kiekiai apskaičiuoti orientaciniu būdu",
              detail=(f"{len(calc)} iš {len(secrows)} pozicijų pažymėtos „Skaičiuojama“ – "
                      "kiekius reikia patikslinti pagal dokumentų žiniaraščius."),
              expected="Kiekiai iš dokumentų", actual=f"{len(calc)} skaičiuojami",
              source="Sąmatos pagrindimas",
              action="Kiekį pakeisti projekto kiekių žiniaraščio reikšme.",
              codes=[r["code"] for r in calc[:8]])

        seen, dups = set(), []
        for r in secrows:
            code = str(r.get("code") or "").strip()
            if not code:
                continue
            if code in seen:
                dups.append(code)
            seen.add(code)
        check(not dups, ptype="Kiekis", severity="medium", section=key,
              title="Pasikartojantys pozicijų kodai",
              detail="Sąmatoje rasti pasikartojantys kodai: " + ", ".join(sorted(set(dups))) + ".",
              expected="Unikalūs kodai", actual=f"{len(set(dups))} pasikartojimai",
              source="Darbų sąmata", action="Pervadinti arba sujungti pasikartojančias pozicijas.",
              codes=sorted(set(dups)))

    zero = [r for r in rows if float(r["qty"] or 0) <= 0]
    check(not zero, ptype="Kiekis", severity="high", section="",
          title="Pozicijos be kiekio",
          detail=f"{len(zero)} pozicijų neturi kiekio – jų negalima įkainoti ar atsiskaityti.",
          expected="Kiekis > 0", actual=f"{len(zero)} pozicijos",
          source="Darbų sąmata", action="Įrašyti kiekį arba pašalinti poziciją.",
          codes=[r["code"] for r in zero[:8]])

    over = [r for r in rows
            if float(r["qty"] or 0) > 0 and float(r["done"] or 0) > float(r["qty"] or 0) + 1e-9]
    check(not over, ptype="Kiekis", severity="high", section="",
          title="Atlikta daugiau nei numatyta",
          detail=f"{len(over)} pozicijų atliktas kiekis viršija sąmatos kiekį.",
          expected="Atlikta ≤ kiekis", actual=f"{len(over)} viršija",
          source="Darbų sąmata", action="Patikrinti atlikimo kiekius.",
          codes=[r["code"] for r in over[:8]])

    nosrc = [r for r in rows if not r.get("source_page") and not r.get("source_doc")]
    check(not nosrc, ptype="Reikalavimas", severity="medium", section="",
          title="Trūksta šaltinio lapo",
          detail=f"{len(nosrc)} pozicijų nenurodytas šaltinio dokumentas arba lapas.",
          expected="Kiekviena pozicija turi šaltinį", actual=f"{len(nosrc)} be šaltinio",
          source="Darbų sąmata", action="Susieti poziciją su dokumentu ir lapu.",
          codes=[r["code"] for r in nosrc[:8]])

    vdata = {"summary": {"total": 0, "ok": 0, "bad": 0}, "checks": []}
    if _doc_row("3-SA", ".pdf"):
        # Fasado patikra sieja konkretaus objekto TP specifikacija su DWG matmenimis.
        # Kitame projekte be 3-SA dokumento ji rodytu svetimo objekto skaicius.
        try:
            vdata = verify_fasadas()
        except Exception:
            logger.warning("Fasado patikra nepavyko: %s", traceback.format_exc())
    for c in vdata.get("checks", []):
        ok = bool(c.get("ok"))
        checks.append(ok)
        if ok:
            continue
        unit = c.get("unit") or ""
        ptype = "Kvadratūra" if unit == "m²" else "Kiekis"
        title = c.get("name") or "Fasado kiekio neatitikimas"
        item = {
            "id": f"p{len(items) + 1}",
            "type": ptype,
            "severity": "high", "section": "fasadas", "sectionLabel": "Fasadas",
            "title": title,
            "detail": c.get("detail") or "Sąmatos reikšmė neatitinka šaltinio.",
            "expected": f"{c.get('expected')} {unit}".strip(),
            "actual": f"{c.get('actual')} {unit}".strip(),
            "source": c.get("source") or "",
            "action": "Sutikrinti fasado sąmatos kiekį su nurodytu šaltiniu.",
            "codes": [],
        }
        dec = decisions.get(decision_key(ptype, "fasadas", title))
        if dec:
            item["id"] = f"r{len(resolved_items) + 1}"
            item["resolved"] = True
            item["decision"] = dec
            resolved_items.append(item)
        else:
            items.append(item)

    schedules = []
    if any(_doc_row(s["doc"], ".pdf") for s in SCHEDULE_SOURCES):
        # Žiniaraščių šaltiniai priskirti konkrečiam objektui – be jų nepatikriname.
        try:
            schedules = build_schedule_coverage(rows)
        except Exception:
            logger.warning("Kiekių žiniaraščių patikra nepavyko: %s", traceback.format_exc())
    for src in schedules:
        summary = src["summary"]
        if src.get("kind") == "spec":
            spec_total = summary["specTotal"]
            works_total = summary["worksTotal"]
            check(abs(works_total - spec_total) <= 0.5,
                  ptype="Kiekis", severity="info", section="apdaila",
                  title="Durų kiekis sąmatoje skiriasi nuo specifikacijos",
                  detail=(f"3-SA l. 70 specifikacijoje {_lt_num(spec_total, 0)} vnt. "
                          f"(D-01 1 vnt. + D-02–D-08 {_lt_num(summary['specInner'], 0)} vnt.), "
                          f"apdailos sąmatoje {_lt_num(works_total, 0)} vnt. "
                          f"(A-13 {_lt_num(summary['worksInner'], 0)} + A-14 "
                          f"{_lt_num(works_total - summary['worksInner'], 0)}). "
                          f"Skirtumas {_lt_num(abs(summary['diff']), 0)} vnt."),
                  expected=f"{_lt_num(spec_total, 0)} vnt.",
                  actual=f"{_lt_num(works_total, 0)} vnt.",
                  source="3-SA l. 70 ↔ apdaila A-13 + A-14",
                  action="Patikslinti, ar A-14 butų įėjimo durys įtrauktos į D-02–D-08 tipus.",
                  codes=["A-13", "A-14"])
            continue
        if src["status"] == "no-works":
            check(False, ptype="Kiekis", severity="info", section="",
                  title="Sklypo kiekių žiniaraštis neturi sąmatos pozicijų",
                  detail=(f"{src['doc']} {src['pageLabel']} nuskaityta {summary['rows']} eilučių, "
                          "tačiau darbų sąmatoje nėra sklypo sutvarkymo sekcijos."),
                  expected="Sklypo darbų sąmata",
                  actual=f"{summary['rows']} eilutės be sąmatos",
                  source=f"{src['doc']} {src['pageLabel']}",
                  action="Įkelti sklypo darbus į sąmatą arba patvirtinti, kad jie neša šio etapo apimties.",
                  codes=[])
            continue
        if not summary["rows"]:
            check(False, ptype="Reikalavimas", severity="info", section=src["section"],
                  title=f"{src['label']} neperskaitytas",
                  detail=f"Nepavyko nuskaityti {src['doc']} {src['pageLabel']} eilučių.",
                  expected="Nuskaitytas žiniaraštis", actual="0 eilučių",
                  source=src["doc"],
                  action="Patikrinti, ar PDF suindeksuotas ir ar tekstas išgaunamas.",
                  codes=[])
            continue
        for item in src["matches"]:
            row = item.get("row") or {}
            code = item["code"]
            if item["status"] == "ok":
                checks.append(True)
                continue
            if item["status"] == "diff":
                check(False, ptype="Kiekis", severity="high", section=src["section"],
                      title=f"{code}: kiekis nesutampa su kiekių žiniaraščiu",
                      detail=(f"{src['doc']} {src['pageLabel']}, l. {row.get('page')}: "
                              f"{_lt_num(row.get('qty'))} {row.get('unit')}; sąmatoje "
                              f"{_lt_num(item['qty'])} {item['unit']}."),
                      expected=f"{_lt_num(row.get('qty'))} {row.get('unit')}",
                      actual=f"{_lt_num(item['qty'])} {item['unit']}",
                      source=f"{src['doc']} l. {row.get('page')} ↔ {code}",
                      action="Sąmatos kiekį pakeisti žiniaraščio reikšme arba paaiškinti perskaičiavimą.",
                      codes=[code])
            elif item["status"] == "unit":
                check(False, ptype="Kiekis", severity="medium", section=src["section"],
                      title=f"{code}: žiniaraštyje nurodytas kitas matavimo vienetas",
                      detail=(f"Kiekis sutampa ({_lt_num(item['qty'])}), tačiau {src['doc']} "
                              f"l. {row.get('page')} nurodyta {_lt_num(row.get('qty'))} "
                              f"{row.get('unit')}, sąmatoje – {_lt_num(item['qty'])} "
                              f"{item['unit']}. Tikėtina žiniaraščio matavimo vieneto klaida."),
                      expected=f"{_lt_num(row.get('qty'))} {row.get('unit')}",
                      actual=f"{_lt_num(item['qty'])} {item['unit']}",
                      source=f"{src['doc']} l. {row.get('page')} ↔ {code}",
                      action="Suderinti matavimo vienetą su projektu (šulinių kiekis paprastai vnt./kompl.).",
                      codes=[code])
            else:
                check(False, ptype="Reikalavimas", severity="medium", section=src["section"],
                      title=f"{code}: kiekių žiniaraštyje nėra tiesioginės eilutės",
                      detail=(f"{src['doc']} {src['pageLabel']} nerasta eilutės, atitinkančios "
                              f"„{item['title']}“ ({_lt_num(item['qty'])} {item['unit']})."),
                      expected="Eilutė žiniaraštyje", actual="Nerasta",
                      source=f"{src['doc']} {src['pageLabel']} ↔ {code}",
                      action="Patikrinti kiekio šaltinį arba susieti su artimiausia žiniaraščio eilute.",
                      codes=[code])
        if src["extras"]:
            extra_detail = "; ".join(
                f"l. {r['page']}: {r['title'][:70]} ({_lt_num(r['qty'])} {r['unit']})"
                for r in src["extras"][:4])
            check(False, ptype="Kiekis", severity="info", section=src["section"],
                  title=f"{src['label']}: eilučių be sąmatos pozicijų",
                  detail=(f"{summary['extra']} žiniaraščio eilučių neturi atitikmens sąmatoje. "
                          f"{extra_detail}."),
                  expected="Visos eilutės susietos",
                  actual=f"{summary['extra']} nesusietos",
                  source=f"{src['doc']} {src['pageLabel']}",
                  action="Įvertinti, ar šių darbų trūksta sąmatoje, ar jie įskaičiuoti į kitas pozicijas.",
                  codes=[])

    norms = []
    docs_total = 0
    with db() as conn:
        docs_total = conn.execute("SELECT COUNT(*) n FROM docs").fetchone()["n"]
        for code, label, match in NORM_REFERENCES:
            docs_n, sample = 0, None
            try:
                docs_n = conn.execute(
                    "SELECT COUNT(DISTINCT d.id) n FROM pages_fts f "
                    "JOIN docs d ON d.id=f.doc_id WHERE pages_fts MATCH ?",
                    (match,)).fetchone()["n"]
                sample = conn.execute(
                    "SELECT d.disc, d.name, f.page FROM pages_fts f "
                    "JOIN docs d ON d.id=f.doc_id WHERE pages_fts MATCH ? "
                    "ORDER BY d.id, f.page LIMIT 1", (match,)).fetchone()
            except sqlite3.Error:
                docs_n = 0
            sample_txt = (f"{sample['disc']} · {sample['name']}, l. {sample['page']}"
                          if sample else "")
            norms.append({"code": code, "label": label, "docs": docs_n,
                          "sample": sample_txt, "ok": docs_n > 0})
            if docs_total:
                check(docs_n > 0, ptype="Normatyvas", severity="medium", section="",
                      title=f"Normatyvo {code} nuoroda projekte nerasta",
                      detail=f"Projekto dokumentuose nerasta nuoroda į {code} ({label}).",
                      expected="Nuoroda dokumentuose", actual="Nerasta",
                      source="Dokumentų indeksas",
                      action="Patikrinti projekto normatyvų sąrašą.", codes=[code])

    items.sort(key=lambda p: (
        PROBLEM_SEVERITY_ORDER.get(p["severity"], 9),
        PROBLEM_TYPES.index(p["type"]) if p["type"] in PROBLEM_TYPES else 9,
        p["title"]))

    data = {
        "generated": now_iso(),
        "summary": {
            "checks": len(checks),
            "passed": sum(1 for c in checks if c),
            "problems": len(items),
            "resolved": len(resolved_items),
            "empty": not docs_total and not rows,
            "byType": {t: sum(1 for p in items if p["type"] == t) for t in PROBLEM_TYPES},
            "bySeverity": {s: sum(1 for p in items if p["severity"] == s)
                           for s in ("high", "medium", "info")},
            "bySection": {k: sum(1 for p in items if p["section"] == k) for k in WORK_SECTIONS},
        },
        "types": PROBLEM_TYPES,
        "sections": labels,
        "problems": items,
        "resolved": resolved_items,
        "decisions": list(decisions.values()),
        "norms": norms,
        "schedules": schedules,
        "verify": vdata.get("summary", {"total": 0, "ok": 0, "bad": 0}),
    }
    with _PROBLEMS_LOCK:
        _PROBLEMS_CACHE["data"] = data
        _PROBLEMS_CACHE["sig"] = sig
        _PROBLEMS_CACHE["ts"] = time.time()
    return data


# --- F2/F3 mėnesiniai atliktų darbų aktai ---

ACT_STATUSES = ("Juodraštis", "Pateiktas", "Patvirtintas")
ACT_DEMO_NUMBER = "CPO393168"
ACT_DEMO_TITLE = ("Šilalės Dariaus ir Girėno progimnazijos paprastojo remonto I etapo darbai, "
                  "adresu: D.Poškos g. 24, Šilalės m.")
ACT_DEMO_GROUPS = [
    ("Ardymo darbai", 32315.00),
    ("Bendrastatybiniai darbai", 75897.98),
    ("Sienos, pertvaros", 162679.24),
    ("Grindys", 163184.90),
    ("Durys", 39599.63),
    ("Lentelės Brailio raštu ir taktiliniai įrenginiai", 12172.08),
    ("Keltuvai", 29383.27),
    ("Laiptai", 971.25),
    ("Vidaus elektros tinklai", 149945.26),
    ("Apsauginė signalizacija", 25828.49),
    ("Elektroniniai vidaus ryšiai", 26241.08),
    ("Gaisrinė signalizacija", 23526.76),
    ("Iškvietimo sistema ŽN WC patalpose", 3030.51),
    ("Santechnikos darbai", 121574.15),
]
ACT_DEMO_ACT1 = [2516.41, 473.55, 1458.29, 0, 0, 0, 0, 0, 4498.36, 4132.55, 4460.98, 3764.29, 0, 2002.40]
ACT_DEMO_ACT2 = [4256.89, 4508.16, 30835.28, 855.00, 0, 0, 0, 0, 10137.98, 0, 0, 0, 0, 10477.71]


def _act_float(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _act_round(v):
    return round(_act_float(v), 2)


def act_money(v):
    return f"{_act_round(v):,.2f}".replace(",", " ").replace(".", ",")


def act_pct_text(v):
    return f"{_act_float(v):.2f}".replace(".", ",")


def act_rate_text(v):
    return f"{_act_float(v):g}".replace(".", ",")


_SUM_UNITS = ["nulis", "vienas", "du", "trys", "keturi", "penki", "šeši", "septyni",
              "aštuoni", "devyni"]
_SUM_TEENS = ["dešimt", "vienuolika", "dvylika", "trylika", "keturiolika", "penkiolika",
              "šešiolika", "septyniolika", "aštuoniolika", "devyniolika"]
_SUM_TENS = ["", "", "dvidešimt", "trisdešimt", "keturiasdešimt", "penkiasdešimt",
             "šešiasdešimt", "septyniasdešimt", "aštuoniasdešimt", "devyniasdešimt"]
_SUM_HUNDRED = ["", "šimtas", "du šimtai", "trys šimtai", "keturi šimtai", "penki šimtai",
                "šeši šimtai", "septyni šimtai", "aštuoni šimtai", "devyni šimtai"]
_SUM_SCALES = [("", "", ""), ("tūkstantis", "tūkstančiai", "tūkstančių"),
               ("milijonas", "milijonai", "milijonų"), ("milijardas", "milijardai", "milijardų")]


def _sum_plural(n, one, few, many):
    m10 = n % 10
    m100 = n % 100
    if m10 == 1 and m100 != 11:
        return one
    if 2 <= m10 <= 9 and (m100 < 11 or m100 > 19):
        return few
    return many


def _sum_under_thousand(n, one_hundred_prefix=False):
    parts = []
    h, rest = divmod(n, 100)
    if h == 1 and one_hundred_prefix:
        parts.append("vienas šimtas")
    elif h:
        parts.append(_SUM_HUNDRED[h])
    if rest:
        if rest < 10:
            parts.append(_SUM_UNITS[rest])
        elif rest < 20:
            parts.append(_SUM_TEENS[rest - 10])
        else:
            t, u = divmod(rest, 10)
            parts.append(_SUM_TENS[t])
            if u:
                parts.append(_SUM_UNITS[u])
    return " ".join(parts)


def _sum_int_words(n):
    if n == 0:
        return _SUM_UNITS[0]
    groups = []
    g = 0
    while n > 0 and g < len(_SUM_SCALES):
        groups.append((n % 1000, g))
        n //= 1000
        g += 1
    highest = len(groups) - 1
    while highest > 0 and not groups[highest][0]:
        highest -= 1
    out = []
    for value, scale in reversed(groups):
        if not value:
            continue
        words = _sum_under_thousand(value, scale < highest)
        if scale == 0:
            out.append(words)
        else:
            if value == 1:
                words = ""
            out.append((words + " " if words else "")
                       + _sum_plural(value, *_SUM_SCALES[scale]))
    return " ".join(" ".join(out).split())


def sum_words(amount):
    cents_total = int(round(abs(_act_float(amount)) * 100))
    euros, cents = divmod(cents_total, 100)
    euro_words = _sum_int_words(euros)
    euro_form = _sum_plural(euros, "euras", "eurai", "eurų")
    text = f"{euro_words} {euro_form} {cents:02d} ct"
    return text[:1].upper() + text[1:]


def _act_pct(part, whole):
    try:
        whole = float(whole)
        return (float(part) / whole * 100.0) if whole else 0.0
    except (TypeError, ValueError, ZeroDivisionError):
        return 0.0


def _contract_groups(conn, contract_id, active_only=False):
    sql = "SELECT * FROM act_groups WHERE contract_id=?"
    if active_only:
        sql += " AND active=1"
    sql += " ORDER BY ord, id"
    return [dict(r) for r in conn.execute(sql, (contract_id,)).fetchall()]


def _act_calc(conn, act, contract=None, groups=None):
    if contract is None:
        contract = conn.execute("SELECT * FROM contracts WHERE id=?", (act["contract_id"],)).fetchone()
    if not contract:
        return [], {}
    contract = dict(contract)
    if groups is None:
        groups = _contract_groups(conn, act["contract_id"])
    current = {r["group_id"]: _act_round(r["amount"]) for r in conn.execute(
        "SELECT group_id, amount FROM act_items WHERE act_id=?", (act["id"],)).fetchall()}
    prev = {r["group_id"]: _act_round(r["sum"]) for r in conn.execute(
        "SELECT i.group_id, SUM(i.amount) AS sum FROM act_items i "
        "JOIN acts a ON a.id=i.act_id WHERE a.contract_id=? "
        "AND (a.num < ? OR (a.num=? AND a.id<?)) GROUP BY i.group_id",
        (act["contract_id"], act["num"], act["num"], act["id"])).fetchall()}
    rows = []
    for g in groups:
        g = dict(g)
        p = _act_round(prev.get(g["id"], 0.0))
        c = _act_round(current.get(g["id"], 0.0))
        if not g.get("active", 1) and abs(p) < 0.004 and abs(c) < 0.004:
            continue
        price = _act_round(g.get("price"))
        total = _act_round(p + c)
        rows.append({
            "id": g["id"], "name": g.get("name") or "", "unit": g.get("unit") or "Kompl.",
            "qty": _act_float(g.get("qty"), 1.0), "price": price,
            "prev": p, "current": c, "total": total,
            "prev_pct": _act_pct(p, price), "current_pct": _act_pct(c, price),
            "total_pct": _act_pct(total, price),
        })
    price_total = _act_round(sum(r["price"] for r in rows))
    prev_total = _act_round(sum(r["prev"] for r in rows))
    current_total = _act_round(sum(r["current"] for r in rows))
    total_total = _act_round(prev_total + current_total)
    vat = _act_float(contract.get("vat"), 21.0)
    ret = _act_float(contract.get("retention"), 0.0)
    adv = _act_float(contract.get("advance"), 0.0)
    totals = {
        "price": price_total, "prev": prev_total, "current": current_total, "total": total_total,
        "prev_pct": _act_pct(prev_total, price_total),
        "current_pct": _act_pct(current_total, price_total),
        "total_pct": _act_pct(total_total, price_total),
        "vat_rate": vat, "retention_pct": ret, "advance_pct": adv,
        "vat_price": _act_round(price_total * vat / 100.0),
        "vat_prev": _act_round(prev_total * vat / 100.0),
        "vat_current": _act_round(current_total * vat / 100.0),
        "vat": _act_round(total_total * vat / 100.0),
        "retention_price": _act_round(price_total * ret / 100.0),
        "retention_prev": _act_round(prev_total * ret / 100.0),
        "retention_current": _act_round(current_total * ret / 100.0),
        "retention": _act_round(total_total * ret / 100.0),
        "advance_price": _act_round(price_total * adv / 100.0),
        "advance_prev": _act_round(prev_total * adv / 100.0),
        "advance_current": _act_round(current_total * adv / 100.0),
        "advance": _act_round(total_total * adv / 100.0),
    }
    totals["price_with_vat"] = _act_round(price_total + totals["vat_price"])
    totals["prev_with_vat"] = _act_round(prev_total + totals["vat_prev"])
    totals["current_with_vat"] = _act_round(current_total + totals["vat_current"])
    totals["total_with_vat"] = _act_round(total_total + totals["vat"])
    totals["payable"] = _act_round(current_total - totals["retention_current"] - totals["advance_current"])
    totals["payable_vat"] = _act_round(totals["payable"] * (1 + vat / 100.0))
    pay_rows = conn.execute(
        "SELECT p.date, p.amount, p.note FROM act_payments p JOIN acts a ON a.id=p.act_id "
        "WHERE a.contract_id=? AND (a.num<? OR (a.num=? AND a.id<=?)) "
        "ORDER BY p.date, p.id",
        (act["contract_id"], act["num"], act["num"], act["id"])).fetchall()
    payments = [{"date": r["date"] or "", "amount": _act_round(r["amount"]), "note": r["note"] or ""}
                for r in pay_rows]
    pay_sum = _act_round(sum(x["amount"] for x in payments))
    totals["payments"] = payments
    totals["payments_total"] = pay_sum
    totals["received"] = pay_sum if payments else _act_round(act.get("received", 0))
    return rows, totals


def list_acts_data():
    with db() as conn:
        contracts = [dict(r) for r in conn.execute("SELECT * FROM contracts ORDER BY id").fetchall()]
        groups = [dict(r) for r in conn.execute("SELECT * FROM act_groups ORDER BY ord, id").fetchall()]
        acts = [dict(r) for r in conn.execute("SELECT * FROM acts ORDER BY contract_id, num, id").fetchall()]
        items = [dict(r) for r in conn.execute("SELECT act_id, group_id, amount FROM act_items").fetchall()]
        pay_by_act = {r["act_id"]: _act_round(r["s"]) for r in conn.execute(
            "SELECT act_id, SUM(amount) AS s FROM act_payments GROUP BY act_id").fetchall()}
    by_act = {}
    for it in items:
        by_act.setdefault(it["act_id"], {})[it["group_id"]] = _act_float(it["amount"])
    prices = {}
    for g in groups:
        prices[g["contract_id"]] = prices.get(g["contract_id"], 0.0) + _act_float(g["price"])
    vats = {c["id"]: _act_float(c.get("vat"), 21.0) for c in contracts}
    running = {}
    out = []
    for a in acts:
        cid = a["contract_id"]
        prev = running.setdefault(cid, {})
        cur = by_act.get(a["id"], {})
        total = dict(prev)
        for gid, v in cur.items():
            total[gid] = prev.get(gid, 0.0) + v
        item = dict(a)
        item["prev_total"] = _act_round(sum(prev.values()))
        item["current_total"] = _act_round(sum(cur.values()))
        item["total"] = _act_round(sum(total.values()))
        item["pct"] = _act_pct(item["total"], prices.get(cid, 0.0))
        item["payments"] = _act_round(pay_by_act.get(a["id"], 0.0))
        item["current_with_vat"] = _act_round(item["current_total"] * (1 + vats.get(cid, 0.0) / 100.0))
        out.append(item)
        running[cid] = total

    finance = []
    for c in contracts:
        cid = c["id"]
        acts_c = [a for a in out if a["contract_id"] == cid]
        invoiced = _act_round(sum(a["current_with_vat"] for a in acts_c if a.get("invoice_no")))
        paid_rows = sum(a["payments"] for a in acts_c)
        paid = paid_rows if paid_rows else _act_round(max((_act_float(a.get("received")) for a in acts_c), default=0.0))
        price = _act_round(prices.get(cid, 0.0))
        done = _act_round(acts_c[-1]["total"] if acts_c else 0.0)
        finance.append({
            "contract_id": cid, "title": c.get("title") or "",
            "price": price, "done": done, "unfinished": _act_round(max(0.0, price - done)),
            "invoiced": invoiced, "received": paid,
            "outstanding": _act_round(invoiced - paid),
            "acts": len(acts_c),
        })
    return {"contracts": contracts, "groups": groups, "acts": out, "statuses": list(ACT_STATUSES),
            "finance": finance}


def contract_payments(contract_id):
    with db() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT p.id, p.date, p.amount, p.note, a.num AS act_num, a.id AS act_id "
            "FROM act_payments p JOIN acts a ON a.id=p.act_id "
            "WHERE a.contract_id=? ORDER BY p.date, p.id", (contract_id,)).fetchall()]
    for r in rows:
        r["amount"] = _act_round(r["amount"])
    return {"payments": rows, "total": _act_round(sum(r["amount"] for r in rows))}


def contract_unfinished(contract_id):
    with db() as conn:
        groups = [dict(r) for r in conn.execute(
            "SELECT * FROM act_groups WHERE contract_id=? AND active=1 ORDER BY ord, id",
            (contract_id,)).fetchall()]
        done = {r["group_id"]: _act_round(r["s"]) for r in conn.execute(
            "SELECT i.group_id, SUM(i.amount) AS s FROM act_items i "
            "JOIN acts a ON a.id=i.act_id WHERE a.contract_id=? GROUP BY i.group_id",
            (contract_id,)).fetchall()}
    rows = []
    for g in groups:
        price = _act_round(g.get("price"))
        worked = done.get(g["id"], 0.0)
        left = _act_round(price - worked)
        if abs(left) < 0.005:
            continue
        rows.append({"id": g["id"], "name": g.get("name") or "", "unit": g.get("unit") or "",
                     "price": price, "done": worked, "left": left,
                     "pct": _act_pct(worked, price)})
    return {"groups": rows, "left": _act_round(sum(r["left"] for r in rows))}


# ---------- F2/F3 Excel (XLSX) be išorinių bibliotekų ----------

def _xcol_num(col):
    n = 0
    for ch in str(col).upper():
        if "A" <= ch <= "Z":
            n = n * 26 + (ord(ch) - 64)
    return n


def _xcol_name(n):
    s = ""
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def _xesc(v):
    return (str(v).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;"))


_XLSX_STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="1"><numFmt numFmtId="164" formatCode="0.00%"/></numFmts>
<fonts count="6">
<font><sz val="10"/><name val="Calibri"/></font>
<font><b/><sz val="10"/><name val="Calibri"/></font>
<font><b/><sz val="14"/><name val="Calibri"/></font>
<font><b/><sz val="9"/><name val="Calibri"/></font>
<font><i/><sz val="9"/><color rgb="FF6B7280"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><name val="Calibri"/></font>
</fonts>
<fills count="3">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFEDF2F9"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="2">
<border><left/><right/><top/><bottom/><diagonal/></border>
<border><left style="thin"><color rgb="FF98A2AE"/></left><right style="thin"><color rgb="FF98A2AE"/></right><top style="thin"><color rgb="FF98A2AE"/></top><bottom style="thin"><color rgb="FF98A2AE"/></bottom><diagonal/></border>
</borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="15">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="4" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="1" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>
<xf numFmtId="4" fontId="1" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
<xf numFmtId="0" fontId="5" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
<xf numFmtId="0" fontId="4" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>
<xf numFmtId="164" fontId="1" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""


def _xlsx_sheet_xml(rows, widths, merges=(), heights=None):
    heights = heights or {}
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
           '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>',
           '<sheetViews><sheetView workbookViewId="0"/></sheetViews>',
           '<sheetFormatPr defaultRowHeight="15"/><cols>']
    for i, w in enumerate(widths, 1):
        out.append(f'<col min="{i}" max="{i}" width="{w}" customWidth="1"/>')
    out.append("</cols><sheetData>")
    for rn in sorted(rows):
        attrs = f' r="{rn}"'
        if rn in heights:
            attrs += f' ht="{heights[rn]}" customHeight="1"'
        out.append(f"<row{attrs}>")
        for col in sorted(rows[rn], key=_xcol_num):
            val, style, kind = rows[rn][col]
            ref = f"{col}{rn}"
            if kind in ("n", "p"):
                try:
                    num = float(val)
                except (TypeError, ValueError):
                    num = 0.0
                if kind == "p":
                    num /= 100.0
                out.append(f'<c r="{ref}" s="{style}"><v>{num:.6f}</v></c>')
            elif str(val) == "":
                out.append(f'<c r="{ref}" s="{style}"/>' if style else "")
            else:
                out.append(f'<c r="{ref}" s="{style}" t="inlineStr"><is><t xml:space="preserve">'
                           f'{_xesc(val)}</t></is></c>')
        out.append("</row>")
    out.append("</sheetData>")
    if merges:
        out.append(f'<mergeCells count="{len(merges)}">')
        out.extend(f'<mergeCell ref="{m}"/>' for m in merges)
        out.append("</mergeCells>")
    out.append('<printOptions horizontalCentered="1"/>'
               '<pageMargins left="0.35" right="0.35" top="0.5" bottom="0.5" header="0.2" footer="0.2"/>'
               '<pageSetup paperSize="9" orientation="portrait" fitToWidth="1" fitToHeight="0"/>'
               '</worksheet>')
    return "".join(out)


def _xlsx_package(sheet_name, sheet_xml, title=""):
    safe = re.sub(r"[\[\]:*?/\\]", " ", str(sheet_name or "F2")).strip()[:31] or "F2"
    ct = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>"""
    rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>"""
    wb = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
          'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
          f'<sheets><sheet name="{_xesc(safe)}" sheetId="1" r:id="rId1"/></sheets></workbook>')
    wbrels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""
    stamp = datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")
    core = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            f'<dc:title>{_xesc(title or safe)}</dc:title><dc:creator>Projekto Štabas</dc:creator>'
            f'<dcterms:created xsi:type="dcterms:W3CDTF">{stamp}</dcterms:created>'
            f'<dcterms:modified xsi:type="dcterms:W3CDTF">{stamp}</dcterms:modified>'
            '</cp:coreProperties>')
    app = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">'
           '<Application>Projekto Štabas</Application></Properties>')
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ct)
        z.writestr("_rels/.rels", rels)
        z.writestr("docProps/core.xml", core)
        z.writestr("docProps/app.xml", app)
        z.writestr("xl/workbook.xml", wb)
        z.writestr("xl/_rels/workbook.xml.rels", wbrels)
        z.writestr("xl/styles.xml", _XLSX_STYLES)
        z.writestr("xl/worksheets/sheet1.xml", sheet_xml)
    return buf.getvalue()


def build_act_xlsx(act_id, form="f2"):
    form = "f3" if str(form).lower() == "f3" else "f2"
    with db() as conn:
        act = conn.execute("SELECT * FROM acts WHERE id=?", (act_id,)).fetchone()
        if not act:
            return None
        act = dict(act)
        contract = conn.execute("SELECT * FROM contracts WHERE id=?", (act["contract_id"],)).fetchone()
        if not contract:
            return None
        contract = dict(contract)
        calc_rows, totals = _act_calc(conn, act, contract)
    co = company_data()
    contractor = co.get("name") or contract.get("contractor") or ""
    customer = contract.get("customer") or ""
    title = contract.get("title") or ""
    signed = contract.get("signed") or ""
    number = contract.get("number") or ""
    meta = "; ".join(x for x in (signed, number) if x)
    act_date = act.get("date") or ""
    pfrom = act.get("period_from") or ""
    pto = act.get("period_to") or ""
    rep_c, rep_t, rep_u = _act_reps(act, contract)
    rows = {}
    heights = {}

    def put(rn, col, val="", style=0, kind="s"):
        rows.setdefault(rn, {})[col] = (val, style, kind)

    def fill(rn, c1, c2, style):
        for ci in range(_xcol_num(c1), _xcol_num(c2) + 1):
            put(rn, _xcol_name(ci), "", style)

    if form == "f2":
        sheet_name = f"F2-Nr.{act['num']} {act_date[:7]}"
        put(1, "F", "PRIEDAS NR. 10", 10)
        fill(2, "A", "L", 0)
        put(2, "A", "ATLIKTŲ DARBŲ AKTO FORMA", 9)
        put(4, "A", "Fiksuotos kainos sutartis", 1)
        for rn, label, value in (("6", "Užsakovas:", customer), ("8", "Rangovas:", contractor),
                                 ("10", "Sutarties pavadinimas:", title),
                                 ("12", "Sutarties data ir numeris:", meta)):
            put(int(rn), "A", label, 1)
            fill(int(rn), "C", "L", 2)
            put(int(rn), "C", value, 2)
        put(14, "A", "Akto data:", 1)
        fill(14, "C", "L", 2)
        put(14, "C", act_date, 2)
        fill(16, "A", "L", 0)
        put(16, "A", f"ATLIKTŲ DARBŲ AKTAS NR. {act['num']}", 11)
        put(18, "A", "Akto laikotarpis:", 1)
        fill(18, "C", "L", 2)
        put(18, "C", f"nuo {pfrom} iki {pto}", 2)
        for rng in ("A20:A22", "B20:B22", "D20:D22", "E20:E22", "F20:F22", "G20:L20",
                    "G21:H21", "I21:J21", "K21:L21"):
            a, b = rng.split(":")
            c1 = "".join(ch for ch in a if ch.isalpha())
            r1 = int("".join(ch for ch in a if ch.isdigit()))
            c2 = "".join(ch for ch in b if ch.isalpha())
            r2 = int("".join(ch for ch in b if ch.isdigit()))
            for rn in range(r1, r2 + 1):
                fill(rn, c1, c2, 5)
        for col, text in (("A", "Eil. Nr."), ("B", "Darbo pavadinimas"), ("D", "Mato vnt."),
                          ("E", "Sutartinis kiekis"), ("F", "Sutartinė kaina, EUR, be PVM"),
                          ("G", "Atliktų Darbų dalis")):
            put(20, col, text, 5)
        for col, text in (("G", "Praeitais laikotarpiais"), ("I", "Ataskaitiniu laikotarpiu"),
                          ("K", "Iš viso nuo Sutarties įsigaliojimo")):
            put(21, col, text, 5)
        for col, text in (("G", "Procentas %"), ("H", "Kaina, EUR be PVM"),
                          ("I", "Procentas %"), ("J", "Kaina, EUR, be PVM"),
                          ("K", "Procentas %"), ("L", "Kaina, EUR, be PVM")):
            put(22, col, text, 5)
        heights.update({2: 22, 10: 30, 16: 20, 20: 25, 21: 19, 22: 27})
        start = 25
        for i, r in enumerate(calc_rows, 1):
            rn = start + i - 1
            put(rn, "A", i, 3, "n")
            put(rn, "B", r["name"], 2)
            put(rn, "D", r["unit"], 3)
            put(rn, "E", r["qty"], 4, "n")
            put(rn, "F", r["price"], 4, "n")
            put(rn, "G", r["prev_pct"], 8, "p")
            put(rn, "H", r["prev"], 4, "n")
            put(rn, "I", r["current_pct"], 8, "p")
            put(rn, "J", r["current"], 4, "n")
            put(rn, "K", r["total_pct"], 8, "p")
            put(rn, "L", r["total"], 4, "n")
            heights[rn] = 24 if len(str(r["name"])) > 44 else 18
        tr = start + len(calc_rows) + 1
        for rn, label in ((tr, "IŠ VISO:"), (tr + 1, f"PVM {totals['vat_rate']:g}%:"),
                          (tr + 2, "IŠ VISO SU PVM:")):
            fill(rn, "B", "E", 6)
            put(rn, "B", label, 6)
            for col in ("G", "I", "K"):
                put(rn, col, "", 14)
        for rn, keys in ((tr, ("price", "prev_pct", "prev", "current_pct", "current", "total_pct", "total")),
                         (tr + 1, ("vat_price", "vat_prev", "vat_current", "vat")),
                         (tr + 2, ("price_with_vat", "prev_with_vat", "current_with_vat", "total_with_vat"))):
            if rn == tr:
                put(rn, "F", totals[keys[0]], 7, "n")
                put(rn, "G", totals[keys[1]], 14, "p")
                put(rn, "H", totals[keys[2]], 7, "n")
                put(rn, "I", totals[keys[3]], 14, "p")
                put(rn, "J", totals[keys[4]], 7, "n")
                put(rn, "K", totals[keys[5]], 14, "p")
                put(rn, "L", totals[keys[6]], 7, "n")
            else:
                put(rn, "F", totals[keys[0]], 7, "n")
                put(rn, "H", totals[keys[1]], 7, "n")
                put(rn, "J", totals[keys[2]], 7, "n")
                put(rn, "L", totals[keys[3]], 7, "n")
        sr = tr + 5
        for label, rep in (("Rangovo atstovas", rep_c), ("Techninis prižiūrėtojas", rep_t),
                           ("Užsakovo atstovas", rep_u)):
            put(sr, "A", label + ":", 11)
            put(sr, "F", rep or "", 1)
            put(sr, "I", "____________", 12)
            put(sr, "K", act_date, 1)
            put(sr + 1, "F", "(vardas, pavardė, pareigos)", 12)
            put(sr + 1, "I", "(parašas)", 12)
            put(sr + 1, "K", "(data)", 12)
            sr += 4
        merges = ["A2:L2", "C6:L6", "C8:L8", "C10:L10", "C12:L12", "C14:L14", "A16:L16", "C18:L18",
                  "A20:A22", "B20:B22", "D20:D22", "E20:E22", "F20:F22", "G20:L20",
                  "G21:H21", "I21:J21", "K21:L21"]
        for rn in (tr, tr + 1, tr + 2):
            merges.append(f"B{rn}:E{rn}")
        widths = [6, 50, 2.5, 10, 10, 16, 11, 14, 11, 14, 11, 14]
    else:
        sheet_name = f"F3-Nr.{act['num']} {act_date[:7]}"
        put(1, "H", "PRIEDAS NR. 11", 10)
        fill(2, "A", "J", 0)
        put(2, "A", "PAŽYMOS APIE ATLIKTŲ DARBŲ VERTĘ FORMA", 9)
        for rn, label, value in ((5, "Užsakovas:", customer), (7, "Rangovas:", contractor),
                                 (9, "Sutarties pavadinimas:", title),
                                 (11, "Sutarties data ir numeris:", meta)):
            put(rn, "A", label, 1)
            fill(rn, "C", "J", 2)
            put(rn, "C", value, 2)
        put(13, "A", "Pažymos data:", 1)
        fill(13, "C", "J", 2)
        put(13, "C", act_date, 2)
        fill(15, "A", "J", 0)
        put(15, "A", f"PAŽYMA APIE ATLIKTŲ DARBŲ VERTĘ NR. {act['num']}", 11)
        put(17, "A", "Pažymos laikotarpis:", 1)
        fill(17, "C", "J", 2)
        put(17, "C", f"Nuo {pfrom} iki {pto}", 2)
        for rn, c1, c2 in ((19, "A", "A"), (19, "B", "B"), (19, "D", "D"), (19, "E", "G"), (19, "H", "J"),
                           (20, "E", "E"), (20, "F", "F"), (20, "G", "G"),
                           (20, "H", "H"), (20, "I", "I"), (20, "J", "J")):
            fill(rn, c1, c2, 5)
        put(19, "A", "Eil. Nr.", 5)
        put(19, "B", "Darbų grupės (Darbo) pavadinimas", 5)
        put(19, "D", "Sutartinė kaina, EUR, be PVM", 5)
        put(19, "E", "Atliktų Darbų vertė, EUR, be PVM", 5)
        put(19, "H", "Atliktų Darbų procentas %", 5)
        for col, text in (("E", "Praeitais laikotarpiais"), ("F", "Ataskaitiniu laikotarpiu"),
                          ("G", "Iš viso nuo Projekto pradžios"), ("H", "Praeitais laikotarpiais"),
                          ("I", "Ataskaitiniu laikotarpiu"), ("J", "Iš viso nuo Sutarties įsigaliojimo")):
            put(20, col, text, 5)
        heights.update({2: 22, 5: 20, 9: 30, 15: 20, 19: 25, 20: 30})
        put(22, "A", 1, 3, "n")
        put(22, "B", title, 2)
        put(22, "D", totals["price"], 4, "n")
        put(22, "E", totals["prev"], 4, "n")
        put(22, "F", totals["current"], 4, "n")
        put(22, "G", totals["total"], 4, "n")
        put(22, "H", totals["prev_pct"], 8, "p")
        put(22, "I", totals["current_pct"], 8, "p")
        put(22, "J", totals["total_pct"], 8, "p")
        heights[22] = 24
        for rn, label in ((25, "IŠ VISO:"), (26, f"PVM {totals['vat_rate']:g}%:"),
                          (27, "IŠ VISO SU PVM:")):
            fill(rn, "B", "C", 6)
            put(rn, "B", label, 6)
        for col, key in (("D", "price"), ("E", "prev"), ("F", "current"), ("G", "total")):
            put(25, col, totals[key], 7, "n")
        for col, key in (("D", "vat_price"), ("E", "vat_prev"), ("F", "vat_current"), ("G", "vat")):
            put(26, col, totals[key], 7, "n")
        for col, key in (("D", "price_with_vat"), ("E", "prev_with_vat"),
                         ("F", "current_with_vat"), ("G", "total_with_vat")):
            put(27, col, totals[key], 7, "n")
        for rn, label, pct_key, eur_key in (
                (28, "Sulaikoma suma, proc.:", "retention_pct", "retention_price"),
                (29, "Sulaikoma suma, EUR:", None, "retention"),
                (30, "Avanso išskaita, proc.:", "advance_pct", "advance_price"),
                (31, "Išskaitytas avansas, EUR:", None, "advance")):
            fill(rn, "B", "C", 6)
            put(rn, "B", label, 6)
            if pct_key:
                for col in ("D", "E", "F", "G"):
                    put(rn, col, totals[pct_key], 4, "n")
            elif rn == 29:
                for col, key in (("D", "retention_price"), ("E", "retention_prev"),
                                 ("F", "retention_current"), ("G", "retention")):
                    put(rn, col, totals[key], 4, "n")
            else:
                for col, key in (("D", "advance_price"), ("E", "advance_prev"),
                                 ("F", "advance_current"), ("G", "advance")):
                    put(rn, col, totals[key], 4, "n")
        debt = _act_float(act.get("debt")) or max(0.0, totals["payable_vat"] - totals.get("received", 0.0))
        for rn, label, value, style in (
                (32, "Mokėtina suma, EUR, be PVM:", totals["payable"], 4),
                (33, "Mokėtina suma, EUR, su PVM:", totals["payable_vat"], 7),
                (34, "Rangovo gauti mokėjimai, EUR:", totals.get("received", 0.0), 4),
                (35, "Užsakovo skola, EUR:", debt, 7)):
            fill(rn, "B", "E", 6)
            put(rn, "B", label, 6)
            put(rn, "F", value, style, "n")
        sr = 38
        for label, rep in (("Rangovo atstovas", rep_c), ("Užsakovo atstovas", rep_u)):
            put(sr, "A", label + ":", 11)
            put(sr, "D", rep or "_________________________", 1)
            put(sr, "G", "____________", 12)
            put(sr, "I", "____________", 12)
            put(sr + 1, "D", "(vardas, pavardė, pareigos)", 12)
            put(sr + 1, "G", "(parašas)", 12)
            put(sr + 1, "I", "(data)", 12)
            sr += 4
        merges = ["A2:J2", "C5:J5", "C7:J7", "C9:J9", "C11:J11", "C13:J13", "A15:J15", "C17:J17",
                  "A19:A20", "B19:B20", "D19:D20", "E19:G19", "H19:J19"]
        for rn in range(25, 36):
            if rn in (32, 33, 34, 35):
                merges.append(f"B{rn}:E{rn}")
            elif rn <= 31:
                merges.append(f"B{rn}:C{rn}")
        widths = [6, 48, 2.5, 16, 16, 16, 16, 15, 15, 17]
    return _xlsx_package(sheet_name, _xlsx_sheet_xml(rows, widths, merges, heights),
                         f"{'F2' if form == 'f2' else 'F3'} Nr. {act['num']}")


# ---------- F2 XLSX importas ----------

def _xlsx_num(v, default=0.0):
    s = str(v if v is not None else "").strip().replace("€", "").replace(" ", "").replace("\u00a0", "")
    if not s:
        return default
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return default


def _xlsx_date(v):
    s = str(v or "").strip()
    m = re.search(r"\d{4}-\d{2}-\d{2}", s)
    if m:
        return m.group(0)
    if re.fullmatch(r"\d{5}(\.\d+)?", s):
        try:
            return (date(1899, 12, 30) + timedelta(days=int(float(s)))).isoformat()
        except (ValueError, OverflowError):
            return ""
    m = re.search(r"(\d{1,2})[./](\d{1,2})[./](\d{4})", s)
    if m:
        try:
            return date(int(m.group(3)), int(m.group(2)), int(m.group(1))).isoformat()
        except ValueError:
            return ""
    return ""


def _xlsx_text(cells):
    return " ".join(cells[k] for k in sorted(cells, key=_xcol_num))


def _xlsx_right(cells, col):
    keys = sorted((k for k in cells if _xcol_num(k) > _xcol_num(col)), key=_xcol_num)
    return cells[keys[0]] if keys else ""


def _norm_group(name):
    s = unicodedata.normalize("NFKC", str(name or "")).lower()
    s = (s.replace("„", '"').replace("“", '"').replace("”", '"')
         .replace("–", "-").replace("—", "-").replace("’", "'"))
    s = re.sub(r"[^0-9a-ząčęėįšųūž]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def _xlsx_parse(raw):
    z = zipfile.ZipFile(io.BytesIO(raw))
    names = set(z.namelist())
    shared = []
    if "xl/sharedStrings.xml" in names:
        root = ET.fromstring(z.read("xl/sharedStrings.xml"))
        for si in root.findall("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}si"):
            shared.append("".join(t.text or "" for t in si.iter(
                "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t")))
    ns_m = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    ns_r = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
    wb = ET.fromstring(z.read("xl/workbook.xml"))
    rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
    relmap = {r.get("Id"): r.get("Target") for r in rels}
    sheets = []
    for sh in wb.iter(ns_m + "sheet"):
        target = relmap.get(sh.get(ns_r + "id")) or ""
        target = unquote(target).lstrip("/")
        if not target:
            continue
        if not target.startswith("xl/"):
            target = "xl/" + target
        if target not in names:
            continue
        root = ET.fromstring(z.read(target))
        rows = {}
        for row in root.iter(ns_m + "row"):
            cells = {}
            for c in row.findall(ns_m + "c"):
                ref = c.get("r") or ""
                col = "".join(ch for ch in ref if ch.isalpha()).upper()
                if not col:
                    continue
                t = c.get("t")
                v = c.find(ns_m + "v")
                val = "" if v is None else (v.text or "")
                if t == "s" and val:
                    try:
                        val = shared[int(val)]
                    except (ValueError, IndexError):
                        val = ""
                elif t == "inlineStr":
                    val = "".join(x.text or "" for x in c.iter(ns_m + "t"))
                elif t == "str":
                    pass
                if str(val).strip():
                    cells[col] = str(val).strip()
            if cells:
                try:
                    rows[int(row.get("r") or 0)] = cells
                except ValueError:
                    pass
        sheets.append({"name": sh.get("name") or "", "rows": rows})
    return sheets


def _parse_f2_sheet(sheet):
    rows = sheet.get("rows") or {}
    meta = {"customer": "", "contractor": "", "title": "", "number": "", "signed": "",
            "date": "", "num": None, "period_from": "", "period_to": ""}
    header_row = None
    for rn in sorted(rows):
        cells = rows[rn]
        text = _xlsx_text(cells)
        low = text.lower()
        b = (cells.get("B") or "").strip().lower()
        if header_row is None and "darbo pavadinimas" in b and "grupės" not in b:
            header_row = rn
        if not meta["customer"] and low.startswith("užsakovas"):
            meta["customer"] = _xlsx_right(cells, "A")
        if not meta["contractor"] and low.startswith("rangovas"):
            meta["contractor"] = _xlsx_right(cells, "A")
        if not meta["title"] and low.startswith("sutarties pavadinimas"):
            meta["title"] = _xlsx_right(cells, "A")
        if not meta["number"] and low.startswith("sutarties data ir numeris"):
            val = _xlsx_right(cells, "A")
            parts = re.split(r"\s*[;,]\s*", val, maxsplit=1)
            first = _xlsx_date(parts[0]) if len(parts) > 1 else ""
            if first:
                meta["signed"] = first
                meta["number"] = parts[1].strip()
            else:
                meta["number"] = val
        if not meta["date"] and low.startswith("akto data"):
            meta["date"] = _xlsx_date(_xlsx_right(cells, "A"))
        if not meta["period_from"] and ("laikotarpis" in low):
            dates = re.findall(r"\d{4}-\d{2}-\d{2}", text)
            if len(dates) >= 2:
                meta["period_from"], meta["period_to"] = dates[0], dates[1]
            elif dates:
                meta["period_from"] = dates[0]
        if meta["num"] is None:
            m = re.search(r"(?:aktas|akto)\D{0,24}?nr\.?\s*(\d+)", low)
            if m:
                meta["num"] = int(m.group(1))
    if header_row is None:
        return None
    if meta["num"] is None:
        m = re.search(r"nr\.?\s*(\d+)", sheet.get("name") or "", re.I)
        if m:
            meta["num"] = int(m.group(1))
    items = []
    totals = {"net": None, "prev": None, "vat": None, "gross": None}
    for rn in sorted(rows):
        if rn <= header_row:
            continue
        cells = rows[rn]
        b = (cells.get("B") or "").strip()
        bu = b.upper()
        if bu.startswith("IŠ VISO") or bu.startswith("PVM"):
            j = _xlsx_num(cells.get("J"), None)
            l = _xlsx_num(cells.get("L"), None)
            h = _xlsx_num(cells.get("H"), None)
            if bu.startswith("IŠ VISO") and "SU PVM" in bu:
                totals["gross"] = j if j is not None else l
            elif bu.startswith("IŠ VISO"):
                totals["net"] = j if j is not None else l
                totals["prev"] = h
            elif bu.startswith("PVM"):
                totals["vat"] = j if j is not None else l
            continue
        a = (cells.get("A") or "").strip()
        has_amount = any(c in cells for c in ("H", "J", "L"))
        if not b or b.isdigit():
            continue
        if not (a.isdigit() or has_amount):
            continue
        j_val = _xlsx_num(cells.get("J"), None)
        h_val = _xlsx_num(cells.get("H"), 0.0)
        l_val = _xlsx_num(cells.get("L"), 0.0)
        if j_val is None:
            cur = l_val if abs(h_val) < 0.004 else 0.0
        else:
            cur = j_val
        items.append({
            "name": b, "unit": (cells.get("D") or "Kompl.").strip() or "Kompl.",
            "qty": _xlsx_num(cells.get("E"), 1.0) or 1.0,
            "price": _xlsx_num(cells.get("F"), 0.0),
            "prev": h_val, "current": _act_round(cur), "total": _act_round(l_val or (h_val + cur)),
        })
    if not items:
        return None
    net = totals.get("net")
    vat = totals.get("vat")
    meta["vat"] = 21.0
    if net and vat and net > 0:
        rate = round(vat / net * 100.0, 1)
        if 0 <= rate <= 40:
            meta["vat"] = rate
    meta["items"] = items
    meta["totals"] = totals
    return meta


# ---------- F3 pažyma apie atliktų darbų vertę ----------

def _is_f3_form_text(text):
    """Ar dokumento tekstas yra F3 pažyma apie atliktų darbų vertę."""
    t = _fold_text(re.sub(r"\s+", " ", text or ""))[:60000]
    if not re.search(r"pazym\w* apie atlikt\w* darb\w* vert\w*", t):
        return False
    return "sutartine kaina" in t or "is viso" in t


_F3_TOTALS_PREFIXES = ("is viso", "pvm", "sulaikoma", "avanso", "isskaitytas",
                       "moketina", "rangovo gauti", "uzsakovo skola")


def _f3_num(cells, *cols):
    for c in cols:
        v = _xlsx_num(cells.get(c), None)
        if v is not None:
            return v
    return None


def _parse_f3_sheet(sheet):
    """F3 pažymos (Priedas Nr. 11) lapas -> rekvizitai, eilutės ir sumos."""
    rows = sheet.get("rows") or {}
    meta = {"customer": "", "contractor": "", "title": "", "number": "", "signed": "",
            "date": "", "num": None, "period_from": "", "period_to": ""}
    header_row = None
    for rn in sorted(rows):
        cells = rows[rn]
        text = _xlsx_text(cells)
        low = _fold_text(text)
        b = _fold_text(cells.get("B") or "")
        if header_row is None and ("grupiu" in b or "grupes" in b):
            header_row = rn
        if not meta["customer"] and low.startswith("uzsakovas"):
            meta["customer"] = _xlsx_right(cells, "A")
        if not meta["contractor"] and low.startswith("rangovas"):
            meta["contractor"] = _xlsx_right(cells, "A")
        if not meta["title"] and low.startswith("sutarties pavadinimas"):
            meta["title"] = _xlsx_right(cells, "A")
        if not meta["number"] and low.startswith("sutarties data ir numeris"):
            val = _xlsx_right(cells, "A")
            parts = re.split(r"\s*[;,]\s*", val, maxsplit=1)
            first = _xlsx_date(parts[0]) if len(parts) > 1 else ""
            if first:
                meta["signed"] = first
                meta["number"] = parts[1].strip()
            else:
                meta["number"] = val
        if not meta["date"] and low.startswith("pazymos data"):
            meta["date"] = _xlsx_date(_xlsx_right(cells, "A"))
        if not meta["period_from"] and "laikotarpis" in low:
            dates = re.findall(r"\d{4}-\d{2}-\d{2}", text)
            if len(dates) >= 2:
                meta["period_from"], meta["period_to"] = dates[0], dates[1]
            elif dates:
                meta["period_from"] = dates[0]
        if meta["num"] is None:
            m = re.search(r"pazym\w*\D{0,40}?nr\.?\s*(\d+)", low)
            if m:
                meta["num"] = int(m.group(1))
    if header_row is None:
        return None
    if meta["num"] is None:
        m = re.search(r"nr\.?\s*(\d+)", sheet.get("name") or "", re.I)
        if m:
            meta["num"] = int(m.group(1))
    items = []
    totals = {}
    for rn in sorted(rows):
        if rn <= header_row:
            continue
        cells = rows[rn]
        b = (cells.get("B") or "").strip()
        bu = _fold_text(b)
        if bu.startswith(_F3_TOTALS_PREFIXES):
            cur = _f3_num(cells, "F", "G")
            if bu.startswith("is viso su pvm"):
                totals["gross_current"] = cur
            elif bu.startswith("is viso"):
                totals["contract_price"] = _f3_num(cells, "D")
                totals["net_prev"] = _f3_num(cells, "E")
                totals["net_current"] = cur
                totals["net_total"] = _f3_num(cells, "G")
            elif bu.startswith("pvm"):
                totals["vat_current"] = cur
            elif bu.startswith("sulaikoma suma, proc"):
                totals["retention_pct"] = cur
            elif bu.startswith("sulaikoma suma, eur"):
                totals["retention_current"] = cur
            elif bu.startswith("avanso iskaita, proc"):
                totals["advance_pct"] = cur
            elif bu.startswith("isskaitytas avansas"):
                totals["advance_current"] = cur
            elif bu.startswith("moketina suma") and "su pvm" in bu:
                totals["payable_vat"] = cur
            elif bu.startswith("moketina suma"):
                totals["payable"] = cur
            elif bu.startswith("rangovo gauti"):
                totals["received"] = cur
            elif bu.startswith("uzsakovo skola"):
                totals["debt"] = cur
            continue
        a = (cells.get("A") or "").strip()
        if not b or not a.isdigit() or b.isdigit():
            continue
        price = _xlsx_num(cells.get("D"), 0.0)
        prev = _xlsx_num(cells.get("E"), 0.0)
        cur = _f3_num(cells, "F")
        total = _f3_num(cells, "G")
        if cur is None:
            cur = max(0.0, (total or 0.0) - (prev or 0.0))
        items.append({"name": b, "unit": (cells.get("C") or "Kompl.").strip() or "Kompl.",
                      "qty": 1.0, "price": _act_round(price), "prev": _act_round(prev),
                      "current": _act_round(cur), "total": _act_round(total or (prev + cur))})
    for key in ("retention_pct", "advance_pct"):
        v = totals.get(key)
        if v is not None and 0 < v <= 1.0:
            totals[key] = _act_round(v * 100.0)
    net, vat = totals.get("net_current"), totals.get("vat_current")
    if net and vat and net > 0:
        rate = round(vat / net * 100.0, 1)
        if 0 < rate <= 40:
            meta["vat"] = rate
    if not items and totals.get("net_current") is None:
        return None
    meta["items"] = items
    meta["totals"] = totals
    return meta


def import_f3_xlsx(raw, filename=""):
    """F3 pažyma iš Excel (Priedas Nr. 11) -> aktai, mokėjimai, sulaikymas."""
    if not raw:
        raise ValueError("Failas tuščias")
    if len(raw) > 20 * 1024 * 1024:
        raise ValueError("Failas per didelis (iki 20 MB)")
    try:
        sheets = _xlsx_parse(raw)
    except (zipfile.BadZipFile, KeyError, ET.ParseError, ValueError):
        raise ValueError("Failas nėra tinkamas Excel (.xlsx / .xlsm) dokumentas")
    parsed = [p for p in (_parse_f3_sheet(s) for s in sheets) if p]
    if not parsed:
        raise ValueError("Faile nerasta F3 pažymos lentelė su darbų grupėmis")
    parsed.sort(key=lambda p: (p.get("num") or 10 ** 9))
    return _import_parsed_f3(parsed, filename)


def _import_parsed_f3(parsed, filename=""):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    parsed = [p for p in parsed or [] if p.get("items") or p.get("totals", {}).get("net_current")]
    if not parsed:
        raise ValueError("F3 pažymoje nerasta sumų")
    first = parsed[0]
    with db() as conn:
        rows = [dict(r) for r in conn.execute("SELECT * FROM contracts ORDER BY id").fetchall()]
        contract = None
        want = _norm_doc_no(first.get("number"))
        if want:
            contract = next((c for c in rows if _norm_doc_no(c.get("number")) == want), None)
        if contract is None and first.get("title"):
            wt = _norm_doc_no(first.get("title"))
            contract = next((c for c in rows if _norm_doc_no(c.get("title")) == wt), None)
        if contract is None and len(rows) == 1:
            contract = rows[0]
        created_contract = False
        if contract is None:
            co = company_data()
            title = first.get("title") or Path(filename or "F3 pažyma").stem
            cur = conn.execute(
                "INSERT INTO contracts(title,customer,contractor,number,signed,vat,retention,advance,"
                "terms,created,updated) VALUES(?,?,?,?,?,?,?,?,30,?,?)",
                (title, first.get("customer") or "", first.get("contractor") or co.get("name") or "",
                 first.get("number") or "", first.get("signed") or "", first.get("vat") or 21.0,
                 first.get("totals", {}).get("retention_pct") or 0.0,
                 first.get("totals", {}).get("advance_pct") or 0.0, now, now))
            cid = cur.lastrowid
            contract = dict(conn.execute("SELECT * FROM contracts WHERE id=?", (cid,)).fetchone())
            created_contract = True
        else:
            cid = contract["id"]
            upd = {}
            for key, val in (("customer", first.get("customer")), ("title", first.get("title")),
                             ("contractor", first.get("contractor")), ("number", first.get("number")),
                             ("signed", first.get("signed"))):
                if val and not (contract.get(key) or ""):
                    upd[key] = val
            for pct_key, field in (("retention_pct", "retention"), ("advance_pct", "advance")):
                val = first.get("totals", {}).get(pct_key)
                if val and abs(_act_float(contract.get(field))) < 0.004:
                    upd[field] = val
            if upd:
                conn.execute("UPDATE contracts SET " + ", ".join(f"{k}=?" for k in upd) +
                             ", updated=? WHERE id=?", (*upd.values(), now, cid))
        groups = {_norm_group(g["name"]): dict(g) for g in conn.execute(
            "SELECT * FROM act_groups WHERE contract_id=? ORDER BY ord, id", (cid,)).fetchall()}
        for key, g in list(groups.items()):
            if not _fold_text(g.get("name")).startswith("sutarties kaina"):
                continue
            used = conn.execute("SELECT 1 FROM act_items WHERE group_id=? LIMIT 1", (g["id"],)).fetchone()
            if not used:
                conn.execute("DELETE FROM act_groups WHERE id=?", (g["id"],))
                groups.pop(key, None)
        max_ord = max([_act_float(g.get("ord")) for g in groups.values()] or [0.0])

        def ensure_group(name, unit, price):
            nonlocal max_ord
            key = _norm_group(name)
            g = groups.get(key)
            if g:
                if abs(_act_float(g.get("price"))) < 0.005 and price:
                    conn.execute("UPDATE act_groups SET price=? WHERE id=?", (price, g["id"]))
                    g["price"] = price
                return g
            max_ord += 1
            cur = conn.execute(
                "INSERT INTO act_groups(contract_id,name,unit,qty,price,ord,active) VALUES(?,?,?,1,?,?,1)",
                (cid, name, unit or "Kompl.", price or 0.0, max_ord))
            g = dict(conn.execute("SELECT * FROM act_groups WHERE id=?", (cur.lastrowid,)).fetchone())
            groups[key] = g
            return g

        nums = {r["num"] for r in conn.execute(
            "SELECT num FROM acts WHERE contract_id=?", (cid,)).fetchall()}
        imported, created, skipped, act_ids = [], [], [], []
        for p in parsed:
            num = p.get("num")
            if not num:
                num = (max(nums) if nums else 0) + 1
            act = conn.execute("SELECT * FROM acts WHERE contract_id=? AND num=? ORDER BY id",
                               (cid, num)).fetchone()
            if act and "f3" not in (act["note"] or "").lower():
                n_items = conn.execute("SELECT COUNT(*) n FROM act_items WHERE act_id=?",
                                       (act["id"],)).fetchone()["n"]
                if n_items:
                    skipped.append(num)
                    act_ids.append(act["id"])
                    _f3_update_act(conn, act["id"], p, now)
                    if p.get("totals", {}).get("received") is not None:
                        _f3_add_payment(conn, act["id"], cid, p, now)
                    continue
            if act:
                aid = act["id"]
                conn.execute(
                    "UPDATE acts SET date=?, period_from=?, period_to=?, status=?, note=?, updated=? "
                    "WHERE id=?",
                    (p.get("date") or p.get("period_to") or "", p.get("period_from") or "",
                     p.get("period_to") or "", "Pateiktas",
                     (act["note"] or "") if "f3" in (act["note"] or "").lower()
                     else ((act["note"] or "") + " ").strip() + "Sukurta iš F3 pažymos.",
                     now, aid))
            else:
                cur = conn.execute(
                    "INSERT INTO acts(contract_id,num,date,period_from,period_to,status,note,created,updated) "
                    "VALUES(?,?,?,?,?,?,?,?,?)",
                    (cid, num, p.get("date") or p.get("period_to") or "", p.get("period_from") or "",
                     p.get("period_to") or "", "Pateiktas", "Sukurta iš F3 pažymos.", now, now))
                aid = cur.lastrowid
                created.append(num)
                nums.add(num)
            title_key = _norm_group(first.get("title") or "")
            for it in p.get("items") or []:
                nm = _norm_group(it.get("name"))
                name = it.get("name")
                summary = bool(title_key and nm and len(nm) > 20 and
                               (nm == title_key or title_key.startswith(nm) or nm.startswith(title_key)))
                if summary or _fold_text(name).startswith("sutarties kaina"):
                    # Apibendrinanti F3 eilutė (visa sutartis) – laikoma sutarties kaina.
                    name = "Sutarties kaina"
                g = ensure_group(name, it.get("unit"), it.get("price"))
                if abs(_act_float(it.get("current"))) > 0.004:
                    conn.execute("INSERT OR REPLACE INTO act_items(act_id,group_id,amount) VALUES(?,?,?)",
                                 (aid, g["id"], it["current"]))
            _f3_update_act(conn, aid, p, now)
            _f3_add_payment(conn, aid, cid, p, now)
            imported.append(num)
            act_ids.append(aid)
        conn.execute("UPDATE contracts SET updated=? WHERE id=?", (now, cid))
        conn.commit()
    return {"ok": True, "contract_id": cid, "contract_created": created_contract,
            "acts": imported, "created": created, "skipped": skipped, "act_ids": act_ids}


def _f3_update_act(conn, act_id, parsed, now):
    totals = parsed.get("totals") or {}
    received = totals.get("received")
    debt = totals.get("debt")
    if received is None and debt is None:
        return
    conn.execute(
        "UPDATE acts SET received=COALESCE(?,received), debt=COALESCE(?,debt), updated=? WHERE id=?",
        (received, debt, now, act_id))


def _f3_add_payment(conn, act_id, contract_id, parsed, now):
    """F3 „gauti mokėjimai“ yra kumuliatyviniai – įrašoma tik trūkstama dalis."""
    received = (parsed.get("totals") or {}).get("received")
    if not received or received <= 0:
        return
    paid = conn.execute(
        "SELECT COALESCE(SUM(p.amount),0) s FROM act_payments p JOIN acts a ON a.id=p.act_id "
        "WHERE a.contract_id=?", (contract_id,)).fetchone()["s"]
    diff = _act_round(received - paid)
    if diff <= 0.004:
        return
    conn.execute(
        "INSERT INTO act_payments(act_id,date,amount,note,created) VALUES(?,?,?,?,?)",
        (act_id, parsed.get("date") or parsed.get("period_to") or today_iso(), diff,
         f"Pagal F3 pažymą Nr. {parsed.get('num') or ''}".strip(), now))


def _attach_doc_to_act(act_id, path):
    """Nukopijuoja šaltinio dokumentą į akto failus (kad būtų „savo vietoje“)."""
    try:
        path = Path(path)
        if not path.exists():
            return False
        with db() as conn:
            has = conn.execute("SELECT 1 FROM act_files WHERE act_id=? AND name=?",
                               (int(act_id), path.name)).fetchone()
        if has:
            return False
        folder = act_files_dir(act_id)
        folder.mkdir(parents=True, exist_ok=True)
        dest = unique_upload_path(folder, path.name)
        shutil.copy2(path, dest)
        add_act_file(act_id, path.name, dest.name, dest.stat().st_size)
        return True
    except Exception as e:
        logger.warning("Nepavyko pridėti dokumento prie akto: %s", e)
        return False


def _attach_f3_text(text, path):
    """F3 pažymos PDF/DOCX dokumentą priskiria atitinkamam aktui (be sumų importo)."""
    t = _fold_text(re.sub(r"\s+", " ", text or ""))
    nums = [int(n) for n in re.findall(r"nr\.?\s*(\d{1,3})\b", t)]
    flat = _norm_doc_no(re.sub(r"\s+", "", text or ""))[:60000]
    with db() as conn:
        contracts = [dict(r) for r in conn.execute("SELECT * FROM contracts ORDER BY id").fetchall()]
        contract = None
        for c in contracts:
            key = _norm_doc_no(c.get("number"))
            if key and key in flat:
                contract = c
                break
        if contract is None and len(contracts) == 1:
            contract = contracts[0]
        if contract is None:
            return None
        act = None
        for n in nums:
            act = conn.execute("SELECT * FROM acts WHERE contract_id=? AND num=? ORDER BY id",
                               (contract["id"], n)).fetchone()
            if act:
                break
        if act is None:
            acts = conn.execute("SELECT id FROM acts WHERE contract_id=?", (contract["id"],)).fetchall()
            if len(acts) != 1:
                return None
            act = acts[0]
        aid = act["id"]
    return aid if _attach_doc_to_act(aid, path) else aid


def import_act_xlsx(raw, filename="", contract_id=None):
    if not raw:
        raise ValueError("Failas tuščias")
    if len(raw) > 20 * 1024 * 1024:
        raise ValueError("Failas per didelis (iki 20 MB)")
    try:
        sheets = _xlsx_parse(raw)
    except (zipfile.BadZipFile, KeyError, ET.ParseError, ValueError):
        raise ValueError("Failas nėra tinkamas Excel (.xlsx / .xlsm) dokumentas")
    parsed = [p for p in (_parse_f2_sheet(s) for s in sheets) if p]
    if not parsed:
        blob = _fold_text(" ".join(
            _xlsx_text(cells) for s in sheets for cells in s.get("rows", {}).values()))
        if "akto forma" in blob and "sutartine kaina" in blob:
            raise ValueError(
                "Šis failas yra tuščias akto šablonas (Priedas Nr. 10): jame nėra "
                "darbų eilučių ar sumų. Įkelkite užpildytą F2 aktą.")
        if "pazym" in blob and "atlikt" in blob:
            raise ValueError(
                "Šis failas yra F3 pažyma (Priedas Nr. 11). F3 pažymą programa "
                "sugeneruoja pagal F2 akto duomenis – įkelkite F2 aktą "
                "(Priedas Nr. 10).")
        raise ValueError("Faile nerasta F2 akto lentelė su darbų eilutėmis")
    parsed.sort(key=lambda p: (p.get("num") or 10 ** 9))
    seen = set()
    uniq = []
    for p in parsed:
        n = p.get("num")
        if n in seen:
            continue
        seen.add(n)
        uniq.append(p)
    parsed = uniq
    return _import_parsed_acts(parsed, filename, contract_id)


def _norm_doc_no(value):
    """Normalizuoja sutarties numerį palyginimui (OCR painioja O/0, I/1)."""
    t = str(value or "").lower()
    t = t.replace("o", "0").replace("i", "1").replace("l", "1")
    return re.sub(r"[^0-9a-z]", "", t)


def _import_parsed_acts(parsed, filename="", contract_id=None):
    first = parsed[0]
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with db() as conn:
        contract = None
        if contract_id:
            row = conn.execute("SELECT * FROM contracts WHERE id=?", (contract_id,)).fetchone()
            if not row:
                raise ValueError("Sutartis nerasta")
            contract = dict(row)
        else:
            if first.get("number"):
                row = conn.execute("SELECT * FROM contracts WHERE number=? ORDER BY id DESC LIMIT 1",
                                   (first["number"],)).fetchone()
                if row:
                    contract = dict(row)
                else:
                    want = _norm_doc_no(first["number"])
                    if want:
                        for c in conn.execute("SELECT * FROM contracts ORDER BY id").fetchall():
                            if _norm_doc_no(c["number"]) == want:
                                contract = dict(c)
                                break
            if contract is None and first.get("title"):
                row = conn.execute("SELECT * FROM contracts WHERE title=? ORDER BY id DESC LIMIT 1",
                                   (first["title"],)).fetchone()
                if row:
                    contract = dict(row)
        if contract is None:
            co = company_data()
            title = first.get("title") or Path(filename or "Importuotas aktas").stem
            cur = conn.execute(
                "INSERT INTO contracts(title,customer,contractor,number,signed,vat,retention,advance,"
                "terms,created,updated) VALUES(?,?,?,?,?,?,5,0,30,?,?)",
                (title, first.get("customer") or "",
                 first.get("contractor") or co.get("name") or "",
                 first.get("number") or "", first.get("signed") or "", first.get("vat") or 21.0, now, now))
            cid = cur.lastrowid
            contract = dict(conn.execute("SELECT * FROM contracts WHERE id=?", (cid,)).fetchone())
        else:
            cid = contract["id"]
            upd = {}
            for key, val in (("customer", first.get("customer")), ("title", first.get("title")),
                             ("contractor", first.get("contractor")), ("number", first.get("number")),
                             ("signed", first.get("signed"))):
                if val and not (contract.get(key) or ""):
                    upd[key] = val
            if upd:
                conn.execute("UPDATE contracts SET " + ", ".join(f"{k}=?" for k in upd) +
                             ", updated=? WHERE id=?", (*upd.values(), now, cid))
        groups = {_norm_group(g["name"]): dict(g) for g in conn.execute(
            "SELECT * FROM act_groups WHERE contract_id=? ORDER BY ord, id", (cid,)).fetchall()}
        real_items = any(not _fold_text(it.get("name")).startswith("sutarties kaina")
                         for p in parsed for it in (p.get("items") or []))
        for key, g in list(groups.items()):
            if not _fold_text(g.get("name")).startswith("sutarties kaina"):
                continue
            used = conn.execute("SELECT 1 FROM act_items WHERE group_id=? LIMIT 1", (g["id"],)).fetchone()
            if real_items or not used:
                # F2 eilutės yra tikslios – sutarties kainos pakaitinė eilutė nebereikalinga.
                conn.execute("DELETE FROM act_items WHERE group_id=?", (g["id"],))
                conn.execute("DELETE FROM act_groups WHERE id=?", (g["id"],))
                groups.pop(key, None)
        max_ord = max([_act_float(g.get("ord")) for g in groups.values()] or [0.0])

        def ensure_group(name, unit, qty, price):
            nonlocal max_ord
            key = _norm_group(name)
            g = groups.get(key)
            if g:
                if not g.get("active", 1):
                    conn.execute("UPDATE act_groups SET active=1 WHERE id=?", (g["id"],))
                    g["active"] = 1
                if abs(_act_float(g.get("price"))) < 0.005 and price:
                    conn.execute("UPDATE act_groups SET price=? WHERE id=?", (price, g["id"]))
                    g["price"] = price
                return g
            max_ord += 1
            cur = conn.execute(
                "INSERT INTO act_groups(contract_id,name,unit,qty,price,ord,active) VALUES(?,?,?,?,?,?,1)",
                (cid, name, unit or "Kompl.", qty or 1.0, price or 0.0, max_ord))
            g = dict(conn.execute("SELECT * FROM act_groups WHERE id=?", (cur.lastrowid,)).fetchone())
            groups[key] = g
            return g

        imported, skipped, warnings, item_count = [], [], [], 0
        imported_ids = []
        for p in parsed:
            act_num = p.get("num")
            nums = {r["num"] for r in conn.execute(
                "SELECT num FROM acts WHERE contract_id=?", (cid,)).fetchall()}
            if not act_num:
                act_num = (max(nums) if nums else 0) + 1
            existing = conn.execute(
                "SELECT a.*, (SELECT COUNT(*) FROM act_items i WHERE i.act_id=a.id) AS n "
                "FROM acts a WHERE a.contract_id=? AND a.num=? ORDER BY a.id", (cid, act_num)).fetchone()
            if existing and existing["n"]:
                if "f3" not in (existing["note"] or "").lower():
                    skipped.append(act_num)
                    continue
                # F2 yra tikslesnis šaltinis – pakeičia iš F3 pažymos sudarytas eilutes.
                conn.execute("DELETE FROM act_items WHERE act_id=?", (existing["id"],))
                conn.execute("UPDATE acts SET note='' WHERE id=?", (existing["id"],))
                existing = dict(existing)
                existing["n"] = 0
            if existing:
                aid = existing["id"]
            else:
                aid = None
            for it in p["items"]:
                it["group"] = ensure_group(it["name"], it["unit"], it["qty"], it["price"])
            prev_total = sum(it["prev"] for it in p["items"])
            if aid is None and prev_total > 0.004 and act_num > 1 and not any(n < act_num for n in nums):
                syn = act_num - 1
                if syn not in nums:
                    syn_date = ""
                    if p.get("period_from"):
                        try:
                            syn_date = (date.fromisoformat(p["period_from"]) - timedelta(days=1)).isoformat()
                        except ValueError:
                            syn_date = ""
                    cur = conn.execute(
                        "INSERT INTO acts(contract_id,num,date,period_from,period_to,status,note,created,updated) "
                        "VALUES(?,?,?,?,?,?,?,?,?)",
                        (cid, syn, syn_date, "", "", "Patvirtintas",
                         "Importuota: ankstesni laikotarpiai", now, now))
                    sid = cur.lastrowid
                    for it in p["items"]:
                        if abs(it["prev"]) > 0.004:
                            conn.execute("INSERT INTO act_items(act_id,group_id,amount) VALUES(?,?,?)",
                                         (sid, it["group"]["id"], it["prev"]))
                    nums.add(syn)
            if aid is None:
                cur = conn.execute(
                    "INSERT INTO acts(contract_id,num,date,period_from,period_to,status,created,updated) "
                    "VALUES(?,?,?,?,?,?,?,?)",
                    (cid, act_num, p.get("date") or p.get("period_to") or "", p.get("period_from") or "",
                     p.get("period_to") or "", "Pateiktas", now, now))
                aid = cur.lastrowid
            else:
                conn.execute(
                    "UPDATE acts SET date=?, period_from=?, period_to=?, status=?, updated=? WHERE id=?",
                    (p.get("date") or p.get("period_to") or "", p.get("period_from") or "",
                     p.get("period_to") or "", "Pateiktas", now, aid))
            for it in p["items"]:
                if abs(it["current"]) > 0.004:
                    conn.execute("INSERT OR REPLACE INTO act_items(act_id,group_id,amount) VALUES(?,?,?)",
                                 (aid, it["group"]["id"], it["current"]))
                    item_count += 1
            imported.append(act_num)
            imported_ids.append(aid)
            net = p["totals"].get("net")
            sum_cur = sum(it["current"] for it in p["items"])
            if net is not None and abs(sum_cur - net) > 0.1:
                warnings.append(f"Nr. {act_num}: eilučių suma {sum_cur:.2f} ≠ akto iš viso {net:.2f}")
        conn.execute("UPDATE contracts SET updated=? WHERE id=?", (now, cid))
        conn.commit()
    return {"ok": True, "contract_id": cid, "contract_title": contract.get("title") or "",
            "acts": imported, "act_ids": imported_ids, "skipped": skipped, "items": item_count,
            "groups": len(groups), "warnings": warnings}


# ---------- F2 importas iš PDF (tekstinis sluoksnis) ----------

def _pdf_layout_text(raw):
    try:
        from pypdf import PdfReader
    except ImportError:
        raise ValueError("PDF importui reikia pypdf bibliotekos")
    try:
        reader = PdfReader(io.BytesIO(raw))
    except Exception:
        raise ValueError("Nepavyko perskaityti PDF dokumento")
    if getattr(reader, "is_encrypted", False):
        try:
            reader.decrypt("")
        except Exception:
            raise ValueError("PDF apsaugotas slaptažodžiu")
    chunks = []
    for page in list(reader.pages)[:4]:
        try:
            chunks.append(page.extract_text(extraction_mode="layout") or "")
        except TypeError:
            chunks.append(page.extract_text() or "")
        except Exception:
            continue
    return "\n".join(chunks)


def _pdf_rotation(raw):
    """Ar bent vienas PDF puslapis pažymėtas kaip pasuktas."""
    try:
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(raw))
        return any(int(page.get("/Rotate") or 0) % 360 for page in reader.pages)
    except Exception:
        return False


def _pdf_upright(raw):
    """PDF kopija, kurioje puslapių pasukimas nuimtas (sugadinti /Rotate)."""
    try:
        from pypdf import PdfReader, PdfWriter
        from pypdf.generic import NameObject, NumberObject
        reader = PdfReader(io.BytesIO(raw))
        writer = PdfWriter()
        for page in reader.pages:
            try:
                page[NameObject("/Rotate")] = NumberObject(0)
            except Exception:
                pass
            writer.add_page(page)
        buf = io.BytesIO()
        writer.write(buf)
        return buf.getvalue()
    except Exception:
        return b""


def _ocr_letter_score(text):
    return len(re.findall(r"[A-Za-zÀ-ž]{2,}", text or ""))


def _ocr_pdf_pages(raw, pages=4):
    """Skenuoto PDF tekstas ir žodžių koordinatės per Windows OCR.

    Kai kuriuose skenuotuose PDF būna neteisingas puslapio /Rotate – tokiu
    atveju variklis rodo tekstą gulus. Bandome abu variantus ir imame geresnį.
    Grąžina (tekstas, [(lapas, [(žodis, x, y, w, h), ...]), ...]).
    """
    if not ocr_supported():
        return "", []
    fd, out = tempfile.mkstemp(prefix="stabas-ocr-pdf-", suffix=".pdf")
    os.close(fd)
    path = Path(out)
    try:
        variants = [raw]
        if _pdf_rotation(raw):
            upright = _pdf_upright(raw)
            if upright:
                variants.append(upright)
        best_text, best_pages, best_score = "", [], -1
        for i, data in enumerate(variants):
            path.write_bytes(data)
            word_pages = _winocr_words(path, pages)
            lines = []
            for _, words in word_pages:
                for _, ws in _group_word_lines(words, 0.0):
                    lines.append(" ".join(w[0] for w in ws))
            text = "\n".join(lines)
            score = _ocr_letter_score(text)
            if score > best_score:
                best_text, best_pages, best_score = text, word_pages, score
            if i == 0 and score >= 200:
                break
        return best_text, best_pages
    finally:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass


def _ocr_pdf_text(raw, pages=OCR_MAX_PAGES):
    """Skenuoto PDF tekstas paieškai (tvarko neteisingą /Rotate)."""
    if not ocr_supported():
        return ""
    fd, out = tempfile.mkstemp(prefix="stabas-ocr-", suffix=".pdf")
    os.close(fd)
    path = Path(out)
    try:
        best = ""
        for i, data in enumerate([raw] + ([_pdf_upright(raw)] if _pdf_rotation(raw) else [])):
            if not data:
                continue
            path.write_bytes(data)
            text = "\n".join(t for _, t in _winocr_pages(path, pages))
            if _ocr_letter_score(text) > _ocr_letter_score(best):
                best = text
            if i == 0 and _ocr_letter_score(best) >= 200:
                break
        return best
    finally:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass


def _group_word_lines(words, k):
    """Sujungia OCR žodžius į eilutes, atsižvelgiant į skeno pasvirimą.

    k – eilutės posvyris (y + k*x). Grąžina [(yc, [(žodis, x, y, w, h), ...])].
    """
    items = sorted(words, key=lambda w: w[2] + k * w[1])
    lines = []
    for w in items:
        yc = w[2] + k * w[1]
        if lines and abs(yc - lines[-1][0]) <= 12:
            lines[-1][1].append(w)
        else:
            lines.append([yc, [w]])
    for line in lines:
        line[1].sort(key=lambda w: w[1])
    return [(yc, ws) for yc, ws in lines]


def _pdf_num(tok):
    t = str(tok).replace("\u00a0", " ").replace(" ", "").replace("€", "").replace("%", "")
    if not t:
        return None
    if "." in t and "," in t:
        if t.rfind(",") > t.rfind("."):
            t = t.replace(".", "").replace(",", ".")
        else:
            t = t.replace(",", "")
    else:
        t = t.replace(",", ".")
    parts = t.split(".")
    if len(parts) > 2:
        if len(parts[-1]) <= 2:
            t = "".join(parts[:-1]) + "." + parts[-1]
        else:
            t = "".join(parts)
    try:
        return float(t)
    except ValueError:
        return None


def _ocr_cents(tok, val):
    """OCR dažnai praranda tūkstančių skirtukus ir dešimtainį kablelį
    (pvz. „3 764,29“ perskaitoma kaip „376429“). Tokį sveiką skaičių
    grąžiname centų tikslumu."""
    t = str(tok or "").strip()
    if val is not None and re.fullmatch(r"\d{4,}", t):
        return round(val / 100.0, 2)
    return val


def _f2_cell_num(tokens):
    """Sujungia celės OCR žetonus ir grąžina skaičių.

    Skenuose tūkstančių tarpai atskiria žetonus („2“ + „516,41“), o dešimtainis
    kablelis kartais prarandamas („1217208“ = 12 172,08).
    """
    parts = [t[0] for t in sorted(tokens or [], key=lambda w: w[1])]
    raw = "".join(p.strip() for p in parts)
    if not raw:
        return None
    raw = raw.replace("o", "0").replace("O", "0")
    raw = re.sub(r"[^0-9.,]", "", raw)
    if not raw:
        return None
    if "," in raw and "." in raw:
        if raw.rfind(",") > raw.rfind("."):
            raw = raw.replace(".", "").replace(",", ".")
        else:
            raw = raw.replace(",", "")
    elif "," in raw:
        raw = raw.replace(",", ".")
    if raw.count(".") > 1:
        chunks = raw.split(".")
        raw = "".join(chunks[:-1]) + "." + chunks[-1]
    if "." not in raw and len(raw) > 3:
        raw = raw[:-2] + "." + raw[-2:]
    try:
        return float(raw)
    except ValueError:
        return None


def _f2_words_meta(words, k, filename=""):
    """F2 akto rekvizitai iš OCR žodžių (skenuotas aktas)."""
    meta = {"customer": "", "contractor": "", "title": "", "number": "", "signed": "",
            "date": "", "num": None, "period_from": "", "period_to": "", "vat": 21.0}
    items = [(_fold_text(w[0]), w[1], w[2] + k * w[1], w[0]) for w in words]

    def label(*frags, xmin=100, xmax=1000):
        for text, x, yc, _ in items:
            if xmin < x < xmax and any(f in text for f in frags):
                return x, yc
        return None

    def lines_of(picked, band=14):
        rows = []
        for it in sorted(picked, key=lambda it: it[2]):
            if rows and abs(it[2] - rows[-1][0]) <= band:
                rows[-1][1].append(it)
            else:
                rows.append([it[2], [it]])
        out = []
        for _, ws in rows:
            ws.sort(key=lambda it: it[1])
            out.append(" ".join(it[3] for it in ws))
        return out

    def value(x0, yc0, xmin, band, xmax=4000):
        picked = [it for it in items if it[1] > max(x0 + 90, xmin) and abs(it[2] - yc0) <= band]
        return re.sub(r"\s{2,}", " ", " ".join(lines_of(picked))).strip()

    cust = label("sakovas")
    if cust:
        meta["customer"] = value(cust[0], cust[1], 400, 30)
    contr = label("rangovas")
    if contr:
        meta["contractor"] = value(contr[0], contr[1], 400, 26)
        m = re.search(r'["„].+', meta["contractor"])
        if m and len(m.group(0)) > 3:
            meta["contractor"] = m.group(0).strip()
    title = label("pavadinimas")
    if title:
        picked = [it for it in items if it[1] > title[0] + 120 and
                  title[1] - 75 <= it[2] <= title[1] + 12]
        meta["title"] = re.sub(r"\s{2,}", " ", " ".join(lines_of(picked))).strip()
    num = label("numeris")
    if num:
        raw = value(num[0], num[1], 400, 22)
        m = re.search(r"(\d{4}-\d{2}-\d{2})", raw)
        if m:
            meta["signed"] = m.group(1)
            raw = raw.replace(m.group(1), " ")
        meta["number"] = " ".join(raw.replace(":", " ").split()).strip(" ;:.,-")
    adate = label("data:", xmin=180, xmax=520)
    if adate:
        raw = value(adate[0], adate[1], 400, 22)
        m = re.search(r"(\d{4}-\d{2}-\d{2})", raw)
        if m:
            meta["date"] = m.group(1)
    period = label("kotarpis")
    if period:
        raw = value(period[0], period[1], 400, 22)
        dates = re.findall(r"\d{4}-\d{2}-\d{2}", raw)
        if len(dates) >= 2:
            meta["period_from"], meta["period_to"] = dates[0], dates[1]
    for i, (text, x, yc, raw) in enumerate(items):
        if text == "nr.":
            near = [it for it in items if it[0].startswith("aktas") and abs(it[2] - yc) < 14
                    and it[1] < x]
            digits = [it for it in items if it[1] > x and abs(it[2] - yc) < 14
                      and re.fullmatch(r"\d{1,4}", it[3])]
            if near and digits:
                meta["num"] = int(min(digits, key=lambda it: it[1])[3])
                break
    if meta["num"] is None:
        m = re.search(r"nr\.?\s*(\d+)", filename or "", re.I)
        if m:
            meta["num"] = int(m.group(1))
    return meta


def _f2_estimate_skew(words):
    """Įvertina skeno pasvirimą (y + k*x), kad eilutės susidėliotų tiesiai."""
    tokens = [(w[1], w[2]) for w in words
              if w[1] > 500 and re.fullmatch(r"[\d.,oO]{1,12}", w[0].strip())]
    if len(tokens) < 50:
        return 0.0
    best_k, best_score = 0.0, -1
    for step in range(-50, 51):
        k = step * 0.0012
        bins = {}
        for x, y in tokens:
            b = int((y + k * x) / 12)
            bins[b] = bins.get(b, 0) + 1
        score = sum(v * v for v in bins.values())
        if score > best_score:
            best_score, best_k = score, k
    return best_k


def _f2_peak_anchors(words, k):
    """Randa 6 skaičių stulpelių (7–12) centrus pagal žodžių pasiskirstymą."""
    hdr = [w for w in words if re.fullmatch(r"\d{1,2}", w[0]) and w[3] <= 40 and w[1] > 900]
    hy = [w[2] + k * w[1] for w in hdr if w[0] in ("7", "8", "9", "10", "11", "12")]
    y_min = (min(hy) + 20) if hy else 0
    centers = []
    for w in words:
        if w[1] < 600 or not re.fullmatch(r"[\d.,oO]{1,12}", w[0].strip()):
            continue
        yc = w[2] + k * w[1]
        if yc > y_min:
            centers.append(w[1] + w[3] / 2)
    if len(centers) < 60:
        return None
    centers.sort()
    clusters = []
    for c in centers:
        if clusters and c - clusters[-1][-1] <= 70:
            clusters[-1].append(c)
        else:
            clusters.append([c])
    strong = [(len(cl), sum(cl) / len(cl)) for cl in clusters if len(cl) >= 6]
    if len(strong) < 6:
        return None
    tail = strong[-6:]
    gaps = [tail[i + 1][1] - tail[i][1] for i in range(5)]
    if min(gaps) < 90 or max(gaps) > min(gaps) * 1.75:
        return None
    return {7 + i: tail[i][1] for i in range(6)}


def _f2_mark_num(text):
    """Eilutės numeris su OCR klaidų taisymu (IO→10, l→1, O→0)."""
    t = (text or "").strip().rstrip(".")
    t = t.replace("I", "1").replace("l", "1").replace("O", "0").replace("o", "0")
    if not re.fullmatch(r"\d{1,2}", t):
        return None
    n = int(t)
    return n if 1 <= n <= 30 else None


def _f2_words_page(words):
    """Skenuoto F2 puslapio lentelė pagal OCR žodžių koordinates."""
    if len(words) < 80:
        return None
    hdr = [w for w in words if re.fullmatch(r"\d{1,2}", w[0]) and w[3] <= 40 and w[1] > 180]
    band = None
    for anchor in hdr:
        if anchor[0] not in ("7", "9", "10") or anchor[1] < 900:
            continue
        cand = {}
        for w in hdr:
            if abs(w[2] - anchor[2]) <= 24 and w[0] in ("7", "8", "9", "10", "11", "12"):
                cand[int(w[0])] = w
        if len(cand) >= 5 and 7 in cand and 12 in cand:
            xs = [cand[c][1] + cand[c][3] / 2 for c in sorted(cand)]
            if all(xs[i] < xs[i + 1] for i in range(len(xs) - 1)) and xs[-1] - xs[0] > 500:
                band = cand
                break
    if band:
        pts = [(w[1] + w[3] / 2, w[2]) for w in band.values()]
        mx = sum(p[0] for p in pts) / len(pts)
        my = sum(p[1] for p in pts) / len(pts)
        den = sum((p[0] - mx) ** 2 for p in pts) or 1.0
        k = sum((p[0] - mx) * (p[1] - my) for p in pts) / den
        k = -k
        if abs(k) > 0.12:
            k = 0.0
        anchors = {c: band[c][1] + band[c][3] / 2 for c in band}
        spacing = (anchors[12] - anchors[7]) / 5.0
        if spacing < 60:
            return None
        y7 = band[7][2] + k * anchors[7]
        for col in (6, 5, 4):
            pred = anchors[7] - (7 - col) * spacing
            pred_y = y7 + k * (pred - anchors[7])
            cand = [w for w in hdr if w[0] == str(col) and abs(w[2] - pred_y) < 22
                    and abs(w[1] + w[3] / 2 - pred) < spacing * 0.6]
            anchors[col] = ((cand[0][1] + cand[0][3] / 2) if cand else pred)
    else:
        # Antrasis skenų variantas: antraštėje trūksta 7–12 numerių.
        # Stulpelius randame pagal skaičių pasiskirstymą, o pasvirimą – pagal eilučių dėsnį.
        k = _f2_estimate_skew(words)
        anchors = _f2_peak_anchors(words, k)
        if not anchors:
            return None
        spacing = (anchors[12] - anchors[7]) / 5.0
        if spacing < 60:
            return None
        for col in (6, 5, 4):
            anchors[col] = anchors[7] - (7 - col) * spacing
        hdr_nums = [w for w in words
                    if w[0] in ("7", "8", "9", "10", "11", "12") and w[3] <= 40 and w[1] > 900]
        best_group = []
        for w0 in hdr_nums:
            grp = [w for w in hdr_nums if abs(w[2] - w0[2]) <= 24]
            if len(grp) > len(best_group):
                best_group = grp
        if len(best_group) >= 4:
            y7 = min(w[2] + k * w[1] for w in best_group)
        else:
            marks_all = sorted(
                (w for w in words if _f2_mark_num(w[0]) and w[3] <= 30
                 and w[1] + w[3] / 2 < 340),
                key=lambda w: w[2] + k * w[1])
            if len(marks_all) < 8:
                return None
            best_gap, cut = 0.0, 0
            for i in range(min(4, len(marks_all) - 1)):
                gap = ((marks_all[i + 1][2] + k * marks_all[i + 1][1])
                       - (marks_all[i][2] + k * marks_all[i][1]))
                if gap > best_gap:
                    best_gap, cut = gap, i + 1
            y7 = marks_all[cut][2] + k * marks_all[cut][1] - 30
    tol = spacing * 0.45
    row_marks = [w for w in words if _f2_mark_num(w[0]) and w[3] <= 30
                 and w[1] + w[3] / 2 < 340 and w[2] + k * w[1] > y7 + 45]
    row_marks.sort(key=lambda w: w[2] + k * w[1])
    if len(row_marks) < 6:
        return None
    items = []
    for mark in row_marks:
        row_y = mark[2] + k * mark[1]
        cells, name_parts = {}, []
        for w in words:
            if w is mark:
                continue
            yc = w[2] + k * w[1]
            if abs(yc - row_y) > 17:
                continue
            cx = w[1] + w[3] / 2
            if cx < 350:
                continue
            best, dist = None, 1e9
            for col, ax in anchors.items():
                d = abs(cx - ax)
                if d < dist:
                    best, dist = col, d
            if best is not None and dist <= tol:
                cells.setdefault(best, []).append(w)
            else:
                name_parts.append(w)
        prev = _f2_cell_num(cells.get(8))
        cur = _f2_cell_num(cells.get(10))
        tot = _f2_cell_num(cells.get(12))
        if prev is None and cur is None and tot is None:
            continue
        if prev is not None and cur is not None:
            if tot is None or abs(tot - (prev + cur)) > max(0.07, abs(tot) * 0.002):
                # OCR dažnai nukerpa pirmą sumos skaitmenį – sumą apskaičiuojame patys.
                tot = _act_round(prev + cur)
        elif tot is not None and (prev is None or cur is None):
            continue
        name_parts.sort(key=lambda w: w[1])
        name = " ".join(w[0] for w in name_parts).strip(" .:;,-")
        if len(name) < 3:
            name = "Darbų grupė %s" % mark[0]
        unit_raw = " ".join(w[0] for w in sorted(cells.get(4, []), key=lambda w: w[1])).strip()
        uf = _fold_text(unit_raw)
        if uf.startswith(("kom", "ko")):
            unit = "Kompl."
        elif re.fullmatch(r"[il1]\.?", uf):
            unit = "l."
        else:
            unit = unit_raw or "Kompl."
        qty = _f2_cell_num(cells.get(5))
        price = _f2_cell_num(cells.get(6))
        items.append({
            "name": name, "unit": unit, "qty": qty if qty else 1.0,
            "price": _act_round(price or 0.0),
            "prev": _act_round(prev or 0.0),
            "current": _act_round(cur or 0.0),
            "total": _act_round(tot if tot is not None else (prev or 0.0) + (cur or 0.0)),
        })
    if len(items) < 6:
        return None
    rows_max = max(w[2] + k * w[1] for w in row_marks)
    totals_y = None
    for w in words:
        yc = w[2] + k * w[1]
        if yc > rows_max + 12 and 500 < w[1] < 1400 and _fold_text(w[0]).startswith(("viso", "visa")):
            totals_y = yc
            break
    if totals_y is None:
        return None

    def cells_at(yc0, tol2=22):
        res = {}
        for w in words:
            yc = w[2] + k * w[1]
            if abs(yc - yc0) > tol2:
                continue
            cx = w[1] + w[3] / 2
            for col, ax in anchors.items():
                if abs(cx - ax) <= tol:
                    res.setdefault(col, []).append(w)
        return res

    total_cells = cells_at(totals_y)
    net = _f2_cell_num(total_cells.get(10))
    if net is None:
        net = _f2_cell_num(total_cells.get(12))
    prev_total = _f2_cell_num(total_cells.get(8))
    if net is None:
        return None
    sum_cur = sum(it["current"] for it in items)
    if abs(sum_cur - net) > max(1.0, abs(net) * 0.005):
        return None
    sum_prev = sum(it["prev"] for it in items)
    if prev_total is not None and abs(sum_prev - prev_total) > max(1.0, abs(prev_total) * 0.01):
        return None
    vat = None
    for w in words:
        yc = w[2] + k * w[1]
        if yc > totals_y and yc < totals_y + 140 and 700 < w[1] < 1500 \
                and _fold_text(w[0]).startswith("pvm"):
            vat = _f2_cell_num(cells_at(yc, 18).get(10))
            break
    meta = _f2_words_meta(words, k)
    meta["items"] = items
    meta["totals"] = {"net": net, "prev": prev_total, "vat": vat,
                      "gross": (net + vat) if vat is not None else None}
    return meta


def _parse_f2_words(pages, filename=""):
    """Bando atpažinti F2 aktą skenuotame PDF pagal žodžių koordinates."""
    for _, words in pages or []:
        flat = _fold_text(" ".join(w[0] for w in words))
        if "sutartine kaina" not in flat or not re.search(r"atlikt\w*\s+darb", flat):
            continue
        try:
            meta = _f2_words_page(words)
        except Exception:
            logger.warning("F2 žodžių analizė nepavyko", exc_info=True)
            meta = None
        if meta:
            if not meta.get("num"):
                m = re.search(r"nr\.?\s*(\d+)", filename or "", re.I)
                if m:
                    meta["num"] = int(m.group(1))
            return meta
    return None


def _parse_f2_pdf_text(text, filename="", ocr=False):
    lines = [ln.rstrip() for ln in str(text or "").splitlines()]
    meta = {"customer": "", "contractor": "", "title": "", "number": "", "signed": "",
            "date": "", "num": None, "period_from": "", "period_to": "", "vat": 21.0}
    labels = (
        ("customer", "užsakovas"), ("contractor", "rangovas"),
        ("title", "sutarties pavadinimas"), ("number", "sutarties data ir numeris"),
        ("date", "akto data"), ("date", "pažymos data"),
    )
    for ln in lines:
        s = ln.strip()
        if not s:
            continue
        low = s.lower()
        for key, label in labels:
            if low.startswith(label + ":") or low.startswith(label + " :"):
                val = s.split(":", 1)[1].strip()
                if not val:
                    continue
                if key == "number":
                    parts = re.split(r"\s*[;,]\s*", val, maxsplit=1)
                    first = _xlsx_date(parts[0]) if len(parts) > 1 else ""
                    if first:
                        meta["signed"] = first
                        meta["number"] = parts[1].strip()
                    else:
                        meta["number"] = val
                elif key == "date":
                    if not meta["date"]:
                        meta["date"] = _xlsx_date(val)
                elif not meta[key]:
                    meta[key] = val
        if not meta["period_from"] and "laikotarpis" in low:
            dates = re.findall(r"\d{4}-\d{2}-\d{2}", s)
            if len(dates) >= 2:
                meta["period_from"], meta["period_to"] = dates[0], dates[1]
            elif dates:
                meta["period_from"] = dates[0]
        if meta["num"] is None:
            m = re.search(r"ATLIKTŲ DARBŲ AKTAS\s+NR\.?\s*(\d+)", s, re.I)
            if m:
                meta["num"] = int(m.group(1))
        if not meta.get("vat_rate"):
            m = re.search(r"PVM\s+(\d+(?:[.,]\d+)?)\s*%", s, re.I)
            if m:
                meta["vat"] = _act_float(m.group(1).replace(",", "."), 21.0)
                meta["vat_rate"] = meta["vat"]
    items = []
    totals = {"net": None, "prev": None, "vat": None, "gross": None}
    for ln in lines:
        s = ln.strip()
        if not s:
            continue
        fields = [f for f in re.split(r"\s{2,}", s) if f]
        if ocr and len(fields) < 10 and re.match(r"^\d", s):
            alt = s.split()
            if len(alt) >= 10:
                fields = alt
        if not fields:
            continue
        head = fields[0].upper()
        if head.startswith("IŠ VISO") or head.startswith("PVM"):
            raw = fields[1:]
            nums = [_pdf_num(x) for x in raw]
            if ocr:
                nums = [_ocr_cents(t, v) for t, v in zip(raw, nums)]
            nums = [v for v in nums if v is not None]
            if not nums:
                continue
            if head.startswith("PVM"):
                totals["vat"] = nums[-1]
            elif "SU PVM" in head:
                totals["gross"] = nums[-1]
            else:
                if len(nums) >= 4:
                    totals["net"] = nums[-3]
                elif len(nums) == 3:
                    totals["net"] = nums[-2]
                else:
                    totals["net"] = nums[-1]
                if len(nums) >= 5:
                    totals["prev"] = nums[-5]
            continue
        num_cell = fields[0]
        num_match = None if num_cell.isdigit() else re.match(r"^(\d{1,3})\s*[|.)]?\s*(\S.*)$", num_cell)
        if not num_cell.isdigit() and not num_match:
            continue
        if len(fields) < 10:
            continue
        last8 = fields[-8:]
        nums = [_pdf_num(x) for x in last8]
        if ocr:
            nums = [_ocr_cents(t, v) for t, v in zip(last8, nums)]
        if any(v is None for v in nums):
            continue
        unit = fields[-9] if len(fields) >= 10 else "Kompl."
        name = num_match.group(2).strip() if num_match else " ".join(fields[1:-9]).strip()
        if not name or len(name) < 3:
            continue
        qty, price, prev_pct, prev, cur_pct, cur, total_pct, total = nums
        if qty is None or price is None:
            continue
        if abs(total - (prev + cur)) > max(0.05, abs(total) * 0.001):
            continue
        items.append({
            "name": name, "unit": unit or "Kompl.", "qty": qty or 1.0, "price": price,
            "prev": _act_round(prev), "current": _act_round(cur), "total": _act_round(total),
        })
    if len(items) < 2:
        return None
    net = totals.get("net")
    sum_cur = sum(it["current"] for it in items)
    if net is not None and abs(sum_cur - net) > max(1.0, abs(net) * 0.005):
        raise ValueError(
            f"PDF lentelės suma {sum_cur:.2f} nesutampa su akto iš viso {net:.2f} – "
            "importas sustabdytas. Patikrinkite PDF arba importuokite Excel.")
    if meta["num"] is None:
        m = re.search(r"nr\.?\s*(\d+)", filename or "", re.I)
        if m:
            meta["num"] = int(m.group(1))
    meta["items"] = items
    meta["totals"] = totals
    return meta


def _looks_like_invoice(text, filename=""):
    """Ar dokumentas labiau PVM sąskaita-faktūra nei atliktų darbų aktas."""
    t = _fold_text(re.sub(r"\s+", " ", text or ""))
    if "sutartine kaina" in t or "atliktu darbu akto forma" in t:
        return False
    letters = re.sub(r"[^a-z]", "", t)
    if ("saskait" in letters and "fakt" in letters) or ("skait" in letters and "sakt" in letters):
        return True
    name = _fold_text(filename or "")
    if re.search(r"saskait|\bpvm\b|invoice", name) and "akt" not in name:
        return True
    return False


def import_act_pdf(raw, filename="", contract_id=None):
    if not raw:
        raise ValueError("Failas tuščias")
    if len(raw) > 40 * 1024 * 1024:
        raise ValueError("Failas per didelis (iki 40 MB)")
    if not raw.startswith(b"%PDF"):
        raise ValueError("Failas nėra PDF dokumentas")
    text = _pdf_layout_text(raw)
    ocr_used = False
    word_pages = []
    if len(re.sub(r"\s+", "", text)) < 120:
        ocr_text, word_pages = _ocr_pdf_pages(raw)
        ocr_used = True
        if _ocr_letter_score(ocr_text) > _ocr_letter_score(text):
            text = ocr_text
    body = re.sub(r"\s+", "", text)
    if len(body) < 120:
        if ocr_supported():
            raise ValueError("PDF yra nuskaitytas vaizdas, o OCR teksto neperskaitė. "
                             "Įkelkite ryškesnį skeną arba Excel formą (Priedas Nr. 10).")
        raise ValueError("PDF yra nuskaitytas vaizdas be tekstinio sluoksnio, o OCR "
                         "šioje sistemoje nepasiekiamas. Importuokite Excel (.xlsx) "
                         "arba įveskite aktą ranka, o skeną pridėkite prie akto failų.")
    if _looks_like_invoice(text, filename):
        raise ValueError("Šis PDF yra PVM sąskaita-faktūra, o ne F2 atliktų darbų "
                         "aktas. Įkelkite F2 aktą (Excel „Priedas Nr. 10“ arba jo PDF).")
    parsed = None
    if ocr_used:
        parsed = _parse_f2_words(word_pages, filename)
    if not parsed and not ocr_used:
        parsed = _parse_f2_pdf_text(text, filename)
    if not parsed:
        if ocr_used:
            raise ValueError("Skenas perskaitytas, bet F2 lentelės (darbų eilutės ir "
                             "sumos) patikimai neatkurtos – importas sustabdytas, kad "
                             "į aktus nepatektų klaidingi skaičiai. Naudokite užpildytą "
                             "Excel formą „Priedas Nr. 10“.")
        raise ValueError("PDF faile nerasta F2 akto lentelė su darbų eilutėmis")
    return _import_parsed_acts([parsed], filename, contract_id)


def import_act_ocr(text, filename="", contract_id=None):
    """Importuoja F2 aktą iš naršyklėje atpažinto skeno teksto."""
    raw = str(text or "").replace("\u00a0", " ")
    if len(raw.strip()) < 40:
        raise ValueError("Tekstas per trumpas – nepavyko nuskaityti skeno. "
                         "Bandykite ryškesnį ar didesnį vaizdą.")
    if contract_id in ("", 0, "0"):
        contract_id = None
    parsed = None
    try:
        parsed = _parse_f2_pdf_text(raw, filename, ocr=True)
    except ValueError:
        raise
    if not parsed:
        raise ValueError("Nepavyko atpažinti F2 akto lentelės. "
                         "Patikrinkite tekstą žemiau arba importuokite Excel failą.")
    res = _import_parsed_acts([parsed], filename, contract_id)
    res["ocr"] = True
    return res


def _is_f2_form_text(text):
    """Ar dokumento tekstas yra F2 atliktų darbų akto forma (ne sąskaita)."""
    t = _fold_text(re.sub(r"\s+", " ", text or ""))[:60000]
    if "sutartine kaina" not in t:
        return False
    if not re.search(r"atlikt\w*\s+darb\w*\s+akt", t):
        return False
    return "is viso" in t and "pvm" in t


def _store_f2_meta(doc_id, meta):
    try:
        with db() as conn:
            conn.execute("UPDATE docs SET meta=? WHERE id=?",
                         (json.dumps(meta, ensure_ascii=False), doc_id))
            conn.commit()
    except Exception:
        logger.warning("Nepavyko išsaugoti F2 importo žymos dok. %s", doc_id)


def _auto_import_f2(path, ext, row, text_rows, meta):
    """Po indeksavimo iškart perkelia rastą F2 aktą arba F3 pažymą į aktus."""
    text = "\n".join(t for _, t in text_rows or [])
    if _is_f3_form_text(text):
        info = {}
        if ext == ".xlsx":
            try:
                res = import_f3_xlsx(Path(path).read_bytes(), row["name"])
                info = {"acts": res.get("acts") or [], "created": res.get("created") or [],
                        "contract_id": res.get("contract_id")}
                for aid in res.get("act_ids") or []:
                    _attach_doc_to_act(aid, path)
                if info["acts"] or info["created"]:
                    logger.info("F3 iš %s perkelta į aktus: %s", row["name"], info)
            except Exception as e:
                info = {"error": str(e)[:240]}
                logger.info("F3 importas iš %s nepavyko: %s", row["name"], e)
        else:
            aid = _attach_f3_text(text, path)
            info = ({"attached_act_id": aid} if aid else
                    {"note": "F3 pažyma rasta – duomenis perkelia Excel (Priedas Nr. 11)"})
        meta["f3_import"] = info
        _store_f2_meta(row["id"], meta)
        if not _is_f2_form_text(text):
            return
    if ext not in (".xlsx", ".pdf"):
        return
    try:
        if ext == ".xlsx":
            res = import_act_xlsx(Path(path).read_bytes(), row["name"])
        else:
            parsed = _parse_f2_pdf_text(text, row["name"], ocr=bool(meta.get("ocr") is True))
            if not parsed:
                res = import_act_pdf(Path(path).read_bytes(), row["name"])
            else:
                res = _import_parsed_acts([parsed], row["name"], None)
        info = {"acts": res.get("acts") or [], "contract_id": res.get("contract_id")}
        for aid in res.get("act_ids") or []:
            _attach_doc_to_act(aid, path)
        if info["acts"]:
            logger.info("F2 iš %s perkeltas į aktus: %s", row["name"], info["acts"])
    except Exception as e:
        info = {"error": str(e)[:240]}
        logger.info("F2 importas iš %s nepavyko: %s", row["name"], e)
    meta["f2_import"] = info
    _store_f2_meta(row["id"], meta)


_LT_MONTHS = (("saus", 1), ("vasa", 2), ("kovo", 3), ("bala", 4), ("gegu", 5),
              ("birz", 6), ("liep", 7), ("rugp", 8), ("rugs", 9), ("spal", 10),
              ("lapk", 11), ("gruo", 12))


def _lt_date(text):
    """Lietuviška data (2026 m. balandžio 10 d.) į ISO formą."""
    m = re.search(r"(\d{4})\s*m?\.?\s*([A-Za-zĄČĘĖĮŠŲŪŽąčęėįšųūž]+)\s*(\d{1,2})\s*d\.", text)
    if m:
        mon = _fold_text(m.group(2))[:4]
        for pre, num in _LT_MONTHS:
            if mon.startswith(pre):
                return "%s-%02d-%02d" % (m.group(1), num, int(m.group(3)))
    m = re.search(r"\b(\d{4})-(\d{2})-(\d{2})\b", text)
    return m.group(0) if m else ""


def _clean_party(kind, name):
    name = " ".join((name or "").replace(",,", "„").split()).strip(" „“\"',.;")
    return f"{kind} „{name}“" if name else ""


def _parse_contract_text(text):
    """Iš sutarties teksto ištraukia rekvizitus (be OCR, tik tekstinis sluoksnis)."""
    flat = " ".join((text or "").split())
    folded = _fold_text(flat)
    if "rangos sutartis" not in folded:
        return None
    tokens = flat.split()
    clean = sum(1 for w in tokens if re.fullmatch(r"[A-Za-zĄČĘĖĮŠŲŪŽąčęėįšųūž]{2,}", w))
    if len(tokens) > 40 and clean / len(tokens) < 0.6:
        # Sugadintas teksto sluoksnis (pvz., blogas skenavimo OCR) – rekvizitų neimame.
        return None
    m = re.search(r"(?:STATYBOS\s+)?SUB?RANGOS\s+SUTARTIS\s+Nr\.?\s*([0-9][0-9A-Za-z./-]{1,24})",
                  flat, re.I)
    if not m:
        return None
    number = m.group(1).strip(".,;")
    signed = _lt_date(flat[m.end():m.end() + 220])
    co = company_data()
    co_name = _fold_text(co.get("name")).replace("uab", "").strip(" „“\"'")
    parties = []
    for kind, name in re.findall(r"(UAB|AB|VŠĮ|VšĮ|IĮ|MB)\s*[„“\"]([^“”\"]{2,80})[“”\"]", flat):
        party = _clean_party(kind, name)
        if party and party not in parties:
            parties.append(party)
    contractor, customer = "", ""
    for party in parties:
        pname = _fold_text(party)
        if co_name and (co_name in pname or pname.strip("uab „“\"") in co_name):
            contractor = party
        elif not customer:
            customer = party
    if not contractor:
        contractor = co.get("name") or ""
    address = ""
    obj = re.search(r"(?:Objekte?|objekt[ao])\s*[–—:-]\s*(.{5,200})", flat, re.I)
    scope = obj.group(1) if obj else flat
    am = re.search(r"([A-ZĄČĘĖĮŠŲŪŽ][\wĄ-ž.\s-]{1,60}?\bg\.\s*\d+[A-Za-z]?,\s*"
                   r"[A-ZĄČĘĖĮŠŲŪŽ][\wĄ-ž.\s-]{2,30})", scope)
    if am:
        address = " ".join(am.group(1).split()).strip(" ,.;")
        address = re.sub(r"\bg\.\s*(\d)", r"g. \1", address)
    price = None
    pm = re.search(r"Sutarties\s+kaina\s*:?\s*([0-9][0-9\s.,]*?)\s*(?:Eur|EUR)\b", flat)
    if pm:
        raw = re.sub(r"\s+", "", pm.group(1)).replace(".", "").replace(",", ".")
        try:
            val = float(raw)
            if 0 < val < 10_000_000:
                price = _act_round(val)
        except ValueError:
            price = None
    title = f"Statybos subrangos sutartis Nr. {number}"
    if address:
        title += f" – {address}"
    quality = int(bool(price)) + int(bool(signed)) + int(bool(address)) + int(bool(customer))
    return {"title": title, "number": number, "signed": signed, "address": address,
            "customer": customer, "contractor": contractor, "price": price, "vat": 21.0,
            "quality": quality}


def _fill_project_meta(info):
    meta = get_setting("project", {}) or {}
    changed = False
    if info.get("address") and not meta.get("address"):
        meta["address"] = info["address"]
        changed = True
    if info.get("customer") and not meta.get("client"):
        meta["client"] = info["customer"]
        changed = True
    if changed:
        set_setting("project", meta)
        data_touch()


def _auto_contract(info, filename=""):
    """Sukuria sutartį iš atpažintų rekvizitų, jei tokios dar nėra."""
    if not info or info.get("quality", 0) < 2:
        return None
    with db() as conn:
        rows = [dict(r) for r in conn.execute("SELECT * FROM contracts").fetchall()]
    key = _norm_doc_no(info.get("number"))
    for c in rows:
        if key and _norm_doc_no(c.get("number")) == key:
            fill = {k: c.get(k) for k in ("title", "customer", "contractor", "number",
                                          "signed", "address", "vat", "retention", "advance",
                                          "terms", "buyer_code", "buyer_vat", "buyer_address",
                                          "rep_contractor", "rep_technical", "rep_customer", "note")}
            changed = False
            for k in ("customer", "contractor", "signed", "address"):
                if info.get(k) and not (fill.get(k) or ""):
                    fill[k] = info[k]
                    changed = True
            if changed:
                save_contract(fill, c["id"])
            _fill_project_meta(info)
            return {"created": False, "id": c["id"], "number": c["number"] or info["number"]}
    body = dict(info)
    body.pop("quality", None)
    body["note"] = "Sutartis atpažinta automatiškai iš dokumento" + (f" „{filename}“." if filename else ".")
    rec = save_contract(body)
    if info.get("price"):
        with db() as conn:
            has_groups = conn.execute("SELECT COUNT(*) n FROM act_groups WHERE contract_id=?",
                                      (rec["id"],)).fetchone()["n"]
            if not has_groups:
                conn.execute(
                    "INSERT INTO act_groups(contract_id,name,unit,qty,price,ord,active) VALUES(?,?,?,?,?,?,1)",
                    (rec["id"], "Sutarties kaina", "Kompl.", 1.0, info["price"], 1))
            conn.commit()
    _fill_project_meta(info)
    logger.info("Sutartis atpažinta iš dokumento: Nr. %s", info.get("number"))
    return {"created": True, "id": rec["id"], "number": info.get("number")}


def scan_contracts():
    """Ieško sutarčių jau indeksuotuose dokumentuose ir sukuriasi trūkstamas."""
    with db() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM docs WHERE ext IN ('.pdf','.docx','.doc','.txt') AND text_state='done' "
            "ORDER BY id").fetchall()]
        texts = {}
        for r in rows:
            texts[r["id"]] = "\n".join(
                x["text"] or "" for x in conn.execute(
                    "SELECT text FROM pages WHERE doc_id=? ORDER BY page", (r["id"],)))
    found, created, existing, errors = [], [], [], []
    best = {}
    for r in rows:
        text = (texts.get(r["id"]) or "")[:20000]
        try:
            info = _parse_contract_text(text)
            if not info:
                continue
            found.append(info["number"])
            key = _norm_doc_no(info["number"]) or info["number"]
            prev = best.get(key)
            if prev is None or info.get("quality", 0) > prev[0].get("quality", 0):
                best[key] = (info, r["name"])
        except Exception as e:
            logger.warning("Sutarties paieška %s: %s", r["name"], e)
            errors.append({"name": r["name"], "error": "Nepavyko perskaityti sutarties"})
    for info, name in best.values():
        try:
            res = _auto_contract(info, name)
            if res and res.get("created"):
                created.append(res["number"])
            elif res:
                existing.append(res["number"])
        except Exception as e:
            logger.warning("Sutarties kūrimas %s: %s", name, e)
            errors.append({"name": name, "error": "Nepavyko įrašyti sutarties"})
    return {"found": found, "created": created, "existing": existing, "errors": errors}


def scan_f2_docs():
    """Peržiūri jau indeksuotus dokumentus: sutartys, F2 aktai ir F3 pažymos."""
    contracts_info = scan_contracts()
    with db() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM docs WHERE ext IN ('.xlsx','.pdf','.docx','.doc') AND text_state='done' "
            "ORDER BY id").fetchall()]
        texts = {}
        for r in rows:
            texts[r["id"]] = "\n".join(
                x["text"] or "" for x in conn.execute(
                    "SELECT text FROM pages WHERE doc_id=? ORDER BY page", (r["id"],)))
    imported, skipped, errors, found = [], [], [], 0
    f3 = {"found": 0, "imported": [], "existing": [], "attached": [], "skipped": [], "errors": []}
    for r in rows:
        text = texts.get(r["id"]) or ""
        path = Path(r["path"])
        if not path.exists():
            continue
        meta = {}
        try:
            meta = json.loads(r["meta"] or "{}")
        except Exception:
            meta = {}
        if _is_f3_form_text(text):
            f3["found"] += 1
            if r["ext"] != ".xlsx":
                aid = _attach_f3_text(text, path)
                if aid:
                    f3["attached"].append({"name": r["name"], "act_id": aid})
                else:
                    f3["skipped"].append({
                        "name": r["name"],
                        "note": "F3 pažyma rasta, bet akto priskyrimas nepavyko"})
            else:
                try:
                    res = import_f3_xlsx(path.read_bytes(), r["name"])
                    acts = res.get("acts") or []
                    f3["imported"].extend(acts)
                    f3["existing"].extend(res.get("skipped") or [])
                    for aid in res.get("act_ids") or []:
                        _attach_doc_to_act(aid, path)
                    meta["f3_import"] = {"acts": acts, "contract_id": res.get("contract_id")}
                    _store_f2_meta(r["id"], meta)
                except ValueError as e:
                    f3["errors"].append({"name": r["name"], "error": str(e)})
                except Exception as e:
                    logger.warning("F3 skenavimas %s: %s", r["name"], e)
                    f3["errors"].append({"name": r["name"], "error": "Nepavyko perskaityti failo"})
        if not _is_f2_form_text(text):
            continue
        if r["ext"] not in (".xlsx", ".pdf"):
            continue
        found += 1
        try:
            if r["ext"] == ".xlsx":
                res = import_act_xlsx(path.read_bytes(), r["name"])
            else:
                parsed = _parse_f2_pdf_text(text, r["name"],
                                            ocr=bool(meta.get("ocr") is True))
                res = (_import_parsed_acts([parsed], r["name"], None) if parsed
                       else import_act_pdf(path.read_bytes(), r["name"]))
            acts = res.get("acts") or []
            imported.extend(acts)
            skipped.extend(res.get("skipped") or [])
            for aid in res.get("act_ids") or []:
                _attach_doc_to_act(aid, path)
            meta["f2_import"] = {"acts": acts, "contract_id": res.get("contract_id")}
            _store_f2_meta(r["id"], meta)
        except ValueError as e:
            errors.append({"name": r["name"], "error": str(e)})
        except Exception as e:
            logger.warning("F2 skenavimas %s: %s", r["name"], e)
            errors.append({"name": r["name"], "error": "Nepavyko perskaityti failo"})
    data_touch()
    return {"ok": True, "found": found, "imported": imported,
            "skipped": skipped, "errors": errors, "contracts": contracts_info, "f3": f3}


def get_act_detail(act_id):
    with db() as conn:
        act = conn.execute("SELECT * FROM acts WHERE id=?", (act_id,)).fetchone()
        if not act:
            return None
        contract = conn.execute("SELECT * FROM contracts WHERE id=?", (act["contract_id"],)).fetchone()
        if not contract:
            return None
        rows, totals = _act_calc(conn, dict(act), dict(contract))
        payments = [dict(r) for r in conn.execute(
            "SELECT id,date,amount,note FROM act_payments WHERE act_id=? ORDER BY date,id",
            (act_id,)).fetchall()]
        files = [act_file_public(r) for r in conn.execute(
            "SELECT * FROM act_files WHERE act_id=? ORDER BY id", (act_id,)).fetchall()]
    return {"act": dict(act), "contract": dict(contract), "groups": rows, "payments": payments,
            "files": files, "totals": totals, "statuses": list(ACT_STATUSES)}


def save_contract(body, contract_id=None):
    vals = {
        "title": str(body.get("title") or "").strip(),
        "customer": str(body.get("customer") or "").strip(),
        "contractor": str(body.get("contractor") or "").strip(),
        "number": str(body.get("number") or "").strip(),
        "signed": str(body.get("signed") or "").strip(),
        "address": str(body.get("address") or "").strip(),
        "vat": _act_float(body.get("vat"), 21.0),
        "retention": _act_float(body.get("retention"), 0.0),
        "advance": _act_float(body.get("advance"), 0.0),
        "terms": int(min(max(_act_float(body.get("terms"), 30.0), 0.0), 365.0)),
        "buyer_code": str(body.get("buyer_code") or "").strip(),
        "buyer_vat": str(body.get("buyer_vat") or "").strip(),
        "buyer_address": str(body.get("buyer_address") or "").strip(),
        "rep_contractor": str(body.get("rep_contractor") or "").strip(),
        "rep_technical": str(body.get("rep_technical") or "").strip(),
        "rep_customer": str(body.get("rep_customer") or "").strip(),
        "note": str(body.get("note") or "").strip(),
    }
    if not vals["title"]:
        raise ValueError("Įrašykite sutarties pavadinimą")
    vals["vat"] = min(max(vals["vat"], 0.0), 100.0)
    vals["retention"] = min(max(vals["retention"], 0.0), 100.0)
    vals["advance"] = min(max(vals["advance"], 0.0), 100.0)
    now = now_iso()
    with db() as conn:
        if contract_id:
            row = conn.execute("SELECT * FROM contracts WHERE id=?", (contract_id,)).fetchone()
            if not row:
                raise ValueError("Sutartis nerasta")
            conn.execute(
                "UPDATE contracts SET title=?,customer=?,contractor=?,number=?,signed=?,address=?,"
                "vat=?,retention=?,advance=?,terms=?,buyer_code=?,buyer_vat=?,buyer_address=?,"
                "rep_contractor=?,rep_technical=?,rep_customer=?,"
                "note=?,updated=? WHERE id=?",
                (vals["title"], vals["customer"], vals["contractor"], vals["number"], vals["signed"],
                 vals["address"], vals["vat"], vals["retention"], vals["advance"], vals["terms"],
                 vals["buyer_code"], vals["buyer_vat"], vals["buyer_address"],
                 vals["rep_contractor"], vals["rep_technical"], vals["rep_customer"],
                 vals["note"], now, contract_id))
        else:
            cur = conn.execute(
                "INSERT INTO contracts(title,customer,contractor,number,signed,address,vat,"
                "retention,advance,terms,buyer_code,buyer_vat,buyer_address,"
                "rep_contractor,rep_technical,rep_customer,note,created,updated) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (vals["title"], vals["customer"], vals["contractor"], vals["number"], vals["signed"],
                 vals["address"], vals["vat"], vals["retention"], vals["advance"], vals["terms"],
                 vals["buyer_code"], vals["buyer_vat"], vals["buyer_address"],
                 vals["rep_contractor"], vals["rep_technical"], vals["rep_customer"],
                 vals["note"], now, now))
            contract_id = cur.lastrowid
        conn.commit()
        row = conn.execute("SELECT * FROM contracts WHERE id=?", (contract_id,)).fetchone()
    data_touch()
    return dict(row)


def save_contract_groups(contract_id, rows):
    now = now_iso()
    with db() as conn:
        if not conn.execute("SELECT 1 FROM contracts WHERE id=?", (contract_id,)).fetchone():
            raise ValueError("Sutartis nerasta")
        existing = {r["id"]: dict(r) for r in conn.execute(
            "SELECT * FROM act_groups WHERE contract_id=?", (contract_id,)).fetchall()}
        keep = set()
        for i, g in enumerate(rows if isinstance(rows, list) else []):
            if not isinstance(g, dict):
                continue
            name = str(g.get("name") or "").strip()
            if not name:
                continue
            unit = str(g.get("unit") or "Kompl.").strip() or "Kompl."
            qty = max(0.0, _act_float(g.get("qty"), 1.0))
            price = max(0.0, _act_round(g.get("price")))
            gid = int(_act_float(g.get("id"), 0))
            if gid and gid in existing:
                conn.execute("UPDATE act_groups SET name=?,unit=?,qty=?,price=?,ord=?,active=1 "
                             "WHERE id=? AND contract_id=?",
                             (name, unit, qty, price, i, gid, contract_id))
                keep.add(gid)
            else:
                cur = conn.execute("INSERT INTO act_groups(contract_id,name,unit,qty,price,ord,active) "
                                   "VALUES(?,?,?,?,?,?,1)",
                                   (contract_id, name, unit, qty, price, i))
                keep.add(cur.lastrowid)
        for gid in set(existing) - keep:
            used = conn.execute("SELECT 1 FROM act_items WHERE group_id=? LIMIT 1", (gid,)).fetchone()
            if used:
                conn.execute("UPDATE act_groups SET active=0 WHERE id=?", (gid,))
            else:
                conn.execute("DELETE FROM act_groups WHERE id=?", (gid,))
        conn.commit()
        saved = _contract_groups(conn, contract_id, active_only=True)
    data_touch()
    return {"ok": True, "groups": saved}


def save_act(body, act_id=None):
    with db() as conn:
        row = None
        if act_id:
            row = conn.execute("SELECT * FROM acts WHERE id=?", (act_id,)).fetchone()
            if not row:
                raise ValueError("Aktas nerastas")
        contract_id = int(_act_float(body.get("contract_id"), row["contract_id"] if row else 0))
        contract = conn.execute("SELECT * FROM contracts WHERE id=?", (contract_id,)).fetchone()
        if not contract:
            raise ValueError("Pasirinkite sutartį")
        num = int(_act_float(body.get("num"), row["num"] if row else 0))
        if num < 1:
            num = int(conn.execute("SELECT COALESCE(MAX(num),0)+1 n FROM acts WHERE contract_id=?",
                                   (contract_id,)).fetchone()["n"])
        status = str(body.get("status") or (row["status"] if row else "Juodraštis")).strip()
        if status not in ACT_STATUSES:
            status = "Juodraštis"
        date_value = str(body.get("date") or (row["date"] if row else "") or "").strip()
        period_from = str(body.get("period_from") or (row["period_from"] if row else "") or "").strip()
        period_to = str(body.get("period_to") or (row["period_to"] if row else "") or "").strip()
        received = max(0.0, _act_round(body.get("received", row["received"] if row else 0)))
        debt = max(0.0, _act_round(body.get("debt", row["debt"] if row else 0)))
        note = str(body.get("note") or (row["note"] if row else "") or "").strip()
        invoice_no = str(body.get("invoice_no") or (row["invoice_no"] if row else "") or "").strip()
        invoice_date = str(body.get("invoice_date") or (row["invoice_date"] if row else "") or "").strip()
        due_date = str(body.get("due_date") or (row["due_date"] if row else "") or "").strip()
        invoice_note = str(body.get("invoice_note") or (row["invoice_note"] if row else "") or "").strip()
        replace_items = act_id is None or "items" in body

        def rep_value(key):
            if key in body:
                return str(body.get(key) or "").strip()
            return str(row[key] if row else "") or ""
        rep_contractor = rep_value("rep_contractor")
        rep_technical = rep_value("rep_technical")
        rep_customer = rep_value("rep_customer")
        items = body.get("items") or {}
        if isinstance(items, list):
            items = {str(x.get("group_id")): x.get("amount") for x in items if isinstance(x, dict)}
        group_ids = {r["id"] for r in conn.execute(
            "SELECT id FROM act_groups WHERE contract_id=?", (contract_id,)).fetchall()}
        clean = {}
        if isinstance(items, dict):
            for key, value in items.items():
                try:
                    gid = int(key)
                except (TypeError, ValueError):
                    continue
                amount = _act_round(value)
                if gid in group_ids and abs(amount) > 0.004:
                    clean[gid] = amount
        payments = body.get("payments")
        replace_payments = act_id is None or payments is not None
        clean_payments = []
        if isinstance(payments, list):
            for item in payments:
                if not isinstance(item, dict):
                    continue
                amount = _act_round(item.get("amount"))
                if abs(amount) < 0.005:
                    continue
                clean_payments.append((str(item.get("date") or "").strip(), amount,
                                       str(item.get("note") or "").strip()))
        if payments is not None:
            received = _act_round(sum(x[1] for x in clean_payments))
        now = now_iso()
        if act_id:
            conn.execute("UPDATE acts SET contract_id=?,num=?,date=?,period_from=?,period_to=?,"
                         "status=?,received=?,debt=?,invoice_no=?,invoice_date=?,due_date=?,"
                         "invoice_note=?,rep_contractor=?,rep_technical=?,rep_customer=?,"
                         "note=?,updated=? WHERE id=?",
                         (contract_id, num, date_value, period_from, period_to, status,
                          received, debt, invoice_no, invoice_date, due_date, invoice_note,
                          rep_contractor, rep_technical, rep_customer, note, now, act_id))
        else:
            cur = conn.execute("INSERT INTO acts(contract_id,num,date,period_from,period_to,status,"
                               "received,debt,invoice_no,invoice_date,due_date,invoice_note,"
                               "rep_contractor,rep_technical,rep_customer,note,created,updated)"
                               " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                               (contract_id, num, date_value, period_from, period_to, status,
                                received, debt, invoice_no, invoice_date, due_date, invoice_note,
                                rep_contractor, rep_technical, rep_customer, note, now, now))
            act_id = cur.lastrowid
        if replace_items:
            conn.execute("DELETE FROM act_items WHERE act_id=?", (act_id,))
            conn.executemany("INSERT INTO act_items(act_id,group_id,amount) VALUES(?,?,?)",
                             [(act_id, gid, amount) for gid, amount in clean.items()])
        if replace_payments:
            conn.execute("DELETE FROM act_payments WHERE act_id=?", (act_id,))
            conn.executemany("INSERT INTO act_payments(act_id,date,amount,note,created) "
                             "VALUES(?,?,?,?,?)",
                             [(act_id, d, amt, note, now) for d, amt, note in clean_payments])
        conn.commit()
    data_touch()
    return get_act_detail(act_id)


def delete_act(act_id):
    with db() as conn:
        if not conn.execute("SELECT 1 FROM acts WHERE id=?", (act_id,)).fetchone():
            raise ValueError("Aktas nerastas")
        conn.execute("DELETE FROM act_items WHERE act_id=?", (act_id,))
        conn.execute("DELETE FROM act_payments WHERE act_id=?", (act_id,))
        conn.execute("DELETE FROM act_files WHERE act_id=?", (act_id,))
        conn.execute("DELETE FROM acts WHERE id=?", (act_id,))
        conn.commit()
    purge_act_files([int(act_id)])
    data_touch()


def delete_contract(contract_id):
    with db() as conn:
        if not conn.execute("SELECT 1 FROM contracts WHERE id=?", (contract_id,)).fetchone():
            raise ValueError("Sutartis nerasta")
        ids = [r["id"] for r in conn.execute("SELECT id FROM acts WHERE contract_id=?", (contract_id,)).fetchall()]
        if ids:
            marks = ",".join("?" * len(ids))
            conn.execute(f"DELETE FROM act_items WHERE act_id IN ({marks})", ids)
            conn.execute(f"DELETE FROM act_payments WHERE act_id IN ({marks})", ids)
            conn.execute(f"DELETE FROM act_files WHERE act_id IN ({marks})", ids)
        conn.execute("DELETE FROM acts WHERE contract_id=?", (contract_id,))
        conn.execute("DELETE FROM act_groups WHERE contract_id=?", (contract_id,))
        conn.execute("DELETE FROM contracts WHERE id=?", (contract_id,))
        conn.commit()
    purge_act_files(ids)
    data_touch()


def seed_demo_contract():
    with db() as conn:
        row = conn.execute("SELECT id FROM contracts WHERE number=? AND title=?",
                           (ACT_DEMO_NUMBER, ACT_DEMO_TITLE)).fetchone()
        if row:
            return row["id"]
        now = now_iso()
        cur = conn.execute(
            "INSERT INTO contracts(title,customer,contractor,number,signed,address,vat,retention,"
            "advance,rep_contractor,rep_technical,rep_customer,note,created,updated) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (ACT_DEMO_TITLE, "Šilalės rajono savivaldybės administracija", 'UAB "Logicor"',
             ACT_DEMO_NUMBER, "2026-07-31", "D.Poškos g. 24, Šilalė", 21, 5, 0,
             "", "", "", "Pavyzdinė sutartis pagal pateiktas F2/F3 formas.", now, now))
        contract_id = cur.lastrowid
        gids = []
        for i, (name, price) in enumerate(ACT_DEMO_GROUPS):
            g = conn.execute("INSERT INTO act_groups(contract_id,name,unit,qty,price,ord,active) "
                             "VALUES(?,?,?,?,?,?,1)", (contract_id, name, "Kompl.", 1, price, i))
            gids.append(g.lastrowid)
        for num, dt, pfrom, pto, status, amounts in (
                (1, "2026-09-30", "2026-09-01", "2026-09-30", "Patvirtintas", ACT_DEMO_ACT1),
                (2, "2026-10-26", "2026-10-01", "2026-10-31", "Juodraštis", ACT_DEMO_ACT2)):
            a = conn.execute("INSERT INTO acts(contract_id,num,date,period_from,period_to,status,"
                             "received,debt,note,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                             (contract_id, num, dt, pfrom, pto, status, 0, 0, "", now, now))
            aid = a.lastrowid
            conn.executemany("INSERT INTO act_items(act_id,group_id,amount) VALUES(?,?,?)",
                             [(aid, gid, amt) for gid, amt in zip(gids, amounts) if abs(amt) > 0.004])
        conn.commit()
    data_touch()
    return contract_id


ACT_PRINT_CSS = """
@page { size: A4 landscape; margin: 8mm 8mm 8mm; }
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; }
body { font-family: "Times New Roman", "Liberation Serif", serif; color: #000; font-size: 8.6pt; line-height: 1.22; }
body.f3 { font-size: 8pt; }
.sheet { width: 100%; }
.priedas { text-align: right; font-size: 8.2pt; font-weight: 700; line-height: 1.35; }
.priedas span { display: block; }
.meta { margin: 2mm 0 1mm; }
.meta div { display: flex; margin: 0.55mm 0; }
.meta b { font-weight: 400; min-width: 43mm; }
.meta span { flex: 1; }
h1 { text-align: center; font-size: 11pt; letter-spacing: .3pt; margin: 1.5mm 0 0.8mm; }
.period { margin: 1mm 0 1.5mm; }
table { width: 100%; border-collapse: collapse; table-layout: fixed; }
th, td { border: 0.55pt solid #000; padding: 0.55mm 1mm; vertical-align: middle; }
th { font-size: 7pt; font-weight: 700; text-align: center; line-height: 1.15; }
td.c { text-align: center; }
td.num { text-align: right; white-space: nowrap; }
tr.total td, tr.sub td { font-weight: 700; }
.signs { display: flex; gap: 8mm; margin-top: 3mm; page-break-inside: avoid; }
.sign { flex: 1; font-size: 8pt; }
.sign .role { font-weight: 700; margin-bottom: 1mm; }
.sign .rep { min-height: 4mm; border-bottom: 0.55pt solid #000; }
.sign .cap { font-size: 6.8pt; margin-top: 0.5mm; }
.sign .row { display: flex; gap: 4mm; margin-top: 2.5mm; }
.sign .row div { flex: 1; }
.sign .line { border-bottom: 0.55pt solid #000; height: 4.5mm; }
.f3page { max-width: 190mm; margin: 0 auto; }
.pay td { font-size: 8pt; }
.pay td.lbl { text-align: right; font-weight: 700; }
.payments th, .payments td { font-size: 7.6pt; padding: 0.5mm 1mm; }
.payments th { font-size: 6.9pt; }
.note { margin-top: 2mm; font-size: 7.2pt; }
.words { margin-top: 1.6mm; font-size: 8pt; }
.words b { font-weight: 700; }
"""


def _act_meta_html(contract, act, form):
    number = "; ".join(x for x in (contract.get("signed"), contract.get("number")) if x)
    date_label = "Pažymos data" if form == "f3" else "Akto data"
    return f"""
    <div class="meta">
      <div><b>Užsakovas:</b><span>{html.escape(contract.get('customer') or '')}</span></div>
      <div><b>Rangovas:</b><span>{html.escape(contract.get('contractor') or '')}</span></div>
      <div><b>Sutarties pavadinimas:</b><span>{html.escape(contract.get('title') or '')}</span></div>
      <div><b>Sutarties data ir numeris:</b><span>{html.escape(number)}</span></div>
      <div><b>{date_label}:</b><span>{html.escape(act.get('date') or '')}</span></div>
    </div>"""


def _act_reps(act, contract):
    keys = ("rep_contractor", "rep_technical", "rep_customer")
    stored = [str(act.get(k) or "").strip() for k in keys]
    if any(stored):
        return tuple(stored)
    return tuple(str(contract.get(k) or "").strip() for k in keys)


def _act_sign_html(role, name):
    return f"""
    <div class="sign">
      <div class="role">{html.escape(role)}:</div>
      <div class="rep">{html.escape(name or '')}</div>
      <div class="cap">(vardas, pavardė, pareigos)</div>
      <div class="row">
        <div><div class="line"></div><div class="cap">(parašas)</div></div>
        <div><div class="line"></div><div class="cap">(data)</div></div>
      </div>
    </div>"""


def act_print_html(act_id, form="f2"):
    form = "f3" if str(form).lower() == "f3" else "f2"
    with db() as conn:
        act = conn.execute("SELECT * FROM acts WHERE id=?", (act_id,)).fetchone()
        if not act:
            return None
        act = dict(act)
        contract = conn.execute("SELECT * FROM contracts WHERE id=?", (act["contract_id"],)).fetchone()
        if not contract:
            return None
        contract = dict(contract)
        rows, totals = _act_calc(conn, act, contract)
    title = "ATLIKTŲ DARBŲ AKTAS" if form == "f2" else "PAŽYMA APIE ATLIKTŲ DARBŲ VERTĘ"
    top = ("<span>PRIEDAS NR. 10</span><span>ATLIKTŲ DARBŲ AKTO FORMA</span>"
           "<span>Fiksuotos kainos sutartis</span>") if form == "f2" else (
           "<span>PRIEDAS NR. 11</span><span>PAŽYMOS APIE ATLIKTŲ DARBŲ VERTĘ FORMA</span>")
    period = (f"nuo {html.escape(act.get('period_from') or '')} iki {html.escape(act.get('period_to') or '')}"
              if form == "f2" else
              f"Nuo {html.escape(act.get('period_from') or '')} iki {html.escape(act.get('period_to') or '')}")
    body = [f"""<!doctype html><html lang="lt"><head><meta charset="utf-8">
<title>{html.escape(title)} Nr. {act['num']}</title><style>{ACT_PRINT_CSS}
{'@page { size: A4 portrait; margin: 10mm 10mm 12mm; }' if form == 'f3' else ''}
</style></head><body class="{form}"><div class="sheet{' f3page' if form == 'f3' else ''}">
<div class="priedas">{top}</div>
{_act_meta_html(contract, act, form)}
<h1>{html.escape(title)} NR. {act['num']}</h1>
<div class="period">{'Akto laikotarpis:' if form == 'f2' else 'Pažymos laikotarpis:'} {period}</div>"""]
    if form == "f2":
        body.append("""<table><colgroup>
<col style="width:8mm"><col><col style="width:13mm"><col style="width:14mm"><col style="width:24mm">
<col style="width:16mm"><col style="width:21mm"><col style="width:16mm"><col style="width:21mm">
<col style="width:16mm"><col style="width:21mm"></colgroup>
<thead>
<tr><th rowspan="3">Eil.<br>Nr.</th><th rowspan="3">Darbo pavadinimas</th><th rowspan="3">Mato<br>vnt.</th>
<th rowspan="3">Sutartinis<br>kiekis</th><th rowspan="3">Sutartinė kaina,<br>EUR, be PVM</th>
<th colspan="6">Atliktų Darbų dalis</th></tr>
<tr><th colspan="2">Praeitais laikotarpiais</th><th colspan="2">Ataskaitiniu laikotarpiu</th>
<th colspan="2">Iš viso nuo Sutarties įsigaliojimo</th></tr>
<tr><th>Procentas %</th><th>Kaina, EUR<br>be PVM</th><th>Procentas %</th><th>Kaina, EUR,<br>be PVM</th>
<th>Procentas %</th><th>Kaina, EUR,<br>be PVM</th></tr>
</thead><tbody>""")
        for i, r in enumerate(rows, 1):
            body.append(f"""<tr><td class="c">{i}</td><td>{html.escape(r['name'])}</td>
<td class="c">{html.escape(r['unit'])}</td><td class="c">{act_money(r['qty'])}</td>
<td class="num">{act_money(r['price'])}</td>
<td class="num">{act_pct_text(r['prev_pct'])}</td><td class="num">{act_money(r['prev'])}</td>
<td class="num">{act_pct_text(r['current_pct'])}</td><td class="num">{act_money(r['current'])}</td>
<td class="num">{act_pct_text(r['total_pct'])}</td><td class="num">{act_money(r['total'])}</td></tr>""")
        body.append(f"""</tbody><tfoot>
<tr class="total"><td colspan="5">IŠ VISO:</td><td class="num">{act_pct_text(totals['prev_pct'])}</td>
<td class="num">{act_money(totals['prev'])}</td><td class="num">{act_pct_text(totals['current_pct'])}</td>
<td class="num">{act_money(totals['current'])}</td><td class="num">{act_pct_text(totals['total_pct'])}</td>
<td class="num">{act_money(totals['total'])}</td></tr>
<tr class="sub"><td colspan="5">PVM {act_rate_text(totals['vat_rate'])}%:</td><td></td>
<td class="num">{act_money(totals['vat_prev'])}</td><td></td><td class="num">{act_money(totals['vat_current'])}</td>
<td></td><td class="num">{act_money(totals['vat'])}</td></tr>
<tr class="total"><td colspan="5">IŠ VISO SU PVM:</td><td></td>
<td class="num">{act_money(totals['prev_with_vat'])}</td><td></td>
<td class="num">{act_money(totals['current_with_vat'])}</td><td></td>
<td class="num">{act_money(totals['total_with_vat'])}</td></tr>
</tfoot></table>
<div class="words"><b>Suma žodžiais:</b> {html.escape(sum_words(totals['current_with_vat']))}.</div>""")
        rep_contractor, rep_technical, rep_customer = _act_reps(act, contract)
        body.append('<div class="signs">' +
                    _act_sign_html("Rangovo atstovas", rep_contractor) +
                    _act_sign_html("Techninis prižiūrėtojas", rep_technical) +
                    _act_sign_html("Užsakovo atstovas", rep_customer) +
                    "</div>")
    else:
        line = html.escape(contract.get("title") or "")
        body.append(f"""<table><colgroup>
<col style="width:8mm"><col><col style="width:26mm"><col style="width:24mm"><col style="width:24mm">
<col style="width:25mm"><col style="width:17mm"><col style="width:17mm"><col style="width:18mm"></colgroup>
<thead>
<tr><th rowspan="2">Eil.<br>Nr.</th><th rowspan="2">Darbų grupės (Darbo) pavadinimas</th>
<th rowspan="2">Sutartinė kaina,<br>EUR, be PVM</th><th colspan="3">Atliktų Darbų vertė, EUR, be PVM</th>
<th colspan="3">Atliktų Darbų procentas %</th></tr>
<tr><th>Praeitais<br>laikotarpiais</th><th>Ataskaitiniu<br>laikotarpiu</th><th>Iš viso nuo<br>Projekto pradžios</th>
<th>Praeitais<br>laikotarpiais</th><th>Ataskaitiniu<br>laikotarpiu</th><th>Iš viso nuo<br>Sutarties įsigaliojimo</th></tr>
</thead><tbody>
<tr><td class="c">1</td><td>{line}</td><td class="num">{act_money(totals['price'])}</td>
<td class="num">{act_money(totals['prev'])}</td><td class="num">{act_money(totals['current'])}</td>
<td class="num">{act_money(totals['total'])}</td><td class="num">{act_pct_text(totals['prev_pct'])}</td>
<td class="num">{act_pct_text(totals['current_pct'])}</td><td class="num">{act_pct_text(totals['total_pct'])}</td></tr>
</tbody><tfoot>
<tr class="total"><td colspan="2">IŠ VISO:</td><td class="num">{act_money(totals['price'])}</td>
<td class="num">{act_money(totals['prev'])}</td><td class="num">{act_money(totals['current'])}</td>
<td class="num">{act_money(totals['total'])}</td><td class="num">{act_pct_text(totals['prev_pct'])}</td>
<td class="num">{act_pct_text(totals['current_pct'])}</td><td class="num">{act_pct_text(totals['total_pct'])}</td></tr>
<tr class="sub"><td colspan="2">PVM {act_rate_text(totals['vat_rate'])}%:</td>
<td class="num">{act_money(totals['vat_price'])}</td><td class="num">{act_money(totals['vat_prev'])}</td>
<td class="num">{act_money(totals['vat_current'])}</td><td class="num">{act_money(totals['vat'])}</td>
<td></td><td></td><td></td></tr>
<tr class="total"><td colspan="2">IŠ VISO SU PVM:</td><td class="num">{act_money(totals['price_with_vat'])}</td>
<td class="num">{act_money(totals['prev_with_vat'])}</td><td class="num">{act_money(totals['current_with_vat'])}</td>
<td class="num">{act_money(totals['total_with_vat'])}</td><td></td><td></td><td></td></tr>
</tfoot></table>
<table class="pay" style="margin-top:4mm"><colgroup><col style="width:62mm"><col><col><col><col></colgroup><tbody>
<tr><td class="lbl">Sulaikoma suma, proc.:</td><td class="num">{act_rate_text(totals['retention_pct'])}</td>
<td class="num">{act_rate_text(totals['retention_pct'])}</td><td class="num">{act_rate_text(totals['retention_pct'])}</td>
<td class="num">{act_rate_text(totals['retention_pct'])}</td></tr>
<tr><td class="lbl">Sulaikoma suma, EUR:</td><td class="num">{act_money(totals['retention_price'])}</td>
<td class="num">{act_money(totals['retention_prev'])}</td><td class="num">{act_money(totals['retention_current'])}</td>
<td class="num">{act_money(totals['retention'])}</td></tr>
<tr><td class="lbl">Avanso išskaita, proc.:</td><td class="num">{act_rate_text(totals['advance_pct'])}</td>
<td class="num">{act_rate_text(totals['advance_pct'])}</td><td class="num">{act_rate_text(totals['advance_pct'])}</td>
<td class="num">{act_rate_text(totals['advance_pct'])}</td></tr>
<tr><td class="lbl">Išskaitytas avansas, EUR:</td><td class="num">{act_money(totals['advance_price'])}</td>
<td class="num">{act_money(totals['advance_prev'])}</td><td class="num">{act_money(totals['advance_current'])}</td>
<td class="num">{act_money(totals['advance'])}</td></tr>
<tr><td class="lbl">Mokėtina suma, EUR, be PVM:</td><td></td><td></td>
<td class="num">{act_money(totals['payable'])}</td><td></td></tr>
<tr><td class="lbl">Mokėtina suma, EUR, su PVM:</td><td></td><td></td>
<td class="num">{act_money(totals['payable_vat'])}</td><td></td></tr>
<tr><td class="lbl">Rangovo gauti mokėjimai, EUR:</td><td></td><td></td>
<td class="num">{act_money(totals['received'])}</td><td></td></tr>
<tr><td class="lbl">Užsakovo skola, EUR:</td><td></td><td></td>
<td class="num">{act_money(act.get('debt'))}</td><td></td></tr>
</tbody></table>
<div class="words"><b>Mokėtina suma žodžiais:</b> {html.escape(sum_words(totals['payable_vat']))}.</div>""")
        if totals.get("payments"):
            pay_html = "".join(
                f'<tr><td class="c">{i}</td><td class="c">{html.escape(x["date"])}</td>'
                f'<td class="num">{act_money(x["amount"])}</td>'
                f'<td>{html.escape(x["note"])}</td></tr>'
                for i, x in enumerate(totals["payments"], 1))
            body.append('<table class="payments" style="margin-top:3mm"><colgroup>'
                        '<col style="width:9mm"><col style="width:30mm"><col style="width:32mm">'
                        '<col></colgroup><thead><tr><th>Eil.<br>Nr.</th><th>Mokėjimo data</th>'
                        '<th>Suma, EUR</th><th>Pastaba</th></tr></thead><tbody>'
                        + pay_html + '</tbody><tfoot><tr class="total">'
                        '<td colspan="2">IŠ VISO GAUTA:</td>'
                        f'<td class="num">{act_money(totals["payments_total"])}</td>'
                        '<td></td></tr></tfoot></table>')
        rep_contractor, rep_technical, rep_customer = _act_reps(act, contract)
        body.append('<div class="signs">' +
                    _act_sign_html("Rangovo atstovas", rep_contractor) +
                    _act_sign_html("Techninis prižiūrėtojas", rep_technical) +
                    _act_sign_html("Užsakovo atstovas", rep_customer) +
                    "</div>")
    body.append("</div></body></html>")
    return "".join(body)


def company_data():
    company = get_setting("company", dict(DEFAULT_COMPANY))
    company = dict(company) if isinstance(company, dict) else dict(DEFAULT_COMPANY)
    for k, v in DEFAULT_COMPANY.items():
        company.setdefault(k, v)
    return company


def _iso_add_days(value, days):
    try:
        return (date.fromisoformat(str(value)) + timedelta(days=int(days))).isoformat()
    except (TypeError, ValueError):
        return ""


def _invoice_no(act):
    if act.get("invoice_no"):
        return act["invoice_no"]
    base = (act.get("invoice_date") or act.get("date") or today_iso())[:4]
    return f"{base}-{int(act.get('num') or 1):03d}"


INVOICE_CSS = """
@page { size: A4 portrait; margin: 12mm 12mm 14mm; }
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; }
body { font-family: "Segoe UI", Arial, sans-serif; color: #111; font-size: 9pt; line-height: 1.35; }
.top { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #1d2a6b; padding-bottom: 4mm; margin-bottom: 5mm; }
.brand b { display: block; font-size: 15pt; letter-spacing: .3pt; color: #1d2a6b; }
.brand span { font-size: 8pt; color: #555; }
.title { text-align: right; }
.title h1 { margin: 0; font-size: 14pt; letter-spacing: .4pt; }
.title .no { font-size: 10pt; font-weight: 700; margin-top: 1mm; }
.title .date { font-size: 8.5pt; color: #555; margin-top: 0.8mm; }
.parties { display: flex; gap: 8mm; margin-bottom: 5mm; }
.party { flex: 1; border: 0.6pt solid #999; border-radius: 2mm; padding: 3mm; }
.party .lbl { font-size: 7pt; text-transform: uppercase; letter-spacing: .5pt; color: #666; margin-bottom: 1.5mm; }
.party b { font-size: 9.5pt; }
.party div { margin: 0.5mm 0; }
table { width: 100%; border-collapse: collapse; }
th, td { border: 0.55pt solid #777; padding: 1.4mm 2mm; vertical-align: middle; }
th { background: #eef1f9; font-size: 7.6pt; text-align: left; }
td.num, th.num { text-align: right; white-space: nowrap; }
td.c { text-align: center; }
tr.total td { font-weight: 700; }
tr.total.big td { font-size: 10pt; background: #f3f5fb; }
.desc { margin: 4mm 0 1mm; font-size: 8.5pt; }
.words { margin-top: 3mm; font-size: 8.5pt; }
.note { margin-top: 2.5mm; font-size: 7.6pt; color: #444; }
.term { margin-top: 2mm; font-size: 9pt; }
.signs { display: flex; gap: 12mm; margin-top: 12mm; page-break-inside: avoid; }
.sign { flex: 1; font-size: 8pt; }
.sign .role { font-weight: 700; margin-bottom: 1mm; }
.sign .line { border-bottom: 0.55pt solid #000; height: 8mm; }
.sign .cap { color: #666; font-size: 7pt; margin-top: 0.8mm; }
.foot { margin-top: 6mm; border-top: 0.5pt solid #bbb; padding-top: 1.5mm; font-size: 7pt; color: #666; text-align: center; }
.recon h1 { text-align: center; font-size: 13pt; margin: 2mm 0 1mm; }
.recon .meta { margin: 2mm 0 4mm; font-size: 9pt; }
.recon .meta div { margin: 0.7mm 0; }
.recon td.small { font-size: 7.8pt; }
@media screen { body { padding: 14mm 12mm; max-width: 210mm; margin: 0 auto; background: #fff; } }
"""


def invoice_print_html(act_id):
    with db() as conn:
        act = conn.execute("SELECT * FROM acts WHERE id=?", (act_id,)).fetchone()
        if not act:
            return None
        act = dict(act)
        contract = conn.execute("SELECT * FROM contracts WHERE id=?", (act["contract_id"],)).fetchone()
        if not contract:
            return None
        contract = dict(contract)
        rows, totals = _act_calc(conn, act, contract)
    company = company_data()
    buyer_address = contract.get("buyer_address") or contract.get("address") or ""
    inv_date = act.get("invoice_date") or act.get("date") or today_iso()
    due = act.get("due_date") or _iso_add_days(inv_date, contract.get("terms") or 30)
    note = act.get("invoice_note") or company.get("invoice_note") or ""
    period = ""
    if act.get("period_from") or act.get("period_to"):
        period = f" ({act.get('period_from') or '…'} – {act.get('period_to') or '…'})"
    service = f"Darbai pagal {act.get('date') or ''} aktą Nr. {act['num']}{period}"
    line_rows = [r for r in rows if abs(r["current"]) > 0.004]
    if not line_rows:
        line_rows = [{"name": service, "unit": "vnt.", "current": totals["current"]}]
    items = "".join(
        f'<tr><td>{i}. {html.escape(r["name"])}</td><td class="c">{html.escape(r.get("unit") or "vnt.")}</td>'
        f'<td class="num">1</td><td class="num">{act_money(r["current"])}</td>'
        f'<td class="num">{act_money(r["current"])}</td></tr>'
        for i, r in enumerate(line_rows, 1))
    deductions = ""
    if totals["retention_current"] or totals["advance_current"]:
        deductions = (f'<div class="note">Sulaikymas {act_rate_text(totals["retention_pct"])} %: '
                      f'{act_money(totals["retention_current"])} EUR, avanso išskaita '
                      f'{act_rate_text(totals["advance_pct"])} %: {act_money(totals["advance_current"])} EUR. '
                      f'Šios sumos išskaitomos atsiskaitant pagal sutartį.</div>')
    return f"""<!doctype html><html lang="lt"><head><meta charset="utf-8">
<title>PVM sąskaita-faktūra {html.escape(_invoice_no(act))}</title><style>{INVOICE_CSS}</style></head><body>
<div class="top">
  <div class="brand"><b>{html.escape(company.get('name') or '')}</b>
    <span>Įm. k. {html.escape(company.get('code') or '')} · PVM {html.escape(company.get('vat') or '')}<br>
    {html.escape(company.get('address') or '')}</span></div>
  <div class="title"><h1>PVM SĄSKAITA-FAKTŪRA</h1>
    <div class="no">Nr. {html.escape(_invoice_no(act))}</div>
    <div class="date">{html.escape(inv_date)}</div></div>
</div>
<div class="parties">
  <div class="party"><div class="lbl">Pardavėjas</div><b>{html.escape(company.get('name') or '')}</b>
    <div>Įm. k. {html.escape(company.get('code') or '')}</div>
    <div>PVM mokėtojo kodas: {html.escape(company.get('vat') or '')}</div>
    <div>{html.escape(company.get('address') or '')}</div>
    <div>{html.escape(company.get('bank') or '')} · {html.escape(company.get('iban') or '')}</div></div>
  <div class="party"><div class="lbl">Pirkėjas</div><b>{html.escape(contract.get('customer') or '')}</b>
    <div>Įm. k. {html.escape(contract.get('buyer_code') or '')}</div>
    <div>PVM mokėtojo kodas: {html.escape(contract.get('buyer_vat') or '')}</div>
    <div>{html.escape(buyer_address)}</div></div>
</div>
<table><colgroup><col><col style="width:18mm"><col style="width:16mm"><col style="width:26mm"><col style="width:28mm"></colgroup>
<thead><tr><th>Pavadinimas</th><th class="c">Mato vnt.</th><th class="num">Kiekis</th>
<th class="num">Kaina, EUR</th><th class="num">Suma, EUR</th></tr></thead>
<tbody>{items}
<tr class="total"><td colspan="4">SUMA BE PVM</td><td class="num">{act_money(totals['current'])}</td></tr>
<tr class="total"><td colspan="4">PVM {act_rate_text(totals['vat_rate'])} %</td>
<td class="num">{act_money(totals['vat_current'])}</td></tr>
<tr class="total big"><td colspan="4">SUMA SU PVM</td>
<td class="num">{act_money(totals['current_with_vat'])}</td></tr>
</tbody></table>
<div class="words"><b>Suma žodžiais:</b> {html.escape(sum_words(totals['current_with_vat']))}.</div>
<div class="desc">{html.escape(service)}. Sutartis: {html.escape(contract.get('number') or '—')}
{('· ' + html.escape(contract.get('signed'))) if contract.get('signed') else ''}.</div>
<div class="term">Apmokėti iki <b>{html.escape(due or '—')}</b>
{('(per ' + str(contract.get('terms') or 30) + ' d.)') if due else ''}.</div>
{deductions}
{('<div class="note">' + html.escape(note) + '</div>') if note else ''}
<div class="signs">
  <div class="sign"><div class="role">Sąskaitą išrašė:</div><div class="line"></div>
    <div class="cap">{html.escape(company.get('director') or '')}{(' · tel. ' + html.escape(company.get('phone'))) if company.get('phone') else ''}</div></div>
  <div class="sign"><div class="role">Sąskaitą priėmė:</div><div class="line"></div>
    <div class="cap">(pareigos, vardas, pavardė, parašas)</div></div>
</div>
<div class="foot">{html.escape(company.get('name') or '')} · Įm. k. {html.escape(company.get('code') or '')}
 · PVM {html.escape(company.get('vat') or '')} · {html.escape(company.get('bank') or '')} · {html.escape(company.get('iban') or '')}</div>
</body></html>"""


def reconciliation_print_html(contract_id):
    with db() as conn:
        contract = conn.execute("SELECT * FROM contracts WHERE id=?", (contract_id,)).fetchone()
        if not contract:
            return None
        contract = dict(contract)
        act_rows = [dict(r) for r in conn.execute(
            "SELECT * FROM acts WHERE contract_id=? ORDER BY num, id", (contract_id,)).fetchall()]
        details = []
        for a in act_rows:
            rows, totals = _act_calc(conn, a, contract)
            details.append((a, totals))
    company = company_data()
    total_gross = 0.0
    total_paid = 0.0
    body_rows = []
    for i, (a, totals) in enumerate(details, 1):
        total_gross += totals["current_with_vat"]
        prev_paid = total_paid
        total_paid = totals["payments_total"]
        paid_act = _act_round(total_paid - prev_paid)
        balance = _act_round(total_gross - total_paid)
        body_rows.append(
            f'<tr><td class="c">{i}</td><td class="c">{html.escape(a.get("date") or "")}</td>'
            f'<td class="small">{html.escape(a.get("period_from") or "")} – {html.escape(a.get("period_to") or "")}</td>'
            f'<td class="num">{act_money(totals["current"])}</td>'
            f'<td class="num">{act_money(totals["vat_current"])}</td>'
            f'<td class="num">{act_money(totals["current_with_vat"])}</td>'
            f'<td class="num">{act_money(paid_act)}</td>'
            f'<td class="num">{act_money(balance)}</td></tr>')
    if not body_rows:
        body_rows.append('<tr><td colspan="8" class="c">Aktų dar nėra</td></tr>')
    balance_total = _act_round(total_gross - total_paid)
    return f"""<!doctype html><html lang="lt"><head><meta charset="utf-8">
<title>Atsiskaitymų suderinimas</title><style>{INVOICE_CSS}</style></head><body class="recon">
<div class="top"><div class="brand"><b>{html.escape(company.get('name') or '')}</b>
  <span>Įm. k. {html.escape(company.get('code') or '')} · {html.escape(company.get('address') or '')}</span></div>
  <div class="title"><h1>ATSISKAITYMŲ SUDERINIMO AKTAS</h1><div class="date">{today_iso()}</div></div></div>
<h1>{html.escape(contract.get('title') or '')}</h1>
<div class="meta">
  <div><b>Užsakovas:</b> {html.escape(contract.get('customer') or '')}</div>
  <div><b>Rangovas:</b> {html.escape(contract.get('contractor') or '')}</div>
  <div><b>Sutartis:</b> {html.escape(contract.get('number') or '—')} {('· ' + html.escape(contract.get('signed'))) if contract.get('signed') else ''}</div>
  <div><b>Suderinimo data:</b> {today_iso()}</div>
</div>
<table><colgroup><col style="width:9mm"><col style="width:22mm"><col><col style="width:27mm"><col style="width:21mm">
<col style="width:27mm"><col style="width:25mm"><col style="width:27mm"></colgroup>
<thead><tr><th>Nr.</th><th>Akto data</th><th>Laikotarpis</th><th class="num">Atlikta be PVM</th>
<th class="num">PVM</th><th class="num">Su PVM</th><th class="num">Gauta</th><th class="num">Likutis</th></tr></thead>
<tbody>{''.join(body_rows)}
<tr class="total big"><td colspan="3">IŠ VISO</td><td class="num">{act_money(total_gross - sum(d[1]['vat_current'] for d in details))}</td>
<td class="num">{act_money(sum(d[1]['vat_current'] for d in details))}</td>
<td class="num">{act_money(total_gross)}</td><td class="num">{act_money(total_paid)}</td>
<td class="num">{act_money(balance_total)}</td></tr>
</tbody></table>
<div class="note">Teigiamas likutis reiškia užsakovo skolą rangovui. Neigiamas – rangovo permoką užsakovui.
Suderinimas sudarytas automatiškai iš F2/F3 aktų ir įrašytų mokėjimų.</div>
<div class="signs">
  <div class="sign"><div class="role">Rangovo atstovas:</div><div class="line"></div><div class="cap">(vardas, pavardė, parašas)</div></div>
  <div class="sign"><div class="role">Užsakovo atstovas:</div><div class="line"></div><div class="cap">(vardas, pavardė, parašas)</div></div>
</div>
</body></html>"""


# --- sąmatos eksportas į PDF (Chrome/Edge headless spausdinimas) ---
PDF_BROWSER_PATHS = [
    Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Google/Chrome/Application/chrome.exe",
    Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Google/Chrome/Application/chrome.exe",
    Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Microsoft/Edge/Application/msedge.exe",
    Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Microsoft/Edge/Application/msedge.exe",
]


def find_pdf_browser():
    for p in PDF_BROWSER_PATHS:
        if p.is_file():
            return p
    for name in ("chrome", "msedge", "chromium"):
        exe = shutil.which(name)
        if exe:
            return Path(exe)
    return None


def render_pdf(url, out_path, wait_ms=12000, timeout=75):
    """Spausdina puslapį į PDF per Chrome/Edge headless. Grąžina klaidos tekstą arba None."""
    exe = find_pdf_browser()
    if not exe:
        return "PDF eksportui reikia Chrome arba Edge naršyklės šiame kompiuteryje"
    profile = Path(tempfile.mkdtemp(prefix="stabas-pdf-"))
    try:
        cmd = [
            str(exe), "--headless=new", "--disable-gpu", "--no-first-run",
            "--no-default-browser-check", "--disable-extensions",
            f"--user-data-dir={profile}", "--no-pdf-header-footer",
            f"--virtual-time-budget={wait_ms}", f"--print-to-pdf={out_path}", url,
        ]
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
        res = subprocess.run(cmd, capture_output=True, timeout=timeout, creationflags=flags)
        out = Path(out_path)
        if not out.is_file() or out.stat().st_size < 1000:
            msg = (res.stderr or b"").decode("utf-8", "replace").strip()[-300:]
            return "Nepavyko sugeneruoti PDF" + (f": {msg}" if msg else "")
        return None
    except subprocess.TimeoutExpired:
        return "PDF kūrimas užtruko per ilgai – bandykite dar kartą"
    except OSError as exc:
        return f"Nepavyko paleisti naršyklės: {exc}"
    finally:
        shutil.rmtree(profile, ignore_errors=True)


def build_state():
    sig = data_signature()
    docs = all_docs()
    docs_by_date = sorted(docs, key=lambda d: (d["date"] or "", d["mtime"] or ""), reverse=True)
    today = today_iso()
    soon = (date.today() + timedelta(days=7)).isoformat()

    with db() as conn:
        tasks = [dict(r) for r in conn.execute("SELECT * FROM tasks ORDER BY sort, id").fetchall()]
        issues = [dict(r) for r in conn.execute("SELECT * FROM issues ORDER BY num DESC").fetchall()]
        works = [dict(r) for r in conn.execute("SELECT * FROM works ORDER BY ord, id").fetchall()]
        disc_rows = {r["disc"]: dict(r) for r in conn.execute("SELECT * FROM disc_status").fetchall()}
        project = get_setting("project", DEFAULT_PROJECT)
        project = dict(project) if isinstance(project, dict) else dict(DEFAULT_PROJECT)
        for k, v in DEFAULT_PROJECT.items():
            project.setdefault(k, v)
        roots = get_roots()

    works_summary = {}
    for key in WORK_SECTIONS:
        rows = [w for w in works if w["section"] == key]
        done_rows = [w for w in rows if float(w["qty"] or 0) > 0 and float(w["done"] or 0) >= float(w["qty"] or 0) - 1e-9]
        works_summary[key] = {
            "label": WORK_SECTIONS[key]["label"],
            "total": len(rows),
            "done": len(done_rows),
            "remaining": len(rows) - len(done_rows),
            "value": round(sum(float(w["qty"] or 0) * float(w["price"] or 0) for w in rows), 2),
            "priced": sum(1 for w in rows if float(w["price"] or 0) > 0),
        }

    open_tasks = [t for t in tasks if t["status"] != "done"]
    overdue_tasks = [t for t in open_tasks if t["due"] and t["due"] < today]
    due_tasks = [t for t in open_tasks if t["due"] and today <= t["due"] <= soon]
    open_issues = [i for i in issues if i["status"] != "Uždaryta"]
    urgent_issues = [i for i in open_issues if i["priority"] in ("Aukšta", "Kritinė")]
    overdue_issues = [i for i in open_issues if i["due"] and i["due"] < today]

    discs = []
    codes = DISC_ORDER + sorted({d["disc"] for d in docs} - set(DISC_ORDER))
    for code in codes:
        ds = disc_rows.get(code, {})
        files = [d for d in docs if d["disc"] == code]
        latest = max((d["date"] for d in files if d["date"]), default="")
        discs.append({
            "code": code,
            "name": disc_name(code),
            "files": len(files),
            "bytes": sum(d["size"] for d in files),
            "latest": latest,
            "indexed": sum(1 for d in files if d["textState"] == "done"),
            "status": ds.get("status") or "Nepažymėta",
            "owner": ds.get("owner") or "",
            "note": ds.get("note") or "",
        })

    dated = [d for d in docs_by_date if d["date"]]
    recent = (dated or docs_by_date)[:8]
    unchecked = 0
    with db() as conn:
        row = conn.execute("SELECT COUNT(*) c FROM checklist WHERE done=0").fetchone()
        unchecked = row["c"] if row else 0
    photos = list_photos()

    return {
        "app": APP_NAME,
        "version": VERSION,
        "dataSig": sig,
        "today": today,
        "project": project,
        "company": company_data(),
        "projects": projects_public()["projects"],
        "activeProject": projects_public()["active"],
        "roots": roots,
        "docs": docs,
        "photos": photos,
        "discs": discs,
        "discStatuses": DISC_STATUSES,
        "recent": recent,
        "tasks": tasks,
        "issues": issues,
        "works": works,
        "worksSummary": works_summary,
        "counts": {
            "docCount": len(docs),
            "discCount": sum(1 for d in discs if d["files"] > 0),
            "photoCount": len(photos),
            "tasksOpen": len(open_tasks),
            "tasksOverdue": len(overdue_tasks),
            "issuesOpen": len(open_issues),
            "issuesUrgent": len(urgent_issues),
            "issuesOverdue": len(overdue_issues),
            "checklistOpen": unchecked,
            "worksTotal": len(works),
            "worksDone": sum(v["done"] for v in works_summary.values()),
            "worksRemaining": sum(v["remaining"] for v in works_summary.values()),
            "worksValue": round(sum(v["value"] for v in works_summary.values()), 2),
        },
        "attention": {
            "overdueTasks": overdue_tasks[:6],
            "dueTasks": due_tasks[:6],
            "urgentIssues": urgent_issues[:6],
            "overdueIssues": overdue_issues[:6],
        },
        "status": {
            "scanning": SCAN_STATE["scanning"],
            "lastScan": SCAN_STATE["last_scan"],
            "filesSeen": SCAN_STATE["files_seen"],
            "indexing": INDEX_STATE["indexing"],
            "indexCurrent": INDEX_STATE["current"],
            "indexDone": INDEX_STATE["done"],
            "indexTotal": INDEX_STATE["total"],
            "texted": sum(1 for d in docs if d["textState"] == "done"),
        },
    }


WORD_RE = re.compile(r"[0-9A-Za-zÀ-ž]+", re.UNICODE)


def fts_match(q):
    terms = [w for w in WORD_RE.findall(q) if len(w) >= 2][:8]
    if not terms:
        return ""
    return " AND ".join('"' + t.replace('"', "") + '"*' for t in terms)


def search(q):
    q = (q or "").strip()
    if len(q) < 2:
        return {"query": q, "docs": [], "pages": [], "truncated": False}
    match = fts_match(q)
    result = {"query": q, "docs": [], "pages": [], "truncated": False}
    if not match:
        return result
    with db() as conn:
        try:
            name_hits = conn.execute(
                "SELECT d.*, bm25(doc_name_fts) rank FROM doc_name_fts f JOIN docs d ON d.id=f.doc_id "
                "WHERE doc_name_fts MATCH ? ORDER BY rank LIMIT 40", (match,)
            ).fetchall()
        except sqlite3.Error:
            name_hits = []
        try:
            page_hits = conn.execute(
                "SELECT d.id, d.name, d.ext, d.disc, f.page, "
                "snippet(pages_fts,0,char(1),char(2),'…',26) AS snip, bm25(pages_fts) rank "
                "FROM pages_fts f JOIN docs d ON d.id=f.doc_id WHERE pages_fts MATCH ? "
                "ORDER BY rank LIMIT 240", (match,)
            ).fetchall()
        except sqlite3.Error:
            page_hits = []
    result["docs"] = [serialize_doc(r) for r in name_hits]
    result["pages"] = [{
        "docId": r["id"],
        "name": r["name"],
        "ext": r["ext"],
        "disc": r["disc"],
        "discName": disc_name(r["disc"]),
        "page": r["page"],
        "snippet": r["snip"] or "",
    } for r in page_hits]
    result["truncated"] = len(page_hits) >= 240
    return result


def search_pages(query, limit=120):
    """Or-operatoriaus pilno teksto paieška; grąžina ištisą puslapio tekstą."""
    if isinstance(query, (list, tuple, set)):
        raw = [str(t) for t in query]
    else:
        raw = WORD_RE.findall(query or "")
    terms = []
    seen = set()
    for word in raw:
        term = word.lower().strip()
        if len(term) < 3 or term in seen:
            continue
        seen.add(term)
        terms.append(term)
        if len(terms) >= 12:
            break
    if not terms:
        return []
    match = " OR ".join('"' + t.replace('"', "") + '"*' for t in terms)
    with db() as conn:
        try:
            rows = conn.execute(
                "SELECT d.id, d.name, d.ext, d.disc, d.rel, d.mtime, "
                "f.page AS fpage, p.text AS ptext "
                "FROM pages_fts f JOIN pages p ON p.doc_id=f.doc_id AND p.page=f.page "
                "JOIN docs d ON d.id=f.doc_id WHERE pages_fts MATCH ? "
                "ORDER BY bm25(pages_fts) LIMIT ?", (match, limit)
            ).fetchall()
        except sqlite3.Error:
            rows = []
    return [{
        "docId": r["id"],
        "name": r["name"],
        "ext": r["ext"],
        "disc": r["disc"],
        "discName": disc_name(r["disc"]),
        "rel": r["rel"],
        "date": "",
        "page": r["fpage"],
        "text": r["ptext"] or "",
    } for r in rows]


def assistant_context():
    state = build_state()
    with db() as conn:
        checklist = [dict(r) for r in conn.execute("SELECT * FROM checklist ORDER BY ord, id").fetchall()]
    return {
        "project": state["project"],
        "docs": state["docs"],
        "discs": state["discs"],
        "counts": state["counts"],
        "attention": state["attention"],
        "checklist": checklist,
        "works": state["works"],
        "worksSummary": state["worksSummary"],
        "today": state["today"],
        "search": search,
        "search_pages": search_pages,
    }


def backup_db():
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    pid = int(PROJECTS_STATE.get("active") or 1)
    target = BACKUP_DIR / f"p{pid}-{stamp}.db"
    src = sqlite3.connect(str(DB_PATH))
    dst = sqlite3.connect(str(target))
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    files = sorted(BACKUP_DIR.glob(f"p{pid}-*.db"))
    for old in files[:-10]:
        try:
            old.unlink()
        except OSError:
            pass
    return str(target)


def auto_backup():
    today = date.today().isoformat()
    pid = int(PROJECTS_STATE.get("active") or 1)
    if not (BACKUP_DIR / f"p{pid}-{today}.db").exists():
        try:
            src = sqlite3.connect(str(DB_PATH))
            dst = sqlite3.connect(str(BACKUP_DIR / f"p{pid}-{today}.db"))
            src.backup(dst)
            dst.close()
            src.close()
            for old in sorted(BACKUP_DIR.glob(f"p{pid}-*.db"))[:-10]:
                old.unlink(missing_ok=True)
        except Exception:
            logger.warning("Atsarginė kopija nepavyko: %s", traceback.format_exc())


class Handler(BaseHTTPRequestHandler):
    server_version = "ProjektoStabas/1.2"
    protocol_version = "HTTP/1.1"

    _auth_lock = threading.Lock()
    _auth_fails = {}

    def _auth_blocked(self):
        ip = self.client_address[0]
        now = time.time()
        with self._auth_lock:
            recent = [t for t in self._auth_fails.get(ip, []) if now - t < 300]
            self._auth_fails[ip] = recent
            return len(recent) >= 8

    def _auth_failed(self):
        with self._auth_lock:
            self._auth_fails.setdefault(self.client_address[0], []).append(time.time())

    def _auth_ok(self):
        with self._auth_lock:
            self._auth_fails.pop(self.client_address[0], None)

    def log_message(self, fmt, *args):
        logger.debug("%s - %s", self.address_string(), fmt % args)

    def _path(self):
        return unquote(urlparse(self.path).path)

    def _query(self):
        return parse_qs(urlparse(self.path).query)

    def _body(self):
        if getattr(self, "_json_body", None) is not None:
            return self._json_body
        try:
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n) if n else b""
            self._json_body = json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            self._json_body = {}
        return self._json_body

    # --- LAN access (loopback is always allowed) ---
    def _client_is_local(self):
        try:
            return ipaddress.ip_address(self.client_address[0]).is_loopback
        except ValueError:
            return False

    def _query_code(self):
        return (self._query().get("k", [""])[0] or "").strip()

    def _cookie_matches(self, value):
        return bool(value) and secrets.compare_digest(value, lan_code())

    def _cookie_valid(self):
        try:
            jar = SimpleCookie(self.headers.get("Cookie") or "")
            morsel = jar.get("stabas_key")
        except CookieError:
            return False
        return bool(morsel) and self._cookie_matches(morsel.value)

    def _key_cookie_header(self):
        return f"stabas_key={lan_code()}; Path=/; Max-Age=2592000; SameSite=Lax; HttpOnly"

    def _send_login(self, error=False):
        self._send_bytes(login_page(error).encode("utf-8"), "text/html; charset=utf-8", 401,
                         {"Connection": "close", "Cache-Control": "no-store"})
        self.close_connection = True

    def _auth_redirect(self):
        target = urlparse(self.path)
        loc = "/" if target.path == "/auth" else (target.path or "/")
        pairs = [(k, v) for k, vs in parse_qs(target.query, keep_blank_values=True).items()
                 if k != "k" for v in vs]
        if pairs:
            loc += "?" + urlencode(pairs)
        self._send_bytes(b"", "text/plain; charset=utf-8", 303,
                         {"Location": loc, "Set-Cookie": self._key_cookie_header(), "Connection": "close"})
        self.close_connection = True

    def _lan_gate(self):
        if self._client_is_local() or self._cookie_valid():
            return True
        if self.command in ("GET", "HEAD") and self._query_code():
            if self._auth_blocked():
                self._send_login(error=True)
            elif self._cookie_matches(self._query_code()):
                self._auth_ok()
                self._auth_redirect()
            else:
                self._auth_failed()
                self._send_login(error=True)
            return False
        if self.command in ("GET", "HEAD") and self._path() in ("/", "/index.html"):
            self._send_login(error="e" in self._query())
            return False
        self._send_bytes(json.dumps({"error": "Reikia prieigos kodo"}, ensure_ascii=False).encode("utf-8"),
                         "application/json; charset=utf-8", 401, {"Connection": "close"})
        self.close_connection = True
        return False

    def handle_auth(self):
        code = ""
        try:
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n).decode("utf-8", "replace") if n else ""
            code = (parse_qs(raw).get("k", [""])[0] or "").strip()
        except Exception:
            code = ""
        if not self._auth_blocked() and self._cookie_matches(code):
            self._auth_ok()
            extra = {"Location": "/", "Set-Cookie": self._key_cookie_header(), "Connection": "close"}
        else:
            if code:
                self._auth_failed()
            extra = {"Location": "/?e=1", "Connection": "close"}
        self._send_bytes(b"", "text/plain; charset=utf-8", 303, extra)
        self.close_connection = True

    def _send_bytes(self, data, ctype="application/octet-stream", status=200, extra=None, cache="no-store"):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", cache)
        if extra:
            for k, v in extra.items():
                self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def send_json(self, obj, status=200):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self._send_bytes(data, "application/json; charset=utf-8", status)

    def fail(self, code, msg):
        self.send_json({"error": msg}, code)

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        p = self._path()
        if not self._lan_gate():
            return
        try:
            if p == "/api/ping":
                return self.send_json({"app": APP_NAME, "version": VERSION})
            if p == "/api/network":
                return self.send_json(network_info(self.server.server_address[1]))
            if p == "/api/state":
                return self.send_json(build_state())
            if p == "/api/projects":
                return self.send_json(projects_public())
            if p == "/api/update":
                return self.send_json(update_payload())
            if p == "/api/sig":
                return self.send_json({
                    "sig": data_signature(),
                    "generated": now_iso(),
                    "status": {
                        "scanning": SCAN_STATE["scanning"],
                        "indexing": INDEX_STATE["indexing"],
                        "indexCurrent": INDEX_STATE["current"],
                        "indexDone": INDEX_STATE["done"],
                        "indexTotal": INDEX_STATE["total"],
                        "lastScan": SCAN_STATE["last_scan"],
                        "filesSeen": SCAN_STATE["files_seen"],
                    },
                })
            if p == "/api/docs":
                return self.send_json({"docs": all_docs()})
            if p == "/api/photos":
                return self.send_json({"photos": list_photos()})
            if p.startswith("/api/photo/"):
                return self.serve_photo_file(p.rsplit("/", 1)[-1])
            if p.startswith("/api/act-file/"):
                return self.serve_act_file(p.rsplit("/", 1)[-1])
            if p == "/api/search":
                return self.send_json(search(self._query().get("q", [""])[0]))
            if p == "/api/assistant":
                question = self._query().get("q", [""])[0]
                return self.send_json(assistant.answer(question, assistant_context()))
            if p.startswith("/api/file/"):
                return self.serve_doc_file(p.rsplit("/", 1)[-1])
            if p == "/api/dwg-cache/status":
                return self.dwg_cache_status()
            if p.startswith("/api/dwg-cache/"):
                return self.serve_dwg_cache(p.rsplit("/", 1)[-1])
            if p == "/api/export":
                return self.export_csv(self._query().get("table", ["docs"])[0])
            if p.startswith("/api/doc/"):
                doc_id = p.rsplit("/", 1)[-1]
                with db() as conn:
                    r = conn.execute("SELECT * FROM docs WHERE id=?", (doc_id,)).fetchone()
                if not r:
                    return self.fail(404, "Dokumentas nerastas")
                return self.send_json({"doc": serialize_doc(r)})
            if p == "/api/problems":
                force = self._query().get("force", [""])[0] in ("1", "true")
                return self.send_json(build_problems(force=force))
            if p == "/api/decisions":
                return self.send_json({"decisions": list_decisions()})
            if p == "/api/works/verify":
                section = self._query().get("section", ["fasadas"])[0]
                if section == "fasadas":
                    return self.send_json(verify_fasadas())
                if section in ("santechnika", "elektra", "apdaila"):
                    return self.send_json(verify_quantities(section))
                return self.fail(400, "Nepalaikoma sekcija")
            if p == "/api/works/pdf":
                return self.works_pdf(self._query().get("section", ["fasadas"])[0])
            if p == "/api/acts":
                return self.send_json(list_acts_data())
            if p.startswith("/api/contracts/"):
                parts = [x for x in p.split("/") if x]
                if len(parts) == 4 and parts[3] == "payments":
                    return self.send_json(contract_payments(parts[2]))
                if len(parts) == 4 and parts[3] == "unfinished":
                    return self.send_json(contract_unfinished(parts[2]))
                if len(parts) == 4 and parts[3] == "pdf":
                    return self.contract_pdf(parts[2])
            if p.startswith("/api/acts/"):
                parts = [x for x in p.split("/") if x]
                if len(parts) == 3:
                    detail = get_act_detail(parts[2])
                    if not detail:
                        return self.fail(404, "Aktas nerastas")
                    return self.send_json(detail)
                if len(parts) == 4 and parts[3] == "pdf":
                    return self.act_pdf(parts[2], self._query().get("form", ["f2"])[0])
                if len(parts) == 4 and parts[3] == "xlsx":
                    return self.export_act_xlsx(parts[2], self._query().get("form", ["f2"])[0])
            if p.startswith("/print/act/"):
                form = self._query().get("form", ["f2"])[0]
                if str(form).lower() == "invoice":
                    page = invoice_print_html(p.rsplit("/", 1)[-1])
                else:
                    page = act_print_html(p.rsplit("/", 1)[-1], form)
                if page is None:
                    return self.fail(404, "Aktas nerastas")
                return self._send_bytes(page.encode("utf-8"), "text/html; charset=utf-8", 200)
            if p.startswith("/print/contract/"):
                page = reconciliation_print_html(p.rsplit("/", 1)[-1])
                if page is None:
                    return self.fail(404, "Sutartis nerasta")
                return self._send_bytes(page.encode("utf-8"), "text/html; charset=utf-8", 200)
            if p in ("/api/tasks", "/api/issues", "/api/notes", "/api/checklist", "/api/works"):
                table = p.rsplit("/", 1)[-1]
                order = {"tasks": "sort, id", "issues": "num DESC", "notes": "date DESC, id DESC",
                         "checklist": "ord, id", "works": "ord, id"}[table]
                where, params = "", []
                section = self._query().get("section", [""])[0]
                if table == "works" and section in WORK_SECTIONS:
                    where, params = " WHERE section=?", [section]
                with db() as conn:
                    rows = [dict(r) for r in conn.execute(
                        f"SELECT * FROM {table}{where} ORDER BY {order}", params).fetchall()]
                return self.send_json({table: rows})
            if p in ("/", "/index.html"):
                return self.static_file(STATIC_DIR / "index.html", "text/html; charset=utf-8")
            if p == "/app.ico":
                return self.static_file(BASE_DIR / "app.ico", "image/x-icon")
            if p == "/favicon.ico":
                return self.static_file(BASE_DIR / "app.ico", "image/x-icon")
            if p in ("/app.js", "/style.css", "/dwg-worker.js", "/ocr.js"):
                ctype = "application/javascript; charset=utf-8" if p.endswith(".js") else "text/css; charset=utf-8"
                return self.static_file(STATIC_DIR / p.lstrip("/"), ctype)
            if p.startswith("/vendor/"):
                return self.vendor_file(p)
            if p.startswith("/ocr/"):
                return self.ocr_file(p)
            if p.startswith("/assets/"):
                return self.assets_file(p)
            return self.fail(404, "Nerasta")
        except Exception:
            logger.error("GET klaida %s: %s", p, traceback.format_exc())
            return self.fail(500, "Serverio klaida")

    def do_POST(self):
        p = self._path()
        if p == "/auth":
            return self.handle_auth()
        if not self._lan_gate():
            return
        if str(self.headers.get("Content-Type") or "").lower().startswith("application/json"):
            # Perskaitome JSON kūną iškart: jei maršrutas jo nenaudoja, likę baitai
            # sugadintų kitą prašymą tame pačiame keep-alive ryšyje.
            self._body()
        try:
            if p == "/api/network/rotate":
                if not self._client_is_local():
                    return self.fail(403, "Keisti kodą galima tik šiame kompiuteryje")
                code = new_lan_code()
                set_setting("lan_code", code)
                return self.send_json({"ok": True, "code": code})
            if p == "/api/rescan":
                scan_event.set()
                return self.send_json({"ok": True})
            if p == "/api/upload":
                return self.handle_upload()
            if p == "/api/photos/upload":
                return self.handle_photo_upload()
            if p.startswith("/api/dwg-cache/"):
                return self.store_dwg_cache(p.rsplit("/", 1)[-1])
            if p == "/api/docs/classify":
                return self.send_json({"ok": True, "moved": classify_uploaded_docs()})
            if p.startswith("/api/doc/") and p.endswith("/disc"):
                parts = [x for x in p.split("/") if x]
                if len(parts) == 4:
                    try:
                        body = self._body()
                        code = set_doc_disc(parts[2], body.get("disc"))
                    except ValueError as e:
                        return self.fail(400, str(e))
                    if code is None:
                        return self.fail(404, "Dokumentas nerastas")
                    return self.send_json({"ok": True, "disc": code, "discName": disc_name(code)})
            if p == "/api/reindex":
                body = self._body()
                with db() as conn:
                    if body.get("id"):
                        conn.execute("UPDATE docs SET text_state='pending' WHERE id=?", (body["id"],))
                    else:
                        conn.execute("UPDATE docs SET text_state='pending' WHERE ext IN ('.pdf','.txt','.ifc','.adoc','.dwg','.docx','.xlsx','.jpg','.jpeg','.png','.bmp','.tif','.tiff')")
                    conn.commit()
                index_event.set()
                return self.send_json({"ok": True})
            if p == "/api/backup":
                return self.send_json({"ok": True, "path": backup_db()})
            if p == "/api/shutdown":
                self.send_json({"ok": True})
                threading.Timer(0.5, lambda: os._exit(0)).start()
                return
            if p == "/api/open":
                body = self._body()
                doc = self.get_doc(body.get("id"))
                if not doc:
                    return self.fail(404, "Dokumentas nerastas")
                os.startfile(doc["path"])  # noqa: S606
                return self.send_json({"ok": True})
            if p == "/api/reveal":
                body = self._body()
                doc = self.get_doc(body.get("id"))
                if not doc:
                    return self.fail(404, "Dokumentas nerastas")
                subprocess.Popen(["explorer", "/select,", doc["path"]])
                return self.send_json({"ok": True})
            if p == "/api/open-data":
                os.startfile(str(DATA_DIR))  # noqa: S606
                return self.send_json({"ok": True})
            if p == "/api/decisions":
                try:
                    return self.send_json(save_decision(self._body()))
                except ValueError as e:
                    return self.fail(400, str(e))
            if p == "/api/contracts":
                try:
                    return self.send_json({"ok": True, "contract": save_contract(self._body())})
                except ValueError as e:
                    return self.fail(400, str(e))
            if p == "/api/acts/seed-demo":
                try:
                    cid = seed_demo_contract()
                    return self.send_json({"ok": True, "contract_id": cid, "data": list_acts_data()})
                except ValueError as e:
                    return self.fail(400, str(e))
            if p.startswith("/api/contracts/"):
                parts = [x for x in p.split("/") if x]
                if len(parts) == 4 and parts[3] == "groups":
                    try:
                        body = self._body()
                        return self.send_json(save_contract_groups(parts[2], body.get("groups")))
                    except ValueError as e:
                        return self.fail(400, str(e))
            if p == "/api/acts/ocr":
                try:
                    body = self._body()
                    cid = body.get("contract_id")
                    cid_val = int(cid) if str(cid or "").isdigit() else None
                    return self.send_json(import_act_ocr(
                        body.get("text") or "", body.get("filename") or "", cid_val))
                except ValueError as e:
                    return self.fail(400, str(e))
            if p == "/api/acts/scan-docs":
                return self.send_json(scan_f2_docs())
            if p == "/api/acts/import":
                try:
                    body = self._body()
                    payload = str(body.get("data") or "")
                    if "," in payload and payload.lstrip().startswith("data:"):
                        payload = payload.split(",", 1)[1]
                    raw = base64.b64decode(payload, validate=False)
                    cid = body.get("contract_id")
                    filename = body.get("filename") or ""
                    cid_val = int(cid) if str(cid or "").isdigit() else None
                    if raw.startswith(b"%PDF"):
                        result = import_act_pdf(raw, filename, cid_val)
                    else:
                        result = import_act_xlsx(raw, filename, cid_val)
                    return self.send_json(result)
                except ValueError as e:
                    return self.fail(400, str(e))
            if p.startswith("/api/acts/") and p.endswith("/files"):
                parts = [x for x in p.split("/") if x]
                if len(parts) == 4:
                    return self.handle_act_file_upload(parts[2])
            if p == "/api/acts":
                try:
                    return self.send_json({"ok": True, "data": save_act(self._body())})
                except ValueError as e:
                    return self.fail(400, str(e))
            if p == "/api/projects":
                try:
                    project = create_project(self._body())
                    return self.send_json({"ok": True, "project": project, **projects_public()})
                except ValueError as e:
                    return self.fail(400, str(e))
            if p == "/api/projects/switch":
                try:
                    body = self._body()
                    switch_project(body.get("id"))
                    return self.send_json({"ok": True, **projects_public()})
                except ValueError as e:
                    return self.fail(400, str(e))
            if p == "/api/update/check":
                return self.send_json(update_check())
            if p == "/api/update/apply":
                try:
                    result = update_apply()
                    restart_program()
                    return self.send_json(result)
                except Exception as e:
                    return self.fail(400, str(e))
            if p == "/api/update/auto":
                body = self._body()
                enabled = bool(body.get("enabled", True))
                global_write(auto_update=enabled)
                return self.send_json({"ok": True, "auto": enabled})
            if p.startswith("/api/"):
                table = p.rsplit("/", 1)[-1]
                body = self._body()
                if table == "tasks":
                    return self.create_task(body)
                if table == "issues":
                    return self.create_issue(body)
                if table == "notes":
                    return self.create_note(body)
                if table == "checklist":
                    return self.create_checklist(body)
                if table == "works":
                    return self.create_work(body)
            return self.fail(404, "Nerasta")
        except Exception:
            logger.error("POST klaida %s: %s", p, traceback.format_exc())
            return self.fail(500, "Serverio klaida")

    def do_PATCH(self):
        p = self._path()
        if not self._lan_gate():
            return
        try:
            parts = [x for x in p.split("/") if x]
            body = self._body()
            if len(parts) == 3 and parts[1] in ("tasks", "issues", "notes", "checklist", "works"):
                return self.update_row(parts[1], parts[2], body)
            if len(parts) == 3 and parts[1] == "disc":
                return self.update_disc(parts[2], body)
            if len(parts) == 3 and parts[1] == "photos":
                try:
                    return self.send_json({"ok": True, "photo": update_photo(parts[2], body)})
                except ValueError as e:
                    return self.fail(400, str(e))
            if len(parts) == 3 and parts[1] == "contracts":
                try:
                    return self.send_json({"ok": True, "contract": save_contract(body, parts[2])})
                except ValueError as e:
                    return self.fail(400, str(e))
            if len(parts) == 3 and parts[1] == "acts":
                try:
                    return self.send_json({"ok": True, "data": save_act(body, parts[2])})
                except ValueError as e:
                    return self.fail(400, str(e))
            if p == "/api/company":
                company = company_data()
                for k in COMPANY_FIELDS:
                    if k in body:
                        company[k] = str(body.get(k) or "").strip()
                set_setting("company", company)
                return self.send_json({"ok": True, "company": company})
            if p == "/api/project":
                ap = active_project_entry()
                if ap:
                    project = update_project_meta(ap["id"], body)
                else:
                    project = get_setting("project", dict(DEFAULT_PROJECT))
                    for k in PROJECT_FIELDS:
                        if k in body:
                            project[k] = str(body.get(k) or "").strip()
                    set_setting("project", project)
                    data_touch()
                return self.send_json({"ok": True, "project": project})
            if len(parts) == 3 and parts[1] == "projects":
                try:
                    project = update_project_meta(parts[2], body)
                    return self.send_json({"ok": True, "project": project, **projects_public()})
                except ValueError as e:
                    return self.fail(400, str(e))
            if p == "/api/roots":
                roots = body.get("roots")
                if not isinstance(roots, list):
                    return self.fail(400, "Neteisingi katalogai")
                roots = [str(r).strip() for r in roots if str(r).strip()]
                set_setting("roots", roots)
                scan_event.set()
                data_touch()
                return self.send_json({"ok": True, "roots": roots})
            return self.fail(404, "Nerasta")
        except Exception:
            logger.error("PATCH klaida %s: %s", p, traceback.format_exc())
            return self.fail(500, "Serverio klaida")

    def do_DELETE(self):
        p = self._path()
        if not self._lan_gate():
            return
        try:
            parts = [x for x in p.split("/") if x]
            if len(parts) == 3 and parts[1] in ("tasks", "issues", "notes", "checklist", "works"):
                table = parts[1]
                with db() as conn:
                    conn.execute(f"DELETE FROM {table} WHERE id=?", (parts[2],))
                    conn.commit()
                if table == "works":
                    problems_invalidate()
                else:
                    data_touch()
                return self.send_json({"ok": True})
            if len(parts) == 3 and parts[1] == "acts":
                try:
                    delete_act(parts[2])
                    return self.send_json({"ok": True})
                except ValueError as e:
                    return self.fail(400, str(e))
            if len(parts) == 3 and parts[1] == "photos":
                try:
                    delete_photo(parts[2])
                    return self.send_json({"ok": True})
                except ValueError as e:
                    return self.fail(400, str(e))
            if len(parts) == 3 and parts[1] == "act-files":
                try:
                    return self.send_json(delete_act_file(parts[2]))
                except ValueError as e:
                    return self.fail(400, str(e))
            if len(parts) == 3 and parts[1] == "contracts":
                try:
                    delete_contract(parts[2])
                    return self.send_json({"ok": True})
                except ValueError as e:
                    return self.fail(400, str(e))
            if len(parts) == 3 and parts[1] == "projects":
                try:
                    delete_project(parts[2])
                    return self.send_json({"ok": True, **projects_public()})
                except ValueError as e:
                    return self.fail(400, str(e))
            return self.fail(404, "Nerasta")
        except Exception:
            logger.error("DELETE klaida %s: %s", p, traceback.format_exc())
            return self.fail(500, "Serverio klaida")

    # --- helpers ---
    def get_doc(self, doc_id):
        try:
            with db() as conn:
                r = conn.execute("SELECT * FROM docs WHERE id=?", (int(doc_id),)).fetchone()
            return dict(r) if r else None
        except (TypeError, ValueError):
            return None

    def static_file(self, path, ctype, cache="no-store"):
        path = Path(path)
        if not path.exists() or not path.is_file():
            return self.fail(404, "Nerasta")
        data = path.read_bytes()
        self._send_bytes(data, ctype, cache=cache)

    def vendor_file(self, p):
        base = (STATIC_DIR / "vendor").resolve()
        target = (base / p[len("/vendor/"):]).resolve()
        try:
            target.relative_to(base)
        except ValueError:
            return self.fail(404, "Nerasta")
        if not target.is_file():
            return self.fail(404, "Nerasta")
        ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        if target.suffix.lower() == ".wasm":
            ctype = "application/wasm"
        return self.static_file(target, ctype, "public, max-age=604800")

    def ocr_file(self, p):
        base = (STATIC_DIR / "ocr").resolve()
        target = (base / p[len("/ocr/"):]).resolve()
        try:
            target.relative_to(base)
        except ValueError:
            return self.fail(404, "Nerasta")
        if not target.is_file():
            return self.fail(404, "Nerasta")
        ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        return self.static_file(target, ctype, "public, max-age=604800")

    def assets_file(self, p):
        base = (STATIC_DIR / "assets").resolve()
        target = (base / p[len("/assets/"):]).resolve()
        try:
            target.relative_to(base)
        except ValueError:
            return self.fail(404, "Nerasta")
        if not target.is_file():
            return self.fail(404, "Nerasta")
        ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        if target.suffix.lower() == ".webp":
            ctype = "image/webp"
        return self.static_file(target, ctype, "public, max-age=86400")

    def dwg_cache_status(self):
        entries = {}
        total = 0
        pid = int(PROJECTS_STATE.get("active") or 1)
        with db() as conn:
            rows = {r["id"]: int(r["mtime"]) for r in conn.execute("SELECT id, mtime FROM docs WHERE ext='.dwg'")}
        for f in DWG_CACHE_DIR.glob(f"dwg_p{pid}_*.svg"):
            m = re.match(rf"dwg_p{pid}_(\d+)_(\d+)\.svg$", f.name)
            if not m:
                continue
            doc_id = int(m.group(1))
            if rows.get(doc_id) != int(m.group(2)):
                continue
            try:
                size = f.stat().st_size
            except OSError:
                continue
            entries[str(doc_id)] = size
            total += size
        self.send_json({"entries": entries, "count": len(entries), "bytes": total})

    def serve_dwg_cache(self, doc_id):
        doc = self.get_doc(doc_id)
        if not doc or doc.get("ext") != ".dwg":
            return self.fail(404, "Nerasta")
        kind = (self._query().get("kind", [""])[0] or "").strip()
        pid = int(PROJECTS_STATE.get("active") or 1)
        if kind == "thumb":
            for ext in (".thumb.png", ".thumb.bmp"):
                path = DWG_CACHE_DIR / f"dwg_p{pid}_{int(doc['id'])}_{int(doc['mtime'])}{ext}"
                if path.is_file():
                    ctype = "image/png" if path.suffix == ".png" else "image/bmp"
                    return self._send_bytes(path.read_bytes(), ctype, cache="public, max-age=31536000, immutable")
            self.send_response(204)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        path = dwg_cache_path(doc)
        if not path.is_file():
            self.send_response(204)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        data = path.read_bytes()
        self._send_bytes(data, "image/svg+xml; charset=utf-8", cache="public, max-age=31536000, immutable")

    def handle_photo_upload(self):
        q = self._query()
        name = (q.get("name", [""])[0] or "").strip()
        try:
            name = safe_upload_name(name)
        except ValueError as exc:
            self.close_connection = True
            return self.fail(400, str(exc))
        ext = Path(name).suffix.lower()
        if ext not in PHOTO_EXTS:
            self.close_connection = True
            return self.fail(400, "Palalkomi JPG, PNG, WEBP, GIF ir BMP formatai")
        date_iso = (q.get("date", [""])[0] or "").strip() or today_iso()
        try:
            date.fromisoformat(date_iso)
        except ValueError:
            self.close_connection = True
            return self.fail(400, "Neteisinga nuotraukos data")
        caption = (q.get("caption", [""])[0] or "").strip()[:500]
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if n <= 0:
            self.close_connection = True
            return self.fail(400, "Nuotrauka tuščia")
        if n > PHOTO_MAX_BYTES:
            self.close_connection = True
            return self.fail(413, "Nuotrauka per didelė (iki 40 MB)")
        folder = photo_dir()
        tmp = None
        path = None
        try:
            folder.mkdir(parents=True, exist_ok=True)
            path = unique_upload_path(folder, name)
            tmp = path.with_name(path.name + ".part")
            remaining = n
            with open(tmp, "wb") as fh:
                while remaining > 0:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise OSError("Nebaigtas failo perdavimas")
                    fh.write(chunk)
                    remaining -= len(chunk)
            with open(tmp, "rb") as fh:
                head = fh.read(16)
            if not photo_magic_ok(head, ext):
                raise ValueError("Failas nėra nuotrauka")
            os.replace(tmp, path)
            tmp = None
        except (OSError, ValueError) as exc:
            if tmp is not None:
                try:
                    tmp.unlink(missing_ok=True)
                except OSError:
                    pass
            logger.warning("Nuotraukos įkėlimas nepavyko: %s", exc)
            return self.fail(500 if not isinstance(exc, ValueError) else 400,
                             "Nepavyko išsaugoti nuotraukos" if not isinstance(exc, ValueError) else str(exc))
        try:
            photo = add_photo(date_iso, name, path.name, path.stat().st_size, caption)
        except Exception:
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass
            logger.error("Nuotraukos įrašymas į DB nepavyko: %s", traceback.format_exc())
            return self.fail(500, "Nepavyko išsaugoti nuotraukos")
        logger.info("Įkelta nuotrauka: %s (%s)", path.name, date_iso)
        return self.send_json({"ok": True, "photo": photo})

    def handle_upload(self):
        name = (self._query().get("name", [""])[0] or "").strip()
        try:
            name = safe_upload_name(name)
        except ValueError as exc:
            self.close_connection = True
            return self.fail(400, str(exc))
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if n <= 0:
            self.close_connection = True
            return self.fail(400, "Failas tuščias")
        if n > UPLOAD_MAX_BYTES:
            self.close_connection = True
            return self.fail(413, "Failas per didelis (iki 300 MB)")
        folder = upload_dir()
        tmp = None
        try:
            folder.mkdir(parents=True, exist_ok=True)
            path = unique_upload_path(folder, name)
            tmp = path.with_name(path.name + ".part")
            remaining = n
            with open(tmp, "wb") as fh:
                while remaining > 0:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise OSError("Nebaigtas failo perdavimas")
                    fh.write(chunk)
                    remaining -= len(chunk)
            os.replace(tmp, path)
            tmp = None
        except (OSError, ValueError) as exc:
            if tmp is not None:
                try:
                    tmp.unlink(missing_ok=True)
                except OSError:
                    pass
            logger.warning("Failo įkėlimas nepavyko: %s", exc)
            return self.fail(500 if not isinstance(exc, ValueError) else 400,
                             "Nepavyko išsaugoti failo" if not isinstance(exc, ValueError) else str(exc))
        for _ in range(20):
            if not SCAN_STATE["scanning"]:
                break
            time.sleep(0.15)
        scan_files()
        doc_id = None
        with db() as conn:
            row = conn.execute("SELECT id FROM docs WHERE path=?", (str(path),)).fetchone()
            if row:
                doc_id = row["id"]
        if doc_id is None:
            scan_event.set()
        logger.info("Įkeltas failas į dokumentus: %s", path.name)
        return self.send_json({"ok": True, "id": doc_id, "name": path.name})

    def store_dwg_cache(self, doc_id):
        doc = self.get_doc(doc_id)
        if not doc or doc.get("ext") != ".dwg":
            return self.fail(404, "Nerasta")
        kind = (self._query().get("kind", [""])[0] or "").strip()
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        limit = 8 * 1024 * 1024 if kind == "thumb" else DWG_SVG_MAX_BYTES
        if n <= 0 or n > limit:
            self.close_connection = True
            return self.fail(413, "Netinkamas failo dydis")
        data = self.rfile.read(n)
        pid = int(PROJECTS_STATE.get("active") or 1)
        if kind == "thumb":
            if data[:8] == b"\x89PNG\r\n\x1a\n":
                path = DWG_CACHE_DIR / f"dwg_p{pid}_{int(doc['id'])}_{int(doc['mtime'])}.thumb.png"
            elif data[:2] == b"BM":
                path = DWG_CACHE_DIR / f"dwg_p{pid}_{int(doc['id'])}_{int(doc['mtime'])}.thumb.bmp"
            else:
                return self.fail(400, "Netinkama miniatiūra")
        else:
            if b"<svg" not in data[:512]:
                return self.fail(400, "Netinkamas SVG")
            path = dwg_cache_path(doc)
        tmp = path.with_suffix(path.suffix + ".tmp")
        try:
            tmp.write_bytes(data)
            os.replace(tmp, path)
        except OSError:
            logger.warning("DWG podėlio įrašymas nepavyko: %s", traceback.format_exc())
            return self.fail(500, "Nepavyko išsaugoti peržiūros")
        if kind != "thumb":
            for old in DWG_CACHE_DIR.glob(f"dwg_p{pid}_{int(doc['id'])}_*.svg"):
                if old != path:
                    try:
                        old.unlink()
                    except OSError:
                        pass
            for old in DWG_CACHE_DIR.glob(f"dwg_p{pid}_{int(doc['id'])}_*.thumb.*"):
                try:
                    old.unlink()
                except OSError:
                    pass
        dwg_cache_cleanup(keep=path)
        logger.info("DWG podėlis: %s (%s, %.1f MB)", doc["name"], kind or "svg", len(data) / 1e6)
        return self.send_json({"ok": True, "bytes": len(data)})

    def serve_doc_file(self, doc_id):
        doc = self.get_doc(doc_id)
        if not doc:
            return self.fail(404, "Dokumentas nerastas")
        path = Path(doc["path"])
        if doc["ext"] == ".adoc":
            try:
                path = _adoc_inner_pdf(path, doc["id"], doc["mtime"])
            except Exception:
                logger.warning("ADOC peržiūra nepavyko: %s", traceback.format_exc())
                return self.fail(415, "ADOC dokumento peržiūra negalima")
        if not path.exists():
            return self.fail(404, "Failas nerastas")
        size = path.stat().st_size
        ctype = "application/pdf" if path.suffix.lower() == ".pdf" else (
            mimetypes.guess_type(str(path))[0] or "application/octet-stream")
        fname = doc["name"]
        disp = "inline; filename*=UTF-8''" + quote(fname)
        rng = self.headers.get("Range")
        start, end = 0, size - 1
        status = 200
        if rng:
            m = re.match(r"bytes=(\d*)-(\d*)", rng.strip())
            if m:
                if m.group(1):
                    start = int(m.group(1))
                    end = int(m.group(2)) if m.group(2) else size - 1
                elif m.group(2):
                    start = max(0, size - int(m.group(2)))
                end = min(end, size - 1)
                if start > end or start >= size:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{size}")
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                status = 206
        length = end - start + 1
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Disposition", disp)
        self.send_header("Cache-Control", "no-store")
        if status == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        if self.command == "HEAD":
            return
        try:
            with open(path, "rb") as f:
                f.seek(start)
                remaining = length
                while remaining > 0:
                    chunk = f.read(min(262144, remaining))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def serve_photo_file(self, photo_id):
        try:
            pid = int(photo_id)
        except (TypeError, ValueError):
            return self.fail(404, "Nuotrauka nerasta")
        ensure_photos_table()
        with db() as conn:
            row = conn.execute("SELECT * FROM photos WHERE id=?", (pid,)).fetchone()
        if not row:
            return self.fail(404, "Nuotrauka nerasta")
        folder = photo_dir().resolve()
        path = (folder / (row["file"] or "")).resolve()
        if path.parent != folder or not path.is_file():
            return self.fail(404, "Nuotraukos failas nerastas")
        size = path.stat().st_size
        ctype = PHOTO_TYPES.get(path.suffix.lower()) or "application/octet-stream"
        fname = row["name"] or path.name
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(size))
        self.send_header("Content-Disposition", "inline; filename*=UTF-8''" + quote(fname))
        self.send_header("Cache-Control", "private, max-age=31536000, immutable")
        self.end_headers()
        if self.command == "HEAD":
            return
        try:
            with open(path, "rb") as f:
                while True:
                    chunk = f.read(262144)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def serve_act_file(self, file_id):
        try:
            fid = int(file_id)
        except (TypeError, ValueError):
            return self.fail(404, "Failas nerastas")
        with db() as conn:
            row = conn.execute("SELECT * FROM act_files WHERE id=?", (fid,)).fetchone()
        if not row:
            return self.fail(404, "Failas nerastas")
        folder = act_files_dir(row["act_id"]).resolve()
        path = (folder / (row["file"] or "")).resolve()
        if path.parent != folder or not path.is_file():
            return self.fail(404, "Failo kopija nerasta")
        size = path.stat().st_size
        ext = (row["ext"] or path.suffix).lower()
        ctype = ACT_FILE_TYPES.get(ext) or "application/octet-stream"
        fname = row["name"] or path.name
        disposition = "inline" if ext in ACT_FILE_INLINE else "attachment"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(size))
        self.send_header("Content-Disposition",
                         f"{disposition}; filename*=UTF-8''" + quote(fname))
        self.send_header("Cache-Control", "private, max-age=31536000, immutable")
        self.end_headers()
        if self.command == "HEAD":
            return
        try:
            with open(path, "rb") as f:
                while True:
                    chunk = f.read(262144)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def handle_act_file_upload(self, act_id):
        q = self._query()
        name = (q.get("name", [""])[0] or "").strip()
        try:
            name = safe_upload_name(name)
        except ValueError as exc:
            self.close_connection = True
            return self.fail(400, str(exc))
        ext = Path(name).suffix.lower()
        if ext not in ACT_FILE_EXTS:
            self.close_connection = True
            return self.fail(400, "Failo tipas nepalaikomas (PDF, JPG, PNG, DOCX, XLSX, DWG, ZIP)")
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if n <= 0:
            self.close_connection = True
            return self.fail(400, "Failas tuščias")
        if n > ACT_FILE_MAX_BYTES:
            self.close_connection = True
            return self.fail(413, "Failas per didelis (iki 60 MB)")
        with db() as conn:
            if not conn.execute("SELECT 1 FROM acts WHERE id=?", (int(act_id),)).fetchone():
                self.close_connection = True
                return self.fail(404, "Aktas nerastas")
        folder = act_files_dir(act_id)
        tmp = None
        path = None
        try:
            folder.mkdir(parents=True, exist_ok=True)
            path = unique_upload_path(folder, name)
            tmp = path.with_name(path.name + ".part")
            remaining = n
            with open(tmp, "wb") as fh:
                while remaining > 0:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise OSError("Nebaigtas failo perdavimas")
                    fh.write(chunk)
                    remaining -= len(chunk)
            with open(tmp, "rb") as fh:
                head = fh.read(16)
            if not act_file_magic_ok(head, ext):
                raise ValueError("Failo turinys neatitinka plėtinio")
            os.replace(tmp, path)
            tmp = None
        except (OSError, ValueError) as exc:
            if tmp is not None:
                try:
                    tmp.unlink(missing_ok=True)
                except OSError:
                    pass
            logger.warning("Akto failo įkėlimas nepavyko: %s", exc)
            return self.fail(500 if not isinstance(exc, ValueError) else 400,
                             "Nepavyko išsaugoti failo" if not isinstance(exc, ValueError) else str(exc))
        try:
            item = add_act_file(act_id, name, path.name, path.stat().st_size)
        except Exception:
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass
            logger.error("Akto failo įrašymas nepavyko: %s", traceback.format_exc())
            return self.fail(500, "Nepavyko išsaugoti failo")
        logger.info("Pridėtas akto failas: %s (aktas %s)", path.name, act_id)
        return self.send_json({"ok": True, "file": item})

    def export_csv(self, table):
        if table == "issues":
            with db() as conn:
                rows = [dict(r) for r in conn.execute("SELECT * FROM issues ORDER BY num").fetchall()]
            head = ["Nr.", "Tipas", "Pavadinimas", "Aprašymas", "Dalis", "Būsena", "Prioritetas", "Terminas", "Atsakingas", "Sukurta"]
            data = [[f"P-{r['num']:03d}", r["kind"], r["title"], r["desc"], r["disc"], r["status"],
                     r["priority"], r["due"], r["assignee"], r["created"]] for r in rows]
        elif table == "tasks":
            with db() as conn:
                rows = [dict(r) for r in conn.execute("SELECT * FROM tasks ORDER BY id").fetchall()]
            head = ["Pavadinimas", "Aprašymas", "Būsena", "Prioritetas", "Terminas", "Atsakingas", "Sukurta"]
            data = [[r["title"], r["desc"], r["status"], r["priority"], r["due"], r["assignee"], r["created"]] for r in rows]
        elif table == "docs":
            docs = all_docs()
            head = ["Pavadinimas", "Dalis", "Tipas", "Dokumento data", "Lapai", "Dydis (KB)", "Kelias"]
            data = [[d["name"], d["discName"], d["ext"], d["date"], d["pages"] or "", round(d["size"] / 1024),
                     d["path"]] for d in docs]
        else:
            return self.fail(400, "Nepalaikomas eksporto lentelės tipas")
        buf = io.StringIO()
        w = csv.writer(buf, delimiter=";")
        w.writerow(head)
        w.writerows(data)
        content = "\ufeff" + buf.getvalue()
        self._send_bytes(content.encode("utf-8"), "text/csv; charset=utf-8", 200,
                         {"Content-Disposition": f"attachment; filename=projekto-stabas-{table}.csv"})

    def act_pdf(self, act_id, form):
        if not self._client_is_local():
            return self.fail(403, "PDF eksportas prieinamas tik pagrindiniame kompiuteryje")
        detail = get_act_detail(act_id)
        if not detail:
            return self.fail(404, "Aktas nerastas")
        form = str(form).lower()
        if form not in ("f2", "f3", "invoice"):
            form = "f2"
        port = self.server.server_address[1]
        url = f"http://127.0.0.1:{port}/print/act/{quote(str(act_id))}?form={form}&v={int(time.time())}"
        tmpdir = Path(tempfile.mkdtemp(prefix="stabas-aktas-"))
        out = tmpdir / "aktas.pdf"
        try:
            err = render_pdf(url, out, wait_ms=3000, timeout=45)
            if err:
                logger.warning("Akto PDF eksportas (%s) nepavyko: %s", act_id, err)
                return self.fail(503, err)
            prefix = {"f3": "F3-pazyma", "invoice": "Saskaita"}.get(form, "F2-aktas")
            date_part = detail["act"].get("date") or today_iso()
            name = f"{prefix}-Nr-{detail['act']['num']}-{date_part}.pdf"
            self._send_bytes(out.read_bytes(), "application/pdf", 200, {
                "Content-Disposition": f"inline; filename=\"aktas.pdf\"; filename*=UTF-8''{quote(name)}",
            })
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def export_act_xlsx(self, act_id, form="f2"):
        detail = get_act_detail(act_id)
        if not detail:
            return self.fail(404, "Aktas nerastas")
        form = "f3" if str(form).lower() == "f3" else "f2"
        try:
            data = build_act_xlsx(act_id, form)
        except Exception:
            logger.error("Akto XLSX eksportas (%s) nepavyko: %s", act_id, traceback.format_exc())
            return self.fail(500, "Nepavyko sudaryti Excel failo")
        if not data:
            return self.fail(404, "Aktas nerastas")
        prefix = "F3-pazyma" if form == "f3" else "F2-aktas"
        date_part = detail["act"].get("date") or today_iso()
        name = f"{prefix}-Nr-{detail['act']['num']}-{date_part}.xlsx"
        self._send_bytes(data, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", 200, {
            "Content-Disposition": f'attachment; filename="aktas.xlsx"; filename*=UTF-8\'\'{quote(name)}',
        })

    def contract_pdf(self, contract_id):
        if not self._client_is_local():
            return self.fail(403, "PDF eksportas prieinamas tik pagrindiniame kompiuteryje")
        with db() as conn:
            contract = conn.execute("SELECT * FROM contracts WHERE id=?", (contract_id,)).fetchone()
        if not contract:
            return self.fail(404, "Sutartis nerasta")
        port = self.server.server_address[1]
        url = f"http://127.0.0.1:{port}/print/contract/{quote(str(contract_id))}?form=recon&v={int(time.time())}"
        tmpdir = Path(tempfile.mkdtemp(prefix="stabas-suderinimas-"))
        out = tmpdir / "suderinimas.pdf"
        try:
            err = render_pdf(url, out, wait_ms=3000, timeout=45)
            if err:
                logger.warning("Suderinimo PDF eksportas (%s) nepavyko: %s", contract_id, err)
                return self.fail(503, err)
            name = f"Suderinimas-{date.today().isoformat()}.pdf"
            self._send_bytes(out.read_bytes(), "application/pdf", 200, {
                "Content-Disposition": f"inline; filename=\"suderinimas.pdf\"; filename*=UTF-8''{quote(name)}",
            })
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def works_pdf(self, section):
        if section not in WORK_SECTIONS:
            return self.fail(400, "Nepalaikoma sekcija")
        if not self._client_is_local():
            return self.fail(403, "PDF eksportas prieinamas tik pagrindiniame kompiuteryje")
        labels = {"elektra": "Elektra", "apdaila": "Apdaila", "santechnika": "Santechnika", "fasadas": "Fasadas"}
        port = self.server.server_address[1]
        url = f"http://127.0.0.1:{port}/?v={int(time.time())}#{section}"
        tmpdir = Path(tempfile.mkdtemp(prefix="stabas-export-"))
        out = tmpdir / "samata.pdf"
        try:
            err = render_pdf(url, out)
            if err:
                logger.warning("PDF eksportas (%s) nepavyko: %s", section, err)
                return self.fail(503, err)
            name = f"Sąmata-{labels[section]}-{date.today().isoformat()}.pdf"
            self._send_bytes(out.read_bytes(), "application/pdf", 200, {
                "Content-Disposition": f"inline; filename=\"samata-{section}.pdf\"; filename*=UTF-8''{quote(name)}",
            })
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def create_task(self, body):
        title = str(body.get("title") or "").strip()
        if not title:
            return self.fail(400, "Įrašykite užduoties pavadinimą")
        with db() as conn:
            cur = conn.execute(
                "INSERT INTO tasks(title,desc,status,priority,due,assignee,created,sort) VALUES(?,?,?,?,?,?,?,?)",
                (title, str(body.get("desc") or ""), body.get("status") or "todo",
                 body.get("priority") or "Normali", str(body.get("due") or ""),
                 str(body.get("assignee") or ""), now_iso(), time.time()),
            )
            conn.commit()
            row = conn.execute("SELECT * FROM tasks WHERE id=?", (cur.lastrowid,)).fetchone()
        data_touch()
        return self.send_json({"ok": True, "task": dict(row)})

    def create_issue(self, body):
        title = str(body.get("title") or "").strip()
        if not title:
            return self.fail(400, "Įrašykite pavadinimą")
        with db() as conn:
            num = conn.execute("SELECT COALESCE(MAX(num),0)+1 n FROM issues").fetchone()["n"]
            cur = conn.execute(
                "INSERT INTO issues(num,kind,title,desc,disc,status,priority,due,assignee,created) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (num, body.get("kind") or "Pastaba", title, str(body.get("desc") or ""),
                 str(body.get("disc") or ""), body.get("status") or "Atvira",
                 body.get("priority") or "Normali", str(body.get("due") or ""),
                 str(body.get("assignee") or ""), now_iso()),
            )
            conn.commit()
            row = conn.execute("SELECT * FROM issues WHERE id=?", (cur.lastrowid,)).fetchone()
        data_touch()
        return self.send_json({"ok": True, "issue": dict(row)})

    def create_note(self, body):
        title = str(body.get("title") or "").strip()
        if not title:
            return self.fail(400, "Įrašykite pavadinimą")
        with db() as conn:
            cur = conn.execute(
                "INSERT INTO notes(date,title,attendees,body,created) VALUES(?,?,?,?,?)",
                (body.get("date") or today_iso(), title, str(body.get("attendees") or ""),
                 str(body.get("body") or ""), now_iso()),
            )
            conn.commit()
            row = conn.execute("SELECT * FROM notes WHERE id=?", (cur.lastrowid,)).fetchone()
        data_touch()
        return self.send_json({"ok": True, "note": dict(row)})

    def create_checklist(self, body):
        title = str(body.get("title") or "").strip()
        if not title:
            return self.fail(400, "Įrašykite pavadinimą")
        stage = str(body.get("stage") or "Papildomi darbai")
        with db() as conn:
            ord_ = conn.execute("SELECT COALESCE(MAX(ord),0)+1 o FROM checklist").fetchone()["o"]
            cur = conn.execute(
                "INSERT INTO checklist(stage,title,done,due,note,ord) VALUES(?,?,0,?,?,?)",
                (stage, title, str(body.get("due") or ""), str(body.get("note") or ""), ord_),
            )
            conn.commit()
            row = conn.execute("SELECT * FROM checklist WHERE id=?", (cur.lastrowid,)).fetchone()
        data_touch()
        return self.send_json({"ok": True, "item": dict(row)})

    def create_work(self, body):
        title = str(body.get("title") or "").strip()
        if not title:
            return self.fail(400, "Įrašykite darbo pavadinimą")
        section = str(body.get("section") or "elektra")
        if section not in WORK_SECTIONS:
            return self.fail(400, "Neteisinga skiltis")
        try:
            qty = max(0.0, float(body.get("qty") or 0))
            done = min(max(0.0, float(body.get("done") or 0)), qty)
            price = max(0.0, float(body.get("price") or 0))
            source_doc = int(body.get("source_doc") or 0)
            source_page = int(body.get("source_page") or 0)
        except (TypeError, ValueError):
            return self.fail(400, "Neteisingi skaičiai")
        unit = str(body.get("unit") or "vnt.").strip() or "vnt."
        kind = str(body.get("kind") or "Sąmata")
        if kind not in ("Sąmata", "Projektas", "Skaičiuojama"):
            kind = "Sąmata"
        with db() as conn:
            ord_ = conn.execute(
                "SELECT COALESCE(MAX(ord),0)+1 o FROM works WHERE section=?", (section,)
            ).fetchone()["o"]
            cur = conn.execute(
                "INSERT INTO works(section,stage,code,title,unit,qty,done,price,kind,basis,"
                "source_doc,source_page,source_name,note,ord,created,updated) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (section, str(body.get("stage") or ""), str(body.get("code") or ""),
                 title, unit, qty, done, price, kind, str(body.get("basis") or ""),
                 source_doc, source_page, str(body.get("source_name") or ""),
                 str(body.get("note") or ""), ord_, now_iso(), now_iso()),
            )
            conn.commit()
            row = conn.execute("SELECT * FROM works WHERE id=?", (cur.lastrowid,)).fetchone()
        problems_invalidate()
        return self.send_json({"ok": True, "work": dict(row)})

    def update_row(self, table, row_id, body):
        allowed = {
            "tasks": {"title", "desc", "status", "priority", "due", "assignee", "sort"},
            "issues": {"kind", "title", "desc", "disc", "status", "priority", "due", "assignee"},
            "notes": {"date", "title", "attendees", "body"},
            "checklist": {"stage", "title", "done", "due", "note", "ord"},
            "works": {"section", "stage", "code", "title", "unit", "qty", "done", "price",
                      "kind", "basis", "source_doc", "source_page", "source_name", "note", "ord"},
        }[table]
        fields = {k: body[k] for k in body if k in allowed}
        if table == "checklist" and "done" in fields:
            fields["done"] = 1 if fields["done"] in (1, True, "1", "true") else 0
        if not fields:
            return self.fail(400, "Nėra ką atnaujinti")
        try:
            row_id = int(row_id)
        except ValueError:
            return self.fail(400, "Neteisingas ID")
        with db() as conn:
            old = conn.execute(f"SELECT * FROM {table} WHERE id=?", (row_id,)).fetchone()
            if not old:
                return self.fail(404, "Įrašas nerastas")
            if table == "tasks" and "status" in fields:
                prev = old["status"]
                fields["done_at"] = now_iso() if fields["status"] == "done" else (old["done_at"] if prev == "done" else "")
            if table == "issues" and "status" in fields:
                fields["closed_at"] = now_iso() if fields["status"] == "Uždaryta" else ""
            if table == "works":
                if "section" in fields and fields["section"] not in WORK_SECTIONS:
                    return self.fail(400, "Neteisinga skiltis")
                if "title" in fields and not str(fields["title"]).strip():
                    return self.fail(400, "Įrašykite darbo pavadinimą")
                try:
                    for k in ("qty", "done", "price", "ord"):
                        if k in fields:
                            fields[k] = max(0.0, float(fields[k] or 0))
                    for k in ("source_doc", "source_page"):
                        if k in fields:
                            fields[k] = max(0, int(fields[k] or 0))
                except (TypeError, ValueError):
                    return self.fail(400, "Neteisingi skaičiai")
                qty_now = float(fields.get("qty", old["qty"] or 0))
                if "done" in fields:
                    fields["done"] = min(float(fields["done"]), qty_now)
                elif "qty" in fields:
                    fields["done"] = min(float(old["done"] or 0), qty_now)
                if "kind" in fields and fields["kind"] not in ("Sąmata", "Projektas", "Skaičiuojama"):
                    fields["kind"] = "Sąmata"
                fields["updated"] = now_iso()
            sql = f"UPDATE {table} SET {', '.join(k + '=?' for k in fields)} WHERE id=?"
            conn.execute(sql, list(fields.values()) + [row_id])
            conn.commit()
            row = conn.execute(f"SELECT * FROM {table} WHERE id=?", (row_id,)).fetchone()
        if table == "works":
            problems_invalidate()
        else:
            data_touch()
        return self.send_json({"ok": True, "row": dict(row)})

    def update_disc(self, code, body):
        status = body.get("status")
        if status is not None and status not in DISC_STATUSES:
            return self.fail(400, "Neteisinga būsena")
        with db() as conn:
            conn.execute("INSERT OR IGNORE INTO disc_status(disc) VALUES(?)", (code,))
            fields = {}
            for k in ("status", "owner", "note"):
                if k in body:
                    fields[k] = str(body[k])
            if fields:
                fields["updated"] = now_iso()
                conn.execute(
                    f"UPDATE disc_status SET {', '.join(k + '=?' for k in fields)} WHERE disc=?",
                    list(fields.values()) + [code],
                )
            conn.commit()
        data_touch()
        return self.send_json({"ok": True})


def find_running():
    for port in range(8765, 8776):
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/ping", timeout=0.4) as r:
                data = json.loads(r.read().decode("utf-8"))
                if data.get("app") == APP_NAME:
                    return port
        except Exception:
            continue
    return None


def free_port():
    for port in range(8765, 8776):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind((BIND_HOST, port))
            return port
        except OSError:
            continue
        finally:
            s.close()
    return 8765


def open_app_window(url):
    """Atidaro programą kaip atskirą langą (be naršyklės adreso juostos), kaip įprastą kompiuterio programą."""
    if os.environ.get("STABAS_APP_WINDOW", "1") == "0":
        webbrowser.open(url)
        return
    exe = find_pdf_browser()
    if exe:
        try:
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
            subprocess.Popen([str(exe), f"--app={url}"], creationflags=flags)
            return
        except OSError:
            logger.warning("Nepavyko atidaryti programos lango: %s", traceback.format_exc())
    webbrowser.open(url)


def main():
    no_browser = bool(os.environ.get("STABAS_NO_BROWSER"))
    existing = find_running()
    if existing:
        if not no_browser:
            open_app_window(f"http://127.0.0.1:{existing}/")
        logger.info("Jau veikia, atidarau programos langą (%s)", existing)
        return
    load_projects()
    primary_project = Path(DB_PATH).resolve() == (DATA_DIR / "app.db").resolve()
    init_db(seed_content=primary_project)
    load_projects()
    for _p in PROJECTS_STATE.get("projects") or []:
        try:
            _path = project_db_path(_p)
            if _path.exists():
                migrate_db(_path)
        except Exception:
            logger.warning("Nepavyko atnaujinti projekto #%s schemos: %s",
                           _p.get("id"), traceback.format_exc())
    auto_backup()
    scan_event.set()
    threading.Thread(target=scanner_loop, daemon=True, name="scanner").start()
    threading.Thread(target=indexer_loop, daemon=True, name="indexer").start()
    port = None
    server = None
    for candidate in range(free_port(), 8776):
        try:
            server = ThreadingHTTPServer((BIND_HOST, candidate), Handler)
            server.daemon_threads = True
            port = candidate
            break
        except OSError:
            continue
    if not server:
        logger.error("Nepavyko užimti prievado")
        return
    logger.info("%s %s paleistas: http://127.0.0.1:%s", APP_NAME, VERSION, port)
    if LAN_ENABLED:
        for url in network_info(port)["lan"]:
            logger.info("Tinkle: %s (kodas: %s)", url, lan_code())
    if not no_browser:
        threading.Timer(0.7, lambda: open_app_window(f"http://127.0.0.1:{port}/")).start()
    threading.Thread(target=update_auto_worker, daemon=True, name="updater").start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
