Option Explicit
Dim sh, fso, base, q
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = base
q = Chr(34)
sh.Run q & base & "\start.vbs" & q, 0, False
