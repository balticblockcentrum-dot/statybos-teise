param(
  [Parameter(Mandatory = $true)][string]$Path,
  [Parameter(Mandatory = $true)][string]$OutFile
)
$ErrorActionPreference = 'Stop'
$Path = [System.IO.Path]::GetFullPath($Path.Replace('/', '\'))
$OutFile = [System.IO.Path]::GetFullPath($OutFile.Replace('/', '\'))
$word = $null
try {
  $word = New-Object -ComObject Word.Application
  $word.Visible = $false
  $word.DisplayAlerts = 0
  try { $word.AutomationSecurity = 3 } catch { }
  $doc = $word.Documents.Open($Path, $false, $true, $false)
  try {
    $text = $doc.Content.Text
  } finally {
    $doc.Close($false)
  }
  [System.IO.File]::WriteAllText($OutFile, $text, (New-Object System.Text.UTF8Encoding($false)))
  exit 0
} catch {
  [Console]::Error.WriteLine($_.Exception.Message)
  exit 1
} finally {
  if ($word) { try { $word.Quit() } catch { } }
}
