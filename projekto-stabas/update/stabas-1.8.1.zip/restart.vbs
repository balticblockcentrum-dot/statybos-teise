Option Explicit
' Palaukia, kol senoji programa išsijungs, tada paleidžia naują versiją.
Dim sh, fso, base, i, ready, http
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = base
ready = False
For i = 1 To 80
    On Error Resume Next
    Set http = CreateObject("MSXML2.XMLHTTP")
    http.Open "GET", "http://127.0.0.1:8765/api/ping", False
    http.Send
    If Err.Number <> 0 Then
        ready = True
        Err.Clear
    ElseIf http.Status <> 200 Then
        ready = True
    End If
    On Error GoTo 0
    If ready Then Exit For
    WScript.Sleep 250
Next
If Not ready Then WScript.Quit 0
WScript.Sleep 700
sh.Run Chr(34) & base & "\start.vbs" & Chr(34), 0, False
