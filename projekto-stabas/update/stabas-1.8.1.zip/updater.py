# -*- coding: utf-8 -*-
"""Projekto Štabas automatiniai atnaujinimai.

Veikia tik tada, kai yra internetas. Be interneto programa paleidžiama įprastai
ir nieko nelaukia. Atnaujinimo paketas tikrinamas pagal SHA-256, o duomenų
katalogas (data/) niekada neperrašomas.
"""

import hashlib
import json
import os
import shutil
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

DEFAULT_REPO = "balticblockcentrum-dot/statybos-teise"
DEFAULT_MANIFEST_PATH = "projekto-stabas/update/manifest.json"
USER_AGENT = "ProjektoStabas-Updater/1.0"
MAX_ZIP_BYTES = 90 * 1024 * 1024
PROTECTED_TOP = {"data", ".git", "__pycache__", "backups"}


def version_tuple(value):
    parts = []
    for chunk in str(value or "").replace("-", ".").split("."):
        try:
            parts.append(int(chunk))
        except ValueError:
            parts.append(0)
    while len(parts) < 4:
        parts.append(0)
    return tuple(parts[:4])


def is_newer(remote, current):
    return version_tuple(remote) > version_tuple(current)


def _repo():
    return os.environ.get("STABAS_UPDATE_REPO") or DEFAULT_REPO


def _manifest_path():
    return (os.environ.get("STABAS_UPDATE_PATH") or DEFAULT_MANIFEST_PATH).lstrip("/")


def _manifest_urls():
    repo = _repo()
    urls = [f"https://raw.githubusercontent.com/{repo}/main/{_manifest_path()}"]
    env = os.environ.get("STABAS_UPDATE_MANIFEST")
    if env:
        urls.insert(0, env)
    return urls


def _get_json(url, timeout=6):
    req = urllib.request.Request(url, headers={
        "User-Agent": USER_AGENT,
        "Accept": "application/json",
        "Cache-Control": "no-cache",
    })
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read(1024 * 512)
    return json.loads(raw.decode("utf-8"))


def _resolve_asset(url, base=None):
    url = str(url or "").strip()
    if url.startswith("http://") or url.startswith("https://"):
        return url
    if url.startswith("file://"):
        if os.environ.get("STABAS_UPDATE_TEST") == "1":
            return url
        raise ValueError("Neteisinga atnaujinimo nuoroda")
    rel = url.lstrip("/")
    if base:
        return base.rstrip("/") + "/" + rel
    return f"https://raw.githubusercontent.com/{_repo()}/main/{rel}"


def check(current_version, timeout=6):
    """Grąžina manifestą, jei yra naujesnė versija, kitu atveju None."""
    last_error = ""
    for url in _manifest_urls():
        try:
            data = _get_json(url, timeout=timeout)
        except urllib.error.HTTPError as exc:
            last_error = ("Atnaujinimų serveris dar nepaskelbtas" if exc.code == 404
                          else f"Atnaujinimų serverio klaida ({exc.code})")
            continue
        except Exception:
            last_error = "Nepavyko pasiekti atnaujinimų serverio – patikrinkite internetą"
            continue
        version = str(data.get("version") or "").strip()
        if not version:
            last_error = "Manifeste nėra versijos"
            continue
        manifest = {
            "version": version,
            "url": _resolve_asset(data.get("url"), url.rsplit("/", 1)[0] + "/"),
            "sha256": str(data.get("sha256") or "").strip().lower(),
            "notes": str(data.get("notes") or ""),
            "date": str(data.get("date") or ""),
            "repo": _repo(),
        }
        if not is_newer(version, current_version):
            return {"up_to_date": True, "manifest": manifest, "latest": version}
        if not manifest["sha256"]:
            last_error = "Manifeste nėra SHA-256"
            continue
        return {"up_to_date": False, "manifest": manifest, "latest": version}
    return {"up_to_date": None, "error": last_error or "Nepavyko pasiekti atnaujinimų serverio"}


def _safe_members(zf):
    base = None
    for info in zf.infolist():
        name = info.filename.replace("\\", "/")
        if name.endswith("/"):
            continue
        if name.startswith("/") or ".." in Path(name).parts:
            raise ValueError("Neteisingas atnaujinimo paketo failo kelias")
        parts = Path(name).parts
        if not parts or parts[0].lower() in PROTECTED_TOP:
            continue
        if base is None:
            base = parts[0]
        yield info, Path(name)


def apply_update(manifest, base_dir):
    """Atsiunčia, patikrina ir įdiegia naują versiją. Grąžina įdiegtų failų skaičių."""
    url = _resolve_asset(manifest.get("url"))
    expected = str(manifest.get("sha256") or "").lower()
    if not expected:
        raise ValueError("Atnaujinimo paketas nepatikrintas (nėra SHA-256)")
    base_dir = Path(base_dir)
    update_dir = base_dir / "data" / "updates"
    update_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    archive = update_dir / f"stabas-{stamp}.zip"
    staging = update_dir / f"staging-{stamp}"
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    digest = hashlib.sha256()
    total = 0
    try:
        with urllib.request.urlopen(req, timeout=60) as resp, open(archive, "wb") as fh:
            while True:
                chunk = resp.read(256 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_ZIP_BYTES:
                    raise ValueError("Atnaujinimo paketas per didelis")
                digest.update(chunk)
                fh.write(chunk)
        if digest.hexdigest().lower() != expected:
            raise ValueError("Atnaujinimo paketo SHA-256 nesutampa – atnaujinimas atšauktas")
        staging.mkdir(parents=True, exist_ok=True)
        copied = 0
        with zipfile.ZipFile(archive) as zf:
            for info, rel in _safe_members(zf):
                target = staging / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as src, open(target, "wb") as dst:
                    shutil.copyfileobj(src, dst)
        for src in sorted(staging.rglob("*")):
            if not src.is_file():
                continue
            rel = src.relative_to(staging)
            if rel.parts and rel.parts[0].lower() in PROTECTED_TOP:
                continue
            dst = base_dir / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            tmp = dst.with_name(dst.name + ".update-tmp")
            shutil.copy2(src, tmp)
            os.replace(tmp, dst)
            copied += 1
        state = {
            "version": str(manifest.get("version") or ""),
            "installed": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "files": copied,
        }
        (base_dir / "data" / "update_state.json").write_text(
            json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
        return copied
    finally:
        try:
            archive.unlink(missing_ok=True)
        except OSError:
            pass
        shutil.rmtree(staging, ignore_errors=True)


def installed_state(base_dir):
    try:
        return json.loads((Path(base_dir) / "data" / "update_state.json").read_text(encoding="utf-8"))
    except Exception:
        return {}
