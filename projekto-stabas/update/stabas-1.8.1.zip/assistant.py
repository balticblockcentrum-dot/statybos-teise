"""Padėjėjas: atsako kur yra dokumentas, kaip jį rasti ir ką daryti."""

import re
import unicodedata

STOP_TOKENS = {
    "kur", "yra", "rasti", "rast", "kaip", "kas", "kada", "kodel", "ar", "man",
    "reikia", "reik", "apie", "tai", "cia", "ten", "gal", "galima", "padaryti",
    "padaryt", "daryti", "daryt", "gauti", "gaut", "butu", "but", "kad", "ir",
    "su", "i", "iki", "nuo", "uz", "ant", "del", "per", "po", "tada", "turetu",
    "turi", "turiu", "noriu", "noret", "noreciau", "parodyk", "rodyk", "papasakok",
    "paaiskink", "duok", "padek", "padekit", "padeti", "klausimas", "klausim",
    "informacij", "informacija", "dokument", "dokumentas", "dokumentai", "fail",
    "failas", "failai", "projekt", "projektas", "projekte", "siame", "sitas",
    "toks", "vel", "dar", "jau", "viska", "viskas", "koki", "kokie", "kokia",
    "kuris", "kuri", "kuriame", "kokiame", "padėk", "padėti", "noriu",
}

WHERE_PHRASES = (
    "kur yra", "kur saug", "kur paziur", "kur rast", "kur iesk", "kur galima rast",
    "kuriame", "kokiame", "kataloge", "kuriame faile", "kur deti", "kur dedam",
)
HOW_VERBS = (
    "kaip", "zingsn", "proces", "padaryt", "padaryti", "gauti", "gaut ", "uzbaig",
    "pradet", "pradeti", "iregistr", "derint", "derinti", "paruost", "sutvark",
    "atlikt", "priduot", "priimt", "pildyt", "pildom", "rengt", "rengti",
)

DEFAULT_SUGGESTIONS = [
    "Ką daryti šiandien?",
    "Kas vėluoja?",
    "Kur yra statybos leidimas?",
    "Kaip užbaigti statybą?",
    "Kas yra projektuotojas?",
    "Kur NT registro dokumentai?",
    "Kaip rasti dokumentą pagal tekstą?",
]

GUIDES = [
    {
        "id": "statybos-leidimas",
        "title": "Statybos leidimas ir jo pakeitimai",
        "ask": "Kaip patikrinti statybos leidimą?",
        "lead": "Statybos leidimas leidžia vykdyti darbus pagal patvirtintą projektą. Jį, priedus ir sąlygas saugokite SLD dalyje.",
        "tip": "Leidimo ieškokite SLD dalyje. Šiame projekte leidimas išduotas 2024-03-27, Nr. LSNS-72-240327-00012.",
        "keys": ["statybos leidim", "leidim statyt", "gauti leidim", "leidimo numer", "leidim galioj", "prates"],
        "doc_terms": "statybos leidimas LSNS",
        "related_discs": ["SLD"],
        "prefer_disc": "SLD",
        "steps": [
            ("Patikrinkite leidimo galiojimą ir priedus", "Leidimas, priedai ir sąlygos – SLD dalyje. Patikrinkite objektą, adresą ir galiojimo laiką."),
            ("Palyginkite leidimo rodiklius su projektu", "Užstatymo plotas, aukštis, butų skaičius ir prisijungimai turi sutapti su architektūros bei konstrukcijų dalimis."),
            ("Jei sprendiniai keičiasi – koreguokite projektą", "Projektuotojas parengia koreguotą dokumentaciją, ji derinama ta pačia tvarka kaip pirminė."),
            ("Pakeitimą įforminkite savivaldybėje arba SPS", "Leidimo pakeitimas ar pratęsimas atliekamas per Statybos leidimų sistemą arba savivaldybės administraciją."),
            ("Naują redakciją įkelkite į SLD katalogą", "Po pakeitimo paspauskite „Atnaujinti failus“ – registras atsinaujins automatiškai."),
        ],
        "links": [("Statybos leidimų sistema (SPS)", "https://www.statybosleidimai.lt")],
    },
    {
        "id": "statybos-uzbaigimas",
        "title": "Statybos užbaigimas ir priėmimas",
        "ask": "Kaip užbaigti statybą ir priimti pastatą?",
        "lead": "Užbaigimas apima trūkumų šalinimą, kadastrinius matavimus, energetinį sertifikatą, užbaigimo deklaraciją ir registro atnaujinimą.",
        "tip": "Užbaigimo dokumentus kaupkite SLD ir NTR dalyse, o eigą – kontroliniame sąraše (6 etapas).",
        "keys": ["uzbaig", "pabaig", "priemim", "priimt", "deklaracij", "kadastrin", "naudojimo prad", "iregistruot pastat", "uzbaigti statyb", "statybos uzbaig", "priimti pastat", "baigtumo deklarac"],
        "doc_terms": "statybos užbaigimas kadastriniai matavimai",
        "related_discs": ["SLD", "NTR"],
        "stage": "6. Užbaigimas",
        "steps": [
            ("Užbaikite darbus ir pašalinkite trūkumus", "Trūkumus fiksuokite žurnale, kiekvienam skirti terminą ir atsakingą."),
            ("Užsakykite kadastrinius matavimus", "Matavimus atlieka kvalifikuotas matininkas; gausite kadastrinių matavimų bylą."),
            ("Užsakykite energetinio naudingumo sertifikatą", "Sertifikatą rengia sertifikuotas energetikas pagal baigtą pastatą."),
            ("Pateikite statybos užbaigimo deklaraciją", "Deklaracija teikiama per SPS arba savivaldybei pagal leidimo sąlygas."),
            ("Surinkite priėmimo dokumentus", "Sutartys, darbų žurnalas, tarpiniai aktai, sertifikatai, matavimų byla – viename kataloge."),
            ("Atnaujinkite NT registro duomenis", "Po priėmimo įregistruokite baigtą statinį ir įkelkite išrašą į NTR katalogą."),
        ],
        "links": [
            ("Registrų centras", "https://www.registrucentras.lt"),
            ("Statybos leidimų sistema (SPS)", "https://www.statybosleidimai.lt"),
        ],
    },
    {
        "id": "nt-registras",
        "title": "Nekilnojamojo turto registro duomenys",
        "ask": "Kur NT registro išrašas ir ką su juo daryti?",
        "lead": "NT registro išrašas patvirtina sklypo ar pastato duomenis. Jį naudokite tikrindami projektą ir po statybos užbaigimo.",
        "tip": "Išrašus ir brėžinius ieškokite NTR dalyje („NTR — Nekilnojamojo turto registras“).",
        "keys": ["nt registr", "registro isras", "registru centre", "kadastr", "nekilnojam", "registro duomen", "unikalus numer"],
        "doc_terms": "NT registras registro išrašas",
        "related_discs": ["NTR"],
        "prefer_disc": "NTR",
        "steps": [
            ("Patikrinkite esamą išrašą", "NTR dalyje raskite naujausią išrašą ir įsitikinkite, kad jis skirtas būtent šiam objektui."),
            ("Palyginkite duomenis su projektu", "Unikalus numeris, plotas, paskirtis ir adresas turi sutapti su BD ir SA dalimis."),
            ("Prireikus užsakykite naują išrašą", "Naujausią išrašą galima gauti Registrų centre arba per savitarną."),
            ("Po statybos atnaujinkite duomenis", "Atlikus kadastrinius matavimus įregistruojamas baigtas statinys, tada atnaujinamas išrašas."),
            ("Įkelkite dokumentus į NTR katalogą", "Pavadinimuose nurodykite datą, kad naujausias failas būtų lengvai atpažįstamas."),
        ],
        "links": [("Registrų centras", "https://www.registrucentras.lt")],
    },
    {
        "id": "projekto-derinimas",
        "title": "Projekto dalių derinimas",
        "ask": "Kaip suderinti projekto dalis?",
        "lead": "Derinimas – tai visų dalių tarpusavio patikra ir suderinimas su savivaldybe, tinklų savininkais bei trečiaisiais asmenimis.",
        "tip": "Suderintą dokumentaciją ieškokite pagal pavadinime esantį „suderinta“ arba datą.",
        "keys": ["derinim", "derint", "ekspertiz", "suderin", "tarpdisciplin", "kolizij"],
        "doc_terms": "suderinta derinimas",
        "stage": "3. Derinimas ir leidimai",
        "steps": [
            ("Surinkite visas projekto dalis", "BD, SP, SA, SK, E, ET, ŠVOK, VN, LVN, TOPO – kiekvienai dalei turi būti galutinė redakcija."),
            ("Atlikite tarpdisciplininę patikrą", "Tikrinkite angas, praėjimus, tinklų trasas ir kolizijas tarp konstrukcijų bei inžinerinių dalių."),
            ("Suderinkite su tinklų savininkais", "Elektros, vandens, nuotekų ir ryšių operatoriai išduoda sąlygas bei derina sprendinius."),
            ("Pateikite derinti savivaldybei", "Jei reikalinga – organizuokite ekspertizę ir atsakykite į pastabas."),
            ("Užfiksuokite pastabas žurnale", "Kiekvieną pastabą veskite kaip atskirą įrašą su terminu ir atsakingu projektuotoju."),
            ("Įkelkite galutinę suderintą redakciją", "Pažymėkite datą ir versiją; senas versijas laikykite atskirame archyvo kataloge."),
        ],
    },
    {
        "id": "statybos-pradzia",
        "title": "Statybos pradžia",
        "ask": "Ką reikia padaryti prieš pradedant statybą?",
        "lead": "Prieš pradedant darbus turi būti sutvarkyti leidimai, sutartys, techninė priežiūra ir statybos žurnalas.",
        "tip": "Pradžios dokumentus ir deklaraciją saugokite SLD dalyje, sutartis – BD arba atskirame sutarčių kataloge.",
        "keys": ["statybos pradz", "pradet statyb", "pradeti statyb", "pradzios deklarac", "aiksteles perdav", "rangovo sutart", "pradesim"],
        "doc_terms": "statybos pradžia rangos sutartis",
        "related_discs": ["SLD"],
        "stage": "5. Statyba",
        "steps": [
            ("Patikrinkite statybos leidimą", "Leidimas turi galioti, o projekto rodikliai – atitikti leidimą."),
            ("Pasirašykite rangos sutartį", "Sutartyje nurodykite apimtį, grafiką, kainą, mokėjimus, garantijas ir atsakomybes."),
            ("Paskirkite techninį prižiūrėtoją", "Techninė priežiūra turi būti nepriklausoma nuo rangovo; sutartis pasirašoma prieš darbus."),
            ("Užveskite statybos darbų žurnalą", "Žurnalas pildomas visą statybą; jame fiksuojami darbai, patikrinimai ir nukrypimai."),
            ("Pateikite statybos pradžios deklaraciją", "Deklaracija teikiama per SPS arba savivaldybei, kaip nurodyta leidime."),
            ("Perduokite aikštelę ir nufotografuokite būklę", "Fotofiksacija padeda išspręsti ginčus dėl esamos būklės."),
        ],
        "links": [("Statybos leidimų sistema (SPS)", "https://www.statybosleidimai.lt")],
    },
    {
        "id": "technine-prieziura",
        "title": "Statybos techninė priežiūra",
        "ask": "Kaip organizuoti techninę priežiūrą?",
        "lead": "Techninis prižiūrėtojas kontroliuoja, ar darbai atliekami pagal projektą ir normatyvus, bei pasirašo tarpinius aktus.",
        "tip": "Priežiūros sutartį ir aktus laikykite kartu su statybos dokumentais.",
        "keys": ["technin priziur", "priziuret", "statybos darbu zurnal", "darbu zurnal", "prieziuros sutart"],
        "doc_terms": "techninė priežiūra statybos darbų žurnalas",
        "related_discs": ["SLD"],
        "stage": "5. Statyba",
        "steps": [
            ("Pasirinkite techninį prižiūrėtoją", "Turi būti atestuotas specialistas, nepriklausomas nuo rangovo."),
            ("Pasirašykite priežiūros sutartį", "Nurodykite objektą, priežiūros apimtį, apsilankymų dažnį ir atsakomybes."),
            ("Sudarykite priežiūros planą", "Suplanuokite, kuriuos darbų etapus būtina patikrinti prieš juos uždengiant."),
            ("Veskite statybos darbų žurnalą", "Fiksuokite kasdienius darbus, medžiagas, patikrinimus ir nukrypimus."),
            ("Pasirašykite tarpinius aktus", "Užbaigtus darbus priimkite etapais – tai padeda kontroliuoti mokėjimus."),
            ("Užbaikite priežiūrą baigtumo aktu", "Baigtumo aktas reikalingas statybos užbaigimo procedūroms."),
        ],
    },
    {
        "id": "rfi",
        "title": "Klausimai projektuotojams (RFI)",
        "ask": "Kaip teisingai užduoti klausimą projektuotojui?",
        "lead": "Kiekvieną neaiškumą ar projekto klaidą fiksuokite žurnale – taip klausimas nepasimes ir turėsite atsakymo istoriją.",
        "tip": "Klausimus ir atsakymus registruokite „Žurnale“: tipas RFI, dalis, terminas, atsakingas.",
        "keys": ["rfi", "klausim projektuotoj", "atsakym", "nesuderinim", "klaida projekte"],
        "doc_terms": "RFI klausimas projektuotojui",
        "related_discs": [],
        "steps": [
            ("Užfiksuokite klausimą žurnale", "Pasirinkite tipą RFI, nurodykite projekto dalį ir prioritetą."),
            ("Pridėkite tikslią vietą", "Nurodykite brėžinio lapą, mazgą ar dokumento punktą – kuo tiksliau, tuo greitesnis atsakymas."),
            ("Priskirkite terminą ir atsakingą", "Atsakingas – projektuotojas arba rangovas, atsakantis už sprendimą."),
            ("Išsiųskite klausimą", "Prisekite ištrauką ar nuotrauką; fiksuokite išsiuntimo datą."),
            ("Įkelkite atsakymą į dokumentus", "Atsakymą saugokite prie projekto dalies, o žurnale įrašą uždarykite."),
        ],
    },
    {
        "id": "rangovas",
        "title": "Rangovas ir sutarties kontrolė",
        "ask": "Kaip sudaryti ir kontroliuoti rangos sutartį?",
        "lead": "Rangos sutartis turi aiškiai apibrėžti apimtį, kainą, grafiką, mokėjimus ir atsakomybes.",
        "tip": "Sutartis, sąmatos ir priedai – atskirame sutarčių kataloge arba BD dalyje.",
        "keys": ["rangov", "sutart su", "sutartis", "darbu apimt", "samat", "biudzet", "mokejim"],
        "doc_terms": "rangos sutartis sąmata",
        "related_discs": [],
        "stage": "4. Pirkimai ir sutartys",
        "steps": [
            ("Apibrėžkite darbų apimtį", "Remkitės projekto dalimis ir kiekių žiniaraščiais; skaičiuokite pagal galutinę redakciją."),
            ("Parengkite grafiką ir mokėjimų tvarką", "Mokėjimus susiekite su etapais arba tarpiniais aktais, ne tik su datomis."),
            ("Nustatykite kainos kitimo ir priedų tvarką", "Papildomi darbai turi būti įforminami raštu prieš juos atliekant."),
            ("Sutarkite garantijas ir trūkumų šalinimą", "Nurodykite garantinį laikotarpį ir reagavimo į trūkumus terminus."),
            ("Kontroliuokite eigą kas savaitę", "Savaitiniuose susitikimuose lyginkite faktą su grafiku ir fiksuokite sprendimus."),
        ],
    },
    {
        "id": "inzineriniai-tinklai",
        "title": "Prisijungimas prie inžinerinių tinklų",
        "ask": "Kaip gauti prisijungimo prie tinklų sąlygas?",
        "lead": "Prisijungimui reikia operatoriaus techninių sąlygų, suderinto projekto ir sutarties su tinklų savininku.",
        "tip": "Sąlygas, sutartis ir derinimo raštus ieškokite ET, VN ir LVN dalyse.",
        "keys": ["prisijungim", "tinklu", "tinkla", "operator", "elektros tinkl", "vandentiek", "nuotek"],
        "doc_terms": "techninės sąlygos prisijungimas",
        "related_discs": ["ET", "VN", "LVN"],
        "steps": [
            ("Nustatykite reikalingus pajėgumus", "Elektros galia, vandens ir nuotekų kiekiai – pagal projektą ir pastato paskirtį."),
            ("Gaukite technines sąlygas", "Kreipkitės į elektros, vandens, nuotekų ir ryšių operatorius; sąlygos turi būti galiojančios."),
            ("Suprojektuokite prisijungimus", "ET, VN ir LVN dalys turi atitikti išduotas sąlygas ir operatoriaus reikalavimus."),
            ("Suderinkite su operatoriumi", "Pateikite projektą derinti ir gausite derinimo raštą."),
            ("Pasirašykite prisijungimo sutartį", "Sutartyje nurodomi pajėgumai, įrengimo terminai ir mokesčiai."),
            ("Priimkite tinklus ir įkelkite aktus", "Po darbų gausite priėmimo aktus – saugokite juos kartu su projekto dokumentais."),
        ],
    },
    {
        "id": "geodezija",
        "title": "Topografija ir geodeziniai matavimai",
        "ask": "Kur topografija ir kam jos reikia?",
        "lead": "Topografinė nuotrauka reikalinga projektavimui, o geodeziniai matavimai – statybos eigai ir užbaigimui.",
        "tip": "Topografiją, suderintus brėžinius ir matavimų bylas ieškokite TOPO dalyje.",
        "keys": ["topograf", "geodez", "nuotrauk", "matavim", "tras"],
        "doc_terms": "topografinė nuotrauka geodeziniai matavimai",
        "related_discs": ["TOPO"],
        "stage": "1. Parengiamieji darbai",
        "steps": [
            ("Užsakykite topografinę nuotrauką", "Ji turi būti aktuali ir apimti sklypą bei gretimas teritorijas."),
            ("Patikrinkite tinklų ir ribų duomenis", "Nuotraukoje turi būti inžineriniai tinklai, sklypo ribos ir reljefas."),
            ("Suplanuokite geodezinius matavimus statybos metu", "Nužymėjimas, ašių išdėstymas ir aukščių kontrolė."),
            ("Užsakykite kontrolinius matavimus", "Prieš dengiant konstrukcijas patikrinamos ašys ir aukščiai."),
            ("Užsakykite kadastrinius matavimus", "Baigus statybą – matavimų byla registro duomenims atnaujinti."),
        ],
    },
    {
        "id": "energija",
        "title": "Energetinio naudingumo sertifikatas",
        "ask": "Kaip gauti energetinio naudingumo sertifikatą?",
        "lead": "Sertifikatas reikalingas statybos užbaigimui ir pastato registro duomenims. Jį rengia sertifikuotas energetikas.",
        "tip": "Sertifikatą ir skaičiavimus ieškokite ŠVOK arba SA dalyse; ieškokite pagal žodį „sertifikatas“.",
        "keys": ["energetin", "naudingumo", "sertifikat", "energijos"],
        "doc_terms": "energetinio naudingumo sertifikatas",
        "related_discs": ["ŠVOK"],
        "stage": "6. Užbaigimas",
        "steps": [
            ("Surinkite pastato duomenis", "Plotai, atitvarų konstrukcijos, inžinerinės sistemos – pagal baigtą projektą."),
            ("Užsakykite sertifikatą", "Kreipkitės į sertifikuotą energetinio naudingumo specialistą."),
            ("Pateikite ŠVOK sprendinius", "Šildymo, vėdinimo ir karšto vandens sistemos turi atitikti projekto sprendinius."),
            ("Patikrinkite sertifikato duomenis", "Sertifikate nurodytas adresas ir plotai turi sutapti su kadastriniais duomenimis."),
            ("Įkelkite sertifikatą į dokumentus", "Saugokite kartu su užbaigimo dokumentais."),
        ],
    },
    {
        "id": "komplektiskumas",
        "title": "Projekto dalių komplektiškumo patikra",
        "ask": "Kaip patikrinti, ar visos projekto dalys sukomplektuotos?",
        "lead": "Kiekviena dalis turi turėti galutinę redakciją, brėžinius, aiškinamuosius raštus ir suderinimus. Programoje dalys sugrupuotos pagal kodus.",
        "tip": "Dokumentų registre filtruokite pagal dalį ir tipą, o trūkstamus failus įkelkite į atitinkamą katalogą.",
        "keys": ["komplektisk", "trukstam", "kokiu dokument", "visos dalys", "patikrint dokument"],
        "doc_terms": "projekto dalys brėžiniai",
        "related_discs": [],
        "steps": [
            ("Patikrinkite BD dalį", "Titulinis lapas, bendrieji rodikliai, aiškinamasis raštas, sąrašai."),
            ("Patikrinkite SP ir SA", "Sklypo planas, sutvarkymas, architektūros brėžiniai ir specifikacijos."),
            ("Patikrinkite SK", "Konstrukcijų schemos, pamatai, perdangos, mazgai ir skaičiavimai."),
            ("Patikrinkite inžinerines dalis", "E, ET, ŠVOK, VN, LVN, TOPO – brėžiniai, schemos ir suderinimai."),
            ("Patikrinkite NTR ir SLD", "Registro išrašai, leidimas, jo priedai ir sąlygos."),
            ("Įkelkite trūkstamus failus", "Sudėkite į tinkamą katalogą ir paspauskite „Atnaujinti failus“."),
        ],
    },
    {
        "id": "dokumentu-ikelimas",
        "title": "Kaip įkelti ir rasti dokumentą programoje",
        "ask": "Kaip įkelti naują dokumentą?",
        "lead": "Programa nekeičia failų – ji skaito nurodytus katalogus. Naują failą tiesiog įdėkite į atitinkamos dalies aplanką.",
        "tip": "Katalogus galima keisti „Nustatymuose“. Po įkėlimo paspauskite „Atnaujinti failus“.",
        "keys": ["naudot program", "naudotis", "pagalba", "kaip rast", "rasti dokument", "rast dokument", "ieskot dokument", "paiesk", "filtruot", "ctrl", "atnaujint fail", "nuskenuot", "ikelt"],
        "steps": [
            ("Įdėkite failą į dalies katalogą", "Pvz., naują architektūros brėžinį – į SA katalogą."),
            ("Paspauskite „Atnaujinti failus“", "Šoninėje juostoje arba Nustatymuose. Skenavimas trunka kelias sekundes."),
            ("Raskite dokumentą registre", "Filtruokite pagal pavadinimą, dalį ar tipą; spustelėkite eilutę peržiūrai."),
            ("Ieškokite tekste", "Spauskite Ctrl+K arba atidarykite „Paiešką“ – veikia ir be diakritikų."),
            ("Peržiūrėkite PDF lapus", "Modalyje įveskite lapo numerį ir spauskite „Eiti į lapą“."),
        ],
    },
    {
        "id": "eiga",
        "title": "Kaip sekti darbų eigą",
        "ask": "Kaip sekti projekto eigą?",
        "lead": "Eigą sudaro trys dalys: užduotys su terminais, žurnalo klausimai ir etapų kontrolinis sąrašas.",
        "tip": "Kasdien užtenka pažiūrėti „Apžvalgą“ – joje rodoma, kam reikia dėmesio.",
        "keys": ["eiga", "projekto eiga", "darbu eiga", "grafik", "aveluoj", "termin", "sekt", "kontrole", "ataskait"],
        "steps": [
            ("Užduotis veskite lentoje", "Kiekvienai užduočiai – terminas, prioritetas ir atsakingas."),
            ("Klausimus veskite žurnale", "RFI, kliūtys ir pastabos su terminais bei būsenomis."),
            ("Žymėkite etapų punktus", "Kontroliniame sąraše pažymėkite atliktus darbus – matysite bendrą eigą."),
            ("Kas savaitę peržiūrėkite apžvalgą", "„Reikia dėmesio“ sąraše matomi vėluojantys ir artėjantys terminai."),
            ("Eksportuokite ataskaitas", "CSV mygtukai yra dokumentų, žurnalo ir kontrolinio sąrašo puslapiuose."),
        ],
    },
]

PROJECT_FACT_WORDS = (
    "statytoj", "uzsakov", "projektuotoj", "projekto numer", "projekto rekvizit",
    "projekto stadij", "projekto etap", "permit", "adres",
)


def norm(text):
    s = unicodedata.normalize("NFKD", (text or "").lower())
    return "".join(ch for ch in s if not unicodedata.combining(ch))


def tokens(qn):
    return [t for t in re.findall(r"[a-z0-9]+", qn) if len(t) >= 2 and t not in STOP_TOKENS]


def _pick_guide(qn):
    best = None
    best_score = 0.0
    for guide in GUIDES:
        score = 0.0
        for key in guide["keys"]:
            if key in qn:
                score += 2.0 + len(key) / 8.0
        if score > best_score:
            best, best_score = guide, score
    return (best, best_score) if best_score >= 2.6 else (None, best_score)


def _disciplines(qn):
    out = set()
    if "elektros tinkl" in qn:
        out.add("ET")
    elif "elektr" in qn or "apsviet" in qn:
        out.add("E")
    if any(w in qn for w in ("sildym", "vedinim", "kondicionav")) or re.search(r"\bsvok\b", qn):
        out.add("ŠVOK")
    if "lauko" in qn and ("vandentiek" in qn or "nuotek" in qn):
        out.add("LVN")
    elif "vandentiek" in qn or "nuotek" in qn:
        out.add("VN")
    if "konstruk" in qn or re.search(r"\bsk\b", qn):
        out.add("SK")
    if "architekt" in qn or re.search(r"\bsa\b", qn):
        out.add("SA")
    if any(w in qn for w in ("topograf", "geodez")) or re.search(r"\btopo\b", qn):
        out.add("TOPO")
    if any(w in qn for w in ("nekilnojam", "kadastr", "nt registr")) or re.search(r"\bntr\b", qn):
        out.add("NTR")
    if "statybos leidim" in qn or re.search(r"\bsld\b", qn):
        out.add("SLD")
    if "sklyp" in qn or re.search(r"\bsp\b", qn):
        out.add("SP")
    if "bendr" in qn or re.search(r"\bbd\b", qn):
        out.add("BD")
    return out


def _entry(doc, match=""):
    return {
        "id": doc["id"],
        "name": doc["name"],
        "ext": doc["ext"],
        "disc": doc["disc"],
        "discName": doc["discName"],
        "rel": doc["rel"],
        "date": doc["date"],
        "pages": doc["pages"],
        "size": doc["size"],
        "hits": [],
        "match": match,
    }


def _find_docs(qn, ctx):
    toks = tokens(qn)
    docs_by_id = {d["id"]: d for d in ctx["docs"]}
    merged = {}
    queries = []
    if toks:
        queries.append(" ".join(toks))
        stems = [t[:max(4, len(t) - 2)] for t in toks]
        if stems != toks:
            queries.append(" ".join(stems))
    for query in queries:
        try:
            found = ctx["search"](query)
        except Exception:
            continue
        for doc in found.get("docs", []):
            merged.setdefault(doc["id"], _entry(doc, "name"))
        for hit in found.get("pages", []):
            entry = merged.get(hit["docId"])
            if entry is None:
                doc = docs_by_id.get(hit["docId"])
                if not doc:
                    continue
                entry = merged.setdefault(doc["id"], _entry(doc))
            if len(entry["hits"]) < 2 and hit.get("snippet"):
                entry["hits"].append({"page": hit["page"], "snippet": hit["snippet"]})

    compact_q = re.sub(r"[^a-z0-9]", "", qn)
    for doc in ctx["docs"]:
        if doc["id"] in merged:
            continue
        name = norm(doc["name"])
        compact_name = re.sub(r"[^a-z0-9]", "", name)
        matched = len(compact_q) >= 4 and compact_q in compact_name
        if not matched:
            matched = any(len(t) >= 5 and t[:5] in name for t in toks)
        if matched:
            merged[doc["id"]] = _entry(doc, "name")

    codes = _disciplines(qn)
    for doc in ctx["docs"]:
        if doc["disc"] in codes:
            entry = merged.setdefault(doc["id"], _entry(doc, "disc"))
            entry["discMatch"] = True

    items = sorted(
        merged.values(),
        key=lambda e: (
            e["match"] == "name",
            bool(e.get("discMatch")),
            len(e["hits"]),
            e["date"] or "",
        ),
        reverse=True,
    )
    return items[:6]


def _permit_facts(project):
    return [
        {"label": "Leidimo Nr.", "value": project.get("permit_no") or "—"},
        {"label": "Išdavimo data", "value": project.get("permit_date") or "—"},
        {"label": "Išdavė", "value": project.get("permit_authority") or "—"},
    ]


def _project_facts(project):
    return [
        {"label": "Projektas", "value": project.get("name") or "—"},
        {"label": "Adresas", "value": project.get("address") or "—"},
        {"label": "Statytojas", "value": project.get("client") or "—"},
        {"label": "Projektuotojas", "value": project.get("designer") or "—"},
        {"label": "Projekto Nr.", "value": project.get("project_no") or "—"},
        {"label": "Statybos leidimas", "value": project.get("permit_no") or "—"},
        {"label": "Stadija", "value": project.get("stage") or "—"},
    ]


def _related_checklist(qn, guide, ctx):
    toks = [t for t in tokens(qn) if len(t) >= 4]
    scored = []
    for item in ctx["checklist"]:
        title = norm(item["title"])
        score = sum(1 for t in toks if t[:5] in title)
        if score:
            scored.append((score, item))
    if not scored and guide and guide.get("stage"):
        scored = [(1, i) for i in ctx["checklist"] if i["stage"] == guide["stage"] and not i["done"]][:3]
    scored.sort(key=lambda pair: pair[0], reverse=True)
    return [
        {"id": i["id"], "stage": i["stage"], "title": i["title"], "done": bool(i["done"])}
        for _, i in scored[:4]
    ]


def _counts_answer(ctx, qn=""):
    counts = ctx["counts"]
    docs = ctx.get("docs") or []
    by_ext = {}
    texted_by_ext = {}
    for doc in docs:
        ext = (doc.get("ext") or "").lower()
        by_ext[ext] = by_ext.get(ext, 0) + 1
        if doc.get("textState") == "done":
            texted_by_ext[ext] = texted_by_ext.get(ext, 0) + 1
    leads = (
        (("brezin", "dwg"), ".dwg", "brėžiniai", "brėžinys", "brėžinius"),
        (("pdf",), ".pdf", "PDF failai", "PDF failas", "PDF failus"),
        (("docx", "word"), ".docx", "Word failai", "Word failas", "Word failus"),
        (("adoc",), ".adoc", "ADOC failai", "ADOC failas", "ADOC failus"),
        (("ifc",), ".ifc", "IFC failai", "IFC failas", "IFC failus"),
        (("txt",), ".txt", "TXT failai", "TXT failas", "TXT failus"),
    )
    chosen = None
    for keys, ext, label_plural, _one, _acc in leads:
        if any(k in qn for k in keys):
            chosen = (ext, label_plural, _one, _acc)
            break
    if chosen:
        ext, label_plural, one, acc = chosen
        n = by_ext.get(ext, 0)
        texted = texted_by_ext.get(ext, 0)
        lead = "Projekte yra %d %s." % (n, label_plural if n != 1 else one)
        if n and texted:
            lead += " Iš jų %d su ištrauktu tekstu." % texted
        return {
            "intent": "counts",
            "title": "Failų skaičiai",
            "lead": lead,
            "facts": [
                {"label": label_plural, "value": n},
                {"label": "Su ištrauktu tekstu", "value": texted},
                {"label": "Iš viso dokumentų", "value": counts["docCount"]},
                {"label": "Dalys su failais", "value": counts["discCount"]},
            ],
            "suggestions": ["Kiek dokumentų projekte?", "Kur yra statybos leidimas?", "Kaip rasti dokumentą pagal tekstą?"],
        }
    return {
        "intent": "counts",
        "title": "Projekto skaičiai",
        "lead": f"Šiuo metu sistemoje yra {counts['docCount']} dokumentai iš {counts['discCount']} dalių.",
        "facts": [
            {"label": "Dokumentai", "value": counts["docCount"]},
            {"label": "Dalys su failais", "value": counts["discCount"]},
            {"label": "Atviros užduotys", "value": counts["tasksOpen"]},
            {"label": "Vėluojančios užduotys", "value": counts["tasksOverdue"]},
            {"label": "Atviri žurnalo įrašai", "value": counts["issuesOpen"]},
            {"label": "Kontrolinio sąrašo liko", "value": counts["checklistOpen"]},
        ],
        "suggestions": ["Kur yra statybos leidimas?", "Ką daryti šiandien?", "Kas yra projektuotojas?"],
    }


def _where_answer(qn, guide, docs, ctx):
    project = ctx["project"]
    if guide and guide.get("prefer_disc"):
        preferred = guide["prefer_disc"]
        docs.sort(key=lambda d: d["disc"] == preferred, reverse=True)
    codes = _disciplines(qn)
    if codes:
        narrowed = [d for d in docs if d["disc"] in codes]
        if narrowed:
            docs = narrowed
    if docs:
        lead = f"Radau susijusių dokumentų: {len(docs)}. Spustelėkite kortelę – atsidarys peržiūra, o „Aplankas“ parodys vietą diske."
    elif guide:
        lead = "Tikslaus failo pagal šiuos žodžius neradau, bet žinau, kur tokie dokumentai paprastai laikomi."
    else:
        lead = "Tikslaus atitikmens dokumentuose neradau. Pabandykite konkretesnį pavadinimą arba dalies kodą (pvz., SA, SK, ŠVOK)."
    facts = []
    if guide and guide["id"] == "statybos-leidimas":
        facts = _permit_facts(project)
    result = {
        "intent": "where",
        "title": guide["title"] if guide else (docs[0]["name"] if docs else "Dokumento paieška"),
        "lead": lead,
        "docs": docs,
        "facts": facts,
        "suggestions": _suggestions_for(guide),
    }
    if guide:
        result["tip"] = guide.get("tip") or ""
    return result


def _how_answer(guide, docs, ctx):
    project = ctx["project"]
    result = {
        "intent": "how",
        "title": guide["title"],
        "lead": guide["lead"],
        "steps": [{"n": n + 1, "text": text, "hint": hint} for n, (text, hint) in enumerate(guide["steps"])],
        "docs": docs,
        "links": [{"label": label, "url": url} for label, url in guide.get("links", [])],
        "checklist": _related_checklist(norm(guide["title"] + " " + guide["ask"]), guide, ctx),
        "suggestions": _suggestions_for(guide),
    }
    if guide["id"] == "statybos-leidimas":
        result["facts"] = _permit_facts(project)
    if guide.get("tip"):
        result["tip"] = guide["tip"]
    return result


def _suggestions_for(guide):
    if not guide:
        return DEFAULT_SUGGESTIONS[:3]
    others = [g["ask"] for g in GUIDES if g["id"] != guide["id"]]
    return [guide["ask"]] + others[:2]


def _issue_label(row):
    try:
        return "P-%03d" % int(row.get("num") or 0)
    except (TypeError, ValueError):
        return "P-"


def _daily_items(ctx):
    att = ctx.get("attention") or {}
    items = []
    seen = set()

    def add(kind, row, tone, meta, badge):
        key = (kind, row.get("id"))
        if key in seen:
            return
        seen.add(key)
        items.append({
            "kind": kind,
            "id": row.get("id"),
            "title": row.get("title") or "—",
            "meta": meta,
            "tone": tone,
            "badge": badge,
        })

    for t in att.get("overdueTasks", []):
        add("task", t, "overdue", "Terminas %s · vėluoja" % (t.get("due") or "—"), "Vėluoja")
    for i in att.get("overdueIssues", []):
        add("issue", i, "overdue", "%s · terminas %s" % (_issue_label(i), i.get("due") or "—"), "Vėluoja")
    for i in att.get("urgentIssues", []):
        add("issue", i, "urgent", "%s · %s · %s" % (_issue_label(i), i.get("priority") or "—", i.get("disc") or "—"), "Skubu")
    for t in att.get("dueTasks", []):
        add("task", t, "soon", "Terminas %s · artėja" % (t.get("due") or "—"), "Artėja")
    return items[:6]


def _daily_intent(qn):
    keys = (
        "siandien", "dienotvark", "kas svarbu", "kas naujo", "kaip sekasi",
        "projekto status", "statusas", "kokia eiga", "projekto eiga", "darbu eiga",
        "veluoj", "artejant", "artimiaus",
    )
    if not any(k in qn for k in keys):
        return False
    if qn.startswith("kaip ") and "kaip sekasi" not in qn:
        return False
    return True


def _daily_answer(ctx):
    counts = ctx["counts"]
    items = _daily_items(ctx)
    if items:
        lead = "Šiandienos suvestinė. Žemiau – darbai ir klausimai, kuriems reikia dėmesio. Spustelėkite įrašą, kad atidarytumėte kortelę."
    else:
        lead = "Šiandien vėluojančių darbų ar kritinių klausimų nėra. Galite peržiūrėti artimiausius terminus arba dokumentus."
    return {
        "intent": "today",
        "title": "Šiandienos suvestinė",
        "lead": lead,
        "facts": [
            {"label": "Atviros užduotys", "value": counts.get("tasksOpen", 0)},
            {"label": "Vėluojančios užduotys", "value": counts.get("tasksOverdue", 0)},
            {"label": "Atviri klausimai", "value": counts.get("issuesOpen", 0)},
            {"label": "Kontrolinis liko", "value": counts.get("checklistOpen", 0)},
        ],
        "items": items,
        "tip": "Spustelėkite įrašą – atsidarys užduoties arba žurnalo įrašo kortelė." if items else "",
        "suggestions": ["Kokie artėjantys terminai?", "Kur yra statybos leidimas?", "Kaip užbaigti statybą?"],
    }


QUANT_QUESTION_WORDS = {
    "kiek", "koks", "kokia", "koki", "kokio", "kokiam", "kokiame", "kokie",
    "kokiu", "kiekis", "kieki", "kiekiai", "parodyk", "nurodyk", "surask",
}

QUANT_FAMILY_WORDS = {
    "area": ("kvadrat", "m2", "m²", "plotas", "plota", "ploto", "plotai", "plotu", "plote"),
    "volume": ("kub", "m3", "m³", "turis", "turio", "turi"),
    "length": ("metr", "ilg", "aukst", "aukšt", "plotis", "ploti", "stor", "skersmuo", "diametr"),
    "count": ("vnt", "vienet", "komplekt", "kiekis", "skaicius", "skaičius"),
    "currency": ("kain", "eur", "€", "biudzet", "biudžet", "samat", "sąmat", "vert"),
}

QUANT_SEARCH_ANCHORS = {
    "area": ("plotas", "ploto", "m2", "kvadrat"),
    "volume": ("turis", "turio", "m3", "kub"),
    "length": ("ilgis", "ilgio", "aukstis", "plotis", "metrai", "metru"),
    "count": ("vnt", "kiekis", "vienet"),
    "currency": ("kaina", "kainos", "eur", "samat", "sąmat"),
}

QUANT_NUM_RE = re.compile(
    r"(?<![\d.,])(\d{1,3}(?:[ \u00a0\u202f]\d{3})+(?:[.,]\d+)?"
    r"|\d{1,3}(?:\.\d{3})+(?:,\d+)?"
    r"|\d+(?:[.,]\d+)?)(?!\d)"
)

QUANT_UNIT_RES = (
    ("area", re.compile(r"\s*(?:m\s*[²2](?!\d)|kv\.?\s*m\.?|kvadrat\w*)", re.I), "m²"),
    ("volume", re.compile(r"\s*(?:m\s*[³3](?!\d)|kub\.?\s*m\.?|kub\w*)", re.I), "m³"),
    ("length", re.compile(r"\s*(?:mm|cm|m)(?![a-zà-ž0-9²³])", re.I), "m"),
    ("count", re.compile(r"\s*(?:vnt\.?|vienet\w*|kompl\.?|komplekt\w*)", re.I), "vnt"),
    ("percent", re.compile(r"\s*%"), "%"),
    ("currency", re.compile(r"\s*(?:€|eur(?:ų|u|ai|as|us)?\b)", re.I), "€"),
)

# Lentelėse vienetas dažnai eina prieš reikšmę („pastato aukštis m 12“).
QUANT_UNIT_BEFORE_RES = (
    ("area", re.compile(r"(?:m\s*[²2](?![\d])|kv\.?\s*m\.?|kvadrat\w*)\s*[.:]?\s*", re.I)),
    ("volume", re.compile(r"(?:m\s*[³3](?![\d])|kub\.?\s*m\.?|kub\w*)\s*[.:]?\s*", re.I)),
    ("length", re.compile(r"(?:mm|cm|m)(?![a-zà-ž0-9²³])\s*[.:]?\s*", re.I)),
    ("percent", re.compile(r"%\s*[.:]?\s*")),
    ("currency", re.compile(r"(?:€|eur\w*)\s*[.:]?\s*", re.I)),
)

QUANT_DIM_VARIANTS = (
    ("aukst", ("aukstis", "aukstis", "aukstis", "aukstį", "aukščio", "aukštį", "aukščiai", "aukstus")),
    ("ploti", ("plotis", "plocio", "plotį", "pločio")),
    ("ilg", ("ilgis", "ilgio", "ilgį", "ilgi")),
    ("stor", ("storis", "storio", "storį", "stori")),
    ("skersmu", ("skersmuo", "skersmens", "skersmenį", "skersmeni")),
    ("tur", ("turis", "turio", "turi", "turį")),
    ("plot", ("plotas", "ploto", "plota", "plotą", "plotai", "plotu", "plotų")),
    ("kiek", ("kiekis", "kiekio", "kiekį", "kiekiai")),
    ("skaic", ("skaicius", "skaičius", "skaiciu", "skaičių")),
    ("kain", ("kaina", "kainos", "kaina", "kainą", "kainuoja", "kainavo")),
    ("samat", ("samata", "sąmata", "samatos", "sąmatos", "samatai", "sąmatą")),
    ("biudzet", ("biudzetas", "biudžetas", "biudzeto", "biudžeto")),
)


def _unit_symbol(family, matched):
    low = (matched or "").strip().lower()
    if family == "length":
        if low.startswith("mm"):
            return "mm"
        if low.startswith("cm"):
            return "cm"
        return "m"
    return {"area": "m²", "volume": "m³", "count": "vnt", "percent": "%", "currency": "€"}.get(family, "")


def _dimension_terms(qn):
    words = set(tokens(qn))
    dims = []
    for stem, variants in QUANT_DIM_VARIANTS:
        if words & {norm(v) for v in variants}:
            if stem not in dims:
                dims.append(stem)
    return dims


def _quantity_families(qn):
    found = []
    for family, words in QUANT_FAMILY_WORDS.items():
        if any(w in qn for w in words):
            found.append(family)
    return found


def _stem(word):
    for suffix in (
        "iems", "iams", "uose", "yje", "oje", "iam", "iais",
        "as", "is", "os", "us", "ai", "ui", "ei", "ų", "u", "o", "a", "e", "ė", "i", "y",
    ):
        if word.endswith(suffix) and len(word) - len(suffix) >= 3:
            return word[:-len(suffix)]
    return word[:max(4, len(word) - 2)]


def _quantity_subjects(qn, question=None):
    originals = re.findall(r"[0-9A-Za-zÀ-ž]+", question or qn)
    family_words = tuple(w for words in QUANT_FAMILY_WORDS.values() for w in words)
    stems, display = [], []
    for original in originals:
        word = norm(original)
        if len(word) < 3 or word in STOP_TOKENS or word in QUANT_QUESTION_WORDS:
            continue
        if any(word.startswith(fw) for fw in family_words):
            continue
        stem = _stem(word)
        if stem not in stems:
            stems.append(stem)
            display.append(original)
    return stems[:6], display[:6]


def _quantity_anchors(families):
    anchors = []
    for family in (families or QUANT_FAMILY_WORDS.keys()):
        for word in QUANT_SEARCH_ANCHORS.get(family, ()):
            if word not in anchors:
                anchors.append(word)
    return anchors[:8]


def _quantity_intent(qn):
    if "kiek laiko" in qn or "kiek liko" in qn or "kiek dar" in qn:
        return False
    if "kiek" in qn.split():
        return True
    return bool(
        re.search(r"\b(koks|kokia|koki|kokio)\b", qn)
        and any(w in qn for w in (
            "plotas", "ploto", "plotą", "turis", "turio", "ilgis", "ilgio",
            "aukstis", "aukštis", "plotis", "svoris", "kaina", "kiekis",
        ))
    )


def _to_float(raw):
    s = raw.replace("\u00a0", "").replace("\u202f", "").replace(" ", "")
    if re.fullmatch(r"\d{1,3}(?:\.\d{3})+", s):
        return float(s.replace(".", ""))
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    else:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def _fmt_num(value):
    if abs(value - round(value)) < 0.005:
        return "{:,}".format(int(round(value))).replace(",", " ")
    return ("{:,.2f}".format(value).replace(",", " ").replace(".", ","))


def _count_word(n, one, few, many):
    if n % 10 == 1 and n % 100 != 11:
        return one
    if 2 <= n % 10 <= 9 and not 11 <= n % 100 <= 19:
        return few
    return many


def _context_label(text, start, end):
    left = max(0, start - 120)
    head = text[left:start]
    cut = 0
    for mark in ("\n", ". ", "; ", "•", "|", "—", "- "):
        pos = head.rfind(mark)
        if pos >= 0:
            cut = max(cut, pos + len(mark))
    start_at = left + cut
    if 0 < start_at < len(text) and text[start_at - 1].isalnum() and text[start_at].isalnum():
        nxt = text.find(" ", start_at)
        if 0 <= nxt <= start_at + 24:
            start_at = nxt + 1
    chunk = re.sub(r"\s+", " ", text[start_at:min(len(text), end + 26)]).strip()
    if len(chunk) > 140:
        chunk = chunk[:140].rsplit(" ", 1)[0]
    if chunk and start_at > 0:
        chunk = "…" + chunk
    return chunk or "—"


def _subject_distance(scope, subjects):
    best = None
    hits = 0
    for stem in subjects:
        idx = scope.rfind(stem)
        if idx < 0:
            continue
        hits += 1
        dist = len(scope) - idx
        if best is None or dist < best:
            best = dist
    return best, hits


def _extract_values(pages, subjects, families, dims=(), qn="", limit=24):
    found_items = []
    seen = set()
    per_doc = {}
    identity = 0
    qualifiers = ("uzstatym", "tankum", "intensyv", "apzeldint", "naudin", "butu", "auksciu")

    def consider(page, text, start, end, family, unit, label, value):
        nonlocal identity
        key = (page["docId"], page["page"], family, round(value, 2))
        if key in seen:
            return False
        seen.add(key)
        pre = norm(text[max(0, start - 40):start])
        dist, hits = _subject_distance(pre, subjects) if subjects else (0, 0)
        if subjects and dist is None:
            return False
        if any(qd in pre and qd not in qn for qd in qualifiers):
            return False
        required = [qd for qd in qualifiers if qd in qn]
        if required and not any(qd in pre for qd in required):
            return False
        dim_hit = any(d in pre for d in dims) if dims else False
        if dims and not dim_hit:
            return False
        item = {
            "num": value,
            "value": _fmt_num(value),
            "unit": unit,
            "family": family,
            "label": label,
            "docId": page["docId"],
            "docName": page["name"],
            "ext": page.get("ext") or "",
            "disc": page["disc"],
            "discName": page.get("discName") or page["disc"],
            "page": page["page"],
            "snippet": re.sub(r"\s+", " ", text[max(0, start - 80):min(len(text), end + 80)]).strip(),
        }
        item["_order"] = identity
        item["_dist"] = dist or 0
        item["_hits"] = hits
        item["_dim"] = 1 if dim_hit else 0
        found_items.append(item)
        identity += 1
        return True

    for page in pages:
        text = page.get("text") or ""
        if not text:
            continue
        doc_id = page["docId"]
        if per_doc.get(doc_id, 0) >= 8:
            continue
        per_page = 0
        for match in QUANT_NUM_RE.finditer(text):
            if per_page >= 6:
                break
            after = text[match.end():match.end() + 14]
            family = unit = None
            for fam, unit_re, _sym in QUANT_UNIT_RES:
                um = unit_re.match(after)
                if um:
                    family, unit = fam, _unit_symbol(fam, um.group(0))
                    break
            if not family:
                continue
            if family == "area" and re.match(r"\s*m\s*[²2]\s*[·*x×]?\s*K\b", after, re.I):
                continue
            if families and family not in families:
                continue
            before = text[max(0, match.start() - 24):match.start()]
            if re.search(r"(?:[≥≤<>±~]\s*|ne\s+mažiau\s*|ne\s+daugiau\s*|iki\s*|nuo\s*|min\.?\s*|max\.?\s*)$", before, re.I):
                continue
            label = _context_label(text, match.start(), match.end())
            if re.search(r"(kur\s*:|formul|sąlyginis|sąlygini)", label, re.I):
                continue
            value = _to_float(match.group(1))
            if value is None or value < 0.01 or value > 100000000:
                continue
            if consider(page, text, match.start(), match.end(), family, unit, label, value):
                per_page += 1
                per_doc[doc_id] = per_doc.get(doc_id, 0) + 1
            if len(found_items) >= limit * 4:
                break
        if per_page < 6 and per_doc.get(doc_id, 0) < 8:
            for family, unit_re in QUANT_UNIT_BEFORE_RES:
                if per_page >= 6:
                    break
                if families and family not in families:
                    continue
                for um in unit_re.finditer(text):
                    num = QUANT_NUM_RE.match(text, um.end())
                    if not num:
                        continue
                    tail = text[num.end():num.end() + 8]
                    if any(r.match(tail) for _f, r, _s in QUANT_UNIT_RES):
                        continue
                    before = text[max(0, um.start() - 24):um.start()]
                    if re.search(r"(?:[≥≤<>±~]\s*|ne\s+mažiau\s*|ne\s+daugiau\s*|iki\s*|nuo\s*|min\.?\s*|max\.?\s*)$", before, re.I):
                        continue
                    value = _to_float(num.group(1))
                    if value is None or value < 0.01 or value > 100000000:
                        continue
                    label = _context_label(text, num.start(), num.end())
                    if re.search(r"(kur\s*:|formul|sąlyginis|sąlygini)", label, re.I):
                        continue
                    if consider(page, text, um.start(), num.end(), family, _unit_symbol(family, um.group(0)), label, value):
                        per_page += 1
                        per_doc[doc_id] = per_doc.get(doc_id, 0) + 1
        if len(found_items) >= limit * 4:
            break
    found_items.sort(key=lambda it: (-it["_dim"], -it["_hits"], it["_dist"], it["_order"]))
    for item in found_items:
        item.pop("_dist", None)
        item.pop("_order", None)
        item.pop("_hits", None)
        item.pop("_dim", None)
    return found_items[:limit], False


def _quantity_answer(question, qn, ctx):
    families = _quantity_families(qn)
    dims = _dimension_terms(qn)
    if not dims:
        if "area" in families:
            dims = ["plot"]
        elif "volume" in families:
            dims = ["tur"]
    subjects, display = _quantity_subjects(qn, question)
    pages = []
    seen_pages = set()
    for chunk in (subjects, _quantity_anchors(families if families else [])):
        if not chunk:
            continue
        try:
            found = ctx["search_pages"](" ".join(chunk), 140)
        except Exception:
            found = []
        for page in found:
            key = (page["docId"], page["page"])
            if key in seen_pages:
                continue
            seen_pages.add(key)
            pages.append(page)
    values, weak = _extract_values(pages, subjects, families, dims, qn)
    subject_label = " ".join(display) if display else (", ".join(families) if families else "ieškomas dydis")
    if values:
        lead = "Radau %d %s, susijusias su „%s“. Patikrinkite šaltinį – skirtingi dokumentai gali pateikti skirtingus to paties dydžio variantus." % (len(values), _count_word(len(values), "reikšmę", "reikšmes", "reikšmių"), subject_label)
        if weak:
            lead = "Tikslaus ryšio su „%s“ nepavyko patvirtinti, todėl pateikiu visas to tipo reikšmes, rastas susijusiuose puslapiuose." % subject_label
    else:
        lead = "Indeksuotuose dokumentuose neradau skaičiaus su ieškomu vienetu šiame kontekste. Pabandykite patikslinti dydį (pvz., „Kiek kvadratų stogo dangos?“) arba nurodyti dalį (SA, SK, BD)."
    result_docs = []
    if not values and display:
        try:
            result_docs = _find_docs(norm(" ".join(display)), ctx)[:3]
        except Exception:
            result_docs = []
    facts = [{"label": "Rasta reikšmių", "value": len(values)}]
    if values:
        used_families = {v["family"] for v in values}
        if len(used_families) == 1 and len(values) > 1:
            numbers = [v["num"] for v in values]
            unit = values[0]["unit"]
            facts.append({"label": "Didžiausia", "value": _fmt_num(max(numbers)) + " " + unit})
            facts.append({"label": "Mažiausia", "value": _fmt_num(min(numbers)) + " " + unit})
            facts.append({"label": "Suma (visi įrašai)", "value": _fmt_num(sum(numbers)) + " " + unit})
    dwg_unindexed = sum(
        1 for d in ctx["docs"]
        if (d.get("ext") or "").lower() == ".dwg" and d.get("textState") != "done"
    )
    note = ""
    if values:
        note = ("Reikšmės nuskaitytos iš indeksuoto dokumentų teksto (PDF, DOCX, TXT, DWG), o ne matuotos geometriškai. "
                "Suma – aritmetinė visų rastų įrašų suma, todėl ji gali dubliuoti tą patį dydį iš skirtingų dokumentų.")
    if dwg_unindexed:
        if note:
            note += " DWG brėžinių tekstas dar neindeksuotas (%d failai), tad jų lentelių reikšmės čia nepatektos." % dwg_unindexed
        else:
            note = ("Skaičiai ieškomi tik indeksuotame PDF, DOCX ir TXT tekste. "
                    "DWG brėžinių tekstas dar neindeksuotas (%d failai), tad ieškomas dydis gali būti nurodytas brėžinyje – atidarykite jį per dokumentų sąrašą." % dwg_unindexed)
    return {
        "intent": "quantity",
        "title": question.strip()[:90] or "Kiekio paieška",
        "lead": lead,
        "facts": facts,
        "values": values,
        "docs": result_docs,
        "note": note,
        "suggestions": [
            "Kiek kvadratų fasado?",
            "Kiek kvadratų stogo dangos?",
            "Koks pastato tūris?",
            "Kur yra sąmata?",
        ],
    }


def _role_answer(qn, ctx):
    project = ctx["project"]
    facts = []
    if "projektuotoj" in qn:
        facts = [
            {"label": "Projektuotojas", "value": project.get("designer") or "—"},
            {"label": "Projekto Nr.", "value": project.get("project_no") or "—"},
        ]
    elif "statytoj" in qn or "uzsakov" in qn:
        facts = [{"label": "Statytojas / užsakovas", "value": project.get("client") or "—"}]
    elif "adres" in qn:
        facts = [{"label": "Adresas", "value": project.get("address") or "—"}]
    else:
        facts = _project_facts(project)
    return {
        "intent": "project",
        "title": "Projekto duomenys",
        "lead": project.get("full_name") or project.get("name") or "",
        "facts": facts,
        "suggestions": ["Kur yra statybos leidimas?", "Kas yra statytojas?", "Kur NT registro dokumentai?"],
    }


def _who_discipline_answer(qn, ctx, docs):
    codes = sorted(_disciplines(qn))
    code = codes[0] if codes else ""
    disc = next((d for d in ctx["discs"] if d["code"] == code), None)
    if not disc:
        return None
    facts = [
        {"label": "Dalis", "value": f"{disc['code']} — {disc['name']}"},
        {"label": "Failai", "value": disc["files"]},
        {"label": "Būsena", "value": disc.get("status") or "Nepažymėta"},
        {"label": "Atsakingas", "value": disc.get("owner") or "Nepriskirtas"},
    ]
    return {
        "intent": "who",
        "title": f"Dalis {disc['code']} — {disc['name']}",
        "lead": "Atsakingą asmenį ir dalies būseną galite įrašyti Apžvalgos lentelėje. Susijusius failus rasite žemiau.",
        "facts": facts,
        "docs": docs,
        "tip": "Spustelėkite „Atidaryti aplanką“, kad pamatytumėte failų vietą diske.",
        "suggestions": [f"Kur yra {disc['name'].lower()} dokumentai?", "Kaip patikrinti projekto komplektiškumą?", "Kur yra statybos leidimas?"],
        "action": {"type": "view", "view": "apzvalga", "label": "Atidaryti Apžvalgą"},
    }


def _nav_action(qn, ctx):
    if not any(qn.startswith(v) for v in ("atidaryk", "rodyk", "nueik", "perjunk", "eik i", "parodyk")):
        return None
    views = [
        ("dokument", "dokumentai", "Dokumentai"),
        ("paiesk", "paieska", "Paieška"),
        ("uzduot", "uzduotys", "Užduotys"),
        ("elektr", "elektra", "Elektra"),
        ("apdail", "apdaila", "Apdaila"),
        ("santech", "santechnika", "Santechnika"),
        ("fasad", "fasadas", "Fasadas"),
        ("zurnal", "zurnalas", "Žurnalas"),
        ("susitikim", "susitikimai", "Susitikimai"),
        ("kontrolin", "kontrolinis", "Kontrolinis sąrašas"),
        ("nustatym", "nustatymai", "Nustatymai"),
        ("apzvalg", "apzvalga", "Apžvalga"),
    ]
    for stem, view, label in views:
        if stem in qn:
            return {"type": "view", "view": view, "label": label}
    return None


def _task_action(qn):
    if not re.search(r"(sukurk|pridek|pridet|nauja).*uzduot", qn):
        return None
    match = re.search(r"uzduot[a-z]*\s*(?:kad\s*)?(.*)$", qn)
    title = (match.group(1).strip(" .:,") if match else "") or "Nauja užduotis"
    title = title[:1].upper() + title[1:]
    return {"type": "task", "title": title, "label": "Sukurti užduotį"}


def welcome(ctx):
    counts = ctx["counts"]
    project = ctx["project"]
    return {
        "intent": "hello",
        "title": "Kuo padėti?",
        "lead": "Parašykite klausimą apie šį projektą. Surasiu dokumentą, nurodysiu jo vietą, paaiškinsiu, ką daryti, ir ištrauksiu dokumentuose nurodytus skaičius (pvz., „Kiek kvadratų stogo?“).",
        "facts": [
            {"label": "Projektas", "value": project.get("name") or "—"},
            {"label": "Dokumentai", "value": counts["docCount"]},
            {"label": "Dalys", "value": counts["discCount"]},
            {"label": "Atviros užduotys", "value": counts["tasksOpen"]},
        ],
        "suggestions": DEFAULT_SUGGESTIONS,
    }


HELP_QUERIES = {
    "ka tu gali", "ka moki", "ka zinai", "kuo gali padeti", "kaip naudotis",
    "pagalba", "padek", "padetum", "ka darai", "ka sugebi", "ka gali padaryti",
    "ka gali", "kokie tavo galimybes", "kaip veikia", "kaip veikia padejejas",
    "ka cia galiu daryti", "kuo galiu padeti",
}


def _help_intent(qn):
    s = qn.strip(" .?!")
    if s in HELP_QUERIES:
        return True
    return s.startswith(("ka tu gali", "ka moki", "kaip naudotis", "kuo gali padet", "kokie tavo gal", "ka gali"))


def _help_answer(ctx):
    return {
        "intent": "help",
        "title": "Kuo galiu padėti",
        "lead": "Moku rasti dokumentus, paaiškinti eigą, parodyti atsakingą asmenį ir ištraukti dokumentuose nurodytus skaičius. Pavyzdžiai:",
        "facts": [
            {"label": "Skaičiai", "value": "Kiek kvadratų stogo? · Koks pastato aukštis?"},
            {"label": "Dokumentai", "value": "Kur yra statybos leidimas?"},
            {"label": "Eiga", "value": "Ką daryti šiandien? · Kas vėluoja?"},
            {"label": "Procesai", "value": "Kaip užbaigti statybą?"},
            {"label": "Atsakomybė", "value": "Kas atsakingas už elektros dalį?"},
            {"label": "Projektas", "value": "Kas yra projektuotojas?"},
        ],
        "suggestions": DEFAULT_SUGGESTIONS[:4],
    }


DESCRIPTIVE_STARTS = (
    "kokie ", "kokios ", "kurie ", "kurios ", "ka nurodyta", "kas nurodyta",
    "ka raso", "kas raso", "kaip atrodo", "kokia sudetis", "kokios sudetys",
    "is ko sudaro", "kas ieina", "kas sudaro", "ka projektuojama", "kokie projektuojami",
)


def _descriptive_intent(qn):
    return qn.startswith(DESCRIPTIVE_STARTS)


DATE_PATTERNS = (
    r"statybos pabaigos metai\s*:?\s*((?:19|20)\d{2})",
    r"statybos pabaiga\s*[–—:,-]?\s*((?:19|20)\d{2}(?:[-.]\d{1,2}(?:[-.]\d{1,2})?)?)",
    r"statybos užbaigimo (?:data|metai)\s*:?\s*((?:19|20)\d{2}(?:[-.]\d{1,2}(?:[-.]\d{1,2})?)?)",
    r"užbaigimo (?:data|metai)\s*:?\s*((?:19|20)\d{2}(?:[-.]\d{1,2}(?:[-.]\d{1,2})?)?)",
    r"numatoma (?:statybos )?pabaiga\s*[–—:,-]?\s*((?:19|20)\d{2}(?:[-.]\d{1,2}(?:[-.]\d{1,2})?)?)",
)
DATE_START_PATTERNS = (
    r"statybos pradžios metai\s*:?\s*((?:19|20)\d{2})",
    r"statybos pradžia\s*[–—:,-]?\s*((?:19|20)\d{2}(?:[-.]\d{1,2}(?:[-.]\d{1,2})?)?)",
)


def _date_intent(qn):
    if not qn.startswith("kada"):
        return False
    return any(w in qn for w in ("pabaig", "uzbaig", "termin", "pradzi", "praside", "prasided", "statyb"))


def _date_answer(qn, ctx, docs):
    start = any(w in qn for w in ("pradzi", "praside", "prasided")) and "pabaig" not in qn
    patterns = DATE_START_PATTERNS if start else DATE_PATTERNS
    seen_pages = set()
    seen_keys = set()
    values = []
    for query in ("statybos pabaigos metai", "statybos pradžios metai"):
        try:
            pages = ctx["search_pages"](query, 80)
        except Exception:
            pages = []
        for page in pages:
            key = (page["docId"], page["page"])
            if key in seen_pages:
                continue
            seen_pages.add(key)
            text = page.get("text") or ""
            for pattern in patterns:
                for m in re.finditer(pattern, text, re.I):
                    value = m.group(1)
                    vkey = (page["docId"], value)
                    if vkey in seen_keys:
                        continue
                    seen_keys.add(vkey)
                    pre = text[max(0, m.start() - 200):m.start()]
                    mark = re.search(r"Žymėjimas plane:\s*([^\s]{1,14})", pre, re.I)
                    label = ("Statybos pradžios metai: " if start else "Statybos pabaigos metai: ") + value
                    if mark:
                        label += " · žymėjimas " + mark.group(1)
                    values.append({
                        "value": value,
                        "unit": "",
                        "family": "date",
                        "label": label,
                        "docId": page["docId"],
                        "docName": page["name"],
                        "ext": page.get("ext") or "",
                        "disc": page["disc"],
                        "discName": page.get("discName") or page["disc"],
                        "page": page["page"],
                        "snippet": re.sub(r"\s+", " ", text[max(0, m.start() - 80):m.end() + 80]).strip(),
                    })
    values.sort(key=lambda v: (v["value"][:4], v["docName"]), reverse=True)
    values = values[:6]
    what = "pradžios" if start else "pabaigos"
    if values:
        return {
            "intent": "when",
            "title": "Statybos terminai",
            "lead": "Dokumentuose nurodyti statybos %s duomenys. Patikrinkite šaltinį – tai registro ar projekto įrašai, o ne patvirtintas darbų grafikas." % what,
            "facts": [{"label": "Rasta įrašų", "value": len(values)}],
            "values": values,
            "note": "Tikslius terminus patogiausia sekti užduotyse ir kontroliniame sąraše.",
            "suggestions": ["Ką daryti šiandien?", "Kaip užbaigti statybą?", "Kur yra statybos leidimas?"],
        }
    return {
        "intent": "when",
        "title": "Statybos terminai",
        "lead": "Tikslaus statybos %s termino dokumentuose neradau. Terminus patogiausia sekti užduotyse ir kontroliniame sąraše." % what,
        "facts": [{"label": "Rasta įrašų", "value": 0}],
        "docs": docs[:3],
        "suggestions": ["Kaip užbaigti statybą?", "Ką daryti šiandien?", "Kur yra statybos leidimas?"],
    }


WORK_SECTION_WORDS = {
    "fasadas": ("fasad", "klinker", "siltin", "šiltin", "palang", "parapet", "turekl", "turėkl", "stiklo paket", "lang", "duru", "durų", "cokol"),
    "elektra": ("elektr", "kabel", "rozet", "apsviet", "apšviet"),
    "apdaila": ("apdail", "plytel", "glaist", "dazym", "dažym"),
    "santechnika": ("santech", "vandentiek", "nuotek", "sanitar"),
}
WORK_SECTION_LABELS = {
    "elektra": "Elektra",
    "apdaila": "Apdaila",
    "santechnika": "Santechnika",
    "fasadas": "Fasadas",
}


def _works_section(qn):
    scores = {}
    for key, words in WORK_SECTION_WORDS.items():
        for word in words:
            if word in qn:
                scores[key] = scores.get(key, 0) + 1
    if not scores:
        return None
    return max(scores, key=scores.get)


def _works_intent(qn, ctx):
    if not ctx.get("works"):
        return None
    section = _works_section(qn)
    has_work = any(w in qn for w in ("darb", "samat", "kieki", "suvest", "pozicij", "kain"))
    asks = "kiek" in qn.split() or "kokie" in qn.split() or "kokia" in qn.split()
    if section and (has_work or asks):
        return section
    if has_work and ("kiek ko" in qn or "visi darb" in qn or "suvest" in qn or "kain" in qn):
        return "all"
    return None


def _fmt_money(value):
    return ("{:,.2f}".format(value).replace(",", " ").replace(".", ",") + " €")


def _pos(n):
    n = abs(int(n or 0))
    if n % 10 == 1 and n % 100 != 11:
        return "pozicija"
    if 2 <= n % 10 <= 9 and not 11 <= n % 100 <= 19:
        return "pozicijos"
    return "pozicijų"


def _works_answer(ctx, section, qn):
    works = ctx.get("works") or []
    summary = ctx.get("worksSummary") or {}
    doc_map = {d["id"]: d for d in ctx.get("docs", [])}
    keys = list(WORK_SECTION_LABELS) if section == "all" else [section]
    facts, values = [], []
    per_section = 4 if section == "all" else 8
    total_positions = 0
    for key in keys:
        rows = [w for w in works if w.get("section") == key]
        if not rows:
            continue
        info = summary.get(key, {})
        total_positions += len(rows)
        facts.append({"label": f"{WORK_SECTION_LABELS[key]} pozicijos",
                      "value": f"{len(rows)}"})
        facts.append({"label": f"{WORK_SECTION_LABELS[key]} atlikta",
                      "value": f"{info.get('done', 0)} / {len(rows)}"})
        if info.get("priced"):
            facts.append({"label": f"{WORK_SECTION_LABELS[key]} vertė",
                          "value": _fmt_money(float(info.get("value") or 0))})
        else:
            facts.append({"label": f"{WORK_SECTION_LABELS[key]} vertė",
                          "value": "kainos neįvestos"})
        chosen = [w for w in rows if float(w.get("qty") or 0) > 0]
        if section == "all":
            chosen.sort(key=lambda w: (0 if w.get("kind") in ("Sąmata", "Projektas") else 1,
                                       float(w.get("ord") or 0)))
        else:
            qwords = [t for t in tokens(qn) if len(t) >= 3]

            def rank(w):
                text = norm(w.get("title") or "") + " " + norm(w.get("basis") or "")
                hits = sum(1 for word in qwords if word[:5] in text)
                return (-hits, 0 if w.get("kind") in ("Sąmata", "Projektas") else 1,
                        float(w.get("ord") or 0))

            chosen.sort(key=rank)
        for w in chosen[:per_section]:
            doc = doc_map.get(int(w.get("source_doc") or 0), {})
            values.append({
                "value": _fmt_num(float(w.get("qty") or 0)),
                "unit": w.get("unit") or "",
                "label": f"{w.get('code') or ''} · {w.get('title') or ''}".strip(" ·"),
                "docId": doc.get("id") or 0,
                "docName": doc.get("name") or w.get("source_name") or "",
                "ext": doc.get("ext") or ".pdf",
                "disc": doc.get("disc") or WORK_SECTION_WORDS.get(key, ("",))[0],
                "discName": doc.get("discName") or WORK_SECTION_LABELS[key],
                "page": int(w.get("source_page") or 1),
                "snippet": w.get("basis") or "",
            })
    if section == "all":
        title = "Darbų kiekių suvestinė"
        lead = (f"Keturiose skiltyse – {total_positions} {_pos(total_positions)}. Žemiau pagrindiniai kiekiai su "
                "matavimo vienetais ir šaltiniu; visus darbus rasite skiltyse „Elektra“, „Apdaila“, „Santechnika“ ir „Fasadas“.")
        action = {"type": "view", "view": "elektra", "label": "Atidaryti Elektros darbus"}
    else:
        label = WORK_SECTION_LABELS[section]
        title = f"{label} darbų kiekiai"
        lead = (f"Skiltyje „{label}“ – {total_positions} {_pos(total_positions)}. Žemiau pagrindiniai kiekiai; "
                "kiekviena pozicija turi pagrindimą – projekto lapą arba skaičiavimo formulę.")
        action = {"type": "view", "view": section, "label": f"Atidaryti skiltį „{label}“"}
    return {
        "intent": "works",
        "title": title,
        "lead": lead,
        "facts": facts,
        "values": values[:12],
        "tip": "Sąmatos pozicijos imtos iš projekto kiekių žiniaraščių, skaičiuojamos – pagal aiškią formulę. "
               "Kainos įvedamos skiltyje pagal rangovo pasiūlymą.",
        "note": "Skaičiuojamos apdailos ir vidaus instaliacijos pozicijos yra orientacinės – jos žymimos žyma "
                "„Skaičiuojama“ ir turi būti patikslintos pagal išklotines bei ET projektą.",
        "action": action,
        "suggestions": ["Kiek ko reikia elektros darbams?", "Kiek apdailos darbų?",
                        "Santechnikos kiekių suvestinė", "Kiek kainuos darbai?"],
    }


def answer(question, ctx):
    q = (question or "").strip()
    if not q:
        return welcome(ctx)
    qn = norm(q)
    guide, _score = _pick_guide(qn)
    docs = _find_docs(qn, ctx)
    toks = tokens(qn)

    nav = _nav_action(qn, ctx)
    if nav:
        return {
            "intent": "navigate",
            "title": "Atidarau",
            "lead": f"Perjungiu į skiltį „{nav['label']}“.",
            "action": nav,
            "suggestions": DEFAULT_SUGGESTIONS[:3],
        }

    task = _task_action(qn)
    if task:
        return {
            "intent": "action",
            "title": "Sukuriu užduotį",
            "lead": "Patikrinkite pavadinimą ir išsaugokite. Terminą bei atsakingą galite nurodyti formoje.",
            "action": task,
            "suggestions": ["Ką daryti šiandien?", "Kaip sekti projekto eigą?"],
        }

    if _help_intent(qn):
        return _help_answer(ctx)

    if _daily_intent(qn):
        return _daily_answer(ctx)

    works_section = _works_intent(qn, ctx)
    if works_section:
        return _works_answer(ctx, works_section, qn)

    count_keys = (
        "dokument", "fail", "uzduot", "irasa", "punkt", "dali",
        "brezin", "pdf", "dwg", "docx", "word", "adoc", "ifc", "txt",
    )
    if "kiek" in qn.split() and any(w in qn for w in count_keys) and not _quantity_families(qn):
        return _counts_answer(ctx, qn)

    if _quantity_intent(qn) and not qn.startswith("kaip"):
        return _quantity_answer(q, qn, ctx)

    if (re.search(r"\bkas\b", qn) or "atsaking" in qn or "atsakomyb" in qn) and _disciplines(qn):
        who = _who_discipline_answer(qn, ctx, docs)
        if who:
            return who

    if guide is None and any(w in qn for w in PROJECT_FACT_WORDS):
        return _role_answer(qn, ctx)

    if _descriptive_intent(qn):
        guide = None

    if _date_intent(qn):
        return _date_answer(qn, ctx, docs)

    has_where = any(p in qn for p in WHERE_PHRASES)
    if "kur" in qn.split() and not any(v in qn for v in HOW_VERBS):
        has_where = True
    if has_where:
        return _where_answer(qn, guide, docs, ctx)

    if guide:
        if len(docs) < 2 and guide.get("doc_terms"):
            extra = _find_docs(norm(guide["doc_terms"]), ctx)
            known = {d["id"] for d in docs}
            docs = docs + [d for d in extra if d["id"] not in known]
        related = guide.get("related_discs")
        if related is not None:
            docs = [d for d in docs if d["disc"] in related]
        return _how_answer(guide, docs[:4], ctx)

    if docs:
        descriptive = _descriptive_intent(qn)
        return {
            "intent": "search",
            "title": "Kas nurodyta dokumentuose" if descriptive else "Susiję dokumentai",
            "lead": ("Radau dokumentus, kuriuose atsakoma į šį klausimą. Žemiau – ištraukos; spustelėkite kortelę detalesnei peržiūrai."
                     if descriptive else "Tikslaus scenarijaus neturiu, bet radau dokumentų, kuriuose paminėti jūsų žodžiai."),
            "docs": docs,
            "suggestions": DEFAULT_SUGGESTIONS[:3],
        }

    return {
        "intent": "help",
        "title": "Nesu tikras dėl šio klausimo",
        "lead": "Pabandykite paklausti konkrečiau: „Kur yra …?“, „Kaip padaryti …?“, „Kas atsakingas už …?“ arba nurodykite dalies kodą.",
        "suggestions": DEFAULT_SUGGESTIONS,
    }
