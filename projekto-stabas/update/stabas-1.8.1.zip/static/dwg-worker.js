import { LibreDwg, Dwg_File_Type } from '/vendor/libredwg/dist/libredwg-web.js';

let libPromise = null;
let queue = Promise.resolve();

function thumbMime(data) {
  if (!data || data.length < 8) return null;
  if (data[0] === 0x89 && data[1] === 0x50 && data[2] === 0x4e && data[3] === 0x47) return 'image/png';
  if (data[0] === 0x42 && data[1] === 0x4d) return 'image/bmp';
  if (data[0] === 0x28 && data[1] === 0 && data[2] === 0 && data[3] === 0) return 'image/bmp-dib';
  if (data[0] === 0xd7 && data[1] === 0xcd && data[2] === 0xc6 && data[3] === 0x9a) return 'image/wmf';
  if (data[0] === 0x01 && data[1] === 0x00 && data[2] === 0x09 && data[3] === 0x00) return 'image/wmf';
  return null;
}

function dibToBmp(buf) {
  const dib = new Uint8Array(buf);
  const biSize = dib[0] | (dib[1] << 8) | (dib[2] << 16) | (dib[3] << 24);
  const offset = 14 + (biSize > 12 ? biSize : 40);
  const out = new Uint8Array(14 + dib.length);
  out[0] = 0x42;
  out[1] = 0x4d;
  const size = out.length;
  out[2] = size & 255;
  out[3] = (size >> 8) & 255;
  out[4] = (size >> 16) & 255;
  out[5] = (size >> 24) & 255;
  out[10] = offset & 255;
  out[11] = (offset >> 8) & 255;
  out[12] = (offset >> 16) & 255;
  out[13] = (offset >> 24) & 255;
  out.set(dib, 14);
  return out;
}

function viewBoxOf(svg) {
  const m = /viewBox="\s*([^"]+)\s*"/.exec(svg);
  if (!m) return null;
  const parts = m[1].trim().split(/[\s,]+/).map(Number);
  if (parts.length !== 4 || parts.some(n => !isFinite(n))) return null;
  return parts;
}

function extractThumb(lib, dwg) {
  try {
    const t = lib.dwg_bmp(dwg);
    if (!t || !t.data || !t.data.length) return null;
    const mime = thumbMime(t.data);
    if (mime === 'image/bmp-dib') {
      return { mime: 'image/bmp', buffer: dibToBmp(t.data).buffer };
    }
    if (mime === 'image/png' || mime === 'image/bmp') {
      return { mime, buffer: new Uint8Array(t.data).buffer };
    }
    return null;
  } catch (err) {
    return null;
  }
}

async function readBody(res, id) {
  const total = Number(res.headers.get('content-length')) || 0;
  if (!res.body || !total || !res.body.getReader) {
    return new Uint8Array(await res.arrayBuffer());
  }
  const reader = res.body.getReader();
  let out = new Uint8Array(total);
  let received = 0;
  let last = -1;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    if (received + value.length > out.length) {
      const bigger = new Uint8Array(Math.max(out.length * 2, received + value.length));
      bigger.set(out.subarray(0, received));
      out = bigger;
    }
    out.set(value, received);
    received += value.length;
    const pct = Math.min(100, Math.round(received / total * 100));
    if (pct >= last + 2) {
      last = pct;
      self.postMessage({ id, progress: true, phase: 'download', pct });
    }
  }
  return received === out.length ? out : out.subarray(0, received);
}

async function handle(msg) {
  const { id, url } = msg || {};
  const started = performance.now();
  try {
    self.postMessage({ id, progress: true, phase: 'engine' });
    libPromise = libPromise || LibreDwg.create();
    const lib = await libPromise;
    self.postMessage({ id, progress: true, phase: 'download' });
    const res = await fetch(url);
    if (!res.ok) throw new Error('Nepavyko nuskaityti failo (' + res.status + ')');
    const buf = await readBody(res, id);
    self.postMessage({ id, progress: true, phase: 'parse' });
    const dwg = lib.dwg_read_data(new Uint8Array(buf), Dwg_File_Type.DWG);
    if (!dwg) throw new Error('DWG failas neperskaitytas');

    const thumb = extractThumb(lib, dwg);
    if (thumb) self.postMessage({ id, preview: true, thumb }, [thumb.buffer]);

    let svg = '';
    let svgError = null;
    try {
      self.postMessage({ id, progress: true, phase: 'convert' });
      const data = lib.convert(dwg);
      self.postMessage({ id, progress: true, phase: 'svg' });
      svg = lib.dwg_to_svg(data) || '';
    } catch (err) {
      svgError = err;
    }

    lib.dwg_free(dwg);

    if (!svg) {
      const detail = svgError ? String(svgError.message || svgError) : '';
      throw new Error('Brėžinio atvaizduoti nepavyko' + (detail ? ': ' + detail : ''));
    }

    self.postMessage({
      id,
      ok: true,
      svg,
      viewBox: viewBoxOf(svg),
      ms: Math.round(performance.now() - started),
      bytes: svg.length,
    });
  } catch (err) {
    self.postMessage({ id, ok: false, error: String((err && err.message) || err) });
  }
}

self.onmessage = e => {
  const data = e.data;
  queue = queue.then(() => handle(data)).catch(() => {});
};
