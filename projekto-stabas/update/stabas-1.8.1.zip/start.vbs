Option Explicit
Dim sh, fso, base, py, cmd, q
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = base
q = Chr(34)
py = "C:\Users\vikto\AppData\Local\Programs\Python\Python312\pythonw.exe"
If Not fso.FileExists(py) Then
    py = "pythonw.exe"
End If
cmd = q & py & q & " " & q & base & "\app.py" & q
sh.Run cmd, 0, False
