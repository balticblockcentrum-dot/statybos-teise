param(
  [Parameter(Mandatory = $true)][string]$Path,
  [Parameter(Mandatory = $true)][string]$OutFile,
  [int]$Width = 2000,
  [int]$MaxPages = 60,
  [switch]$Words
)
$ErrorActionPreference = 'Stop'
$Path = [System.IO.Path]::GetFullPath($Path.Replace('/', '\'))
$OutFile = [System.IO.Path]::GetFullPath($OutFile.Replace('/', '\'))
try {
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  $asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
  function Await($op, $type) {
    $m = $asTaskGeneric.MakeGenericMethod($type)
    $t = $m.Invoke($null, @($op))
    $t.Wait(-1) | Out-Null
    $t.Result
  }
  $asTaskAction = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction' })[0]
  function AwaitAction($op) {
    $t = $asTaskAction.Invoke($null, @($op))
    $t.Wait(-1) | Out-Null
  }
  [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime] | Out-Null
  [Windows.Data.Pdf.PdfDocument, Windows.Data.Pdf, ContentType = WindowsRuntime] | Out-Null
  [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime] | Out-Null
  [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null
  [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime] | Out-Null

  $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
  if (-not $engine) { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new('en-US')) }
  if (-not $engine) { throw 'Nėra OCR kalbos paketo' }

  $out = New-Object System.Text.StringBuilder
  $sf = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($Path)) ([Windows.Storage.StorageFile])
  if ($Path -match '\.pdf$') {
    $pdf = Await ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($sf)) ([Windows.Data.Pdf.PdfDocument])
    $n = [Math]::Min([int]$pdf.PageCount, $MaxPages)
    for ($i = 0; $i -lt $n; $i++) {
      $page = $pdf.GetPage($i)
      $ms = [Windows.Storage.Streams.InMemoryRandomAccessStream]::new()
      $opt = [Windows.Data.Pdf.PdfPageRenderOptions]::new()
      $opt.DestinationWidth = [uint32]$Width
      AwaitAction ($page.RenderToStreamAsync($ms, $opt))
      $ms.Seek(0)
      $dec = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($ms)) ([Windows.Graphics.Imaging.BitmapDecoder])
      $bmp = Await ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
      $res = Await ($engine.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
      [void]$out.AppendLine("===PAGE " + ($i + 1) + "===")
      if ($Words) {
        foreach ($line in $res.Lines) {
          foreach ($w in $line.Words) {
            $r = $w.BoundingRect
            [void]$out.AppendLine(("{0}`t{1}`t{2}`t{3}`t{4}" -f $w.Text.Replace("`t", " "), [int]$r.X, [int]$r.Y, [int]$r.Width, [int]$r.Height))
          }
        }
      } else {
        [void]$out.AppendLine($res.Text)
      }
      $bmp.Dispose(); $ms.Dispose(); $page.Dispose()
    }
  } else {
    $ms = Await ($sf.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    $dec = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($ms)) ([Windows.Graphics.Imaging.BitmapDecoder])
    try {
      $bmp = Await ($dec.GetSoftwareBitmapAsync([Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8, [Windows.Graphics.Imaging.BitmapAlphaMode]::Premultiplied, [Windows.Graphics.Imaging.BitmapTransform]::new(), [Windows.Graphics.Imaging.ExifOrientationMode]::RespectExifOrientation, [Windows.Graphics.Imaging.ColorManagementMode]::DoNotColorManage)) ([Windows.Graphics.Imaging.SoftwareBitmap])
    } catch {
      $bmp = Await ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    }
    $res = Await ($engine.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
    [void]$out.AppendLine('===PAGE 1===')
    if ($Words) {
      foreach ($line in $res.Lines) {
        foreach ($w in $line.Words) {
          $r = $w.BoundingRect
          [void]$out.AppendLine(("{0}`t{1}`t{2}`t{3}`t{4}" -f $w.Text.Replace("`t", " "), [int]$r.X, [int]$r.Y, [int]$r.Width, [int]$r.Height))
        }
      }
    } else {
      [void]$out.AppendLine($res.Text)
    }
    $bmp.Dispose(); $ms.Dispose()
  }
  [System.IO.File]::WriteAllText($OutFile, $out.ToString(), (New-Object System.Text.UTF8Encoding($false)))
  exit 0
} catch {
  [Console]::Error.WriteLine($_.Exception.Message)
  exit 1
}
