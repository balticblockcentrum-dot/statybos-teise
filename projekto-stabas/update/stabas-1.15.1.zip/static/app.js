'use strict';

/* ============ helpers ============ */
const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => Array.from(el.querySelectorAll(sel));

const VIEW_TITLES = {
  apzvalga: 'Apžvalga',
  dokumentai: 'Dokumentai',
  fotofiksacija: 'Fotofiksacija',
  paieska: 'Paieška',
  elektra: 'Elektra',
  apdaila: 'Apdaila',
  santechnika: 'Santechnika',
  fasadas: 'Fasadas',
  aktai: 'Aktai F2/F3',
  problemos: 'Problemos',
  uzduotys: 'Užduotys',
  zurnalas: 'Žurnalas',
  susitikimai: 'Susitikimai',
  kontrolinis: 'Kontrolinis sąrašas',
  nustatymai: 'Nustatymai',
};

const DISC_STATUS_CLASS = {
  'Nepažymėta': '',
  'Rengiama': 'disc-status-Rengiama',
  'Pateikta derinti': 'disc-status-Pateikta',
  'Derinama': 'disc-status-Derinama',
  'Patvirtinta': 'disc-status-Patvirtinta',
};

const TASK_COLS = [
  { key: 'todo', label: 'Padaryti' },
  { key: 'doing', label: 'Vykdoma' },
  { key: 'done', label: 'Padaryta' },
];

const ICONS = {
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  building: '<rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M8 7h2M14 7h2M8 11h2M14 11h2M8 15h2M14 15h2M10 21v-3h4v3"/>',
  file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  tasks: '<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M8 2v4M16 2v4M3 9h18M8 14l2 2 4-4"/>',
  book: '<path d="M4 4h13a3 3 0 0 1 3 3v13H7a3 3 0 0 1-3-3z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
  users: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-5.5 6-5.5s6 2.2 6 5.5"/><circle cx="17.5" cy="9" r="2.4"/><path d="M16 14.6c2.8.2 5 2.3 5 5.4"/>',
  check: '<path d="M9 4h6M9 2h6v4H9z"/><path d="M6 4H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-1"/><path d="m8 13 2 2 4-4"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 6.3M20 4v7h-7"/>',
  alert: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  calendar: '<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M8 2v4M16 2v4M3 9h18"/>',
  external: '<path d="M14 4h6v6M20 4l-9 9"/><path d="M19 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h5"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  chevron: '<path d="m9 18 6-6-6-6"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
  user: '<circle cx="12" cy="8" r="3.5"/><path d="M5 20c0-3.6 3-6 7-6s7 2.4 7 6"/>',
  inbox: '<path d="M4 13 6 5h12l2 8v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><path d="M4 13h5l1 2h4l1-2h5"/>',
  building: '<path d="M4 21V6a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v15M16 9h2a2 2 0 0 1 2 2v10M2 21h20M8 8h2M8 12h2M8 16h2"/>',
  help: '<path d="M21 12a8 8 0 0 1-8 8H5l-2 2V12a8 8 0 0 1 8-8h2a8 8 0 0 1 8 8z"/><path d="M8 10h8M8 14h5"/>',
  bolt: '<path d="M13 2 4.5 13h5L10 22l8.5-11h-5z"/>',
  drop: '<path d="M12 3s6 6.4 6 10a6 6 0 0 1-12 0c0-3.6 6-10 6-10z"/>',
  roller: '<rect x="3" y="4" width="12" height="5" rx="1"/><path d="M15 6.5h5v5h-8v3"/><rect x="9" y="18" width="3" height="3" rx="1"/>',
  pencil: '<path d="M4 20h4l10-10a2.8 2.8 0 0 0-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
  ruler: '<path d="m3 15 12-12 6 6L9 21z"/><path d="m7 11 2 2M10 8l2 2M13 5l2 2"/>',
  wallet: '<path d="M3 7a2 2 0 0 1 2-2h13a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M21 9h-5a3 3 0 0 0 0 6h5"/>',
  cube: '<path d="m12 2.5 8.5 4.8v9.4L12 21.5l-8.5-4.8V7.3z"/><path d="m3.5 7.3 8.5 4.9 8.5-4.9M12 12.2v9.3"/>',
  printer: '<path d="M6 9V3h12v6"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="7" rx="1"/>',
  download: '<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M4 20h16"/>',
  upload: '<path d="M12 21V9"/><path d="m7 14 5-5 5 5"/><path d="M4 4h16"/>',
  camera: '<path d="M4 7h3l1.5-3h7L17 7h3a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1z"/><circle cx="12" cy="13" r="3.4"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13"/>',
};

function icon(name, cls = 'ic') {
  return `<svg viewBox="0 0 24 24" class="${cls}">${ICONS[name] || ICONS.file}</svg>`;
}
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function parseDate(s) {
  if (!s) return null;
  const d = new Date(String(s).length <= 10 ? s + 'T00:00:00' : s);
  return isNaN(d.getTime()) ? null : d;
}
function fmtDate(s) {
  const d = parseDate(s);
  return d ? d.toLocaleDateString('lt-LT', { year: 'numeric', month: '2-digit', day: '2-digit' }) : '—';
}
function fmtDateShort(s) {
  const d = parseDate(s);
  return d ? d.toLocaleDateString('lt-LT', { month: '2-digit', day: '2-digit' }) : '—';
}
function fmtDateLong(s) {
  const d = parseDate(s);
  return d ? d.toLocaleDateString('lt-LT', { year: 'numeric', month: 'long', day: 'numeric' }) : 'Be datos';
}
function fmtDateTime(s) {
  const d = parseDate(s);
  return d ? d.toLocaleString('lt-LT', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—';
}
function fmtSize(n) {
  n = Number(n) || 0;
  if (n >= 1048576) return (n / 1048576).toFixed(1) + ' MB';
  if (n >= 1024) return Math.round(n / 1024) + ' KB';
  return n + ' B';
}
function fmtNum(n) {
  const v = Math.round((Number(n) || 0) * 100) / 100;
  return v.toLocaleString('lt-LT', { maximumFractionDigits: 2 });
}
function fmtEur(n) {
  return (Number(n) || 0).toLocaleString('lt-LT', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
}
function numAttr(n) {
  const v = Math.round((Number(n) || 0) * 100) / 100;
  return v ? String(v) : '';
}
function posWord(n) {
  n = Math.abs(Number(n) || 0);
  if (n % 10 === 1 && n % 100 !== 11) return 'pozicija';
  if (n % 10 >= 2 && n % 10 <= 9 && !(n % 100 >= 11 && n % 100 <= 19)) return 'pozicijos';
  return 'pozicijų';
}
function todayISO() {  return (S.data && S.data.today) || new Date().toISOString().slice(0, 10);
}
function addDaysISO(iso, days) {
  const d = new Date((iso || todayISO()) + 'T12:00:00');
  d.setDate(d.getDate() + (Number(days) || 0));
  return d.toISOString().slice(0, 10);
}
function dayDiff(due) {
  if (!due) return null;
  const a = new Date(due + 'T00:00:00');
  const b = new Date(todayISO() + 'T00:00:00');
  return Math.round((a - b) / 86400000);
}
function dueLabel(due) {
  const d = dayDiff(due);
  if (d == null) return '';
  if (d < 0) return `vėluoja ${-d} d.`;
  if (d === 0) return 'šiandien';
  if (d === 1) return 'rytoj';
  return `po ${d} d.`;
}
function isLate(due) { const d = dayDiff(due); return d != null && d < 0; }
function snipHtml(s) {
  return esc(s).replace(/\u0001/g, '<mark>').replace(/\u0002/g, '</mark>');
}
const collator = new Intl.Collator('lt', { numeric: true, sensitivity: 'base' });

/* ============ state ============ */
const S = {
  data: null,
  docs: [],
  tasks: [],
  issues: [],
  notes: [],
  checklist: [],
  works: [],
  problems: null,
  sig: '',
  view: 'apzvalga',
  searchQ: '',
  searchData: null,
  showAll: {},
  docsUI: { q: '', disc: '', ext: '', sort: 'date' },
  journalUI: { kind: '', status: '' },
  worksUI: { q: '', stage: '', status: '' },
  actsData: null,
  actsUI: { contract: 0 },
  problemsUI: { type: '', section: '' },
  photoDate: '',
  paletteSel: 0,
  paletteItems: [],
  dragging: false,
};

/* ============ api ============ */
async function api(path, method = 'GET', body = null) {
  const opts = { method, headers: {} };
  if (body) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const res = await fetch('/api/' + path, opts);
  let data = {};
  try { data = await res.json(); } catch (e) { data = {}; }
  if (!res.ok) throw new Error(data.error || ('Klaida (' + res.status + ')'));
  return data;
}
async function loadAll() {
  const [st, t, i, n, c, p] = await Promise.all([
    api('state'), api('tasks'), api('issues'), api('notes'), api('checklist'),
    api('problems').catch(() => null),
  ]);
  S.data = st;
  S.docs = st.docs || [];
  S.tasks = t.tasks || [];
  S.issues = i.issues || [];
  S.notes = n.notes || [];
  S.checklist = c.checklist || [];
  S.works = st.works || [];
  S.problems = p || S.problems;
  S.sig = st.dataSig || S.sig;
  updateChrome();
}

/* ============ toast / modal ============ */
function toast(msg, kind = 'ok') {
  const root = $('#toasts');
  const el = document.createElement('div');
  el.className = 'toast ' + kind;
  el.textContent = msg;
  root.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .25s'; }, 2600);
  setTimeout(() => el.remove(), 3000);
}
function openModal(html, opts = {}) {
  const root = $('#modalRoot');
  root.innerHTML = `<div class="modal-backdrop"><div class="modal ${opts.wide ? 'wide' : ''}" role="dialog" aria-modal="true">${html}</div></div>`;
  root.classList.add('open');
  const backdrop = $('.modal-backdrop', root);
  backdrop.addEventListener('mousedown', e => { if (e.target === backdrop) closeModal(); });
  $$('[data-close]', root).forEach(b => { b.onclick = closeModal; });
  return root;
}
function closeModal() {
  dwgRevoke();
  dwgAbort();
  const root = $('#modalRoot');
  root.classList.remove('open');
  root.innerHTML = '';
}
function formValues(form) {
  const out = {};
  new FormData(form).forEach((v, k) => { out[k] = v; });
  return out;
}

/* ============ chrome ============ */
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme === 'dark' ? 'dark' : 'light';
  localStorage.setItem('stabas-theme', theme);
}
function updateChrome() {
  const d = S.data;
  if (!d) return;
  const c = d.counts || {};
  $('#navDocs').textContent = c.docCount || '';
  const navPhotos = $('#navPhotos');
  if (navPhotos) navPhotos.textContent = c.photoCount || '';
  $('#navTasks').textContent = c.tasksOpen || '';
  $('#navIssues').textContent = c.issuesOpen || '';
  $('#navCheck').textContent = c.checklistOpen || '';
  const navP = $('#navProblems');
  if (navP) {
    const pc = S.problems?.summary?.problems || 0;
    navP.textContent = pc || '';
    navP.title = pc ? `${pc} ${problemWord(pc)} · ${S.problems.summary.checks} patikros` : '';
  }
  const ws = d.worksSummary || {};
  [['#navElektra', 'elektra'], ['#navApdaila', 'apdaila'], ['#navSantechnika', 'santechnika'], ['#navFasadas', 'fasadas']].forEach(([sel, key]) => {
    const el = $(sel);
    if (!el) return;
    const info = ws[key] || {};
    el.textContent = info.remaining || '';
    el.title = info.total ? `${info.total} ${posWord(info.total)} · ${info.done} atlikta` : '';
  });
  $('#brandSub').textContent = d.project.address || 'projektų valdymas';
  const psName = $('#psName'), psAddr = $('#psAddr');
  if (psName) psName.textContent = d.project.name || 'Projektas';
  if (psAddr) psAddr.textContent = d.project.address || ((d.projects || []).length + ' projektai');
  const st = d.status || {};
  const dot = $('#indexDot');
  const txt = $('#indexText');
  const sub = $('#indexSub');
  const bar = $('#indexBar');
  dot.className = 'dot';
  if (st.scanning) {
    dot.classList.add('busy');
    txt.textContent = 'Skenuojami failai…';
    sub.textContent = 'Tikrinami katalogai';
    bar.style.width = '100%';
    bar.style.opacity = '.45';
  } else if (st.indexing) {
    dot.classList.add('busy');
    txt.textContent = `Indeksuojama ${st.indexDone}/${st.indexTotal}`;
    sub.textContent = st.indexCurrent || '';
    const pct = st.indexTotal ? Math.round(st.indexDone / st.indexTotal * 100) : 0;
    bar.style.width = pct + '%';
    bar.style.opacity = '1';
  } else {
    txt.textContent = 'Paruošta';
    sub.textContent = `${c.docCount || 0} dokumentai · ${st.texted || 0} su tekstu` + (st.lastScan ? ' · ' + fmtDateTime(st.lastScan) : '');
    bar.style.width = '100%';
    bar.style.opacity = '0';
  }
  const cp = $('#crumbSub');
  if (cp) cp.textContent = d.project.name || '';
}

/* ============ routing ============ */
function setActiveNav(view) {
  $$('#nav .nav-item').forEach(a => a.classList.toggle('active', a.dataset.view === view));
  $('#crumbText').textContent = VIEW_TITLES[view] || 'Apžvalga';
  const sub = $('#crumbSub');
  if (sub && S.data) sub.textContent = S.data.project.name || '';
}
function go(view) {
  if (location.hash === '#' + view) {
    if (view === 'paieska') { const inp = $('#globalSearch'); if (inp) inp.focus(); }
    return;
  }
  location.hash = '#' + view;
}
async function route() {
  const hash = (location.hash || '#apzvalga').slice(1);
  S.view = VIEW_TITLES[hash] ? hash : 'apzvalga';
  setActiveNav(S.view);
  closeSidebar();
  try {
    await loadAll();
    render();
  } catch (e) {
    $('#view').innerHTML = `<div class="card pad"><div class="empty"><b>Nepavyko įkelti duomenų</b>${esc(e.message)}</div></div>`;
  }
}
function render() {
  if (!S.data) return;
  updateChrome();
  const v = $('#view');
  switch (S.view) {
    case 'dokumentai': renderDocuments(v); break;
    case 'fotofiksacija': renderPhotos(v); break;
    case 'paieska': renderSearch(v); break;
    case 'elektra':
    case 'apdaila':
    case 'santechnika':
    case 'fasadas': renderWorks(v, S.view); break;
    case 'aktai': renderActs(v); break;
    case 'problemos': renderProblems(v); break;
    case 'uzduotys': renderTasks(v); break;
    case 'zurnalas': renderJournal(v); break;
    case 'susitikimai': renderNotes(v); break;
    case 'kontrolinis': renderChecklist(v); break;
    case 'nustatymai': renderSettings(v); break;
    default: renderOverview(v);
  }
}

/* ============ shared snippets ============ */
function extClass(ext) {
  const e = (ext || '').toLowerCase();
  if (e === '.pdf') return 'pdf';
  if (e === '.dwg') return 'dwg';
  if (e === '.ifc') return 'ifc';
  if (e === '.adoc') return 'adoc';
  if (e === '.txt') return 'txt';
  return 'other';
}
function extLabel(ext) {
  return (ext || '').replace('.', '').toUpperCase() || 'FILE';
}
function fileIcon(doc) {
  return `<span class="file-ico ${extClass(doc.ext)}">${esc(extLabel(doc.ext))}</span>`;
}
function textBadge(doc) {
  if (doc.textState === 'done' && doc.textLen > 0) {
    if (doc.meta && doc.meta.ocr === true) return `<span class="chip green" title="Tekstas atpažintas iš skenavimo (OCR), ${doc.textLen} simbolių">OCR</span>`;
    return `<span class="chip green" title="${doc.textLen || 0} simbolių">Tekstas</span>`;
  }
  if (doc.textState === 'done') {
    if (doc.meta && doc.meta.ocr === 'none') return '<span class="chip gray" title="Teksto atpažinti nepavyko">Be teksto</span>';
    return '<span class="chip gray" title="PDF be teksto sluoksnio (skaitmenintas brėžinys)">Be teksto</span>';
  }
  if (doc.textState === 'error') return '<span class="chip red" title="Nepavyko ištraukti teksto">Klaida</span>';
  if (doc.textState === 'pending') return '<span class="chip amber">Laukia</span>';
  return '<span class="chip gray" title="Šio tipo failo tekstas neindeksuojamas">Be teksto</span>';
}
function priorityChip(p) {
  const cls = { 'Žema': 'gray', 'Normali': 'blue', 'Aukšta': 'amber', 'Kritinė': 'red' }[p] || 'gray';
  return `<span class="chip ${cls}">${esc(p || 'Normali')}</span>`;
}
function issueStatusChip(st) {
  const cls = { 'Atvira': 'red', 'Laukiama': 'amber', 'Uždaryta': 'green' }[st] || 'gray';
  return `<span class="chip ${cls}">${esc(st || '')}</span>`;
}
function kindChip(k) {
  const cls = { 'Klausimas': 'blue', 'Pastaba': 'amber', 'RFI': 'purple', 'Kliūtis': 'red' }[k] || 'gray';
  return `<span class="chip ${cls}">${esc(k || 'Pastaba')}</span>`;
}
function docRow(d) {
  return `<tr data-doc="${d.id}">
    <td><div class="name">${fileIcon(d)}<div><span>${esc(d.name)}</span><small>${esc(d.rel)}</small></div></div></td>
    <td><span class="chip disc">${esc(d.disc)}</span></td>
    <td class="row-muted">${fmtDate(d.date)}</td>
    <td class="num-col row-muted">${d.pages == null ? '—' : d.pages}</td>
    <td class="num-col row-muted">${fmtSize(d.size)}</td>
    <td>${textBadge(d)}</td>
  </tr>`;
}

/* ============ overview ============ */
function renderOverview(v) {
  const d = S.data;
  const p = d.project;
  const c = d.counts;
  const st = d.status;
  const att = d.attention;
  const indexing = st.scanning || st.indexing;

  const attItems = [];
  (att.overdueTasks || []).forEach(t => attItems.push({ kind: 'task', id: t.id, cls: 'overdue', ic: 'clock', title: t.title, sub: [`Terminas ${fmtDate(t.due)}`, dueLabel(t.due)], late: true }));
  (att.urgentIssues || []).forEach(i => attItems.push({ kind: 'issue', id: i.id, cls: 'overdue', ic: 'alert', title: i.title, sub: [`P-${String(i.num).padStart(3, '0')}`, i.priority, i.disc], late: false }));
  (att.dueTasks || []).forEach(t => attItems.push({ kind: 'task', id: t.id, cls: 'soon', ic: 'calendar', title: t.title, sub: [`Terminas ${fmtDate(t.due)}`, dueLabel(t.due)], late: false }));
  (att.overdueIssues || []).forEach(i => attItems.push({ kind: 'issue', id: i.id, cls: 'overdue', ic: 'alert', title: i.title, sub: [`P-${String(i.num).padStart(3, '0')}`, 'vėluoja', fmtDate(i.due)], late: true }));

  const discRows = (d.discs || []).map(ds => `
    <tr>
      <td><div class="disc-name"><span class="chip disc">${esc(ds.code)}</span><div class="disc-text"><span title="${esc(ds.name)}">${esc(ds.name)}</span><small>${fmtDate(ds.latest)}</small></div></div></td>
      <td class="num-col">${ds.files ? `<button type="button" class="disc-files" data-disc-files="${esc(ds.code)}" title="Atidaryti dalies failus">${ds.files}</button>` : '<span class="faint">0</span>'}</td>
      <td><select class="mini-select ${DISC_STATUS_CLASS[ds.status] || ''}" data-disc-status="${esc(ds.code)}">
        ${(d.discStatuses || []).map(s => `<option ${s === ds.status ? 'selected' : ''}>${esc(s)}</option>`).join('')}
      </select></td>
      <td><input class="mini-input" data-disc-owner="${esc(ds.code)}" value="${esc(ds.owner)}" placeholder="Atsakingas" title="Atsakingas asmuo"></td>
    </tr>`).join('');

  const factRows = [
    ['Statytojas / užsakovas', p.client],
    ['Projektuotojas', p.designer],
    ['Projekto Nr.', p.project_no],
    ['Statybos leidimas', p.permit_no ? p.permit_no + (p.permit_date ? ' · ' + fmtDate(p.permit_date) : '') : ''],
    ['Stadija', p.stage],
    ['Adresas', p.address],
  ].filter(row => row[1] && String(row[1]).trim());
  const heroFacts = factRows.length
    ? `<div class="facts">${factRows.map(row => `<div><span>${esc(row[0])}</span><b>${esc(row[1])}</b></div>`).join('')}</div>`
    : `<div class="sub" style="opacity:.72;margin-top:10px">Projekto rekvizitai dar nenurodyti – įrašykite juos skiltyje „Nustatymai“.</div>`;
  const bp = [
    [p.plotis, 'plotis · m'],
    [p.gylis, 'gylis · m'],
    [p.aukstis, 'aukštis · m'],
    [p.langai, 'langai'],
    [p.fasadopoz, 'fasado pozicijos'],
  ].filter(row => row[0] && String(row[0]).trim());
  const bpRail = bp.length
    ? `<div class="bp-rail" title="Pastato matmenys pagal projekto rekvizitus">${bp.map((row, i) => `${i ? '<span class="bp-rule"></span>' : ''}<span class="bp-node"><b>${esc(row[0])}</b><small>${esc(row[1])}</small></span>`).join('')}</div>`
    : '';

  v.innerHTML = `
    ${indexing ? `<div class="banner"><span class="spinner"></span><span>${st.scanning ? 'Skenuojami projekto failai…' : `Indeksuojamas tekstas: ${esc(st.indexCurrent || '')} (${st.indexDone}/${st.indexTotal})`}</span></div>` : ''}
    <section class="hero">
      <div class="hero-top">
        <div>
          <div class="eyebrow">Aktyvus projektas</div>
          <h1>${esc(p.name)}</h1>
          ${p.full_name && p.full_name !== p.name ? `<div class="sub">${esc(p.full_name)}</div>` : ''}
        </div>
        <div class="hero-actions">
          <button class="btn ghost small" data-act="rescan">${icon('refresh')} Atnaujinti failus</button>
          <button class="btn primary small" data-act="docs">${icon('file')} Dokumentai</button>
        </div>
      </div>
      ${heroFacts}
      ${bpRail}
    </section>

    <div class="kpis">
      <div class="card kpi" data-go="dokumentai">
        <div class="k-top"><span class="k-icon">${icon('file')}</span>Dokumentai</div>
        <div class="num">${c.docCount}</div>
        <div class="sub">${c.discCount} dalys · ${st.texted} su tekstu</div>
      </div>
      <div class="card kpi" data-go="uzduotys">
        <div class="k-top"><span class="k-icon ${c.tasksOverdue ? 'warn' : ''}">${icon('tasks')}</span>Atviros užduotys</div>
        <div class="num">${c.tasksOpen}</div>
        <div class="sub">${c.tasksOverdue ? `<b>${c.tasksOverdue} vėluoja</b>` : 'Viskas pagal planą'}</div>
      </div>
      <div class="card kpi" data-go="zurnalas">
        <div class="k-top"><span class="k-icon ${c.issuesOpen ? 'danger' : 'ok'}">${icon('alert')}</span>Problemos ir klausimai</div>
        <div class="num">${c.issuesOpen}</div>
        <div class="sub">${c.issuesUrgent ? `<b>${c.issuesUrgent} aukštas prioritetas</b>` : 'Kritinių nėra'}</div>
      </div>
      <div class="card kpi" data-go="kontrolinis">
        <div class="k-top"><span class="k-icon ${c.checklistOpen ? 'warn' : 'ok'}">${icon('check')}</span>Kontrolinis sąrašas</div>
        <div class="num">${c.checklistOpen}</div>
        <div class="sub">neatlikti punktai</div>
      </div>
    </div>

    <div class="grid-2 section">
      <section class="card pad">
        <div class="card-head"><h2>Dalių kontrolė</h2><div class="spacer"></div><span class="chip gray">${c.discCount} aktyvios</span></div>
        <div class="table-wrap">
          <table class="table disc-table">
            <thead><tr><th>Dalis</th><th>Failai</th><th>Būsena</th><th>Atsakingas</th></tr></thead>
            <tbody>${discRows}</tbody>
          </table>
        </div>
      </section>
      <section class="card pad">
        <div class="card-head"><h2>Reikia dėmesio</h2><div class="spacer"></div>
          <button class="btn small" data-act="new-task">${icon('plus')} Užduotis</button>
        </div>
        <div class="attention-list">
          ${attItems.length ? attItems.slice(0, 8).map(a => `
            <div class="att-item ${a.cls}" data-kind="${a.kind}" data-id="${a.id}">
              <span class="att-ico">${icon(a.ic)}</span>
              <div class="att-body">
                <div class="att-title">${esc(a.title)}</div>
                <div class="att-sub">${a.sub.filter(Boolean).map((x, idx) => idx === a.sub.length - 1 && a.late ? `<span class="late">${esc(x)}</span>` : `<span>${esc(x)}</span>`).join('<span>·</span>')}</div>
              </div>
              ${icon('chevron', 'ic faint')}
            </div>`).join('') : `<div class="empty"><b>Viskas kontroliuojama</b>Nėra vėluojančių užduočių ar kritinių klausimų.</div>`}
        </div>
      </section>
    </div>

    <section class="card pad section">
      <div class="card-head"><h2>Naujausi dokumentai</h2><div class="spacer"></div>
        <button class="btn small" data-go="dokumentai">Visi dokumentai ${icon('chevron')}</button>
      </div>
      <div class="recent-list">
        ${(d.recent || []).map(x => `
          <div class="recent-row" data-doc="${x.id}">
            ${fileIcon(x)}
            <div class="r-main">
              <div class="r-name">${esc(x.name)}</div>
              <div class="r-sub">${esc(x.discName)} · ${esc(x.rel)}</div>
            </div>
            <div class="r-date">${fmtDate(x.date)}</div>
          </div>`).join('') || '<div class="empty">Dokumentų dar nerasta.</div>'}
      </div>
    </section>`;

  v.querySelectorAll('[data-go]').forEach(el => el.onclick = () => go(el.dataset.go));
  v.querySelectorAll('[data-act="docs"]').forEach(el => el.onclick = () => go('dokumentai'));
  v.querySelectorAll('[data-act="rescan"]').forEach(el => el.onclick = rescan);
  v.querySelectorAll('[data-act="new-task"]').forEach(el => el.onclick = () => taskModal(null));
  v.querySelectorAll('[data-doc]').forEach(el => el.onclick = () => openDoc(el.dataset.doc));
  v.querySelectorAll('.att-item').forEach(el => el.onclick = () => {
    if (el.dataset.kind === 'task') taskModal(el.dataset.id);
    else issueModal(el.dataset.id);
  });
  v.querySelectorAll('[data-disc-files]').forEach(btn => {
    btn.onclick = () => {
      S.docsUI.q = '';
      S.docsUI.disc = btn.dataset.discFiles;
      S.docsUI.ext = '';
      S.docsUI.sort = 'date';
      go('dokumentai');
    };
  });
  v.querySelectorAll('[data-disc-status]').forEach(sel => {
    sel.onchange = async () => {
      try {
        await api('disc/' + encodeURIComponent(sel.dataset.discStatus), 'PATCH', { status: sel.value });
        toast('Dalių būsena atnaujinta');
        await loadAll();
        render();
      } catch (e) { toast(e.message, 'err'); }
    };
  });
  v.querySelectorAll('[data-disc-owner]').forEach(inp => {
    inp.onchange = async () => {
      try {
        await api('disc/' + encodeURIComponent(inp.dataset.discOwner), 'PATCH', { owner: inp.value });
        toast('Atsakingas atnaujintas');
        await loadAll();
      } catch (e) { toast(e.message, 'err'); }
    };
  });
}

/* ============ documents ============ */
function filteredDocs() {
  const ui = S.docsUI;
  const q = ui.q.trim().toLowerCase();
  let list = S.docs.slice();
  if (ui.disc) list = list.filter(d => d.disc === ui.disc);
  if (ui.ext) list = list.filter(d => (d.ext || '') === ui.ext);
  if (q) list = list.filter(d => (d.name + ' ' + d.rel + ' ' + d.discName).toLowerCase().includes(q));
  if (ui.sort === 'name') list.sort((a, b) => collator.compare(a.name, b.name));
  else if (ui.sort === 'size') list.sort((a, b) => b.size - a.size);
  else list.sort((a, b) => String(b.date || b.fileDate || '').localeCompare(String(a.date || a.fileDate || '')) || collator.compare(a.name, b.name));
  return list;
}
function renderDocuments(v) {
  const discs = Array.from(new Set(S.docs.map(d => d.disc))).sort((a, b) => {
    const order = S.data.discs.map(x => x.code);
    return order.indexOf(a) - order.indexOf(b);
  });
  const exts = Array.from(new Set(S.docs.map(d => d.ext))).sort();
  v.innerHTML = `
    <div class="page-head">
      <div><h1>Dokumentų registras</h1><p>Visi projekto failai pagal dalis. Spustelėkite eilutę – atsidarys peržiūra. Failus galima įkelti iš kompiuterio arba nutempti į šią lentelę.</p></div>
      <div class="spacer"></div>
      <button class="btn primary" id="uploadDocs">${icon('plus')} Įkelti failus</button>
      <input type="file" id="uploadInput" multiple hidden>
      <button class="btn" id="classifyDocs" title="Pagal failo pavadinimą priskirti dalims">${icon('inbox')} Išskirstyti įkeltus</button>
      <button class="btn" id="exportDocs">${icon('external')} Eksportuoti CSV</button>
      <button class="btn" id="rescanDocs">${icon('refresh')} Atnaujinti</button>
    </div>
    <div class="card pad" id="docsCard">
      <div class="toolbar">
        <div class="search-big" style="flex:1;min-width:220px;position:relative">
          <svg viewBox="0 0 24 24" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:1.8;color:var(--faint)"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
          <input class="input" id="docSearch" placeholder="Filtruoti pagal pavadinimą arba kelią…" value="${esc(S.docsUI.q)}" style="padding-left:38px">
        </div>
        <select class="select" id="docDisc">
          <option value="">Visos dalys</option>
          ${discs.map(d => `<option value="${esc(d)}" ${S.docsUI.disc === d ? 'selected' : ''}>${esc(d)} — ${esc((S.data.discs.find(x => x.code === d) || {}).name || (d === 'Įkelti' ? 'Įkelti failai' : d))}</option>`).join('')}
        </select>
        <select class="select" id="docSort">
          <option value="date" ${S.docsUI.sort === 'date' ? 'selected' : ''}>Pagal datą</option>
          <option value="name" ${S.docsUI.sort === 'name' ? 'selected' : ''}>Pagal pavadinimą</option>
          <option value="size" ${S.docsUI.sort === 'size' ? 'selected' : ''}>Pagal dydį</option>
        </select>
        <span class="chip gray" id="docsCount"></span>
      </div>
      <div class="doc-chips" id="docChips"></div>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>Failas</th><th>Dalis</th><th>Data</th><th style="text-align:right">Lapai</th><th style="text-align:right">Dydis</th><th>Tekstas</th></tr></thead>
          <tbody id="docsBody"></tbody>
        </table>
      </div>
    </div>`;

  const redraw = () => {
    const list = filteredDocs();
    $('#docsBody').innerHTML = list.length
      ? list.map(docRow).join('')
      : `<tr><td colspan="6"><div class="empty"><b>Nieko nerasta</b>Pakeiskite filtrą arba atnaujinkite failus.</div></td></tr>`;
    $('#docsCount').textContent = `${list.length} / ${S.docs.length}`;
  };
  redraw();

  const chipsEl = $('#docChips');
  const extCounts = new Map();
  S.docs.forEach(d => extCounts.set(d.ext, (extCounts.get(d.ext) || 0) + 1));
  const chipOrder = ['.pdf', '.dwg', '.ifc', '.adoc', '.txt'];
  const chipExts = [...chipOrder.filter(e => extCounts.has(e)), ...exts.filter(e => !chipOrder.includes(e))];
  chipsEl.innerHTML = [
    `<button type="button" class="doc-chip" data-doc-ext="">Visi tipai <b>${S.docs.length}</b></button>`,
    ...chipExts.map(e => `<button type="button" class="doc-chip" data-doc-ext="${esc(e)}">${esc(extLabel(e))} <b>${extCounts.get(e)}</b></button>`),
  ].join('');
  const syncChips = () => $$('[data-doc-ext]', chipsEl).forEach(b => b.classList.toggle('on', b.dataset.docExt === S.docsUI.ext));
  syncChips();
  chipsEl.onclick = e => {
    const b = e.target.closest('[data-doc-ext]');
    if (!b) return;
    S.docsUI.ext = b.dataset.docExt;
    syncChips();
    redraw();
  };

  $('#docSearch').oninput = e => { S.docsUI.q = e.target.value; redraw(); };
  $('#docDisc').onchange = e => { S.docsUI.disc = e.target.value; redraw(); };
  $('#docSort').onchange = e => { S.docsUI.sort = e.target.value; redraw(); };
  $('#rescanDocs').onclick = rescan;
  $('#classifyDocs').onclick = async () => {
    try {
      const out = await api('docs/classify', 'POST', {});
      await loadAll();
      render();
      toast(out.moved ? `Išskirstyta į dalis: ${out.moved}` : 'Įkeltų failų, kuriuos būtų galima išskirstyti, nerasta');
    } catch (e) { toast(e.message, 'err'); }
  };
  $('#exportDocs').onclick = () => window.open('/api/export?table=docs', '_blank');
  const uploadInput = $('#uploadInput');
  $('#uploadDocs').onclick = () => uploadInput.click();
  uploadInput.onchange = () => { uploadDocs(uploadInput.files); uploadInput.value = ''; };
  const dropCard = $('#docsCard');
  if (dropCard) {
    dropCard.addEventListener('dragover', e => { e.preventDefault(); dropCard.classList.add('drop-on'); });
    dropCard.addEventListener('dragleave', e => { if (!dropCard.contains(e.relatedTarget)) dropCard.classList.remove('drop-on'); });
    dropCard.addEventListener('drop', e => {
      e.preventDefault();
      dropCard.classList.remove('drop-on');
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) uploadDocs(e.dataTransfer.files);
    });
  }
  $('#docsBody').onclick = e => {
    const tr = e.target.closest('tr[data-doc]');
    if (tr) openDoc(tr.dataset.doc);
  };
}

async function uploadDocs(files) {
  const list = Array.from(files || []).filter(Boolean);
  if (!list.length) return;
  const btn = $('#uploadDocs');
  const label = btn ? btn.innerHTML : '';
  const errors = [];
  let done = 0;
  for (let i = 0; i < list.length; i++) {
    const f = list[i];
    if (btn) btn.textContent = `Įkeliama ${i + 1}/${list.length}…`;
    try {
      const res = await fetch('/api/upload?name=' + encodeURIComponent(f.name), {
        method: 'POST',
        headers: { 'Content-Type': 'application/octet-stream' },
        body: f,
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error || 'Nepavyko įkelti');
      done++;
    } catch (err) {
      errors.push(`${f.name}: ${err.message}`);
    }
  }
  if (btn) { btn.disabled = false; btn.innerHTML = label; }
  if (done) {
    await loadAll();
    render();
    toast(done === 1 ? 'Failas įkeltas į dokumentus' : `Įkelta failų: ${done}`);
  }
  if (errors.length) toast(errors[0], 'err', 8000);
}

/* ============ fotofiksacija ============ */
function photoWord(n) {
  if (n === 1) return 'nuotrauka';
  if (n % 10 >= 2 && n % 10 <= 9 && !(n % 100 >= 11 && n % 100 <= 19)) return 'nuotraukos';
  return 'nuotraukų';
}

function renderPhotos(v) {
  const photos = (S.data && S.data.photos) || [];
  const today = (S.data && S.data.today) || new Date().toISOString().slice(0, 10);
  if (!S.photoDate) S.photoDate = today;
  const byDate = new Map();
  photos.forEach(ph => {
    const key = ph.date || '';
    if (!byDate.has(key)) byDate.set(key, []);
    byDate.get(key).push(ph);
  });
  const groupsHtml = Array.from(byDate.entries()).map(([date, list]) => `
    <section class="photo-group">
      <div class="photo-date"><b>${fmtDateLong(date)}</b><span>${list.length} ${photoWord(list.length)}</span></div>
      <div class="photo-grid">
        ${list.map(ph => `
          <figure class="photo-card" data-photo="${ph.id}" title="${esc(ph.caption || ph.name)}">
            <img src="${ph.url}" alt="${esc(ph.caption || ph.name)}" loading="lazy" decoding="async">
            <figcaption>${ph.caption ? `<b>${esc(ph.caption)}</b>` : esc(ph.name)}</figcaption>
          </figure>`).join('')}
      </div>
    </section>`).join('');

  v.innerHTML = `
    <div class="page-head"><div><h1>Fotofiksacija</h1><p>Objekto nuotraukos pagal datas. Pasirinkite datą ir įkelkite nuotraukas – jos bus išdėstytos chronologiškai.</p></div></div>
    <section class="card pad photo-panel">
      <div class="photo-controls">
        <div class="field"><label>Data</label><input class="input" type="date" id="photoDate" value="${esc(S.photoDate)}"></div>
        <div class="field photo-caption"><label>Aprašymas (neprivaloma)</label><input class="input" id="photoCaption" maxlength="500" placeholder="Pvz. Šiaurinis fasadas, cokolis, įėjimas"></div>
        <button class="btn primary" id="photoUploadBtn">${icon('plus')} Įkelti nuotraukas</button>
        <input type="file" id="photoInput" accept="image/jpeg,image/png,image/webp,image/gif,image/bmp,.jpg,.jpeg,.jfif,.png,.webp,.gif,.bmp" multiple hidden>
      </div>
      <div class="photo-drop" id="photoDrop">Nutempkite nuotraukas čia arba spauskite „Įkelti nuotraukas“. Jos bus priskirtos pasirinktai datai.</div>
    </section>
    ${photos.length ? groupsHtml : `<div class="card pad section"><div class="empty">${icon('camera')}<b>Nuotraukų dar nėra</b>Pasirinkite datą ir įkelkite pirmąsias objekto nuotraukas.</div></div>`}
  `;

  const dateInput = $('#photoDate');
  if (dateInput) dateInput.onchange = () => { S.photoDate = dateInput.value || today; };
  const input = $('#photoInput');
  $('#photoUploadBtn').onclick = () => input.click();
  input.onchange = () => { if (input.files && input.files.length) uploadPhotos(input.files); };

  const drop = $('#photoDrop');
  if (drop) {
    drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('drop-on'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('drop-on'));
    drop.addEventListener('drop', e => {
      e.preventDefault();
      drop.classList.remove('drop-on');
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) uploadPhotos(e.dataTransfer.files);
    });
  }
  v.onclick = e => {
    const fig = e.target.closest('figure[data-photo]');
    if (fig) openPhoto(Number(fig.dataset.photo));
  };
}

async function uploadPhotos(files) {
  const allowed = /\.(jpe?g|jfif|png|webp|gif|bmp)$/i;
  const list = Array.from(files || []).filter(f => f && allowed.test(f.name));
  const btn = $('#photoUploadBtn');
  const label = btn ? btn.innerHTML : '';
  if (!list.length) { toast('Pasirinkite JPG, PNG, WEBP, GIF arba BMP nuotraukas', 'err'); return; }
  const dateVal = ($('#photoDate') && $('#photoDate').value) || (S.data && S.data.today);
  if (dateVal) S.photoDate = dateVal;
  const caption = (($('#photoCaption') && $('#photoCaption').value) || '').trim();
  const errors = [];
  let done = 0;
  if (btn) btn.disabled = true;
  for (let i = 0; i < list.length; i++) {
    const f = list[i];
    if (btn) btn.textContent = `Įkeliama ${i + 1}/${list.length}…`;
    if (f.size > 40 * 1024 * 1024) { errors.push(`${f.name}: didesnė nei 40 MB`); continue; }
    try {
      const url = '/api/photos/upload?name=' + encodeURIComponent(f.name)
        + '&date=' + encodeURIComponent(dateVal || '')
        + '&caption=' + encodeURIComponent(caption);
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/octet-stream' },
        body: f,
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error || 'Nepavyko įkelti');
      done++;
    } catch (err) {
      errors.push(`${f.name}: ${err.message}`);
    }
  }
  if (btn) { btn.disabled = false; btn.innerHTML = label; }
  if (done) {
    await loadAll();
    render();
    toast(done === 1 ? 'Nuotrauka įkelta' : `Įkelta nuotraukų: ${done}`);
  }
  if (errors.length) toast(errors[0], 'err', 8000);
}

function openPhoto(id) {
  const ph = ((S.data && S.data.photos) || []).find(x => x.id === id);
  if (!ph) return;
  openModal(`
    <div class="modal-head"><h3>${esc(ph.caption || ph.name)}</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
    <div class="modal-body photo-modal">
      <div class="photo-full-wrap"><img class="photo-full" src="${ph.url}" alt="${esc(ph.caption || ph.name)}"></div>
      <div class="form-grid">
        <div class="field"><label>Data</label><input class="input" type="date" id="photoEditDate" value="${esc(ph.date)}"></div>
        <div class="field"><label>Failas</label><input class="input" value="${esc(ph.name)}" disabled></div>
        <div class="field full"><label>Aprašymas</label><input class="input" id="photoEditCaption" maxlength="500" value="${esc(ph.caption)}" placeholder="Pvz. Cokolis, šiaurinis fasadas"></div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn danger" id="photoDelete">${icon('trash')} Ištrinti</button>
      <div class="spacer"></div>
      <button class="btn" data-close>Atšaukti</button>
      <button class="btn primary" id="photoSave">${icon('check')} Išsaugoti</button>
    </div>`, { wide: true });
  $('#photoSave').onclick = async () => {
    try {
      await api('photos/' + ph.id, 'PATCH', {
        date: $('#photoEditDate').value || '',
        caption: $('#photoEditCaption').value || '',
      });
      closeModal(); await loadAll(); render(); toast('Nuotrauka atnaujinta');
    } catch (e) { toast(e.message, 'err'); }
  };
  $('#photoDelete').onclick = async () => {
    if (!confirm('Ištrinti šią nuotrauką?')) return;
    try {
      await api('photos/' + ph.id, 'DELETE');
      closeModal(); await loadAll(); render(); toast('Nuotrauka ištrinta');
    } catch (e) { toast(e.message, 'err'); }
  };
}

/* ============ doc modal ============ */
function discSelectHtml(current) {
  const list = (S.data.discs || []).map(d => ({ code: d.code, name: d.name || d.code }));
  if (current && !list.some(x => x.code === current)) list.push({ code: current, name: current });
  return list.map(x => `<option value="${esc(x.code)}" ${x.code === current ? 'selected' : ''}>${esc(x.code)} — ${esc(x.name)}</option>`).join('');
}

async function openDoc(id, page = 1) {
  dwgRevoke();
  dwgAbort();
  try {
    const { doc } = await api('doc/' + id);
    const meta = doc.meta || {};
    const previewable = doc.ext === '.pdf' || doc.ext === '.adoc';
    const isDwg = doc.ext === '.dwg';
    const src = `/api/file/${doc.id}?v=${encodeURIComponent(doc.mtime || '')}#page=${page}`;
    const adocBox = (meta.signer || meta.signed || meta.reg_no) ? `
      <div class="adoc-box">
        <div class="a-title">Skaitmeninis parašas (ADOC)</div>
        ${meta.title ? `<div><span>Dokumentas:</span> ${esc(meta.title)}</div>` : ''}
        ${meta.signer ? `<div><span>Pasirašė:</span> ${esc(meta.signer)}</div>` : ''}
        ${meta.signed ? `<div><span>Data:</span> ${fmtDateTime(meta.signed)}</div>` : ''}
        ${meta.reg_no ? `<div><span>Reg. Nr.:</span> ${esc(meta.reg_no)}</div>` : ''}
      </div>` : '';
    const previewHtml = previewable
      ? `<div class="doc-view"><iframe id="docFrame" src="${src}" title="${esc(doc.name)}"></iframe></div>`
      : isDwg
        ? `<div class="doc-view dwg-view">
          <div class="dwg-bar">
            <div class="dwg-status" id="dwgStatus"><span class="spinner"></span> Skaitomas DWG brėžinys…</div>
            <span class="dwg-elapsed" id="dwgElapsed" hidden></span>
            <div class="dwg-tools" id="dwgTools" hidden>
              <button class="btn small ghost" id="dwgOut" title="Mažinti">−</button>
              <span class="dwg-zoom" id="dwgZoom">100%</span>
              <button class="btn small ghost" id="dwgIn" title="Didinti">+</button>
              <input type="range" id="dwgSlider" class="dwg-slider" min="0" max="100" step="1" value="31" title="Mastelis" aria-label="Mastelis">
              <button class="btn small ghost" id="dwgFit">Talpinti</button>
              <button class="btn small ghost" id="dwgThumb" hidden title="Perjungti vektorinį vaizdą ir išsaugotą miniatiūrą">Miniatiūra</button>
              <button class="btn small ghost" id="dwgSave" title="Išsaugoti brėžinį SVG formatu">SVG</button>
            </div>
            <div class="dwg-prog" id="dwgProg" hidden><i id="dwgProgFill"></i></div>
          </div>
          <div class="dwg-stage" id="dwgStage"><img id="dwgImg" alt="${esc(doc.name)}"></div>
          <p class="dwg-note">Brėžinys atvaizduotas vietoje iš DWG failo. Kai kurie CAD elementai (matmenys, štrichuotės, rėmeliai) gali būti nevisiškai tikslūs.</p>
        </div>`
        : `<div class="doc-view"><div class="no-prev">${fileIcon(doc)}
          <div style="color:#fff;font-weight:600;font-size:14px">${esc(extLabel(doc.ext))} failas</div>
          <p>Šio tipo failams peržiūra naršyklėje neteikiama. Atidarykite jį numatytojoje programoje.</p>
          <button class="btn primary" id="openBig">${icon('external')} Atidaryti failą</button>
        </div></div>`;

    openModal(`
      <div class="modal-head">
        <span class="chip disc">${esc(doc.disc)}</span>
        <h3 title="${esc(doc.name)}">${esc(doc.name)}</h3>
        <button class="icon-btn" data-close aria-label="Uždaryti">${icon('x')}</button>
      </div>
      <div class="doc-layout">
        ${previewHtml}
        <aside class="doc-side">
          ${adocBox}
          ${previewable ? `<div class="page-jump">
            <input class="input" id="jumpPage" type="number" min="1" value="${page}" title="Lapo numeris">
            <button class="btn" id="goPage">Eiti į lapą</button>
          </div>` : ''}
          <h4>Informacija</h4>
          <div class="doc-meta">
            <div class="mrow"><span>Dalis</span>
              <select class="select disc-sel" id="docDiscSel" title="Priskirti dokumentą daliai">
                ${discSelectHtml(doc.disc)}
              </select></div>
            <div class="mrow"><span>Failas</span><b>${esc(doc.name)}</b></div>
            <div class="mrow"><span>Katalogas</span><b>${esc(doc.rel)}</b></div>
            <div class="mrow"><span>Dokumento data</span><b>${fmtDate(doc.date)}</b></div>
            <div class="mrow"><span>Failo data</span><b>${fmtDateTime(doc.mtime)}</b></div>
            <div class="mrow"><span>Lapai</span><b>${doc.pages == null ? '—' : doc.pages}</b></div>
            <div class="mrow"><span>Dydis</span><b>${fmtSize(doc.size)}</b></div>
            <div class="mrow"><span>Tekstas</span><b>${doc.textState === 'done' ? (doc.meta && doc.meta.ocr === true ? 'Atpažinta (OCR, ' : 'Indeksuota (') + (doc.textLen || 0).toLocaleString('lt-LT') + ' simb.)' : doc.textState === 'error' ? 'Klaida' : doc.textState === 'pending' ? 'Laukia eilėje' : 'Neindeksuojama'}</b></div>
          </div>
          <h4>Veiksmai</h4>
          <div class="doc-actions">
            <button class="btn" data-act="open">${icon('external')} Atidaryti numatytoje programoje</button>
            <button class="btn" data-act="reveal">${icon('folder')} Atidaryti aplanką</button>
            <button class="btn" data-act="copy">${icon('copy')} Kopijuoti kelią</button>
            <button class="btn" data-act="reindex">${icon('refresh')} Indeksuoti iš naujo</button>
          </div>
        </aside>
      </div>`, { wide: true });

    const acts = {
      open: async () => { await api('open', 'POST', { id: doc.id }); toast('Atidaroma…'); },
      reveal: async () => { await api('reveal', 'POST', { id: doc.id }); toast('Atidarytas aplankas'); },
      copy: async () => {
        try { await navigator.clipboard.writeText(doc.path); toast('Kelias nukopijuotas'); }
        catch (e) { toast('Nepavyko nukopijuoti', 'err'); }
      },
      reindex: async () => { await api('reindex', 'POST', { id: doc.id }); toast('Indeksavimas pradėtas'); },
    };
    $$('.doc-actions [data-act]').forEach(b => b.onclick = () => acts[b.dataset.act]().catch(err => toast(err.message, 'err')));
    const discSel = $('#docDiscSel');
    if (discSel) discSel.onchange = async () => {
      const val = discSel.value;
      discSel.disabled = true;
      try {
        const out = await api('doc/' + doc.id + '/disc', 'POST', { disc: val });
        await loadAll();
        const chip = document.querySelector('#modalRoot .modal-head .chip.disc');
        if (chip) chip.textContent = out.disc;
        render();
        toast('Dalis: ' + out.disc + ' — ' + out.discName);
      } catch (err) {
        discSel.value = doc.disc;
        toast(err.message, 'err');
      } finally {
        discSel.disabled = false;
      }
    };
    const ob = $('#openBig');
    if (ob) ob.onclick = () => acts.open().catch(err => toast(err.message, 'err'));
    const goPage = $('#goPage');
    if (goPage) goPage.onclick = () => {
      const n = Math.max(1, parseInt($('#jumpPage').value || '1', 10) || 1);
      $('#docFrame').src = `/api/file/${doc.id}?v=${Date.now()}#page=${n}`;
    };
    if (previewable) $('#jumpPage').addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); goPage.click(); }
    });
    if (isDwg) initDwgView(doc);
  } catch (e) {
    toast(e.message, 'err');
  }
}

/* ============ DWG peržiūra ============ */
let dwgWorker = null;
let dwgSeq = 0;
let dwgLastUrl = null;
let dwgLastThumbUrl = null;
let dwgProgTimer = null;
const dwgPending = new Map();

function dwgProgStop() {
  if (dwgProgTimer) {
    clearInterval(dwgProgTimer);
    dwgProgTimer = null;
  }
}

function dwgRevoke() {
  dwgProgStop();
  [dwgLastUrl, dwgLastThumbUrl].forEach(url => {
    if (url) {
      try { URL.revokeObjectURL(url); } catch (e) { /* jau atlaisvintas */ }
    }
  });
  dwgLastUrl = null;
  dwgLastThumbUrl = null;
}

function dwgAbort() {
  dwgProgStop();
  if (!dwgPending.size) return;
  dwgPending.clear();
  if (dwgWorker) {
    try { dwgWorker.terminate(); } catch (e) { /* jau sustabdytas */ }
    dwgWorker = null;
  }
}

function dwgWorkerGet() {
  if (dwgWorker) return dwgWorker;
  try {
    dwgWorker = new Worker('/dwg-worker.js', { type: 'module' });
  } catch (e) {
    return null;
  }
  dwgWorker.onmessage = e => {
    const cb = dwgPending.get(e.data && e.data.id);
    if (cb) {
      if (!e.data.preview && !e.data.progress) dwgPending.delete(e.data.id);
      cb(e.data);
    }
  };
  dwgWorker.onerror = e => {
    const msg = (e && e.message) || 'DWG variklio klaida';
    dwgPending.forEach(cb => cb({ ok: false, error: msg }));
    dwgPending.clear();
    try { dwgWorker.terminate(); } catch (err) { /* jau sustabdytas */ }
    dwgWorker = null;
  };
  return dwgWorker;
}

function dwgCacheStore(id, svg, thumb) {
  if (!svg || svg.length < 100) return Promise.resolve(false);
  return fetch('/api/dwg-cache/' + id, {
    method: 'POST',
    headers: { 'Content-Type': 'image/svg+xml; charset=utf-8' },
    body: svg,
  }).then(r => r.ok).catch(() => false).then(ok => {
    if (thumb && thumb.buffer) {
      fetch('/api/dwg-cache/' + id + '?kind=thumb', {
        method: 'POST',
        headers: { 'Content-Type': thumb.mime || 'application/octet-stream' },
        body: thumb.buffer,
      }).catch(() => {});
    }
    return ok;
  });
}

let dwgWarmBusy = false;
let dwgWarmStop = false;
async function warmDwgCache(btn) {
  if (dwgWarmBusy) {
    dwgWarmStop = true;
    toast('Stabdoma po dabartinio brėžinio…');
    return;
  }
  const dwgs = (S.docs || []).filter(d => d.ext === '.dwg');
  if (!dwgs.length) { toast('DWG brėžinių nerasta'); return; }
  let entries = {};
  try {
    const st = await fetch('/api/dwg-cache/status', { cache: 'no-store' }).then(r => r.json());
    entries = st.entries || {};
  } catch (e) { /* podėlis nepasiekiamas – ruošiame viską */ }
  const todo = dwgs.filter(d => !entries[String(d.id)]);
  if (!todo.length) { toast('Visų brėžinių peržiūros jau paruoštos'); return; }

  dwgWarmBusy = true;
  dwgWarmStop = false;
  const label = btn ? btn.innerHTML : '';
  const worker = new Worker('/dwg-worker.js', { type: 'module' });
  const pending = new Map();
  let seq = 0;
  worker.onmessage = e => {
    const cb = pending.get(e.data && e.data.id);
    if (cb) {
      if (!e.data.preview && !e.data.progress) pending.delete(e.data.id);
      cb(e.data);
    }
  };
  const convert = doc => new Promise(resolve => {
    const id = ++seq;
    let thumb = null;
    const timer = setTimeout(() => { pending.delete(id); resolve({ error: 'Laikas baigėsi' }); }, 240000);
    pending.set(id, msg => {
      if (msg.preview) { if (msg.thumb) thumb = msg.thumb; return; }
      if (msg.progress) return;
      clearTimeout(timer);
      resolve(msg.ok ? { svg: msg.svg, thumb } : { error: msg.error || 'Nepavyko' });
    });
    worker.postMessage({ id, url: `/api/file/${doc.id}?v=${encodeURIComponent(doc.mtime || '')}` });
  });
  const modalOpen = () => !!document.querySelector('#modalRoot.open');
  let ok = 0;
  let fail = 0;
  let stopped = false;
  try {
    for (let i = 0; i < todo.length; i++) {
      while (modalOpen() && !dwgWarmStop) await new Promise(r => setTimeout(r, 600));
      if (dwgWarmStop) { stopped = true; break; }
      if (btn && btn.isConnected) btn.innerHTML = `${icon('x')} Stabdyti (${i + 1}/${todo.length})`;
      const res = await convert(todo[i]);
      if (res.svg) {
        ok++;
        await dwgCacheStore(todo[i].id, res.svg, res.thumb);
      } else {
        fail++;
      }
    }
  } finally {
    worker.terminate();
    dwgWarmBusy = false;
    if (btn && btn.isConnected) btn.innerHTML = label;
  }
  toast(stopped ? `Sustabdyta: paruošta ${ok}` : `Paruošta ${ok} brėžinių${fail ? `, nepavyko ${fail}` : ''}`, fail ? 'err' : 'ok');
}

function svgViewBox(svg) {
  const m = /viewBox="\s*([^"]+)\s*"/.exec(svg);
  if (!m) return null;
  const parts = m[1].trim().split(/[\s,]+/).map(Number);
  return parts.length === 4 && parts.every(n => isFinite(n)) ? parts : null;
}

function tightenSvgViewBox(svgText) {
  if (svgText.length > 8e6) return null;
  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;left:-100000px;top:0;width:1200px;height:800px;visibility:hidden;pointer-events:none';
  document.body.appendChild(host);
  try {
    host.innerHTML = svgText;
    const svg = host.querySelector('svg');
    const g = svg && svg.querySelector(':scope > g');
    if (!g) return null;
    const b = g.getBBox();
    if (!(b.width > 0) || !(b.height > 0) || !isFinite(b.width) || !isFinite(b.height)) return null;
    const box = [b.x, -b.y - b.height, b.width, b.height];
    const attr = box.map(n => +n.toFixed(3)).join(' ');
    const out = svgText.replace(/viewBox="[^"]*"/, `viewBox="${attr}"`);
    return out === svgText ? null : { svg: out, box };
  } catch (e) {
    return null;
  } finally {
    host.remove();
  }
}

function initDwgView(doc) {
  const status = $('#dwgStatus');
  const tools = $('#dwgTools');
  const stage = $('#dwgStage');
  const img = $('#dwgImg');
  const thumbBtn = $('#dwgThumb');
  const slider = $('#dwgSlider');
  if (!status || !tools || !stage || !img) return;

  let svgText = '';
  let fitPct = 100;
  let zoom = 100;
  let vRatio = 1;
  let mode = 'vector';
  let thumb = null;
  let cachedSrc = null;

  const progEl = $('#dwgProg');
  const progFill = $('#dwgProgFill');
  const elapsedEl = $('#dwgElapsed');
  const startedAt = performance.now();
  const PHASES = {
    engine: { label: 'Kraunamas DWG variklis', from: 4, to: 12, tau: 1.4 },
    download: { label: 'Siunčiamas failas', from: 12, to: 45, tau: 3 },
    parse: { label: 'Skaitoma DWG failo struktūra', from: 45, to: 60, tau: 1.5 },
    convert: { label: 'Kuriamas vektorinis vaizdas', from: 60, to: 88, tau: 3 },
    svg: { label: 'Baigiamas brėžinys', from: 88, to: 97, tau: 1.6 },
  };
  let statusMode = 'progress';
  let progDone = false;
  let phase = 'engine';
  let phaseStart = startedAt;
  let phaseFrom = 4;
  let phaseTo = 12;
  let phaseTau = 1.4;
  let downPct = null;
  let lastPct = 4;
  const setStatus = html => { statusMode = 'custom'; status.innerHTML = html; };

  const setPhase = name => {
    const def = PHASES[name];
    if (!def || progDone) return;
    phase = name;
    phaseStart = performance.now();
    phaseFrom = Math.max(lastPct, def.from);
    phaseTo = def.to;
    phaseTau = name === 'convert'
      ? Math.max(2, Math.min(18, (doc.size || 2e6) / 3.2e6))
      : def.tau;
    if (name === 'download') downPct = null;
    if (statusMode === 'progress') status.innerHTML = '<span class="spinner"></span> ' + def.label + '…';
    tickProg();
  };

  const tickProg = () => {
    if (progDone || !progEl || progEl.hidden) return;
    const t = (performance.now() - phaseStart) / 1000;
    let pct;
    if (phase === 'download' && downPct != null) pct = phaseFrom + (phaseTo - phaseFrom) * (downPct / 100);
    else pct = phaseFrom + (phaseTo - phaseFrom) * (1 - Math.exp(-t / phaseTau));
    pct = Math.max(lastPct, Math.min(pct, phaseTo - 0.1));
    lastPct = pct;
    progFill.style.width = pct.toFixed(1) + '%';
    if (elapsedEl) {
      elapsedEl.textContent = Math.round(pct) + '% · ' + ((performance.now() - startedAt) / 1000).toFixed(1).replace('.', ',') + ' s';
    }
  };

  const progFinish = () => {
    if (progDone) return;
    progDone = true;
    dwgProgStop();
    if (progFill) progFill.style.width = '100%';
    if (elapsedEl) {
      elapsedEl.textContent = '100% · ' + ((performance.now() - startedAt) / 1000).toFixed(1).replace('.', ',') + ' s';
      setTimeout(() => { elapsedEl.hidden = true; }, 1400);
    }
    if (progEl) setTimeout(() => { progEl.hidden = true; }, 800);
  };

  const ZMIN = 40;
  const ZMAX = 800;
  const zoomToSlider = z => Math.round(Math.log(Math.max(ZMIN, z) / ZMIN) / Math.log(ZMAX / ZMIN) * 100);
  const sliderToZoom = v => ZMIN * Math.pow(ZMAX / ZMIN, v / 100);
  const applyZoom = (syncSlider = true) => {
    zoom = Math.max(ZMIN, Math.min(ZMAX, zoom));
    img.style.width = zoom + '%';
    img.style.margin = zoom > 100 ? '0' : '0 auto';
    $('#dwgZoom').textContent = Math.round(zoom) + '%';
    if (slider && syncSlider) slider.value = zoomToSlider(zoom);
  };
  const zoomFit = () => {
    const w = stage.clientWidth || 1;
    const h = stage.clientHeight || 1;
    fitPct = Math.min(100, Math.max(20, (h * vRatio / w) * 100));
    zoom = fitPct;
    applyZoom();
  };
  const showThumb = (note, ready = true) => {
    if (!thumb) return false;
    if (!dwgLastThumbUrl) dwgLastThumbUrl = URL.createObjectURL(new Blob([thumb.buffer], { type: thumb.mime }));
    mode = 'thumb';
    img.onerror = null;
    img.onload = () => { fitPct = 100; zoom = 100; applyZoom(); };
    img.style.maxWidth = 'none';
    img.style.maxHeight = 'none';
    img.src = dwgLastThumbUrl;
    tools.hidden = false;
    if (thumbBtn) { thumbBtn.hidden = !ready; thumbBtn.textContent = 'Vektorinis'; }
    status.innerHTML = note || 'Rodoma išsaugota DWG miniatiūra. Spauskite „Vektorinis“ tikslesniam vaizdui.';
    statusMode = 'custom';
    return true;
  };
  const showVector = (note, onReady) => {
    if (!dwgLastUrl && !cachedSrc) return false;
    mode = 'vector';
    img.onerror = () => {
      if (thumb && showThumb('Vektorinio brėžinio parodyti nepavyko, rodoma miniatiūra.', false)) return;
      if (onReady) { onReady(false); return; }
      setStatus('Brėžinio parodyti naršyklėje nepavyko.');
      stage.innerHTML = '<div class="dwg-empty">Brėžinio parodyti nepavyko.<br>Failą atidarykite aplanke.</div>';
      tools.hidden = true;
    };
    img.onload = () => { img.onerror = null; zoomFit(); if (onReady) onReady(true); };
    img.style.maxWidth = 'none';
    img.style.maxHeight = 'none';
    img.src = dwgLastUrl || cachedSrc;
    tools.hidden = false;
    if (thumbBtn) { thumbBtn.hidden = !thumb; thumbBtn.textContent = 'Miniatiūra'; }
    if (note) setStatus(note);
    return true;
  };

  $('#dwgIn').onclick = () => { zoom *= 1.25; applyZoom(); };
  $('#dwgOut').onclick = () => { zoom /= 1.25; applyZoom(); };
  if (slider) slider.oninput = () => { zoom = sliderToZoom(+slider.value); applyZoom(false); };
  $('#dwgFit').onclick = () => {
    zoom = fitPct;
    applyZoom();
    stage.scrollTop = 0;
    stage.scrollLeft = 0;
  };
  if (thumbBtn) thumbBtn.onclick = () => {
    if (mode === 'thumb') showVector('Vektorinis DWG vaizdas.');
    else showThumb();
  };
  $('#dwgSave').onclick = () => {
    if (!svgText) return;
    const blob = new Blob([svgText], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = doc.name.replace(/\.dwg$/i, '') + '.svg';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const startConversion = () => {
    progDone = false;
    lastPct = 4;
    phase = 'engine';
    phaseFrom = 4;
    phaseTo = 12;
    downPct = null;
    statusMode = 'progress';
    const worker = dwgWorkerGet();
    if (!worker) {
      setStatus('<b>Naršyklė nepalaiko DWG peržiūros.</b> Atidarykite failą aplanke.');
      return;
    }

    dwgProgStop();
    if (progEl) progEl.hidden = false;
    if (elapsedEl) { elapsedEl.hidden = false; elapsedEl.textContent = '0% · 0,0 s'; }
    dwgProgTimer = setInterval(tickProg, 200);
    setPhase('engine');

    const id = ++dwgSeq;
    dwgPending.set(id, msg => {
      if (msg.progress) {
        if (msg.phase === 'download') {
          if (typeof msg.pct === 'number') {
            if (phase !== 'download') setPhase('download');
            downPct = msg.pct;
          }
        } else {
          setPhase(msg.phase);
        }
        return;
      }
      if (msg.preview) {
        if (msg.thumb) {
          thumb = msg.thumb;
          if (mode !== 'thumb') showThumb('<span class="spinner"></span> Rodoma miniatiūra, ruošiamas vektorinis vaizdas…', false);
        }
        return;
      }
      if (!msg.ok) {
        progFinish();
        if (thumb && showThumb('Vektorinės peržiūros paruošti nepavyko, rodoma išsaugota miniatiūra.', false)) return;
        setStatus(esc(msg.error || 'Brėžinio atvaizduoti nepavyko.'));
        stage.innerHTML = '<div class="dwg-empty">Brėžinio atvaizduoti nepavyko.<br>Failą atidarykite aplanke.</div>';
        tools.hidden = true;
        return;
      }
      let box = msg.viewBox;
      const rough = box && box[3] ? Math.abs(box[2] / box[3]) : 1;
      const odd = rough > 40 || rough < 0.025;
      svgText = msg.svg;
      if (odd) {
        const tight = tightenSvgViewBox(msg.svg);
        if (tight) { svgText = tight.svg; box = tight.box; }
      }
      vRatio = box && box[3] ? Math.abs(box[2] / box[3]) : 1;
      if (dwgLastUrl) {
        try { URL.revokeObjectURL(dwgLastUrl); } catch (e) { /* jau atlaisvintas */ }
        dwgLastUrl = null;
      }
      progFinish();
      if (statusMode === 'progress') status.innerHTML = '<span class="spinner"></span> Išsaugoma peržiūra…';
      const note = thumb
        ? 'Rodoma išsaugota miniatiūra. Spauskite „Vektorinis“ detalesniam vaizdui.'
        : `Brėžinys paruoštas${msg.ms ? ' per ' + (msg.ms / 1000).toLocaleString('lt-LT', { maximumFractionDigits: 1 }) + ' s' : ''}.`;
      const cacheUrl = `/api/dwg-cache/${doc.id}?v=${encodeURIComponent(doc.mtime || '')}`;
      const show = () => {
        if (!status.isConnected) return;
        if (thumb) showThumb(note);
        else showVector(note);
      };
      Promise.race([
        dwgCacheStore(doc.id, svgText, thumb),
        new Promise(r => setTimeout(() => r(false), 3000)),
      ]).then(ok => {
        if (!status.isConnected) return;
        if (ok) {
          cachedSrc = cacheUrl;
        } else {
          dwgLastUrl = URL.createObjectURL(new Blob([svgText], { type: 'image/svg+xml' }));
        }
        show();
      });
    });
    worker.postMessage({ id, url: `/api/file/${doc.id}?v=${encodeURIComponent(doc.mtime || '')}` });
  };

  status.innerHTML = '<span class="spinner"></span> Tikrinama išsaugota peržiūra…';
  const cacheBase = `/api/dwg-cache/${doc.id}`;
  Promise.all([
    fetch(cacheBase, { cache: 'no-store' }).then(r => (r.ok ? r.text() : null)).catch(() => null),
    fetch(cacheBase + '?kind=thumb', { cache: 'no-store' }).then(r => (r.ok ? r.blob() : null)).catch(() => null),
  ]).then(([svg, thumbBlob]) => {
    if (!status.isConnected) return;
    if (!svg || svg.indexOf('<svg') < 0) { startConversion(); return; }
    const box = svgViewBox(svg);
    svgText = svg;
    vRatio = box && box[3] ? Math.abs(box[2] / box[3]) : 1;
    cachedSrc = `${cacheBase}?v=${encodeURIComponent(doc.mtime || '')}`;
    const secs = ((performance.now() - startedAt) / 1000).toFixed(1).replace('.', ',');
    if (thumbBlob && thumbBlob.size) {
      thumb = { buffer: thumbBlob, mime: thumbBlob.type || 'image/png' };
      progFinish();
      showThumb(`Išsaugota peržiūra įkelta per ${secs} s. Spauskite „Vektorinis“ tikslesniam vaizdui.`, true);
      return;
    }
    showVector('', ok => {
      if (!ok) { startConversion(); return; }
      progFinish();
      setStatus(`Išsaugota peržiūra įkelta per ${secs} s.`);
    });
  }).catch(() => { if (status.isConnected) startConversion(); });
}

/* ============ search ============ */
function renderSearch(v) {
  const hints = ['statybos leidimas', 'energinis naudingumas', 'pamatai', 'stogas', 'ventiliacija', 'nuotekos'];
  v.innerHTML = `
    <div class="page-head">
      <div><h1>Paieška dokumentų turinyje</h1><p>Ieškoma PDF, ADOC, TXT, IFC turinyje ir DWG brėžinių tekste. Veikia ir be diakritikų.</p></div>
    </div>
    <div class="card pad">
      <div class="search-big">
        <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
        <input class="input" id="globalSearch" placeholder="Įveskite žodį, pvz., „hidroizoliacija“, „armatūra“, „leidimas“…" value="${esc(S.searchQ)}" autocomplete="off">
      </div>
      <div class="search-hints">${hints.map(h => `<button data-q="${esc(h)}">${esc(h)}</button>`).join('')}</div>
    </div>
    <div id="searchResults" class="section"></div>`;
  const inp = $('#globalSearch');
  let timer = null;
  inp.oninput = () => {
    S.searchQ = inp.value;
    clearTimeout(timer);
    timer = setTimeout(() => doSearch(), 280);
  };
  v.querySelectorAll('[data-q]').forEach(b => b.onclick = () => { inp.value = b.dataset.q; S.searchQ = b.dataset.q; doSearch(); inp.focus(); });
  if (S.searchQ.trim().length >= 2) doSearch();
  else $('#searchResults').innerHTML = `<div class="card pad"><div class="empty"><b>Pradėkite paiešką</b>Įrašykite bent 2 simbolius. Paieška apima PDF, ADOC, TXT, IFC tekstą ir DWG brėžinių užrašus.</div></div>`;
  setTimeout(() => { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); }, 30);
}
async function doSearch() {
  const q = S.searchQ.trim();
  const box = $('#searchResults');
  if (!box) return;
  if (q.length < 2) {
    box.innerHTML = `<div class="card pad"><div class="empty">Įrašykite bent 2 simbolius.</div></div>`;
    return;
  }
  box.innerHTML = `<div class="card pad"><div class="empty">Ieškoma…</div></div>`;
  try {
    const data = await api('search?q=' + encodeURIComponent(q));
    S.searchData = data;
    renderSearchResults(data);
  } catch (e) {
    box.innerHTML = `<div class="card pad"><div class="empty">${esc(e.message)}</div></div>`;
  }
}
function renderSearchResults(data) {
  const box = $('#searchResults');
  if (!box) return;
  const groups = new Map();
  (data.pages || []).forEach(h => {
    if (!groups.has(h.docId)) groups.set(h.docId, { doc: h, hits: [] });
    groups.get(h.docId).hits.push(h);
  });
  const namePart = data.docs && data.docs.length ? `
    <div class="search-group">
      <div class="search-head" style="cursor:default">
        ${icon('file')}<span class="s-name">Failų pavadinimai (${data.docs.length})</span>
      </div>
      ${data.docs.map(d => `
        <div class="hit" data-doc="${d.id}" data-page="1">
          <span class="page">${esc(extLabel(d.ext))}</span>
          <div><div style="font-weight:550;font-size:12.8px">${esc(d.name)}</div><div class="snip">${esc(d.discName)} · ${esc(d.rel)}</div></div>
        </div>`).join('')}
    </div>` : '';
  const groupPart = Array.from(groups.values()).map(g => {
    const showAll = S.showAll[g.doc.docId];
    const hits = showAll ? g.hits : g.hits.slice(0, 4);
    return `<div class="search-group">
      <div class="search-head" data-doc="${g.doc.docId}" data-page="${g.hits[0].page}">
        <span class="chip disc">${esc(g.doc.disc)}</span>
        <span class="s-name">${esc(g.doc.name)}</span>
        <span class="s-meta">${g.hits.length} atitikmen${g.hits.length === 1 ? 'is' : 'ai'}</span>
        ${icon('chevron')}
      </div>
      ${hits.map(h => `
        <div class="hit" data-doc="${g.doc.docId}" data-page="${h.page}">
          <span class="page">${g.doc.ext === '.dwg' ? 'Brėžinys' : 'Lap. ' + h.page}</span>
          <div class="snip">${snipHtml(h.snippet)}</div>
        </div>`).join('')}
      ${g.hits.length > 4 ? `<div class="more-hits" data-more="${g.doc.docId}">${showAll ? 'Rodyti mažiau' : `Rodyti visus (${g.hits.length})`}</div>` : ''}
    </div>`;
  }).join('');
  const total = (data.pages || []).length;
  box.innerHTML = `
    <div class="muted" style="font-size:12px;margin-bottom:10px">Rasta ${total} teksto atitikmenų${data.truncated ? ' (rodomi pirmi 240)' : ''}${data.docs && data.docs.length ? ` · ${data.docs.length} failų pagal pavadinimą` : ''}</div>
    ${namePart}${groupPart || (!namePart ? `<div class="card pad"><div class="empty"><b>Nieko nerasta</b>Pabandykite trumpesnį žodį, kitą formą arba be galūnės.</div></div>` : '')}`;
  $$('.hit, .search-head[data-doc]', box).forEach(el => el.onclick = () => openDoc(el.dataset.doc, parseInt(el.dataset.page || '1', 10)));
  $$('[data-more]', box).forEach(el => el.onclick = e => {
    e.stopPropagation();
    S.showAll[el.dataset.more] = !S.showAll[el.dataset.more];
    renderSearchResults(data);
  });
}

/* ============ tasks ============ */
function renderTasks(v) {
  const by = { todo: [], doing: [], done: [] };
  S.tasks.forEach(t => { (by[t.status] || by.todo).push(t); });
  const card = t => {
    const late = isLate(t.due) && t.status !== 'done';
    const initials = (t.assignee || '').trim().split(/\s+/).filter(Boolean).map(x => x[0]).slice(0, 2).join('').toUpperCase();
    return `<div class="task-card prio-${esc(t.priority)} ${t.status === 'done' ? 'done' : ''}" draggable="true" data-task="${t.id}">
      <div class="t-title">${esc(t.title)}</div>
      ${t.due ? `<div class="t-due ${late ? 'late' : ''}">${icon('clock', 'ic')} ${fmtDate(t.due)} · ${esc(dueLabel(t.due))}</div>` : ''}
      <div class="t-meta">
        ${initials ? `<span class="avatar" title="${esc(t.assignee)}">${esc(initials)}</span>` : ''}
        ${t.assignee ? `<span>${esc(t.assignee)}</span>` : '<span>Nepaskirtas</span>'}
        <span style="margin-left:auto">${esc(t.priority)}</span>
      </div>
    </div>`;
  };
  v.innerHTML = `
    <div class="page-head">
      <div><h1>Užduotys</h1><p>Vilkite kortelę į kitą stulpelį, kad pakeistumėte būseną. Spustelėkite – redagavimas.</p></div>
      <div class="spacer"></div>
      <button class="btn primary" id="addTask">${icon('plus')} Nauja užduotis</button>
    </div>
    <div class="board">
      ${TASK_COLS.map(col => `
        <section class="board-col" data-col="${col.key}">
          <div class="board-head"><h3>${col.label}</h3><span class="count">${by[col.key].length}</span>
            <button class="add-col" data-add="${col.key}" title="Pridėti">+</button>
          </div>
          <div class="board-body" data-drop="${col.key}">
            ${by[col.key].map(card).join('') || `<div class="board-empty">Nėra užduočių</div>`}
          </div>
        </section>`).join('')}
    </div>`;
  $('#addTask').onclick = () => taskModal(null);
  v.querySelectorAll('[data-add]').forEach(b => b.onclick = () => taskModal(null, b.dataset.add));
  v.querySelectorAll('.task-card').forEach(el => {
    el.onclick = () => { if (!S.dragging) taskModal(el.dataset.task); };
    el.ondragstart = e => {
      S.dragging = true;
      e.dataTransfer.setData('text/plain', el.dataset.task);
      e.dataTransfer.effectAllowed = 'move';
      el.style.opacity = '.5';
    };
    el.ondragend = () => { S.dragging = false; el.style.opacity = ''; setTimeout(() => { S.dragging = false; }, 60); };
  });
  v.querySelectorAll('[data-drop]').forEach(col => {
    col.ondragover = e => { e.preventDefault(); col.closest('.board-col').classList.add('drag-over'); };
    col.ondragleave = () => col.closest('.board-col').classList.remove('drag-over');
    col.ondrop = async e => {
      e.preventDefault();
      col.closest('.board-col').classList.remove('drag-over');
      const id = e.dataTransfer.getData('text/plain');
      const status = col.dataset.drop;
      try {
        await api('tasks/' + id, 'PATCH', { status });
        await loadAll();
        render();
        toast('Užduotis perkelta');
      } catch (err) { toast(err.message, 'err'); }
    };
  });
}
function taskModal(id, presetStatus) {
  const t = id ? S.tasks.find(x => String(x.id) === String(id)) : null;
  const item = t || { status: presetStatus || 'todo', priority: 'Normali', title: '', desc: '', due: '', assignee: '' };
  openModal(`
    <div class="modal-head"><h3>${t ? 'Redaguoti užduotį' : 'Nauja užduotis'}</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
    <form id="taskForm" class="modal-body">
      <div class="form-grid">
        <div class="field full"><label>Pavadinimas</label><input class="input" name="title" required value="${esc(item.title)}" placeholder="Ką reikia padaryti?"></div>
        <div class="field full"><label>Aprašymas</label><textarea class="input" name="desc" placeholder="Detalės, nuorodos, pastabos…">${esc(item.desc)}</textarea></div>
        <div class="field"><label>Būsena</label><select class="select" name="status">
          ${TASK_COLS.map(c => `<option value="${c.key}" ${item.status === c.key ? 'selected' : ''}>${c.label}</option>`).join('')}
        </select></div>
        <div class="field"><label>Prioritetas</label><select class="select" name="priority">
          ${['Žema', 'Normali', 'Aukšta', 'Kritinė'].map(p => `<option ${item.priority === p ? 'selected' : ''}>${p}</option>`).join('')}
        </select></div>
        <div class="field"><label>Terminas</label><input class="input" type="date" name="due" value="${esc(item.due)}"></div>
        <div class="field"><label>Atsakingas</label><input class="input" name="assignee" value="${esc(item.assignee)}" placeholder="Vardas, pavardė"></div>
      </div>
    </form>
    <div class="modal-foot">
      ${t ? `<button class="btn danger" id="delTask">${icon('x')} Šalinti</button>` : ''}
      <div class="spacer"></div>
      <button class="btn" data-close>Atšaukti</button>
      <button class="btn primary" id="saveTask">Išsaugoti</button>
    </div>`);
  $('#saveTask').onclick = async () => {
    const form = $('#taskForm');
    if (!form.reportValidity()) return;
    const body = formValues(form);
    try {
      if (t) await api('tasks/' + t.id, 'PATCH', body);
      else await api('tasks', 'POST', body);
      closeModal();
      await loadAll();
      render();
      toast(t ? 'Užduotis atnaujinta' : 'Užduotis sukurta');
    } catch (e) { toast(e.message, 'err'); }
  };
  if (t) $('#delTask').onclick = async () => {
    if (!confirm('Pašalinti šią užduotį?')) return;
    try {
      await api('tasks/' + t.id, 'DELETE');
      closeModal(); await loadAll(); render(); toast('Užduotis pašalinta');
    } catch (e) { toast(e.message, 'err'); }
  };
}

/* ============ journal ============ */
function renderJournal(v) {
  const kinds = ['Pastaba', 'Klausimas', 'RFI', 'Kliūtis'];
  const statuses = ['Atvira', 'Laukiama', 'Uždaryta'];
  v.innerHTML = `
    <div class="page-head">
      <div><h1>Problemų ir klausimų žurnalas</h1><p>Fiksuokite pastabas, klausimus, RFI ir kliūtis – su terminais ir atsakingais.</p></div>
      <div class="spacer"></div>
      <button class="btn" id="exportIssues">${icon('external')} CSV</button>
      <button class="btn primary" id="addIssue">${icon('plus')} Naujas įrašas</button>
    </div>
    <div class="card pad">
      <div class="toolbar">
        <input class="input search" id="issueSearch" placeholder="Ieškoti žurnale…">
        <select class="select" id="issueKind"><option value="">Visi tipai</option>${kinds.map(k => `<option>${k}</option>`).join('')}</select>
        <select class="select" id="issueStatus"><option value="">Visos būsenos</option>${statuses.map(s => `<option>${s}</option>`).join('')}</select>
        <div class="spacer"></div>
        <span class="chip gray" id="issuesCount"></span>
      </div>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>Nr.</th><th>Tipas</th><th>Pavadinimas</th><th>Dalis</th><th>Prioritetas</th><th>Būsena</th><th>Terminas</th><th>Atsakingas</th></tr></thead>
          <tbody id="issuesBody"></tbody>
        </table>
      </div>
    </div>`;
  const draw = () => {
    const q = $('#issueSearch').value.trim().toLowerCase();
    const kf = $('#issueKind').value;
    const sf = $('#issueStatus').value;
    const list = S.issues.filter(i => {
      if (kf && i.kind !== kf) return false;
      if (sf && i.status !== sf) return false;
      if (q && !(i.title + ' ' + i.desc + ' ' + i.assignee).toLowerCase().includes(q)) return false;
      return true;
    });
    $('#issuesBody').innerHTML = list.length ? list.map(i => `
      <tr data-issue="${i.id}">
        <td class="row-muted mono">P-${String(i.num).padStart(3, '0')}</td>
        <td>${kindChip(i.kind)}</td>
        <td><div class="name"><div><span>${esc(i.title)}</span>${i.desc ? `<small>${esc(i.desc.slice(0, 90))}</small>` : ''}</div></div></td>
        <td>${i.disc ? `<span class="chip disc">${esc(i.disc)}</span>` : '—'}</td>
        <td>${priorityChip(i.priority)}</td>
        <td onclick="event.stopPropagation()"><select class="mini-select" data-issue-status="${i.id}">
          ${statuses.map(s => `<option ${i.status === s ? 'selected' : ''}>${s}</option>`).join('')}
        </select></td>
        <td class="${isLate(i.due) && i.status !== 'Uždaryta' ? 'row-muted' : 'row-muted'}">${i.due ? `<span class="${isLate(i.due) && i.status !== 'Uždaryta' ? 'chip red' : ''}">${fmtDate(i.due)}</span>` : '—'}</td>
        <td class="row-muted">${esc(i.assignee) || '—'}</td>
      </tr>`).join('') : `<tr><td colspan="8"><div class="empty"><b>Žurnalas tuščias</b>Pridėkite pirmą įrašą.</div></td></tr>`;
    $('#issuesCount').textContent = `${list.length} / ${S.issues.length}`;
    $('#issuesBody').onclick = e => {
      const tr = e.target.closest('tr[data-issue]');
      if (tr) issueModal(tr.dataset.issue);
    };
    $$('#issuesBody [data-issue-status]').forEach(sel => {
      sel.onclick = e => e.stopPropagation();
      sel.onchange = async e => {
        e.stopPropagation();
        try {
          await api('issues/' + sel.dataset.issueStatus, 'PATCH', { status: sel.value });
          await loadAll(); render(); toast('Būsena atnaujinta');
        } catch (err) { toast(err.message, 'err'); }
      };
    });
  };
  draw();
  $('#issueSearch').oninput = draw;
  $('#issueKind').onchange = draw;
  $('#issueStatus').onchange = draw;
  $('#addIssue').onclick = () => issueModal(null);
  $('#exportIssues').onclick = () => window.open('/api/export?table=issues', '_blank');
}
function issueModal(id) {
  const i = id ? S.issues.find(x => String(x.id) === String(id)) : null;
  const item = i || { kind: 'Pastaba', status: 'Atvira', priority: 'Normali', disc: '', title: '', desc: '', due: '', assignee: '' };
  const discs = S.data.discs.map(d => d.code);
  openModal(`
    <div class="modal-head"><h3>${i ? 'P-' + String(i.num).padStart(3, '0') + ' · Redaguoti įrašą' : 'Naujas žurnalo įrašas'}</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
    <form id="issueForm" class="modal-body">
      <div class="form-grid">
        <div class="field"><label>Tipas</label><select class="select" name="kind">
          ${['Pastaba', 'Klausimas', 'RFI', 'Kliūtis'].map(k => `<option ${item.kind === k ? 'selected' : ''}>${k}</option>`).join('')}
        </select></div>
        <div class="field"><label>Dalis</label><select class="select" name="disc">
          <option value="">—</option>
          ${discs.map(d => `<option value="${esc(d)}" ${item.disc === d ? 'selected' : ''}>${esc(d)}</option>`).join('')}
        </select></div>
        <div class="field full"><label>Pavadinimas</label><input class="input" name="title" required value="${esc(item.title)}" placeholder="Trumpai – kas negerai / ko klausiama"></div>
        <div class="field full"><label>Aprašymas</label><textarea class="input" name="desc" placeholder="Detalės, vieta, brėžinio lapas, nuorodos…">${esc(item.desc)}</textarea></div>
        <div class="field"><label>Būsena</label><select class="select" name="status">
          ${['Atvira', 'Laukiama', 'Uždaryta'].map(s => `<option ${item.status === s ? 'selected' : ''}>${s}</option>`).join('')}
        </select></div>
        <div class="field"><label>Prioritetas</label><select class="select" name="priority">
          ${['Žema', 'Normali', 'Aukšta', 'Kritinė'].map(p => `<option ${item.priority === p ? 'selected' : ''}>${p}</option>`).join('')}
        </select></div>
        <div class="field"><label>Terminas</label><input class="input" type="date" name="due" value="${esc(item.due)}"></div>
        <div class="field"><label>Atsakingas</label><input class="input" name="assignee" value="${esc(item.assignee)}" placeholder="Vardas, pavardė / įmonė"></div>
      </div>
    </form>
    <div class="modal-foot">
      ${i ? `<button class="btn danger" id="delIssue">${icon('x')} Šalinti</button>` : ''}
      <div class="spacer"></div>
      <button class="btn" data-close>Atšaukti</button>
      <button class="btn primary" id="saveIssue">Išsaugoti</button>
    </div>`);
  $('#saveIssue').onclick = async () => {
    const form = $('#issueForm');
    if (!form.reportValidity()) return;
    const body = formValues(form);
    try {
      if (i) await api('issues/' + i.id, 'PATCH', body);
      else await api('issues', 'POST', body);
      closeModal(); await loadAll(); render();
      toast(i ? 'Įrašas atnaujintas' : 'Įrašas pridėtas');
    } catch (e) { toast(e.message, 'err'); }
  };
  if (i) $('#delIssue').onclick = async () => {
    if (!confirm('Pašalinti šį įrašą?')) return;
    try {
      await api('issues/' + i.id, 'DELETE');
      closeModal(); await loadAll(); render(); toast('Įrašas pašalintas');
    } catch (e) { toast(e.message, 'err'); }
  };
}

/* ============ notes ============ */
function renderNotes(v) {
  v.innerHTML = `
    <div class="page-head">
      <div><h1>Susitikimų ir pokalbių užrašai</h1><p>Užfiksuokite susitikimų eigą, dalyvius ir susitarimus.</p></div>
      <div class="spacer"></div>
      <button class="btn primary" id="addNote">${icon('plus')} Naujas užrašas</button>
    </div>
    <div class="notes-grid">
      ${S.notes.length ? S.notes.map(n => `
        <article class="card note-card" data-note="${n.id}">
          <div class="n-date">${fmtDate(n.date)}</div>
          <h3>${esc(n.title)}</h3>
          <div class="n-body">${esc(n.body)}</div>
          ${n.attendees ? `<div class="n-people">${icon('users', 'ic')} ${esc(n.attendees)}</div>` : ''}
        </article>`).join('') : `<div class="card pad"><div class="empty"><b>Užrašų dar nėra</b>Pridėkite pirmą susitikimo užrašą.</div></div>`}
    </div>`;
  $('#addNote').onclick = () => noteModal(null);
  v.querySelectorAll('[data-note]').forEach(el => el.onclick = () => noteModal(el.dataset.note));
}
function noteModal(id) {
  const n = id ? S.notes.find(x => String(x.id) === String(id)) : null;
  const item = n || { date: todayISO(), title: '', attendees: '', body: '' };
  openModal(`
    <div class="modal-head"><h3>${n ? 'Redaguoti užrašą' : 'Naujas susitikimo užrašas'}</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
    <form id="noteForm" class="modal-body">
      <div class="form-grid">
        <div class="field"><label>Data</label><input class="input" type="date" name="date" value="${esc(item.date)}"></div>
        <div class="field"><label>Dalyviai</label><input class="input" name="attendees" value="${esc(item.attendees)}" placeholder="Kas dalyvavo"></div>
        <div class="field full"><label>Pavadinimas</label><input class="input" name="title" required value="${esc(item.title)}" placeholder="Susitikimo tema"></div>
        <div class="field full"><label>Užrašai</label><textarea class="input" name="body" style="min-height:220px" placeholder="Sprendimai, susitarimai, veiksmai…">${esc(item.body)}</textarea></div>
      </div>
    </form>
    <div class="modal-foot">
      ${n ? `<button class="btn danger" id="delNote">${icon('x')} Šalinti</button>` : ''}
      <div class="spacer"></div>
      <button class="btn" data-close>Atšaukti</button>
      <button class="btn primary" id="saveNote">Išsaugoti</button>
    </div>`);
  $('#saveNote').onclick = async () => {
    const form = $('#noteForm');
    if (!form.reportValidity()) return;
    const body = formValues(form);
    try {
      if (n) await api('notes/' + n.id, 'PATCH', body);
      else await api('notes', 'POST', body);
      closeModal(); await loadAll(); render();
      toast(n ? 'Užrašas atnaujintas' : 'Užrašas pridėtas');
    } catch (e) { toast(e.message, 'err'); }
  };
  if (n) $('#delNote').onclick = async () => {
    if (!confirm('Pašalinti šį užrašą?')) return;
    try {
      await api('notes/' + n.id, 'DELETE');
      closeModal(); await loadAll(); render(); toast('Užrašas pašalintas');
    } catch (e) { toast(e.message, 'err'); }
  };
}

/* ============ checklist ============ */
function renderChecklist(v) {
  const stages = [];
  S.checklist.forEach(it => {
    let st = stages.find(s => s.name === it.stage);
    if (!st) { st = { name: it.stage, items: [] }; stages.push(st); }
    st.items.push(it);
  });
  const total = S.checklist.length;
  const done = S.checklist.filter(x => x.done).length;
  const pctAll = total ? Math.round(done / total * 100) : 0;
  v.innerHTML = `
    <div class="page-head">
      <div><h1>Projekto kontrolinis sąrašas</h1><p>Etapai nuo parengiamųjų darbų iki statinio priėmimo. Pažymėkite atliktus punktus.</p></div>
      <div class="spacer"></div>
      <button class="btn" id="exportCheck">${icon('external')} CSV</button>
      <button class="btn primary" id="addCheck">${icon('plus')} Pridėti punktą</button>
    </div>
    <div class="card pad">
      <div class="stage-head" style="margin-bottom:16px">
        <h3>Bendra eiga</h3>
        <div class="bar"><div style="width:${pctAll}%"></div></div>
        <span class="pct">${done}/${total} · ${pctAll}%</span>
      </div>
      ${stages.map(st => {
        const dn = st.items.filter(x => x.done).length;
        const pct = st.items.length ? Math.round(dn / st.items.length * 100) : 0;
        return `<div class="stage">
          <div class="stage-head"><h3>${esc(st.name)}</h3><div class="bar"><div style="width:${pct}%"></div></div><span class="pct">${dn}/${st.items.length}</span>
            <button class="row-x" data-add-stage="${esc(st.name)}" title="Pridėti į šį etapą">+</button>
          </div>
          ${st.items.map(it => `
            <div class="check-item ${it.done ? 'done' : ''}">
              <input type="checkbox" data-check="${it.id}" ${it.done ? 'checked' : ''}>
              <div class="check-main" data-check-edit="${it.id}">
                <div class="c-title">${esc(it.title)}</div>
                ${it.note ? `<div class="c-note">${esc(it.note)}</div>` : ''}
              </div>
              <div class="check-meta">
                ${it.due ? `<span class="${isLate(it.due) && !it.done ? 'late' : ''}">${fmtDate(it.due)}</span>` : ''}
                <button class="row-x" data-check-del="${it.id}" title="Šalinti">×</button>
              </div>
            </div>`).join('')}
        </div>`;
      }).join('')}
    </div>`;
  v.querySelectorAll('[data-check]').forEach(cb => cb.onchange = async () => {
    try {
      await api('checklist/' + cb.dataset.check, 'PATCH', { done: cb.checked ? 1 : 0 });
      await loadAll(); render();
    } catch (e) { toast(e.message, 'err'); }
  });
  v.querySelectorAll('[data-check-edit]').forEach(el => el.onclick = () => checkModal(el.dataset.checkEdit));
  v.querySelectorAll('[data-check-del]').forEach(b => b.onclick = async e => {
    e.stopPropagation();
    if (!confirm('Pašalinti šį punktą?')) return;
    try {
      await api('checklist/' + b.dataset.checkDel, 'DELETE');
      await loadAll(); render(); toast('Punktas pašalintas');
    } catch (err) { toast(err.message, 'err'); }
  });
  $('#addCheck').onclick = () => checkModal(null, stages.length ? stages[stages.length - 1].name : '');
  v.querySelectorAll('[data-add-stage]').forEach(b => b.onclick = () => checkModal(null, b.dataset.addStage));
  $('#exportCheck').onclick = () => {
    const rows = [['Etapas', 'Punktas', 'Atlikta', 'Terminas', 'Pastaba']];
    S.checklist.forEach(i => rows.push([i.stage, i.title, i.done ? 'Taip' : 'Ne', i.due || '', i.note || '']));
    const csv = '\ufeff' + rows.map(r => r.map(x => '"' + String(x).replace(/"/g, '""') + '"').join(';')).join('\r\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    a.download = 'kontrolinis-sarasas.csv';
    a.click();
    URL.revokeObjectURL(a.href);
  };
}
function checkModal(id, presetStage) {
  const it = id ? S.checklist.find(x => String(x.id) === String(id)) : null;
  const stages = Array.from(new Set(S.checklist.map(x => x.stage)));
  const item = it || { stage: presetStage || (stages[0] || 'Papildomi darbai'), title: '', due: '', note: '' };
  openModal(`
    <div class="modal-head"><h3>${it ? 'Redaguoti punktą' : 'Naujas kontrolinis punktas'}</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
    <form id="checkForm" class="modal-body">
      <div class="form-grid">
        <div class="field full"><label>Etapas</label><input class="input" name="stage" required value="${esc(item.stage)}" list="stageList">
          <datalist id="stageList">${stages.map(s => `<option value="${esc(s)}">`).join('')}</datalist>
        </div>
        <div class="field full"><label>Punktas</label><input class="input" name="title" required value="${esc(item.title)}" placeholder="Ką reikia atlikti"></div>
        <div class="field"><label>Terminas</label><input class="input" type="date" name="due" value="${esc(item.due)}"></div>
        <div class="field"><label>Pastaba</label><input class="input" name="note" value="${esc(item.note)}" placeholder="Papildoma informacija"></div>
      </div>
    </form>
    <div class="modal-foot">
      ${it ? `<button class="btn danger" id="delCheck">${icon('x')} Šalinti</button>` : ''}
      <div class="spacer"></div>
      <button class="btn" data-close>Atšaukti</button>
      <button class="btn primary" id="saveCheck">Išsaugoti</button>
    </div>`);
  $('#saveCheck').onclick = async () => {
    const form = $('#checkForm');
    if (!form.reportValidity()) return;
    const body = formValues(form);
    try {
      if (it) await api('checklist/' + it.id, 'PATCH', body);
      else await api('checklist', 'POST', body);
      closeModal(); await loadAll(); render();
      toast(it ? 'Punktas atnaujintas' : 'Punktas pridėtas');
    } catch (e) { toast(e.message, 'err'); }
  };
  if (it) $('#delCheck').onclick = async () => {
    if (!confirm('Pašalinti šį punktą?')) return;
    try {
      await api('checklist/' + it.id, 'DELETE');
      closeModal(); await loadAll(); render(); toast('Punktas pašalintas');
    } catch (e) { toast(e.message, 'err'); }
  };
}

/* ============ darbai (sąmata) ============ */
const WORK_META = {
  elektra: {
    label: 'Elektra', icon: 'bolt',
    lead: 'Lauko 0,4 kV kabelių linija, apskaitos spintos ir įžeminimas pagal 25-E-5269-TDP-E.SŽ kiekių žiniaraštį. Vidaus instaliacija – orientacinė, tikslinama pagal ET projektą.',
  },
  apdaila: {
    label: 'Apdaila', icon: 'roller',
    lead: 'Sienų, lubų, grindų, sanitarinių patalpų, durų ir bendrųjų patalpų darbai. Kiekiai skaičiuojami pagal 1 225,33 m² bendrąjį plotą – tikslinti pagal išklotines.',
  },
  santechnika: {
    label: 'Santechnika', icon: 'drop',
    lead: 'Lauko vandentiekis, buitinės ir lietaus nuotekos pagal LVN projektą. Vidaus tinklai, stovai ir sanitariniai prietaisai – orientaciniai, tikslinami pagal VN brėžinius.',
  },
  fasadas: {
    label: 'Fasadas', icon: 'building',
    lead: 'Fasado šiltinimas, klinkerio apdaila, palangės, parapetai, balkonų plokštės ir turėklai. Kiekiai pagrįsti 2023 m. TP (3-SA) ir 2026 m. DWG: 96 langai (24 tipai), 21 balkono plokštė. Mygtukas „Patikrinti kiekius“ lygina sąmatą su PDF, DWG ir IFC failais.',
  },
};
const WORK_UNITS = ['m', 'm²', 'm³', 'vnt.', 'kompl.', 'ltr', 'kg', 't'];
const WORK_VERIFY_SECTIONS = ['fasadas', 'santechnika', 'elektra', 'apdaila'];
const WORK_SCHEDULE_SECTIONS = ['santechnika', 'elektra', 'apdaila'];
const SCHED_UNIT_LABEL = { vnt: 'vnt.', kompl: 'kompl.' };
function schedUnit(u) { return SCHED_UNIT_LABEL[u] || u || ''; }
function linesWord(n) {
  n = Math.abs(Number(n) || 0);
  if (n % 10 === 1 && n % 100 !== 11) return 'eilutė';
  if (n % 10 >= 2 && n % 10 <= 9 && !(n % 100 >= 11 && n % 100 <= 19)) return 'eilutės';
  return 'eilučių';
}
function mismatchWord(n) {
  n = Math.abs(Number(n) || 0);
  return n % 10 === 1 && n % 100 !== 11 ? 'neatitikimas' : 'neatitikimai';
}

const TRADE_ART = {
  elektra: {
    title: 'Lauko 0,4 kV linija', color: 'amber', badge: '0,4 kV',
    desc: 'Kabelių trasa, apskaitos spinta ir įžeminimo kontūras — pagal TDP-E.SŽ.',
    notes: ['Kabelių linija', 'Apskaitos spinta', 'Įžeminimas'],
  },
  apdaila: {
    title: 'Sienų apdailos sluoksniai', color: 'purple', badge: '1 225,33 m²',
    desc: 'Mūro, tinko ir dažų sluoksniai, grindjuostės ir apsaugotos grindys.',
    notes: ['Sienos', 'Lubos', 'Grindys'],
  },
  santechnika: {
    title: 'Nuotekų trasa ir stovas', color: 'blue', badge: 'LVN',
    desc: 'Šulinys, požeminė nuotekų linija ir stovas su sanitariniais prietaisais.',
    notes: ['Vandentiekis', 'Buitinės nuotekos', 'Lietaus nuotekos'],
  },
  fasadas: {
    title: 'Fasado šiltinimas ir apdaila', color: 'accent', badge: '24,94 × 12,85 m',
    desc: 'Klinkerio apdaila, šiltinimas, langai ir balkonai — 3-SA ir 2026 m. DWG pagrindu.',
    notes: ['96 langai', '24 tipai', '21 balkono plokštė'],
  },
};


function workIsDone(w) {
  const qty = Number(w.qty) || 0;
  return qty > 0 && (Number(w.done) || 0) >= qty - 1e-9;
}
function workKindChip(kind) {
  const cls = kind === 'Skaičiuojama' ? 'k-skaiciuojama' : kind === 'Projektas' ? 'k-projektas' : 'k-samata';
  return `<span class="work-kind ${cls}">${esc(kind || 'Sąmata')}</span>`;
}
function renderWorks(v, key) {
  const meta = WORK_META[key];
  if (!meta) return;
  const art = TRADE_ART[key] || { color: 'accent', title: meta.label, desc: '', notes: [], badge: '' };
  const all = S.works.filter(w => w.section === key);
  const stages = Array.from(new Set(all.map(w => w.stage).filter(Boolean)));
  const hasPrice = all.some(w => Number(w.price) > 0);
  v.innerHTML = `
    <div class="page-head">
      <div class="works-title"><h1>${meta.label}</h1><p>${esc(meta.lead)}</p></div>
      <div class="head-btns">
        ${WORK_VERIFY_SECTIONS.includes(key) ? `<button class="btn small ghost" id="workVerify">${icon('check')} Patikrinti kiekius</button>` : ''}
        <button class="btn small ghost" id="workPdf">${icon('download')} PDF</button>
        <button class="btn small ghost" id="workPrint">${icon('printer')} Spausdinti</button>
        <button class="btn small ghost" id="workExport">${icon('external')} CSV</button>
        <button class="btn primary" id="workAdd">${icon('plus')} Naujas darbas</button>
      </div>
    </div>
    <div class="trade-strip" data-trade="${art.color}">
      <div class="trade-copy">
        <span class="trade-eyebrow">${icon('cube')} 3D vaizdas · ${esc(meta.label)}</span>
        <b class="trade-title">${esc(art.title)}</b>
        <p class="trade-desc">${esc(art.desc)}</p>
        <div class="trade-notes">${art.notes.map(n => `<span>${esc(n)}</span>`).join('')}</div>
      </div>
      <figure class="trade-art">
        <img class="trade-img" src="/assets/trade-${key}.jpg?v=1" alt="${esc(art.title)}" width="1000" height="1000" loading="lazy" decoding="async">
        <figcaption class="trade-tag">${esc(art.badge)}</figcaption>
      </figure>
    </div>
    <div class="kpis works-kpis" id="workKpis"></div>
    <div class="grid-2 section">
      <section class="card pad">
        <div class="card-head"><h2>Kiekių suvestinė</h2><div class="spacer"></div><span class="chip gray">pagal vienetus</span></div>
        <div id="workUnits"></div>
      </section>
      <section class="card pad">
        <div class="card-head"><h2>Šaltiniai ir pagrindimas</h2></div>
        <div id="workSources"></div>
      </section>
    </div>
    ${WORK_SCHEDULE_SECTIONS.includes(key) ? '<section class="card pad section sched-card" id="workSchedCard"></section>' : ''}
    ${WORK_VERIFY_SECTIONS.includes(key) ? '<section class="card pad section verify-card" id="verifyCard" hidden></section>' : ''}
    <section class="card pad section">
      <div class="print-head">
        <div class="ph-title">${esc(meta.label)} — darbų sąmata</div>
        <div class="ph-sub">${esc(S.data?.project?.name || '')}${S.data?.project?.address ? ' · ' + esc(S.data.project.address) : ''} · ${new Date().toLocaleDateString('lt-LT')}</div>
      </div>
      <div class="card-head works-head">
        <h2>Darbų sąmata</h2>
        <span class="chip gray" id="workCount"></span>
        <div class="spacer"></div>
        <div class="work-progress" id="workProgress"></div>
      </div>
      <div class="toolbar works-toolbar">
        <input class="input" id="workSearch" placeholder="Ieškoti pagal kodą, darbą arba pagrindimą…" value="${esc(S.worksUI.q)}" style="flex:1;min-width:210px">
        <select class="select" id="workStageSel">
          <option value="">Visi skyriai</option>
          ${stages.map(s => `<option value="${esc(s)}" ${S.worksUI.stage === s ? 'selected' : ''}>${esc(s)}</option>`).join('')}
        </select>
        <select class="select" id="workStatusSel">
          <option value="" ${S.worksUI.status === '' ? 'selected' : ''}>Visos pozicijos</option>
          <option value="open" ${S.worksUI.status === 'open' ? 'selected' : ''}>Neatliktos</option>
          <option value="done" ${S.worksUI.status === 'done' ? 'selected' : ''}>Atliktos</option>
        </select>
      </div>
      <div class="table-wrap">
        <table class="table works-table">
          <thead><tr>
            <th class="wt-check"></th><th class="wt-code">Eil. Nr.</th><th>Darbas ir pagrindimas</th>
            <th class="num-col">Vnt.</th><th class="num-col">Kiekis</th><th class="num-col">Atlikta</th>
            <th class="num-col">Liko</th><th class="num-col">Kaina €/vnt.</th><th class="num-col">Suma €</th>
          </tr></thead>
          <tbody id="workBody"></tbody>
        </table>
      </div>
      <p class="work-hint" id="workHint">${hasPrice ? 'Suma = kiekis × kaina. Kainas įveskite pagal rangovo pasiūlymą.' : 'Kainos dar neįvestos – įrašykite kainą prie kiekvienos pozicijos, ir vertė suskaičiuojama automatiškai.'} Kiekį ir atlikimą galima koreguoti tiesiogiai lentelėje.</p>
    </section>`;

  const redraw = () => {
    const rows = S.works.filter(w => w.section === key);
    const q = S.worksUI.q.trim().toLowerCase();
    const shown = rows.filter(w => {
      if (S.worksUI.stage && w.stage !== S.worksUI.stage) return false;
      if (S.worksUI.status === 'open' && workIsDone(w)) return false;
      if (S.worksUI.status === 'done' && !workIsDone(w)) return false;
      if (q && !(`${w.code} ${w.title} ${w.stage} ${w.basis} ${w.unit}`.toLowerCase().includes(q))) return false;
      return true;
    }).sort((a, b) => (Number(a.ord) || 0) - (Number(b.ord) || 0));

    const doneRows = rows.filter(workIsDone);
    const total = rows.length;
    const doneN = doneRows.length;
    const pct = total ? Math.round(doneN / total * 100) : 0;
    const priced = rows.filter(w => Number(w.price) > 0);
    const value = rows.reduce((s, w) => s + (Number(w.qty) || 0) * (Number(w.price) || 0), 0);
    const totalQty = rows.reduce((s, w) => s + (Number(w.qty) || 0), 0);

    $('#workKpis').innerHTML = `
      <div class="card kpi"><div class="k-top"><span class="k-icon">${icon(meta.icon)}</span>Pozicijos</div>
        <div class="num">${total}</div><div class="sub">${stages.length} ${stages.length === 1 ? 'skyrius' : 'skyriai'} · ${priced.length} su kaina</div></div>
      <div class="card kpi"><div class="k-top"><span class="k-icon ok">${icon('check')}</span>Atlikta</div>
        <div class="num">${doneN}</div><div class="sub">${pct}% pozicijų</div></div>
      <div class="card kpi"><div class="k-top"><span class="k-icon ${total - doneN ? 'warn' : 'ok'}">${icon('clock')}</span>Liko atlikti</div>
        <div class="num">${total - doneN}</div><div class="sub">${total - doneN ? 'neatliktos pozicijos' : 'visos pozicijos atliktos'}</div></div>
      <div class="card kpi"><div class="k-top"><span class="k-icon">${icon('ruler')}</span>Sąmatos vertė</div>
        <div class="num work-money">${priced.length ? fmtEur(value) : '—'}</div>
        <div class="sub">${priced.length ? `${priced.length} / ${total} pozicijų su kaina` : 'įveskite kainas lentelėje'}</div></div>`;

    const unitMap = new Map();
    rows.forEach(w => {
      const unit = w.unit || 'vnt.';
      if (!unitMap.has(unit)) unitMap.set(unit, { n: 0, qty: 0, done: 0, left: 0 });
      const u = unitMap.get(unit);
      const qty = Number(w.qty) || 0;
      const done = Math.min(Number(w.done) || 0, qty);
      u.n += 1; u.qty += qty; u.done += done; u.left += Math.max(0, qty - done);
    });
    const unitRows = Array.from(unitMap.entries()).sort((a, b) => b[1].n - a[1].n);
    $('#workUnits').innerHTML = unitRows.length ? `
      <table class="table work-units-table">
        <thead><tr><th>Vienetas</th><th class="num-col">Pozicijos</th><th class="num-col">Kiekis</th><th class="num-col">Atlikta</th><th class="num-col">Liko</th></tr></thead>
        <tbody>${unitRows.map(([unit, u]) => `<tr>
          <td><span class="work-unit-tag">${esc(unit)}</span></td>
          <td class="num-col">${u.n}</td>
          <td class="num-col"><b>${fmtNum(u.qty)}</b></td>
          <td class="num-col">${fmtNum(u.done)}</td>
          <td class="num-col">${fmtNum(u.left)}</td>
        </tr>`).join('')}</tbody>
      </table>
      <p class="work-note">Skirtingų pozicijų kiekiai sumuojami pagal matavimo vienetus. Tai bendras orientyras – sąmatos eilutėse matomi tikslūs kiekiai (${fmtNum(totalQty)} matavimo vienetų iš viso).</p>`
      : '<div class="empty"><b>Pozicijų nėra</b>Pridėkite pirmą darbą.</div>';

    const srcMap = new Map();
    rows.forEach(w => {
      const id = Number(w.source_doc) || 0;
      if (!id) return;
      if (!srcMap.has(id)) srcMap.set(id, { name: w.source_name || 'Dokumentas', pages: [], n: 0 });
      const s = srcMap.get(id);
      s.n += 1;
      const page = Number(w.source_page) || 0;
      if (page && !s.pages.includes(page)) s.pages.push(page);
    });
    const kindCount = {};
    rows.forEach(w => { const k = w.kind || 'Sąmata'; kindCount[k] = (kindCount[k] || 0) + 1; });
    const kindLine = Object.entries(kindCount).map(([k, n]) => `${esc(k)} – ${n}`).join(' · ');
    const srcHtml = Array.from(srcMap.entries()).map(([id, s]) => {
      const pages = s.pages.sort((a, b) => a - b);
      const label = pages.length === 1 ? `l. ${pages[0]}` : pages.length ? `l. ${pages[0]}–${pages[pages.length - 1]}` : '';
      return `<button type="button" class="work-source" data-work-src="${id}" data-work-page="${pages[0] || 1}" title="Atidaryti ${esc(s.name)}">
        <span class="ws-ico">${icon('file')}</span>
        <span class="ws-main"><b>${esc(s.name)}</b><small>${s.n} ${posWord(s.n)}${label ? ' · ' + label : ''}</small></span>
        ${icon('external', 'ic faint')}
      </button>`;
    }).join('');
    $('#workSources').innerHTML = `${srcHtml || '<div class="empty"><b>Šaltinio dokumento nėra</b>Pozicijos skaičiuojamos pagal formulę.</div>'}
      <div class="work-kinds">${kindLine}</div>
      <p class="work-note">„Sąmata“ – kiekis paimtas tiesiogiai iš projekto kiekių žiniaraščio. „Skaičiuojama“ – kiekis apskaičiuotas pagal formulę, nurodytą prie pozicijos; jį būtina patikslinti pagal išklotines arba projekto brėžinius.</p>`;

    const schedCard = $('#workSchedCard');
    if (schedCard) {
      const sch = (S.problems?.schedules || []).find(x => x.section === key);
      schedCard.innerHTML = sch ? schedCardHtml(sch)
        : '<div class="empty"><b>Žiniaraštis dar nesusietas</b>Duomenys atsinaujins atlikus patikrą.</div>';
    }

    const groups = [];
    shown.forEach(w => {
      const name = w.stage || 'Kita';
      let g = groups.find(x => x.name === name);
      if (!g) { g = { name, rows: [] }; groups.push(g); }
      g.rows.push(w);
    });

    const body = $('#workBody');
    if (!shown.length) {
      body.innerHTML = `<tr><td colspan="9"><div class="empty"><b>Nieko nerasta</b>Pakeiskite filtrą arba pridėkite naują darbą.</div></td></tr>`;
    } else {
      const groupsHtml = groups.map(g => {
        const dn = g.rows.filter(workIsDone).length;
        const p = Math.round(dn / g.rows.length * 100);
        const gSum = g.rows.reduce((s, w) => s + (Number(w.qty) || 0) * (Number(w.price) || 0), 0);
        const gPriced = g.rows.filter(w => Number(w.price) > 0).length;
        return `<tr class="work-stage-row"><td colspan="9">
          <div class="work-stage-head"><span class="ws-name">${esc(g.name)}</span>
            <span class="ws-bar"><i style="width:${p}%"></i></span>
            <span class="ws-pct">${dn}/${g.rows.length} · ${p}%</span>
            ${gPriced ? `<span class="ws-sum" title="Skyriaus suma: ${gPriced} ${posWord(gPriced)} su kaina">${fmtEur(gSum)}</span>` : ''}
          </div></td></tr>` + g.rows.map(w => {
          const qty = Number(w.qty) || 0;
          const done = Math.min(Number(w.done) || 0, qty);
          const left = Math.max(0, qty - done);
          const price = Number(w.price) || 0;
          const isDone = workIsDone(w);
          const page = Number(w.source_page) || 1;
          const srcBtn = Number(w.source_doc)
            ? `<button type="button" class="work-src" data-work-src="${w.source_doc}" data-work-page="${page}" title="Atidaryti šaltinio lapą">${icon('file')} ${esc(w.source_page ? 'l. ' + w.source_page : 'šaltinis')}</button>`
            : '';
          return `<tr class="work-row ${isDone ? 'is-done' : ''}" data-work="${w.id}">
            <td class="wt-check"><button type="button" class="work-tick ${isDone ? 'on' : ''}" data-work-toggle="${w.id}" title="${isDone ? 'Atžymėti neatliktu' : 'Pažymėti atliktu'}">${isDone ? '✓' : ''}</button></td>
            <td class="wt-code"><span>${esc(w.code || '—')}</span></td>
            <td class="wt-main">
              <div class="wt-title">${esc(w.title)}</div>
              <div class="wt-basis" title="${esc(w.basis || '')}">${workKindChip(w.kind)}<span class="wt-basis-text">${esc(w.basis || 'Pagrindimas nenurodytas')}</span>${srcBtn}${workSchedChip(w)}</div>
            </td>
            <td class="num-col wt-unit" data-label="Vnt.">${esc(w.unit || 'vnt.')}</td>
            <td class="num-col" data-label="Kiekis"><b>${fmtNum(qty)}</b></td>
            <td class="num-col" data-label="Atlikta"><input class="work-num" type="number" min="0" max="${qty}" step="0.01" inputmode="decimal" data-work-done="${w.id}" value="${numAttr(done)}" placeholder="0" title="Kiek atlikta"></td>
            <td class="num-col wt-left" data-label="Liko">${fmtNum(left)}</td>
            <td class="num-col" data-label="Kaina €/vnt."><input class="work-num" type="number" min="0" step="0.01" inputmode="decimal" data-work-price="${w.id}" value="${numAttr(price)}" placeholder="—" title="Kaina už vienetą"></td>
            <td class="num-col wt-sum" data-label="Suma">${price > 0 ? fmtEur(qty * price) : '—'}</td>
          </tr>`;
        }).join('');
      }).join('');
      const pricedShown = shown.filter(w => Number(w.price) > 0);
      const shownSum = shown.reduce((s, w) => s + (Number(w.qty) || 0) * (Number(w.price) || 0), 0);
      body.innerHTML = groupsHtml + (pricedShown.length
        ? `<tr class="work-total-row"><td colspan="7">
            <span class="wtot-label">Iš viso${shown.length === total ? '' : ' (pagal filtrą)'}</span>
            <span class="wtot-sub">${pricedShown.length} ${posWord(pricedShown.length)} su kaina</span>
          </td><td class="num-col"></td><td class="num-col wtot-sum">${fmtEur(shownSum)}</td></tr>`
        : '');
    }

    $('#workCount').textContent = shown.length === total ? `${total} ${posWord(total)}` : `${shown.length} / ${total}`;
    const hint = $('#workHint');
    if (hint) hint.textContent = (priced.length
      ? 'Suma = kiekis × kaina. Kainas įveskite pagal rangovo pasiūlymą.'
      : 'Kainos dar neįvestos – įrašykite kainą prie kiekvienos pozicijos, ir vertė suskaičiuojama automatiškai.')
      + ' Kiekį ir atlikimą galima koreguoti tiesiogiai lentelėje.';
    $('#workProgress').innerHTML = `<span class="work-progress-bar"><i style="width:${pct}%"></i></span><span class="work-progress-txt">${doneN}/${total} · ${pct}%</span>`;
  };
  redraw();

  const refresh = async () => {
    await loadAll();
    updateChrome();
    redraw();
  };
  $('#workSearch').oninput = e => { S.worksUI.q = e.target.value; redraw(); };
  $('#workStageSel').onchange = e => { S.worksUI.stage = e.target.value; redraw(); };
  $('#workStatusSel').onchange = e => { S.worksUI.status = e.target.value; redraw(); };
  $('#workAdd').onclick = () => workModal(null, key);
  $('#workPrint').onclick = () => window.print();
  $('#workPdf').onclick = async () => {
    const btn = $('#workPdf');
    const label = btn.innerHTML;
    btn.disabled = true;
    btn.textContent = 'Ruošiama…';
    try {
      const res = await fetch(`/api/works/pdf?section=${encodeURIComponent(key)}`);
      if (!res.ok) {
        let msg = 'Nepavyko parengti PDF';
        try { msg = (await res.json()).error || msg; } catch (e) { /* ne JSON */ }
        throw new Error(msg);
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Sąmata-${meta.label}-${new Date().toISOString().slice(0, 10)}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      toast('PDF paruoštas ir išsaugotas');
    } catch (err) {
      toast(err.message, 'err');
    } finally {
      btn.disabled = false;
      btn.innerHTML = label;
    }
  };
  $('#workExport').onclick = () => exportWorks(key);
  $('#workSources').onclick = e => {
    const b = e.target.closest('[data-work-src]');
    if (b) openDoc(b.dataset.workSrc, Number(b.dataset.workPage) || 1);
  };
  $('#workBody').onclick = async e => {
    const toggle = e.target.closest('[data-work-toggle]');
    if (toggle) {
      const item = S.works.find(w => String(w.id) === toggle.dataset.workToggle);
      if (!item) return;
      const target = workIsDone(item) ? 0 : (Number(item.qty) || 0);
      try {
        await api('works/' + item.id, 'PATCH', { done: target });
        await refresh();
        toast(target ? 'Pozicija pažymėta atlikta' : 'Pozicija atžymėta');
      } catch (err) { toast(err.message, 'err'); }
      return;
    }
    const src = e.target.closest('[data-work-src]');
    if (src) { openDoc(src.dataset.workSrc, Number(src.dataset.workPage) || 1); return; }
    if (e.target.closest('input,button,select,textarea')) return;
    const tr = e.target.closest('tr[data-work]');
    if (tr) workModal(tr.dataset.work);
  };
  const verifyBtn = $('#workVerify');
  if (verifyBtn) {
    verifyBtn.onclick = async () => {
      const card = $('#verifyCard');
      verifyBtn.disabled = true;
      const label = verifyBtn.innerHTML;
      verifyBtn.textContent = 'Tikrinama…';
      try {
        const data = await api('works/verify?section=' + encodeURIComponent(key));
        card.innerHTML = verifyCardHtml(data);
        card.hidden = false;
        toast(data.summary.bad ? `Rasta neatitikimų: ${data.summary.bad}` : `Visi ${data.summary.total} kiekiai sutampa`, data.summary.bad ? 'err' : '');
      } catch (err) {
        toast(err.message, 'err');
      } finally {
        verifyBtn.disabled = false;
        verifyBtn.innerHTML = label;
      }
    };
  }
  const schedCardEl = $('#workSchedCard');
  if (schedCardEl) {
    schedCardEl.onclick = e => {
      const open = e.target.closest('[data-sched-doc]');
      if (open) openDoc(open.dataset.schedDoc, Number(open.dataset.schedPage) || 1);
    };
  }
  $('#workBody').onchange = async e => {
    const doneEl = e.target.closest('[data-work-done]');
    if (doneEl) {
      const item = S.works.find(w => String(w.id) === doneEl.dataset.workDone);
      if (!item) return;
      const val = Math.min(Math.max(Number(doneEl.value) || 0, 0), Number(item.qty) || 0);
      try {
        await api('works/' + item.id, 'PATCH', { done: val });
        await refresh();
        toast('Atlikimas atnaujintas');
      } catch (err) { toast(err.message, 'err'); }
      return;
    }
    const priceEl = e.target.closest('[data-work-price]');
    if (priceEl) {
      const val = Math.max(Number(priceEl.value) || 0, 0);
      try {
        await api('works/' + priceEl.dataset.workPrice, 'PATCH', { price: val });
        await refresh();
        toast(val ? 'Kaina išsaugota' : 'Kaina pašalinta');
      } catch (err) { toast(err.message, 'err'); }
    }
  };
}
function workSchedChip(w) {
  const src = (S.problems?.schedules || []).find(x => x.section === w.section && x.byCode);
  const m = src?.byCode?.[w.code];
  if (!m) return '';
  const row = m.row || {};
  const label = `${src.label} ${src.pageLabel}${row.page ? ', l. ' + row.page : ''}`;
  if (m.resolved) {
    return `<span class="wt-sched ok" title="${esc(label + ': ' + (row.title || '') + ' – priimtas projekto vadovo sprendimas (žr. „Problemos“)')}">${icon('check')} žiniaraštis</span>`;
  }
  if (m.status === 'ok') {
    return `<span class="wt-sched ok" title="${esc(label + ': ' + (row.title || '') + ' – kiekis sutampa')}">${icon('check')} žiniaraštis</span>`;
  }
  if (m.status === 'diff') {
    return `<span class="wt-sched bad" title="${esc(label + ': ' + (row.title || '') + ' – žiniaraštyje ' + fmtNum(row.qty) + ' ' + schedUnit(row.unit) + ', sąmatoje ' + fmtNum(m.qty) + ' ' + schedUnit(m.unit))}">${icon('alert')} ${fmtNum(row.qty)} ${esc(schedUnit(row.unit))}</span>`;
  }
  if (m.status === 'unit') {
    return `<span class="wt-sched warn" title="${esc(label + ': ' + (row.title || '') + ' – žiniaraštyje ' + fmtNum(row.qty) + ' ' + schedUnit(row.unit) + ', sąmatoje ' + fmtNum(m.qty) + ' ' + schedUnit(m.unit))}">${icon('alert')} ${esc(schedUnit(row.unit))}</span>`;
  }
  return `<span class="wt-sched warn" title="${esc(label + ': tiesioginės eilutės nerasta')}">be eilutės</span>`;
}

function schedCardHtml(sch) {
  const s = sch.summary || {};
  const docBtn = sch.docId
    ? `<button class="btn small ghost" data-sched-doc="${sch.docId}" data-sched-page="${(sch.pages || [1])[0]}">${icon('external')} ${esc(sch.doc)}</button>`
    : `<span class="chip gray">${esc(sch.doc)}</span>`;
  let chip, stats, bar, note = '';
  const issues = [];
  if (sch.kind === 'spec') {
    const diff = Number(s.diff) || 0;
    const res = !!sch.resolved;
    chip = Math.abs(diff) > 0.5 ? (res
      ? `<span class="chip green">Sutarta · ${fmtNum(Math.abs(diff))} vnt.</span>`
      : `<span class="chip amber">${fmtNum(Math.abs(diff))} vnt. skirtumas</span>`)
      : '<span class="chip green">Sutampa</span>';
    bar = `<div class="sched-bar"><i class="${Math.abs(diff) > 0.5 && !res ? 'bad' : ''}" style="width:${res ? 100 : (s.worksTotal ? Math.min(100, s.specTotal / s.worksTotal * 100) : 0)}%"></i></div>`;
    stats = `<div class="sched-stats"><span><b>${fmtNum(s.specTotal)}</b> vnt. specifikacijoje</span><span><b>${fmtNum(s.worksTotal)}</b> vnt. sąmatoje</span><span class="${Math.abs(diff) > 0.5 && !res ? 'bad' : 'ok'}"><b>${fmtNum(Math.abs(diff))}</b> skirtumas</span>${res ? '<span class="ok"><b>PV</b> sprendimas</span>' : ''}</div>`;
    issues.push(`<div class="sched-issue"><span class="chip gray mono">D-02–D-08</span><span>${fmtNum(s.specInner)} vnt. specifikacijoje ↔ A-13 ${fmtNum(s.worksInner)} vnt.</span></div>`);
    note = 'D-01 – lauko durys (tikrintos fasade), D-02–D-08 – vidaus durys. A-14 gali dubliuoti dalį tipų.';
    if (res) note += ' Skirtumas priimtas projekto vadovo sprendimu su sąlyga – žr. „Problemos“.';
  } else if (sch.status === 'no-works') {
    const res = !!sch.resolved;
    chip = res ? '<span class="chip green">Sprendimas</span>' : '<span class="chip amber">Nėra sąmatos</span>';
    bar = `<div class="sched-bar"><i class="${res ? '' : 'bad'}" style="width:100%"></i></div>`;
    stats = `<div class="sched-stats"><span><b>${s.rows}</b> ${linesWord(s.rows)}</span><span><b>0</b> sąmatos pozicijų</span><span class="${res ? 'ok' : 'bad'}"><b>${res ? 'PV' : s.rows}</b> ${res ? 'sprendimas' : 'be sąmatos'}</span></div>`;
    note = res
      ? 'Sklypo darbai priimti kaip atskiras etapas – sąmatos neatitikimas padengtas projekto vadovo sprendimu.'
      : 'Sklypo darbų sąmatoje nėra – žiniaraštis nuskaitomas, bet neturi su kuo lyginti.';
  } else {
    const rawBad = (s.diff || 0) + (s.unit || 0) + (s.missingWorks || 0);
    const resN = Number(s.resolvedIssues) || 0;
    const bad = Math.max(0, rawBad - resN);
    chip = !s.rows ? '<span class="chip gray">Neperskaityta</span>'
      : bad ? `<span class="chip amber">${bad} ${mismatchWord(bad)}</span>`
      : `<span class="chip green">${s.ok}/${s.works} sutampa${resN ? ' · sprendimas' : ''}</span>`;
    const pct = s.works ? Math.round(((s.ok || 0) + resN) / s.works * 100) : 0;
    bar = `<div class="sched-bar"><i class="${bad ? 'bad' : ''}" style="width:${Math.min(100, pct)}%"></i></div>`;
    stats = `<div class="sched-stats">
      <span><b>${s.rows}</b> ${linesWord(s.rows)}</span><span><b>${s.matched}</b> susietos</span>
      <span class="ok"><b>${s.ok}</b> sutampa</span>
      <span class="${bad ? 'bad' : ''}"><b>${bad}</b> ${mismatchWord(bad)}</span>
      ${resN ? `<span class="ok"><b>${resN}</b> sprendimas</span>` : ''}
      <span class="${s.extra && s.extrasResolved ? 'ok' : ''}"><b>${s.extra}</b> be pozicijos${s.extra && s.extrasResolved ? ' · sprendimas' : ''}</span></div>`;
    (sch.matches || []).filter(m => m.status !== 'ok').forEach(m => {
      const r = m.row || {};
      if (m.resolved) issues.push(`<div class="sched-issue"><span class="chip green mono">${esc(m.code)}</span><span>${fmtNum(r.qty || 0)} ${esc(schedUnit(r.unit))} → ${fmtNum(m.qty)} ${esc(schedUnit(m.unit))} · priimtas sprendimas</span><small>l. ${r.page || '—'}</small></div>`);
      else if (m.status === 'diff') issues.push(`<div class="sched-issue"><span class="chip red mono">${esc(m.code)}</span><span>${fmtNum(r.qty)} ${esc(schedUnit(r.unit))} → ${fmtNum(m.qty)} ${esc(schedUnit(m.unit))}</span><small>l. ${r.page || '—'}</small></div>`);
      else if (m.status === 'unit') issues.push(`<div class="sched-issue"><span class="chip amber mono">${esc(m.code)}</span><span>${fmtNum(r.qty)} ${esc(schedUnit(r.unit))} žiniaraštyje → ${fmtNum(m.qty)} ${esc(schedUnit(m.unit))} sąmatoje</span><small>l. ${r.page || '—'}</small></div>`);
      else issues.push(`<div class="sched-issue"><span class="chip gray mono">${esc(m.code)}</span><span>Tiesioginės eilutės žiniaraštyje nėra</span></div>`);
    });
    (sch.extras || []).slice(0, 3).forEach(r => issues.push(`<div class="sched-issue"><span class="chip ${s.extrasResolved ? 'green' : 'gray'}">+</span><span>${esc(String(r.title).slice(0, 90))}</span><small>${fmtNum(r.qty)} ${esc(schedUnit(r.unit))} · l. ${r.page}${s.extrasResolved ? ' · sprendimas' : ''}</small></div>`));
    note = sch.status === 'ok' && !s.extra
      ? 'Visos sąmatos pozicijos atitinka žiniaraštį.'
      : (bad ? 'Neatitikimai taip pat įtraukti į skiltį „Problemos“.'
             : 'Neatitikimai padengti projekto vadovo sprendimais – žr. „Problemos“.');
  }
  return `
    <div class="card-head works-head">
      <h2>Kiekių žiniaraštis</h2>
      ${chip}
      <div class="spacer"></div>
      ${docBtn}
    </div>
    <div class="sched-meta"><b>${esc(sch.label)}</b> · ${esc(sch.doc)} ${esc(sch.pageLabel)} · ${esc(sch.note)}</div>
    ${bar}
    ${stats}
    ${issues.length ? `<div class="sched-issues">${issues.join('')}</div>` : ''}
    <p class="work-note">${esc(note)}</p>`;
}

function verifyCardHtml(d) {
  const s = d.summary || { total: 0, ok: 0, bad: 0 };
  const when = d.generated ? String(d.generated).replace('T', ' ') : '';
  return `
    <div class="card-head works-head">
      <h2>${esc(d.title || 'Kiekių patikra pagal visus formatus')}</h2>
      <span class="chip ${s.bad ? 'red' : 'green'}">${s.ok} / ${s.total} sutampa</span>
      ${s.resolved ? `<span class="chip green">${s.resolved} sprendimas</span>` : ''}
      <div class="spacer"></div>
      <span class="verify-time">${esc(when)}</span>
    </div>
    <div class="verify-grid">
      ${(d.checks || []).map(c => {
        const good = c.ok || c.resolved;
        return `<div class="verify-row ${good ? 'ok' : 'bad'}">
        <span class="verify-dot">${good ? '✓' : '!'}</span>
        <div class="verify-main"><b>${esc(c.name)}</b>${c.resolved && !c.ok ? '<span class="chip green">sprendimas</span>' : ''}
          <small>${esc(String(c.expected))}${c.unit ? ' ' + esc(c.unit) : ''} → ${esc(String(c.actual))}${c.unit ? ' ' + esc(c.unit) : ''}${c.detail ? ' · ' + esc(c.detail) : ''}</small>
        </div>
        <span class="verify-src">${esc(c.source || '')}</span>
      </div>`;
      }).join('')}
    </div>
    <div class="verify-sources">${(d.sources || []).map(x => `<span><b>${esc(x.label)}</b> ${esc(x.info)}</span>`).join('')}</div>`;
}
/* ============ F2/F3 aktai ============ */
function isoDay(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function actMonthRange() {
  const n = new Date();
  return [isoDay(new Date(n.getFullYear(), n.getMonth(), 1)), isoDay(new Date(n.getFullYear(), n.getMonth() + 1, 0))];
}
function actStatusChip(st) {
  const cls = { 'Juodraštis': 'gray', 'Pateiktas': 'amber', 'Patvirtintas': 'green' }[st] || 'gray';
  return `<span class="chip ${cls}">${esc(st || '')}</span>`;
}
function actGroupWord(n) {
  const last = n % 10, teen = n % 100;
  if (n === 1) return 'darbų grupė';
  if (last >= 2 && last <= 9 && !(teen >= 11 && teen <= 19)) return 'darbų grupės';
  return 'darbų grupių';
}

function csvDownload(filename, rows) {
  const lines = rows.map(r => r.map(x => '"' + String(x == null ? '' : x).replace(/"/g, '""') + '"').join(';'));
  const csv = '\ufeff' + lines.join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}
function csvNum(v) {
  return Number(v || 0).toFixed(2).replace('.', ',');
}

async function renderActs(v) {
  let data;
  try { data = await api('acts'); }
  catch (e) {
    v.innerHTML = `<div class="card pad"><div class="empty"><b>Nepavyko įkelti aktų</b>${esc(e.message)}</div></div>`;
    return;
  }
  S.actsData = data;
  const contracts = data.contracts || [];
  let cid = Number(S.actsUI.contract) || 0;
  if (!contracts.some(c => Number(c.id) === cid)) cid = contracts.length ? Number(contracts[0].id) : 0;
  S.actsUI.contract = cid;
  const contract = contracts.find(c => Number(c.id) === cid) || null;
  const groups = (data.groups || []).filter(g => Number(g.contract_id) === cid && Number(g.active) !== 0);
  const acts = (data.acts || []).filter(a => Number(a.contract_id) === cid).sort((a, b) => Number(a.num) - Number(b.num));
  const price = groups.reduce((s, g) => s + (Number(g.price) || 0), 0);
  const last = acts.length ? acts[acts.length - 1] : null;
  const done = last ? Number(last.total) || 0 : 0;
  const month = last ? Number(last.current_total) || 0 : 0;
  const left = Math.max(0, price - done);
  const fin = (data.finance || []).find(f => Number(f.contract_id) === cid) || { invoiced: 0, received: 0, outstanding: 0 };

  const head = `
    <div class="page-head">
      <div class="works-title"><h1>Aktai F2/F3</h1><p>Mėnesiniai atliktų darbų aktai ir pažymos apie atliktų darbų vertę. Procentai, PVM, sulaikymas ir avansas suskaičiuojami automatiškai.</p></div>
      <div class="head-btns">
        <button class="btn small" id="actRegister">${icon('inbox')} Visų sutarčių registras</button>
        <button class="btn small" id="actCsv">${icon('external')} CSV</button>
        <button class="btn small" id="actScan" title="Peržiūri įkeltus dokumentus ir perkelia juose rastas F2 formas į aktus">${icon('search')} Rasti F2 dokumentuose</button>
        <button class="btn small" id="actImportXlsx">${icon('upload')} Importuoti F2</button>
        <button class="btn small" id="actOcr">${icon('camera')} Atpažinti skeną</button>
        <button class="btn small" id="actNewContract">${icon('plus')} Nauja sutartis</button>
        ${contract ? `<button class="btn small" id="actRecon">${icon('printer')} Suderinimas</button>
        <button class="btn small" id="actJournal">${icon('wallet')} Mokėjimai</button>
        <button class="btn small" id="actUnfinished">${icon('clock')} Neatlikti darbai</button>
        <button class="btn primary" id="actNew">${icon('plus')} Naujas aktas</button>` : ''}
      </div>
    </div>
    <input type="file" id="actImportFile" accept=".xlsx,.xlsm,.pdf" hidden>`;

  if (!contract) {
    v.innerHTML = head + `
      <div class="card pad">
        <div class="empty"><b>Sutarčių ir F2 aktų nėra</b>Įkelkite užpildytą F2 formą (Excel „Priedas Nr. 10“ arba PDF) arba leiskite programai surasti F2 dokumentuose, kuriuos jau įkėlėte į šį projektą. Pastaba: PVM sąskaitos-faktūros ir tušti šablonai F2 aktais nelaikomi.
          <div class="act-empty-btns">
            <button class="btn primary" id="actScan2">${icon('search')} Rasti F2 dokumentuose</button>
            <button class="btn" id="actImportXlsx2">${icon('upload')} Importuoti F2 failą</button>
            <button class="btn" id="actSeed">Įkelti pavyzdį</button>
            <button class="btn" id="actNewContract2">Nauja sutartis</button>
          </div>
        </div>
      </div>`;
    $('#actNewContract').onclick = () => contractModal(null);
    $('#actNewContract2').onclick = () => contractModal(null);
    $('#actCsv').onclick = () => toast('Pirmiausia sukurkite sutartį', 'err');
    $('#actRegister').onclick = () => allActsRegister();
    $('#actScan').onclick = () => scanActsDocs();
    $('#actScan2').onclick = () => scanActsDocs();
    $('#actImportXlsx2').onclick = () => $('#actImportFile').click();
    bindActImport(0);
    $('#actOcr').onclick = () => ocrModal(0);
    $('#actSeed').onclick = async () => {
      try {
        await api('acts/seed-demo', 'POST', {});
        await loadAll(); render();
        toast('Pavyzdinė sutartis įkelta');
      } catch (e) { toast(e.message, 'err'); }
    };
    return;
  }

  const actRows = acts.length ? acts.map(a => `
    <tr>
      <td><b>Nr. ${a.num}</b></td>
      <td class="nowrap">${esc(fmtDate(a.period_from) || '—')} – ${esc(fmtDate(a.period_to) || '—')}<span class="act-unit">${esc(fmtDate(a.date) || 'data nenurodyta')}</span></td>
      <td class="num-col">${fmtEur(a.current_total)}</td>
      <td class="num-col">${fmtEur(a.total)}<span class="act-unit">${fmtNum(a.pct)} %</span></td>
      <td>${actStatusChip(a.status)}</td>
      <td><div class="acts-actions">
        <a class="act-dl" href="/api/acts/${a.id}/pdf?form=f2" target="_blank" rel="noopener" title="F2 atliktų darbų aktas (PDF)">F2</a>
        <a class="act-dl" href="/api/acts/${a.id}/pdf?form=f3" target="_blank" rel="noopener" title="F3 pažyma apie atliktų darbų vertę (PDF)">F3</a>
        <a class="act-dl xls" href="/api/acts/${a.id}/xlsx?form=f2" title="F2 atliktų darbų aktas (Excel XLSX)">XLS</a>
        <a class="act-dl inv" href="/api/acts/${a.id}/pdf?form=invoice" target="_blank" rel="noopener" title="PVM sąskaita-faktūra (PDF)">SĄS</a>
        <button class="icon-btn" data-act-edit="${a.id}" title="Redaguoti aktą">${icon('pencil')}</button>
        <button class="icon-btn" data-act-del="${a.id}" title="Šalinti aktą">${icon('x')}</button>
      </div></td>
    </tr>`).join('') : `<tr><td colspan="6"><div class="empty"><b>Aktų dar nėra</b>Sukurkite pirmą mėnesio aktą.</div></td></tr>`;

  const groupRows = groups.length ? groups.map((g, i) => `
    <tr><td class="row-muted">${i + 1}</td><td>${esc(g.name)}</td><td class="num-col">${fmtEur(g.price)}</td></tr>`).join('')
    : `<tr><td colspan="3"><div class="empty"><b>Grupių nėra</b>Įveskite darbų grupes ir jų kainas.</div></td></tr>`;

  v.innerHTML = head + `
    <section class="card pad">
      <div class="card-head act-contract-head">
        <h2>Sutartis</h2>
        <select class="select" id="actContractSel">${contracts.map(c => `<option value="${c.id}" ${Number(c.id) === cid ? 'selected' : ''}>${esc(c.title)}</option>`).join('')}</select>
        <div class="spacer"></div>
        <button class="btn small ghost" id="actEditContract">${icon('pencil')} Redaguoti</button>
        <button class="btn small ghost" id="actEditGroups">${icon('ruler')} Grupės ir kainos</button>
        <button class="btn small ghost danger" id="actDelContract">${icon('x')} Šalinti</button>
      </div>
      <div class="act-meta">
        <div><span>Užsakovas</span><b>${esc(contract.customer || '—')}</b></div>
        <div><span>Rangovas</span><b>${esc(contract.contractor || '—')}</b></div>
        <div><span>Sutartis</span><b>${esc(contract.signed || '—')}${contract.number ? ' · ' + esc(contract.number) : ''}</b></div>
        <div><span>PVM / sulaikymas</span><b>${fmtNum(contract.vat)} % / ${fmtNum(contract.retention)} %</b></div>
      </div>
    </section>
    <div class="kpis acts-kpis">
      <div class="card kpi"><div class="k-top"><span class="k-icon">${icon('file')}</span>Sutarties vertė</div><div class="num">${fmtEur(price)}</div><div class="sub">${groups.length} ${actGroupWord(groups.length)}</div></div>
      <div class="card kpi"><div class="k-top"><span class="k-icon ok">${icon('check')}</span>Atlikta iš viso</div><div class="num">${fmtEur(done)}</div><div class="sub">${fmtNum(price ? done / price * 100 : 0)} % sutarties</div></div>
      <div class="card kpi"><div class="k-top"><span class="k-icon">${icon('calendar')}</span>Paskutinis aktas</div><div class="num">${fmtEur(month)}</div><div class="sub">${last ? 'Nr. ' + last.num + ' · ' + fmtDate(last.date) : 'aktų dar nėra'}</div></div>
      <div class="card kpi"><div class="k-top"><span class="k-icon ${left ? 'warn' : 'ok'}">${icon('clock')}</span>Liko</div><div class="num">${fmtEur(left)}</div><div class="sub">${left ? 'neatlikta pagal sutartį' : 'sutartis įvykdyta'}</div></div>
    </div>
    <section class="card pad act-finance">
      <div><span>Išrašyta sąskaitų</span><b>${fmtEur(fin.invoiced)}</b></div>
      <div><span>Gauta mokėjimų</span><b>${fmtEur(fin.received)}</b></div>
      <div class="${fin.outstanding > 0 ? 'due' : ''}"><span>Užsakovo skola</span><b>${fmtEur(Math.max(0, fin.outstanding))}</b></div>
      <div class="spacer"></div>
      <a class="btn ghost small" href="/api/contracts/${cid}/pdf?form=recon" target="_blank" rel="noopener">${icon('printer')} Suderinimo PDF</a>
    </section>
    <div class="acts-layout section">
      <section class="card pad">
        <div class="card-head"><h2>Mėnesio aktai</h2><span class="chip gray">${acts.length}</span></div>
        <div class="table-wrap">
          <table class="table acts-table">
            <thead><tr><th>Nr.</th><th>Laikotarpis</th><th class="num-col">Ataskaitinis</th><th class="num-col">Iš viso</th><th>Būsena</th><th></th></tr></thead>
            <tbody>${actRows}</tbody>
          </table>
        </div>
      </section>
      <section class="card pad">
        <div class="card-head"><h2>Darbų grupės</h2><div class="spacer"></div><button class="btn small ghost" id="actEditGroups2">${icon('pencil')} Keisti</button></div>
        <div class="table-wrap acts-groups-wrap">
          <table class="table acts-groups-table">
            <thead><tr><th>Nr.</th><th>Grupė</th><th class="num-col">Kaina, €</th></tr></thead>
            <tbody>${groupRows}</tbody>
          </table>
        </div>
      </section>
    </div>`;

  $('#actContractSel').onchange = e => { S.actsUI.contract = Number(e.target.value); render(); };
  $('#actRegister').onclick = () => allActsRegister();
  $('#actScan').onclick = () => scanActsDocs();
  $('#actCsv').onclick = () => exportActsCsv(contract, acts);
  $('#actNew').onclick = () => actModal(null);
  $('#actRecon').onclick = () => window.open(`/api/contracts/${cid}/pdf?form=recon`, '_blank', 'noopener');
  $('#actJournal').onclick = () => paymentsJournal(contract);
  $('#actUnfinished').onclick = () => unfinishedWorks(contract);
  $('#actEditContract').onclick = () => contractModal(contract);
  $('#actEditGroups').onclick = () => groupsModal(contract);
  $('#actEditGroups2').onclick = () => groupsModal(contract);
  $('#actDelContract').onclick = async () => {
    if (!confirm('Pašalinti sutartį kartu su visais jos aktais?')) return;
    try {
      await api('contracts/' + contract.id, 'DELETE');
      S.actsUI.contract = 0;
      await loadAll(); render(); toast('Sutartis pašalinta');
    } catch (e) { toast(e.message, 'err'); }
  };
  v.querySelectorAll('[data-act-edit]').forEach(b => b.onclick = () => actModal(b.dataset.actEdit));
  v.querySelectorAll('[data-act-del]').forEach(b => b.onclick = async () => {
    if (!confirm('Pašalinti šį aktą?')) return;
    try {
      await api('acts/' + b.dataset.actDel, 'DELETE');
      await loadAll(); render(); toast('Aktas pašalintas');
    } catch (e) { toast(e.message, 'err'); }
  });
  bindActImport(cid);
  $('#actOcr').onclick = () => ocrModal(cid);
}

let ocrCurrentFile = null;

function ocrAvailable() {
  return !!(window.StabasOCR && window.StabasOCR.supported());
}

function ocrModal(opts = {}) {
  if (!ocrAvailable()) { toast('Ši naršyklė nepalaiko OCR', 'err'); return; }
  const mode = opts.mode === 'text' ? 'text' : 'import';
  const contracts = (S.actsData && S.actsData.contracts) || [];
  const cid = Number(opts.contractId) || (contracts[0] ? Number(contracts[0].id) : 0);
  const actId = Number(opts.actId) || 0;
  ocrCurrentFile = opts.file || null;
  const cidField = mode === 'import' ? `
      <div class="field ocr-cid"><label>Kuriai sutarčiai priskirti aktą</label>
        <select class="input" id="ocrCid">${contracts.map(c => `<option value="${c.id}" ${Number(c.id) === cid ? 'selected' : ''}>${esc(c.title || ('Sutartis #' + c.id))}</option>`).join('') || '<option value="0">Sukurti naują sutartį automatiškai</option>'}</select>
      </div>` : '';
  openModal(`
    <div class="modal-head"><div><h2>${mode === 'import' ? 'Skeno atpažinimas' : 'Skeno tekstas'}</h2>
      <div class="sub">Vykdoma šiame kompiuteryje, be interneto.${mode === 'import' ? ' Pirmą kartą įkeliamas ~8 MB variklis.' : ''}</div></div>
      <button class="modal-close" data-close>×</button></div>
    <div class="modal-body">
      <div class="ocr-drop" id="ocrDrop">
        <input type="file" id="ocrFile" accept=".pdf,.png,.jpg,.jpeg,.webp,.bmp,.gif,.tif,.tiff" hidden>
        <button type="button" class="btn" id="ocrPick">${icon('upload')} Pasirinkti PDF arba paveikslėlį</button>
        <div class="act-hint">Galima įvilkti failą čia. Tinka skenuotas PDF, JPG ar PNG.</div>
        <div class="ocr-file" id="ocrFileInfo"></div>
      </div>
      ${cidField}
      <div id="ocrProgWrap" hidden>
        <div class="progress"><div id="ocrBar"></div></div>
        <div class="act-hint" id="ocrStatus"></div>
      </div>
      <div id="ocrResult" hidden>
        <label class="ocr-label" for="ocrText">Atpažintas tekstas${mode === 'import' ? ' (galite taisyti prieš importą)' : ''}</label>
        <textarea class="input ocr-text" id="ocrText" spellcheck="false"></textarea>
        <div class="ocr-actions">
          ${mode === 'import'
            ? `<button type="button" class="btn primary" id="ocrImport">${icon('check')} Importuoti kaip F2 aktą</button>`
            : `<button type="button" class="btn primary" id="ocrSaveTxt" ${actId ? '' : 'hidden'}>${icon('file')} Išsaugoti .txt prie akto</button>`}
          <button type="button" class="btn" id="ocrCopy">${icon('copy')} Kopijuoti</button>
          <button type="button" class="btn ghost" id="ocrAgain">Kitas failas</button>
        </div>
        <div class="act-hint" id="ocrMsg"></div>
      </div>
    </div>
    <div class="modal-foot"><span class="act-hint ocr-foot-hint">Pirmas nuskaitymas gali užtrukti apie minutę.</span><div class="spacer"></div><button class="btn" data-close>Uždaryti</button></div>`, { wide: true });

  const fileInp = $('#ocrFile');
  const drop = $('#ocrDrop');
  $('#ocrPick').onclick = () => fileInp.click();
  fileInp.onchange = () => {
    const f = fileInp.files && fileInp.files[0];
    if (f) ocrRun(f);
  };
  ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => {
    e.preventDefault(); drop.classList.add('over');
  }));
  ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => {
    e.preventDefault(); drop.classList.remove('over');
  }));
  drop.addEventListener('drop', e => {
    const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (f) ocrRun(f);
  });
  $('#ocrAgain').onclick = () => {
    $('#ocrResult').hidden = true;
    $('#ocrProgWrap').hidden = true;
    $('#ocrFileInfo').textContent = '';
    $('#ocrMsg').textContent = '';
    ocrCurrentFile = null;
    fileInp.value = '';
    fileInp.click();
  };
  $('#ocrCopy').onclick = () => copyText($('#ocrText').value);
  const imp = $('#ocrImport');
  if (imp) imp.onclick = async () => {
    const text = $('#ocrText').value.trim();
    if (!text) { toast('Nėra teksto', 'err'); return; }
    const cidEl = $('#ocrCid');
    const cidVal = cidEl ? Number(cidEl.value) || null : null;
    const msg = $('#ocrMsg');
    const old = imp.innerHTML;
    imp.disabled = true;
    imp.textContent = 'Importuojama…';
    if (msg) { msg.className = 'act-hint'; msg.textContent = ''; }
    try {
      const out = await api('acts/ocr', 'POST', {
        text,
        filename: ocrCurrentFile ? ocrCurrentFile.name : 'skenas',
        contract_id: cidVal,
      });
      await loadAll();
      const ids = out.act_ids || [];
      let attachFailed = false;
      if (ocrCurrentFile && ids.length) {
        try {
          const res = await fetch('/api/acts/' + ids[0] + '/files?name=' + encodeURIComponent(ocrCurrentFile.name), {
            method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: ocrCurrentFile,
          });
          if (!res.ok) attachFailed = true;
        } catch (e) { attachFailed = true; }
      }
      closeModal();
      render();
      if (out.acts && out.acts.length) toast('Importuota: ' + out.acts.map(n => 'Nr. ' + n).join(', '));
      else if (out.skipped && out.skipped.length) toast('Jau yra: ' + out.skipped.map(n => 'Nr. ' + n).join(', '));
      if (out.warnings && out.warnings.length) setTimeout(() => alert('Importo pastabos:\n' + out.warnings.join('\n')), 80);
      if (attachFailed) toast('Aktas importuotas, bet skeno pridėti nepavyko', 'err', 5000);
      if (ids.length) actModal(ids[0]);
    } catch (e) {
      if (msg) { msg.className = 'act-hint err'; msg.textContent = e.message; }
      imp.disabled = false;
      imp.innerHTML = old;
    }
  };
  const saveTxt = $('#ocrSaveTxt');
  if (saveTxt) saveTxt.onclick = async () => {
    const text = $('#ocrText').value.trim();
    if (!text) { toast('Nėra teksto', 'err'); return; }
    saveTxt.disabled = true;
    try {
      const base = ((ocrCurrentFile && ocrCurrentFile.name) || 'skenas').replace(/\.[^.]+$/, '');
      const name = base + '.ocr.txt';
      const body = new File([text], name, { type: 'text/plain' });
      const res = await fetch('/api/acts/' + actId + '/files?name=' + encodeURIComponent(name), {
        method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body,
      });
      const out = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(out.error || 'Nepavyko išsaugoti teksto');
      await loadAll();
      closeModal();
      await actModal(actId);
      toast('Tekstas išsaugotas prie akto');
    } catch (e) {
      toast(e.message, 'err');
      saveTxt.disabled = false;
    }
  };
  if (ocrCurrentFile) ocrRun(ocrCurrentFile);
}

function ocrRun(file) {
  const info = $('#ocrFileInfo');
  const progWrap = $('#ocrProgWrap');
  const status = $('#ocrStatus');
  const result = $('#ocrResult');
  if (!progWrap || !status || !result) return;
  const kind = window.StabasOCR.fileKind(file);
  if (!kind) { toast('Tinka tik PDF arba paveikslėlis', 'err'); return; }
  ocrCurrentFile = file;
  if (info) info.textContent = file.name + ' · ' + fmtSize(file.size);
  result.hidden = true;
  progWrap.hidden = false;
  $('#ocrBar').style.width = '0%';
  status.className = 'act-hint';
  status.textContent = 'Įkeliamas OCR variklis…';
  $('#ocrMsg').textContent = '';
  window.StabasOCR.readFile(file, p => {
    if (!document.getElementById('ocrBar')) return;
    $('#ocrBar').style.width = Math.round((Number(p.progress) || 0) * 100) + '%';
    $('#ocrStatus').textContent = p.text || 'Skaitoma…';
  }).then(res => {
    if (!document.getElementById('ocrText')) return;
    const text = String(res.text || '').trim();
    $('#ocrBar').style.width = '100%';
    $('#ocrStatus').textContent = text
      ? 'Atpažinta · ' + ((res.pages && res.pages.length) || 1) + ' psl.'
      : 'Tekstas nepavyko nuskaityti';
    $('#ocrText').value = text;
    result.hidden = false;
    if (!text) $('#ocrMsg').textContent = 'Bandykite ryškesnį ar didesnį vaizdą.';
  }, e => {
    if (!document.getElementById('ocrStatus')) return;
    $('#ocrStatus').className = 'act-hint err';
    $('#ocrStatus').textContent = 'Klaida: ' + (e && e.message ? e.message : e);
    toast('OCR klaida: ' + (e && e.message ? e.message : e), 'err', 6000);
  });
}

function bindActImport(cid) {
  const btn = $('#actImportXlsx'), inp = $('#actImportFile');
  if (!btn || !inp) return;
  btn.onclick = () => inp.click();
  inp.onchange = () => {
    const f = inp.files && inp.files[0];
    if (!f) return;
    if (!/\.(xlsx|xlsm|pdf)$/i.test(f.name)) {
      inp.value = '';
      toast(f.name.toLowerCase().endsWith('.xls')
        ? 'Senas .xls formatas nepalaikomas – atidarykite Excel ir išsaugokite kaip .xlsx'
        : 'Palaikomi .xlsx, .xlsm ir tekstiniai .pdf failai', 'err', 8000);
      return;
    }
    const reader = new FileReader();
    reader.onload = async () => {
      const run = $('#actImportXlsx');
      try {
        const raw = String(reader.result || '');
        const data = raw.includes(',') ? raw.slice(raw.indexOf(',') + 1) : raw;
        if (run) { run.disabled = true; run.textContent = 'Importuojama…'; }
        const out = await api('acts/import', 'POST', { data, filename: f.name, contract_id: cid || null });
        await loadAll();
        render();
        if (out.acts && out.acts.length) toast('Importuota: ' + out.acts.map(n => 'Nr. ' + n).join(', '));
        else if (out.skipped && out.skipped.length) toast('Jau yra: ' + out.skipped.map(n => 'Nr. ' + n).join(', '));
        if (out.warnings && out.warnings.length) {
          setTimeout(() => alert('Importo pastabos:\n' + out.warnings.join('\n')), 80);
        }
      } catch (e) {
        toast(e.message, 'err');
        if (run) { run.disabled = false; run.innerHTML = icon('upload') + ' Importuoti F2'; }
      }
      inp.value = '';
    };
    reader.onerror = () => toast('Nepavyko perskaityti failo', 'err');
    reader.readAsDataURL(f);
  };
}

async function scanActsDocs() {
  const btns = [$('#actScan'), $('#actScan2')].filter(Boolean);
  const labels = btns.map(b => b.innerHTML);
  btns.forEach(b => { b.disabled = true; b.textContent = 'Ieškoma…'; });
  try {
    const res = await api('acts/scan-docs', 'POST', {});
    const got = (res.imported || []).length;
    const errs = res.errors || [];
    if (got) {
      await loadAll(); render();
      toast('F2 aktai perkelti: ' + (res.imported || []).map(n => 'Nr. ' + n).join(', ')
        + (errs.length ? ' (su pastabomis: ' + errs.length + ')' : ''));
    } else if (errs.length) {
      toast(errs[0].error || 'Nepavyko perkelti F2 formų', 'err', 9000);
    } else if ((res.skipped || []).length) {
      toast('Visi rasti aktai jau yra: ' + (res.skipped || []).map(n => 'Nr. ' + n).join(', '));
    } else if (res.found) {
      toast('Rastos F2 formos, bet aktų perkelti nepavyko', 'err');
    } else {
      toast('Įkeltuose dokumentuose F2 formų nerasta');
    }
  } catch (e) {
    toast(e.message, 'err');
  } finally {
    btns.forEach((b, i) => { b.disabled = false; b.innerHTML = labels[i]; });
  }
}

function exportActsCsv(contract, acts) {
  const rows = [['Sutartis', 'Akto Nr.', 'Akto data', 'Nuo', 'Iki', 'Būsena', 'Sąskaitos Nr.',
    'Sąskaitos data', 'Mokėti iki', 'Suma be PVM', 'PVM', 'Suma su PVM', 'Gauta', 'Skola']];
  acts.forEach(a => {
    const gross = Number(a.current_with_vat) || 0;
    const net = Number(a.current_total) || 0;
    const paid = Number(a.payments) || 0;
    rows.push([
      contract.title || '', a.num, a.date || '', a.period_from || '', a.period_to || '',
      a.status || '', a.invoice_no || '', a.invoice_date || '', a.due_date || '',
      csvNum(net), csvNum(gross - net), csvNum(gross), csvNum(paid), csvNum(Math.max(0, gross - paid)),
    ]);
  });
  csvDownload('aktai-registras.csv', rows);
}

function allActsRegister() {
  const data = S.actsData || {};
  const contracts = data.contracts || [];
  const acts = (data.acts || []).slice().sort((a, b) => {
    const ca = contracts.find(c => Number(c.id) === Number(a.contract_id));
    const cb = contracts.find(c => Number(c.id) === Number(b.contract_id));
    return String(ca?.title || '').localeCompare(String(cb?.title || ''), 'lt')
      || Number(a.num) - Number(b.num);
  });
  const byContract = {};
  contracts.forEach(c => { byContract[c.id] = c; });
  const gross = a => Number(a.current_with_vat) || 0;
  const paid = a => Number(a.payments) || 0;
  const debt = a => Math.max(0, gross(a) - paid(a));
  let filter = 'all';
  const count = {
    all: acts.length,
    draft: acts.filter(a => a.status === 'Juodraštis').length,
    issued: acts.filter(a => a.status !== 'Juodraštis').length,
    debt: acts.filter(a => debt(a) > 0.004).length,
  };
  const openEdit = async (aid) => {
    const a = acts.find(x => Number(x.id) === Number(aid));
    if (!a) return;
    S.actsUI.contract = Number(a.contract_id);
    closeModal();
    await actModal(aid);
  };
  const draw = () => {
    const list = acts.filter(a => {
      if (filter === 'draft') return a.status === 'Juodraštis';
      if (filter === 'issued') return a.status !== 'Juodraštis';
      if (filter === 'debt') return debt(a) > 0.004;
      return true;
    });
    const sum = list.reduce((s, a) => s + gross(a), 0);
    const left = list.reduce((s, a) => s + debt(a), 0);
    $('#regBody').innerHTML = `
      <div class="btn-row reg-filters">
        ${[['all', 'Visi'], ['draft', 'Juodraščiai'], ['issued', 'Išrašyti'], ['debt', 'Su skola']]
          .map(([k, l]) => `<button class="btn small ${filter === k ? 'primary' : ''}" data-reg-filter="${k}">${l} · ${count[k]}</button>`).join('')}
      </div>
      <div class="table-wrap"><table class="table reg-table">
        <thead><tr><th>Sutartis</th><th>Aktas</th><th>Data</th><th>Laikotarpis</th><th class="num-col">Be PVM</th>
        <th class="num-col">Su PVM</th><th class="num-col">Gauta</th><th class="num-col">Skola</th><th>Būsena</th><th></th></tr></thead>
        <tbody>${list.length ? list.map(a => {
          const c = byContract[a.contract_id] || {};
          return `<tr>
            <td class="reg-title">${esc(c.title || '—')}</td>
            <td class="nowrap"><b>Nr. ${a.num}</b></td>
            <td class="nowrap">${esc(fmtDate(a.date) || '—')}</td>
            <td class="nowrap">${esc(fmtDate(a.period_from) || '')} – ${esc(fmtDate(a.period_to) || '')}</td>
            <td class="num-col">${fmtEur(a.current_total)}</td>
            <td class="num-col">${fmtEur(gross(a))}</td>
            <td class="num-col">${fmtEur(paid(a))}</td>
            <td class="num-col ${debt(a) > 0.004 ? 'due' : ''}">${fmtEur(debt(a))}</td>
            <td>${actStatusChip(a.status)}</td>
            <td><div class="acts-actions">
              <a class="act-dl" href="/api/acts/${a.id}/pdf?form=f2" target="_blank" rel="noopener" title="F2 PDF">F2</a>
              <a class="act-dl inv" href="/api/acts/${a.id}/pdf?form=invoice" target="_blank" rel="noopener" title="Sąskaita PDF">SĄS</a>
              <button class="icon-btn" data-reg-edit="${a.id}" title="Atidaryti aktą">${icon('pencil')}</button>
            </div></td></tr>`;
        }).join('') : `<tr><td colspan="10"><div class="empty"><b>Aktų nėra</b>Pagal pasirinktą filtrą aktų nerasta.</div></td></tr>`}</tbody>
        <tfoot><tr><td colspan="5">IŠ VISO (${list.length})</td><td class="num-col">${fmtEur(sum)}</td>
        <td class="num-col">${fmtEur(list.reduce((s, a) => s + paid(a), 0))}</td>
        <td class="num-col">${fmtEur(left)}</td><td colspan="2"></td></tr></tfoot>
      </table></div>`;
    $$('#regBody [data-reg-filter]').forEach(b => b.onclick = () => { filter = b.dataset.regFilter; draw(); });
    $$('#regBody [data-reg-edit]').forEach(b => b.onclick = () => openEdit(b.dataset.regEdit));
  };
  openModal(`
    <div class="modal-head"><h3>Visų sutarčių aktų registras</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
    <div class="modal-body">
      <p class="act-hint">Visi šio projekto sutarčių aktai vienoje lentelėje: sumos, mokėjimai, skola ir būsena.</p>
      <div id="regBody"></div>
    </div>
    <div class="modal-foot"><button class="btn" id="regCsv">${icon('external')} CSV</button><div class="spacer"></div><button class="btn" data-close>Uždaryti</button></div>`,
    { wide: true });
  draw();
  $('#regCsv').onclick = () => {
    const rows = [['Sutartis', 'Sutarties Nr.', 'Akto Nr.', 'Akto data', 'Nuo', 'Iki', 'Būsena', 'Sąskaitos Nr.',
      'Suma be PVM', 'PVM', 'Suma su PVM', 'Gauta', 'Skola']];
    acts.forEach(a => {
      const c = byContract[a.contract_id] || {};
      rows.push([c.title || '', c.number || '', a.num, a.date || '', a.period_from || '', a.period_to || '',
        a.status || '', a.invoice_no || '', csvNum(a.current_total), csvNum(gross(a) - (Number(a.current_total) || 0)),
        csvNum(gross(a)), csvNum(paid(a)), csvNum(debt(a))]);
    });
    csvDownload('visu-sutarciu-aktai.csv', rows);
  };
}

function paymentsJournal(contract) {
  api('contracts/' + contract.id + '/payments').then(d => {
    const payRows = d.payments || [];
    const rows = payRows.length ? payRows.map(p => `
      <tr><td class="c">Nr. ${esc(p.act_num)}</td><td class="nowrap">${esc(fmtDate(p.date) || '—')}</td>
      <td class="num-col">${fmtEur(p.amount)}</td><td>${esc(p.note || '')}</td></tr>`).join('')
      : `<tr><td colspan="4"><div class="empty"><b>Mokėjimų dar nėra</b>Mokėjimus įrašykite aktų redagavimo lange.</div></td></tr>`;
    openModal(`
      <div class="modal-head"><h3>Mokėjimų žurnalas</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
      <div class="modal-body">
        <p class="act-hint">${esc(contract.title)} · visi su šia sutartimi susieti mokėjimai.</p>
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Aktas</th><th>Data</th><th class="num-col">Suma, €</th><th>Pastaba</th></tr></thead>
          <tbody>${rows}</tbody>
          <tfoot><tr><td colspan="2">IŠ VISO GAUTA</td><td class="num-col"><b>${fmtEur(d.total || 0)}</b></td><td></td></tr></tfoot>
        </table></div>
      </div>
      <div class="modal-foot"><button class="btn" id="payCsv">${icon('external')} CSV</button><div class="spacer"></div><button class="btn" data-close>Uždaryti</button></div>`, { wide: true });
    const payCsv = $('#payCsv');
    if (payCsv) payCsv.onclick = () => {
      const out = [['Sutartis', 'Akto Nr.', 'Mokėjimo data', 'Suma', 'Pastaba']];
      payRows.forEach(p => out.push([contract.title || '', p.act_num, p.date || '', csvNum(p.amount), p.note || '']));
      out.push(['', '', 'IŠ VISO', csvNum(d.total || 0), '']);
      csvDownload('mokejimai.csv', out);
    };
  }).catch(e => toast(e.message, 'err'));
}

function unfinishedWorks(contract) {
  api('contracts/' + contract.id + '/unfinished').then(d => {
    const groups = d.groups || [];
    const rows = groups.length ? groups.map((g, i) => `
      <tr><td class="row-muted">${i + 1}</td><td>${esc(g.name)}</td><td class="num-col">${fmtEur(g.price)}</td>
      <td class="num-col">${fmtEur(g.done)}</td><td class="num-col">${fmtNum(g.pct)} %</td>
      <td class="num-col"><b>${fmtEur(g.left)}</b></td></tr>`).join('')
      : `<tr><td colspan="6"><div class="empty"><b>Neatliktų darbų nėra</b>Visos sutarties grupės atliktos pagal aktus.</div></td></tr>`;
    openModal(`
      <div class="modal-head"><h3>Neatlikti darbai</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
      <div class="modal-body">
        <p class="act-hint">${esc(contract.title)} · sutartinė kaina atėmus visų F2 aktų sumas.</p>
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Nr.</th><th>Darbų grupė</th><th class="num-col">Sutartis</th><th class="num-col">Atlikta</th>
          <th class="num-col">%</th><th class="num-col">Liko</th></tr></thead>
          <tbody>${rows}</tbody>
          <tfoot><tr><td colspan="5">LIKO ATLIKTI</td><td class="num-col"><b>${fmtEur(d.left || 0)}</b></td></tr></tfoot>
        </table></div>
      </div>
      <div class="modal-foot"><button class="btn" id="unfCsv">${icon('external')} CSV</button><div class="spacer"></div><button class="btn" data-close>Uždaryti</button></div>`, { wide: true });
    const unfCsv = $('#unfCsv');
    if (unfCsv) unfCsv.onclick = () => {
      const out = [['Nr.', 'Darbų grupė', 'Sutartis', 'Atlikta', 'Procentas', 'Liko']];
      groups.forEach((g, i) => out.push([i + 1, g.name || '', csvNum(g.price), csvNum(g.done), csvNum(g.pct), csvNum(g.left)]));
      out.push(['', 'LIKO ATLIKTI', csvNum(groups.reduce((s, g) => s + (Number(g.price) || 0), 0)),
        csvNum(groups.reduce((s, g) => s + (Number(g.done) || 0), 0)), '', csvNum(d.left || 0)]);
      csvDownload('neatlikti-darbai.csv', out);
    };
  }).catch(e => toast(e.message, 'err'));
}

function contractModal(contract) {
  const c = contract || { title: '', customer: '', contractor: '', number: '', signed: '', address: '', vat: 21, retention: 5, advance: 0, terms: 30, buyer_code: '', buyer_vat: '', buyer_address: '', rep_contractor: '', rep_technical: '', rep_customer: '', note: '' };
  openModal(`
    <div class="modal-head"><h3>${contract ? 'Redaguoti sutartį' : 'Nauja sutartis'}</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
    <form id="contractForm" class="modal-body">
      <div class="form-grid">
        <div class="field full"><label>Sutarties pavadinimas</label><input class="input" name="title" required value="${esc(c.title)}" placeholder="Darbų pavadinimas ir adresas"></div>
        <div class="field"><label>Užsakovas</label><input class="input" name="customer" value="${esc(c.customer)}"></div>
        <div class="field"><label>Rangovas</label><input class="input" name="contractor" value="${esc(c.contractor)}"></div>
        <div class="field"><label>Sutarties data</label><input class="input" type="date" name="signed" value="${esc(c.signed)}"></div>
        <div class="field"><label>Sutarties numeris</label><input class="input" name="number" value="${esc(c.number)}"></div>
        <div class="field full"><label>Objekto adresas</label><input class="input" name="address" value="${esc(c.address)}"></div>
        <div class="field"><label>Pirkėjo įm. kodas</label><input class="input" name="buyer_code" value="${esc(c.buyer_code || '')}"></div>
        <div class="field"><label>Pirkėjo PVM kodas</label><input class="input" name="buyer_vat" value="${esc(c.buyer_vat || '')}" placeholder="LT..."></div>
        <div class="field full"><label>Pirkėjo adresas</label><input class="input" name="buyer_address" value="${esc(c.buyer_address || '')}"></div>
        <div class="field"><label>PVM, %</label><input class="input" type="number" min="0" max="100" step="0.01" name="vat" value="${numAttr(c.vat || 21)}"></div>
        <div class="field"><label>Sulaikoma suma, %</label><input class="input" type="number" min="0" max="100" step="0.01" name="retention" value="${numAttr(c.retention)}"></div>
        <div class="field"><label>Avanso išskaita, %</label><input class="input" type="number" min="0" max="100" step="0.01" name="advance" value="${numAttr(c.advance)}"></div>
        <div class="field"><label>Apmokėjimo terminas, d.</label><input class="input" type="number" min="0" max="365" step="1" name="terms" value="${numAttr(c.terms || 30)}"></div>
        <div class="field"><label>Rangovo atstovas</label><input class="input" name="rep_contractor" value="${esc(c.rep_contractor)}" placeholder="Vardas, pavardė, pareigos"></div>
        <div class="field"><label>Techninis prižiūrėtojas</label><input class="input" name="rep_technical" value="${esc(c.rep_technical)}" placeholder="Vardas, pavardė, pareigos"></div>
        <div class="field"><label>Užsakovo atstovas</label><input class="input" name="rep_customer" value="${esc(c.rep_customer)}" placeholder="Vardas, pavardė, pareigos"></div>
        <div class="field full"><label>Pastaba</label><textarea class="input" name="note" placeholder="Sutarties pastabos, priedai…">${esc(c.note)}</textarea></div>
      </div>
    </form>
    <div class="modal-foot"><div class="spacer"></div><button class="btn" data-close>Atšaukti</button><button class="btn primary" id="saveContract">Išsaugoti</button></div>`, { wide: true });
  $('#saveContract').onclick = async () => {
    const form = $('#contractForm');
    if (!form.reportValidity()) return;
    try {
      const res = contract ? await api('contracts/' + contract.id, 'PATCH', formValues(form)) : await api('contracts', 'POST', formValues(form));
      if (!contract && res.contract) S.actsUI.contract = Number(res.contract.id);
      closeModal(); await loadAll(); render(); toast(contract ? 'Sutartis atnaujinta' : 'Sutartis sukurta');
    } catch (e) { toast(e.message, 'err'); }
  };
}

function groupEditRow(g) {
  return `<tr data-gid="${g && g.id ? g.id : 0}">
    <td><input class="input" name="gname" value="${esc(g ? g.name : '')}" placeholder="Darbų grupės pavadinimas"></td>
    <td><input class="input" name="gunit" value="${esc(g ? (g.unit || 'Kompl.') : 'Kompl.')}"></td>
    <td><input class="input" type="number" min="0" step="0.01" name="gqty" value="${numAttr(g ? g.qty : 1)}"></td>
    <td><input class="input" type="number" min="0" step="0.01" name="gprice" value="${numAttr(g ? g.price : 0)}"></td>
    <td><button type="button" class="row-x" data-gdel title="Šalinti">×</button></td>
  </tr>`;
}

function groupsModal(contract) {
  const groups = (S.actsData?.groups || []).filter(g => Number(g.contract_id) === Number(contract.id) && Number(g.active) !== 0);
  openModal(`
    <div class="modal-head"><h3>Darbų grupės ir sutartinės kainos</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
    <div class="modal-body">
      <p class="act-hint">Kaina – visa grupės kaina pagal sutartį (ne už vienetą). Panaudota grupė iš istorinių aktų neištrinama, tik paslepiama.</p>
      <div class="table-wrap">
        <table class="table act-groups-edit">
          <thead><tr><th>Pavadinimas</th><th>Vnt.</th><th class="num-col">Kiekis</th><th class="num-col">Kaina, €</th><th></th></tr></thead>
          <tbody id="groupEditBody">${groups.map(groupEditRow).join('')}</tbody>
        </table>
      </div>
      <button type="button" class="btn ghost small" id="groupAddRow">${icon('plus')} Pridėti grupę</button>
    </div>
    <div class="modal-foot"><div class="spacer"></div><button class="btn" data-close>Atšaukti</button><button class="btn primary" id="saveGroups">Išsaugoti</button></div>`, { wide: true });
  const bindDel = () => $$('#groupEditBody [data-gdel]').forEach(b => b.onclick = () => b.closest('tr').remove());
  bindDel();
  $('#groupAddRow').onclick = () => {
    $('#groupEditBody').insertAdjacentHTML('beforeend', groupEditRow(null));
    bindDel();
  };
  $('#saveGroups').onclick = async () => {
    const rows = $$('#groupEditBody tr').map(tr => ({
      id: Number(tr.dataset.gid) || 0,
      name: $('[name=gname]', tr).value.trim(),
      unit: $('[name=gunit]', tr).value.trim() || 'Kompl.',
      qty: Number($('[name=gqty]', tr).value) || 1,
      price: Number($('[name=gprice]', tr).value) || 0,
    })).filter(r => r.name);
    if (!rows.length) { toast('Įveskite bent vieną grupę', 'err'); return; }
    try {
      await api('contracts/' + contract.id + '/groups', 'POST', { groups: rows });
      closeModal(); await loadAll(); render(); toast('Darbų grupės išsaugotos');
    } catch (e) { toast(e.message, 'err'); }
  };
}

function actPayRow(p) {
  const v = p || {};
  return `<tr>
    <td><input class="input" type="date" name="paydate" value="${esc(v.date || todayISO())}"></td>
    <td><input class="input pay-amount" type="number" min="0" step="0.01" inputmode="decimal" name="payamount" value="${v.amount ? numAttr(v.amount) : ''}" placeholder="0"></td>
    <td><input class="input" name="paynote" value="${esc(v.note || '')}" placeholder="Pvz. avansas, mokėjimas Nr."></td>
    <td><button type="button" class="row-x" data-paydel title="Šalinti mokėjimą">×</button></td>
  </tr>`;
}

function actEditRow(g, i) {
  const prev = Number(g.prev) || 0;
  const current = Number(g.current) || 0;
  const price = Number(g.price) || 0;
  return `<tr data-gid="${g.id}" data-price="${price}" data-prev="${prev}">
    <td class="c">${i + 1}</td>
    <td>${esc(g.name)}<small class="act-unit">${esc(g.unit || '')}</small></td>
    <td class="num-col">${fmtEur(price)}</td>
    <td class="num-col">${fmtEur(prev)}</td>
    <td class="num-col"><input class="work-num act-amount" type="number" min="0" step="0.01" inputmode="decimal" value="${current ? numAttr(current) : ''}" placeholder="0"></td>
    <td class="num-col act-line-total">${fmtEur(prev + current)}</td>
    <td class="num-col act-line-pct">${price ? fmtNum((prev + current) / price * 100) + ' %' : '—'}</td>
  </tr>`;
}

function updateActCalc(contract) {
  const vat = Number(contract.vat) || 0;
  const ret = Number(contract.retention) || 0;
  const adv = Number(contract.advance) || 0;
  let cur = 0, total = 0, price = 0;
  $$('#actEditBody tr').forEach(tr => {
    const p = Number(tr.dataset.prev) || 0;
    const priceG = Number(tr.dataset.price) || 0;
    const c = Number($('.act-amount', tr).value) || 0;
    cur += c; total += p + c; price += priceG;
    $('.act-line-total', tr).textContent = fmtEur(p + c);
    $('.act-line-pct', tr).textContent = priceG ? fmtNum((p + c) / priceG * 100) + ' %' : '—';
  });
  const vatCur = Math.round(cur * vat) / 100;
  const vatTotal = Math.round(total * vat) / 100;
  $('#actCurTotal').textContent = fmtEur(cur);
  $('#actTotalTotal').textContent = fmtEur(total);
  $('#actTotalPct').textContent = fmtNum(price ? total / price * 100 : 0) + ' %';
  $('#actVatCur').textContent = fmtEur(vatCur);
  $('#actVatTotal').textContent = fmtEur(vatTotal);
  $('#actCurVat').textContent = fmtEur(cur + vatCur);
  $('#actTotalVat').textContent = fmtEur(total + vatTotal);
  const retention = cur * ret / 100;
  const advance = cur * adv / 100;
  const payable = cur - retention - advance;
  $('#actCalc').innerHTML = `
    <div><span>Šio laikotarpio atlikta</span><b>${fmtEur(cur)}</b></div>
    <div><span>Sulaikymas ${fmtNum(ret)} %</span><b>${fmtEur(retention)}</b></div>
    <div><span>Avanso išskaita ${fmtNum(adv)} %</span><b>${fmtEur(advance)}</b></div>
    <div class="strong"><span>Mokėtina be PVM</span><b>${fmtEur(payable)}</b></div>
    <div><span>PVM ${fmtNum(vat)} %</span><b>${fmtEur(Math.round(payable * vat) / 100)}</b></div>
    <div class="strong"><span>Mokėtina su PVM</span><b>${fmtEur(payable + Math.round(payable * vat) / 100)}</b></div>`;
}

async function actModal(id) {
  const cid = Number(S.actsUI.contract) || 0;
  const contract = (S.actsData?.contracts || []).find(c => Number(c.id) === cid);
  if (!contract) { toast('Pasirinkite sutartį', 'err'); return; }
  let groups = [];
  let payments = [];
  let files = [];
  let act;
  if (id) {
    let detail;
    try { detail = await api('acts/' + id); } catch (e) { toast(e.message, 'err'); return; }
    act = detail.act;
    groups = detail.groups;
    payments = (detail.payments || []).slice();
    files = (detail.files || []).slice();
    if (!payments.length && Number(act.received) > 0) {
      payments = [{ date: act.date || todayISO(), amount: Number(act.received), note: '' }];
    }
  } else {
    const acts = (S.actsData.acts || []).filter(a => Number(a.contract_id) === cid).sort((a, b) => Number(a.num) - Number(b.num));
    const [pf, pt] = actMonthRange();
    act = { num: acts.length ? Number(acts[acts.length - 1].num) + 1 : 1, date: todayISO(), period_from: pf, period_to: pt, status: 'Juodraštis', received: 0, debt: 0, note: '',
      invoice_no: `${todayISO().slice(0, 4)}-${String(acts.length ? Number(acts[acts.length - 1].num) + 1 : 1).padStart(3, '0')}`,
      invoice_date: todayISO(), due_date: addDaysISO(todayISO(), contract.terms || 30),
      invoice_note: (S.data.company && S.data.company.invoice_note) || '' };
    if (acts.length) {
      try {
        const lastDetail = await api('acts/' + acts[acts.length - 1].id);
        groups = lastDetail.groups.map(g => ({ ...g, prev: g.total, current: 0, total: g.total, prev_pct: g.total_pct, current_pct: 0, total_pct: g.total_pct }));
      } catch (e) { groups = []; }
    } else {
      groups = (S.actsData.groups || []).filter(g => Number(g.contract_id) === cid && Number(g.active) !== 0)
        .map(g => ({ ...g, prev: 0, current: 0, total: 0, prev_pct: 0, current_pct: 0, total_pct: 0 }));
    }
  }
  act.rep_contractor = act.rep_contractor || contract.rep_contractor || '';
  act.rep_technical = act.rep_technical || contract.rep_technical || '';
  act.rep_customer = act.rep_customer || contract.rep_customer || '';
  openModal(`
    <div class="modal-head"><h3>${id ? 'Aktas Nr. ' + act.num : 'Naujas aktas'}</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
    <form id="actForm" class="modal-body act-modal-body">
      <div class="form-grid">
        <div class="field"><label>Akto Nr.</label><input class="input" type="number" min="1" step="1" name="num" value="${act.num}"></div>
        <div class="field"><label>Akto data</label><input class="input" type="date" name="date" value="${esc(act.date)}"></div>
        <div class="field"><label>Nuo</label><input class="input" type="date" name="period_from" value="${esc(act.period_from)}"></div>
        <div class="field"><label>Iki</label><input class="input" type="date" name="period_to" value="${esc(act.period_to)}"></div>
        <div class="field"><label>Būsena</label><select class="select" name="status">${(S.actsData.statuses || []).map(s => `<option ${act.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
      </div>
      <div class="form-grid act-invoice">
        <div class="field"><label>Sąskaitos-faktūros Nr.</label><input class="input" name="invoice_no" value="${esc(act.invoice_no || '')}" placeholder="pvz. 2026-001"></div>
        <div class="field"><label>Sąskaitos data</label><input class="input" type="date" name="invoice_date" id="actInvoiceDate" value="${esc(act.invoice_date || '')}"></div>
        <div class="field"><label>Apmokėti iki</label><input class="input" type="date" name="due_date" id="actDueDate" value="${esc(act.due_date || '')}"></div>
        <div class="field full"><label>Sąskaitos pastaba</label><input class="input" name="invoice_note" value="${esc(act.invoice_note || '')}" placeholder="Papildoma informacija sąskaitoje"></div>
      </div>
      <p class="act-hint">Sąskaitai naudojami įmonės rekvizitai iš Nustatymų → Mano įmonė; pirkėjo rekvizitai – iš sutarties.</p>
      <div class="form-grid act-reps">
        <div class="field"><label>Rangovo atstovas</label><input class="input" name="rep_contractor" value="${esc(act.rep_contractor)}" placeholder="Vardas, pavardė, pareigos"></div>
        <div class="field"><label>Techninis prižiūrėtojas</label><input class="input" name="rep_technical" value="${esc(act.rep_technical)}" placeholder="Vardas, pavardė, pareigos"></div>
        <div class="field"><label>Užsakovo atstovas</label><input class="input" name="rep_customer" value="${esc(act.rep_customer)}" placeholder="Vardas, pavardė, pareigos"></div>
      </div>
      <p class="act-hint">Šie atstovai spausdinami F2 akto ir F3 pažymos parašų blokuose. Mokėjimų sumos žemiau rodomos F3 pažymoje.</p>
      <div class="table-wrap act-edit-wrap">
        <table class="table act-edit-table">
          <thead><tr><th>Nr.</th><th>Darbų grupė</th><th class="num-col">Sutartinė kaina</th><th class="num-col">Praeitais</th><th class="num-col">Šį laikotarpį, €</th><th class="num-col">Iš viso</th><th class="num-col">%</th></tr></thead>
          <tbody id="actEditBody">${groups.map(actEditRow).join('')}</tbody>
          <tfoot>
            <tr><td colspan="4">IŠ VISO:</td><td id="actCurTotal"></td><td id="actTotalTotal"></td><td id="actTotalPct"></td></tr>
            <tr><td colspan="4">PVM:</td><td id="actVatCur"></td><td id="actVatTotal"></td><td></td></tr>
            <tr><td colspan="4">IŠ VISO SU PVM:</td><td id="actCurVat"></td><td id="actTotalVat"></td><td></td></tr>
          </tfoot>
        </table>
      </div>
      <div class="act-pay-block">
        <div class="act-pay-head"><b>Gauti mokėjimai (F3 pažymoje)</b><span class="act-pay-sum" id="actPayTotal"></span></div>
        <div class="table-wrap">
          <table class="table act-pay-table">
            <thead><tr><th>Mokėjimo data</th><th class="num-col">Suma, €</th><th>Pastaba</th><th></th></tr></thead>
            <tbody id="actPayBody">${payments.map(actPayRow).join('')}</tbody>
          </table>
        </div>
        <button type="button" class="btn ghost small" id="actPayAdd">${icon('plus')} Pridėti mokėjimą</button>
        <p class="act-hint">F3 pažymoje mokėjimai spausdinami po eilutę. Mokėjimą įrašykite vieną kartą — vėlesnėse pažymose jis atsiras automatiškai.</p>
      </div>
      <div class="act-files-block">
        <div class="act-pay-head"><b>Akto failai</b><span class="act-pay-sum">${files.length ? files.length + ' ' + (files.length === 1 ? 'failas' : 'failai') : 'nėra'}</span></div>
        <div class="act-files-list" id="actFilesList">${files.map(f => `
          <div class="act-file-row">
            <a class="act-file-link" href="${esc(f.url)}" target="_blank" rel="noopener">${esc(f.name)}</a>
            <span class="act-file-meta">${fmtSize(f.size)}${f.created ? ' · ' + esc(fmtDate(String(f.created).slice(0, 10)) || '') : ''}</span>
            ${/\.(pdf|png|jpe?g|webp|bmp|gif)$/i.test(f.name) ? `<button type="button" class="icon-btn" data-actfile-ocr="${f.id}" title="Atpažinti tekstą (OCR)">${icon('camera')}</button>` : ''}
            <button type="button" class="icon-btn" data-actfile-del="${f.id}" title="Pašalinti failą">${icon('x')}</button>
          </div>`).join('') || '<div class="act-file-empty">Failų dar nėra</div>'}</div>
        ${id ? `<button type="button" class="btn ghost small" id="actFileAdd">${icon('upload')} Pridėti failą</button>
        <input type="file" id="actFileInput" hidden accept=".pdf,.png,.jpg,.jpeg,.webp,.bmp,.gif,.docx,.xlsx,.doc,.xls,.dwg,.zip,.txt">` : '<p class="act-hint">Failus (pasirašytą aktą, skeną ar nuotrauką) galėsite pridėti išsaugoję aktą.</p>'}
        <p class="act-hint">Failai saugomi vietoje, programos duomenų kataloge, ir priskiriami tik šiam aktui.</p>
      </div>
      <div class="form-grid">
        <div class="field"><label>Užsakovo skola, €</label><input class="input" type="number" min="0" step="0.01" name="debt" value="${numAttr(act.debt)}"></div>
        <div class="field"><label>Pastaba</label><input class="input" name="note" value="${esc(act.note)}"></div>
      </div>
      <div class="act-calc" id="actCalc"></div>
    </form>
    <div class="modal-foot">
      ${id ? `<button class="btn danger" id="delAct">${icon('x')} Šalinti</button>` : ''}
      <div class="spacer"></div>
      ${id ? `<a class="btn" href="/api/acts/${id}/pdf?form=f2" target="_blank" rel="noopener">F2 PDF</a><a class="btn" href="/api/acts/${id}/pdf?form=f3" target="_blank" rel="noopener">F3 PDF</a><a class="btn" href="/api/acts/${id}/pdf?form=invoice" target="_blank" rel="noopener">Sąskaita PDF</a><a class="btn" href="/api/acts/${id}/xlsx?form=f2" rel="noopener">F2 Excel</a><a class="btn" href="/api/acts/${id}/xlsx?form=f3" rel="noopener">F3 Excel</a>` : ''}
      <button class="btn" data-close>Atšaukti</button>
      <button class="btn primary" id="saveAct">Išsaugoti</button>
    </div>`, { wide: true });
  updateActCalc(contract);
  if ($('#actInvoiceDate')) $('#actInvoiceDate').onchange = e => {
    if (!$('#actDueDate').value) $('#actDueDate').value = addDaysISO(e.target.value, contract.terms || 30);
  };
  $$('#actEditBody .act-amount').forEach(inp => inp.oninput = () => updateActCalc(contract));
  const updatePayTotal = () => {
    const sum = $$('#actPayBody .pay-amount').reduce((a, inp) => a + (Number(inp.value) || 0), 0);
    $('#actPayTotal').textContent = 'Iš viso: ' + fmtEur(sum);
  };
  const bindPayDel = () => $$('#actPayBody [data-paydel]').forEach(b => b.onclick = () => {
    b.closest('tr').remove(); updatePayTotal();
  });
  updatePayTotal();
  bindPayDel();
  $$('#actPayBody .pay-amount').forEach(inp => inp.oninput = updatePayTotal);
  $('#actPayAdd').onclick = () => {
    $('#actPayBody').insertAdjacentHTML('beforeend', actPayRow(null));
    bindPayDel(); updatePayTotal();
    $$('#actPayBody .pay-amount').forEach(inp => inp.oninput = updatePayTotal);
  };
  if (id) {
    const fileInp = $('#actFileInput');
    const fileBtn = $('#actFileAdd');
    if (fileBtn && fileInp) {
      fileBtn.onclick = () => fileInp.click();
      fileInp.onchange = async () => {
        const f = fileInp.files && fileInp.files[0];
        if (!f) return;
        if (f.size > 60 * 1024 * 1024) { toast('Failas didesnis nei 60 MB', 'err'); fileInp.value = ''; return; }
        fileBtn.disabled = true;
        fileBtn.textContent = 'Įkeliama…';
        try {
          const res = await fetch('/api/acts/' + id + '/files?name=' + encodeURIComponent(f.name), {
            method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: f,
          });
          const out = await res.json().catch(() => ({}));
          if (!res.ok) throw new Error(out.error || 'Nepavyko įkelti failo');
          closeModal();
          await actModal(id);
          await loadAll();
          render();
          toast('Failas pridėtas');
        } catch (e) {
          toast(e.message, 'err');
          fileBtn.disabled = false;
          fileBtn.innerHTML = icon('upload') + ' Pridėti failą';
        }
        fileInp.value = '';
      };
    }
    $$('#actFilesList [data-actfile-ocr]').forEach(b => b.onclick = async () => {
      const f = files.find(x => Number(x.id) === Number(b.dataset.actfileOcr));
      if (!f) return;
      try {
        const res = await fetch(f.url);
        if (!res.ok) throw new Error('Nepavyko atidaryti failo');
        const blob = await res.blob();
        closeModal();
        ocrModal({
          mode: 'text', actId: id, contractId: contract.id,
          file: new File([blob], f.name, { type: blob.type || 'application/octet-stream' }),
        });
      } catch (e) { toast(e.message, 'err'); }
    });
    $$('#actFilesList [data-actfile-del]').forEach(b => b.onclick = async () => {
      if (!confirm('Pašalinti šį failą?')) return;
      try {
        await api('act-files/' + b.dataset.actfileDel, 'DELETE');
        closeModal();
        await actModal(id);
        await loadAll();
        render();
        toast('Failas pašalintas');
      } catch (e) { toast(e.message, 'err'); }
    });
  }
  $('#saveAct').onclick = async () => {
    const form = $('#actForm');
    if (!form.reportValidity()) return;
    const body = formValues(form);
    body.contract_id = cid;
    const items = {};
    $$('#actEditBody tr').forEach(tr => {
      const value = Number($('.act-amount', tr).value) || 0;
      if (Math.abs(value) > 0.004) items[tr.dataset.gid] = value;
    });
    body.items = items;
    body.payments = $$('#actPayBody tr').map(tr => ({
      date: $('[name=paydate]', tr).value,
      amount: Number($('[name=payamount]', tr).value) || 0,
      note: $('[name=paynote]', tr).value.trim(),
    })).filter(p => p.amount > 0.004);
    try {
      if (id) await api('acts/' + id, 'PATCH', body);
      else await api('acts', 'POST', body);
      closeModal(); await loadAll(); render(); toast(id ? 'Aktas atnaujintas' : 'Aktas sukurtas');
    } catch (e) { toast(e.message, 'err'); }
  };
  if (id) $('#delAct').onclick = async () => {
    if (!confirm('Pašalinti šį aktą?')) return;
    try {
      await api('acts/' + id, 'DELETE');
      closeModal(); await loadAll(); render(); toast('Aktas pašalintas');
    } catch (e) { toast(e.message, 'err'); }
  };
}

/* ============ problemos ============ */
const PROBLEM_TYPE_CLASS = {
  'Kvadratūra': 'blue', 'Kiekis': 'amber', 'Kaina': 'purple',
  'Reikalavimas': 'gray', 'Normatyvas': 'gray',
};
const PROBLEM_SEV_LABEL = { high: 'Kritinė', medium: 'Svarbi', info: 'Pastaba' };

function problemWord(n) {
  n = Math.abs(Number(n) || 0);
  if (n % 10 === 1 && n % 100 !== 11) return 'problema';
  if (n % 10 >= 2 && n % 10 <= 9 && !(n % 100 >= 11 && n % 100 <= 19)) return 'problemos';
  return 'problemų';
}

async function renderProblems(v) {
  v.innerHTML = `
    <div class="page-head">
      <div class="works-title"><h1>Problemos</h1><p>Viso pastato nesutapimai: kvadratūra, kiekiai, kainos, reikalavimai ir normatyvai. Sąrašas sudaromas automatiškai iš sąmatų, BD rodiklių, DWG ir projekto dokumentų.</p></div>
      <div class="head-btns">
        <button class="btn small ghost" id="problemsRefresh">${icon('refresh')} Atnaujinti</button>
        <button class="btn small ghost" id="problemsPrint">${icon('printer')} Spausdinti</button>
      </div>
    </div>
    <div id="problemsBody"><div class="card pad"><div class="empty">Tikrinami pastato duomenys…</div></div></div>`;
  $('#problemsRefresh').onclick = () => loadProblems(true);
  $('#problemsPrint').onclick = () => window.print();
  S.problemsUI = { type: '', section: '' };
  if (S.problems) renderProblemsBody($('#problemsBody'), S.problems);
  else await loadProblems(false);
}

async function loadProblems(force) {
  const body = $('#problemsBody');
  if (!body) return;
  const btn = $('#problemsRefresh');
  if (force) {
    body.innerHTML = '<div class="card pad"><div class="empty">Tikrinami pastato duomenys…</div></div>';
    if (btn) btn.disabled = true;
  }
  try {
    const d = await api('problems' + (force ? '?force=1' : ''));
    S.problems = d;
    const nav = $('#navProblems');
    if (nav) {
      nav.textContent = d.summary.problems || '';
      nav.title = `${d.summary.problems} ${problemWord(d.summary.problems)} · ${d.summary.resolved || 0} išspręsta · ${d.summary.checks} patikros`;
    }
    renderProblemsBody(body, d);
  } catch (e) {
    body.innerHTML = `<div class="card pad"><div class="empty"><b>Nepavyko atlikti patikros</b>${esc(e.message)}</div></div>`;
  } finally {
    if (btn) btn.disabled = false;
  }
}

function schedTileHtml(s) {
  const sum = s.summary || {};
  const isSpec = s.kind === 'spec';
  const resolvedN = Number(sum.resolvedIssues) || 0;
  const isResolved = !!s.resolved;
  const works = isSpec ? 1 : (sum.works || 0);
  const ok = isSpec ? (s.status === 'ok' ? 1 : 0) : (sum.ok || 0);
  const rawBad = isSpec ? (s.status === 'bad' ? 1 : 0)
    : (sum.diff || 0) + (sum.unit || 0) + (sum.missingWorks || 0);
  const bad = isSpec ? (isResolved ? 0 : rawBad) : Math.max(0, rawBad - resolvedN);
  const status = s.status === 'no-works'
    ? (isResolved ? 'ok' : 'no-works')
    : (!sum.rows ? 'empty' : (bad ? 'bad' : 'ok'));
  const chip = isSpec
    ? (Math.abs(Number(sum.diff) || 0) > 0.5
        ? (isResolved
            ? `<span class="chip green">Sutarta · ${fmtNum(Math.abs(sum.diff))} vnt.</span>`
            : `<span class="chip amber">${fmtNum(Math.abs(sum.diff))} vnt. skirtumas</span>`)
        : '<span class="chip green">Sutampa</span>')
    : s.status === 'no-works'
      ? (isResolved ? '<span class="chip green">Sprendimas</span>' : '<span class="chip amber">Nėra sąmatos</span>')
    : status === 'empty' ? '<span class="chip gray">Neperskaityta</span>'
    : status === 'bad' ? `<span class="chip amber">${bad} ${mismatchWord(bad)}</span>`
    : `<span class="chip green">${sum.ok || 0}/${sum.works || 0} sutampa${resolvedN ? ' · sprendimas' : ''}</span>`;
  const pct = isSpec ? (isResolved ? 100 : (works ? Math.round(ok / works * 100) : 0))
    : (works ? Math.min(100, Math.round((ok + resolvedN) / works * 100)) : 0);
  const open = s.docId
    ? `<button class="btn small ghost sched-open" data-sched-doc="${s.docId}" data-sched-page="${(s.pages || [1])[0]}">${icon('external')} ${esc(s.pageLabel)}</button>`
    : '';
  const issues = [];
  if (isSpec) {
    issues.push(`<div class="sched-issue"><span class="chip gray mono">D-01–D-08</span><span>${fmtNum(sum.specTotal)} vnt. specifikacijoje ↔ ${fmtNum(sum.worksTotal)} vnt. sąmatoje</span><small>${fmtNum(sum.diff)}</small></div>`);
  } else {
    (s.matches || []).filter(m => m.status !== 'ok').slice(0, 4).forEach(m => {
      const r = m.row || {};
      const text = m.status === 'diff' ? `${fmtNum(r.qty)} ${schedUnit(r.unit)} → ${fmtNum(m.qty)} ${schedUnit(m.unit)}`
        : m.status === 'unit' ? `${fmtNum(r.qty)} ${schedUnit(r.unit)} → ${fmtNum(m.qty)} ${schedUnit(m.unit)} (vienetas)`
        : 'Eilutė žiniaraštyje nerasta';
      issues.push(`<div class="sched-issue"><span class="chip ${m.resolved ? 'green' : (m.status === 'diff' ? 'red' : 'amber')} mono">${esc(m.code)}</span><span>${esc(text)}</span><small>${m.resolved ? 'sprendimas' : (r.page ? 'l. ' + r.page : '')}</small></div>`);
    });
    (s.extras || []).slice(0, 2).forEach(r => issues.push(`<div class="sched-issue"><span class="chip ${s.extrasResolved ? 'green' : 'gray'}">+</span><span>${esc(String(r.title).slice(0, 80))}</span><small>${fmtNum(r.qty)} ${esc(schedUnit(r.unit))}${s.extrasResolved ? ' · sprendimas' : ''}</small></div>`));
  }
  const workStats = isSpec
    ? `<span><b>${fmtNum(sum.specTotal)}</b> spec.</span><span><b>${fmtNum(sum.worksTotal)}</b> sąmatoje</span>${isResolved ? '<span class="ok"><b>PV</b> sprendimas</span>' : ''}`
    : s.status === 'no-works'
      ? `<span class="${isResolved ? 'ok' : 'bad'}"><b>${sum.rows || 0}</b> be sąmatos${isResolved ? ' · sprendimas' : ''}</span>`
      : `<span><b>${sum.matched || 0}</b> susietos</span><span><b>${sum.ok || 0}</b> sutampa</span>${bad ? `<span class="bad"><b>${bad}</b> ${mismatchWord(bad)}</span>` : ''}${resolvedN ? `<span class="ok"><b>${resolvedN}</b> sprendimas</span>` : ''}`;
  return `<article class="sched-tile ${status}">
    <div class="sched-tile-head"><b>${esc(s.label)}</b>${chip}</div>
    <div class="sched-tile-sub">${esc(s.doc)} ${esc(s.pageLabel)} · ${esc(s.note || '')}</div>
    <div class="sched-bar"><i class="${bad ? 'bad' : ''}" style="width:${pct}%"></i></div>
    <div class="sched-tile-stats"><span><b>${sum.rows || 0}</b> ${linesWord(sum.rows || 0)}</span>${workStats}</div>
    ${issues.length ? `<div class="sched-issues">${issues.join('')}</div>` : ''}
    ${open}
  </article>`;
}

function decisionCardHtml(p) {
  const dec = p.decision || {};
  const when = dec.updated ? String(dec.updated).replace('T', ' ').slice(0, 16) : '';
  const statusChip = dec.status === 'Su sąlyga'
    ? '<span class="chip green">Su sąlyga</span>'
    : '<span class="chip green">Išspręsta</span>';
  return `<article class="problem solved ${esc(p.severity)}">
    <div class="problem-side">
      <span class="chip ${PROBLEM_TYPE_CLASS[p.type] || 'gray'}">${esc(p.type)}</span>
      ${statusChip}
      <span class="problem-sec">${esc(p.sectionLabel || 'Visas pastatas')}</span>
    </div>
    <div class="problem-main">
      <b>${esc(p.title)}</b>
      <p>${esc(p.detail)}</p>
      <div class="decision-note"><span class="decision-mark">${icon('check')}</span><div><b>Sprendimas</b>${esc(dec.note || '')}</div></div>
      ${dec.basis ? `<div class="decision-basis"><b>Pagrindas</b> ${esc(dec.basis)}</div>` : ''}
      ${(p.codes || []).length ? `<div class="problem-codes">${p.codes.map(c => `<span class="chip gray mono">${esc(c)}</span>`).join('')}</div>` : ''}
    </div>
    <div class="problem-compare">
      ${p.expected ? `<div class="cmp-row"><small>Turėtų būti</small><b>${esc(p.expected)}</b></div>` : ''}
      ${p.actual ? `<div class="cmp-row"><small>Duomenyse</small><b>${esc(p.actual)}</b></div>` : ''}
      ${p.source ? `<small class="problem-src">${esc(p.source)}</small>` : ''}
      <small class="decision-meta">${esc(dec.owner || 'Projekto vadovas')}${when ? ' · ' + esc(when) : ''}</small>
      <button class="btn small ghost" data-reopen="${esc(dec.key || '')}">Grąžinti į aktyvias</button>
    </div>
  </article>`;
}

function decisionModal(p) {
  const key = p.decision?.key || `${p.type}|${p.section || ''}|${p.title}`;
  openModal(`
    <div class="modal-head"><h3>Sprendimas dėl nesutapimo</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
    <form id="decisionForm" class="modal-body">
      <div class="decision-target"><span class="chip ${PROBLEM_TYPE_CLASS[p.type] || 'gray'}">${esc(p.type)}</span><b>${esc(p.title)}</b><small>${esc(p.detail)}</small></div>
      <div class="field full"><label>Sprendimas</label><textarea class="input" name="note" rows="4" required placeholder="Pvz., kiekis atitinka projektą, skirtumas paaiškinamas matavimo metodika…"></textarea></div>
      <div class="field full"><label>Reglamento pagrindas</label><input class="input" name="basis" placeholder="STR 1.04.04:2017; 1-BD l. 7; …"></div>
      <div class="form-grid">
        <div class="field"><label>Būsena</label><select class="select" name="status"><option>Priimta</option><option>Su sąlyga</option><option>Įvykdyta</option></select></div>
        <div class="field"><label>Atsakingas</label><input class="input" name="owner" value="Projekto vadovas"></div>
      </div>
      <input type="hidden" name="key" value="${esc(key)}">
      <input type="hidden" name="title" value="${esc(p.title)}">
      <input type="hidden" name="type" value="${esc(p.type)}">
      <input type="hidden" name="section" value="${esc(p.section || '')}">
      <div class="modal-foot"><button type="button" class="btn ghost" data-close>Atšaukti</button><button class="btn primary" type="submit">Išspręsti</button></div>
    </form>`);
  const form = $('#decisionForm');
  form.onsubmit = async (e) => {
    e.preventDefault();
    const body = { ...formValues(form), codes: p.codes || [] };
    try {
      await api('decisions', 'POST', body);
      closeModal();
      toast('Sprendimas išsaugotas');
      await loadProblems(true);
    } catch (err) { toast(err.message, 'err'); }
  };
}

async function reopenDecision(key) {
  if (!key) return;
  try {
    await api('decisions', 'POST', { key, action: 'reopen' });
    toast('Sprendimas atšauktas – nesutapimas grąžintas į aktyvias');
    await loadProblems(true);
  } catch (e) { toast(e.message, 'err'); }
}

function renderProblemsBody(root, d) {
  const s = d.summary || {};
  const sev = s.bySeverity || {};
  const byType = s.byType || {};
  const ui = S.problemsUI;
  const all = d.problems || [];
  const resolved = (d.resolved || []).slice().sort((a, b) =>
    String(a.sectionLabel || '').localeCompare(String(b.sectionLabel || ''), 'lt') ||
    String(a.type || '').localeCompare(String(b.type || ''), 'lt'));
  const resolvedCount = resolved.length;
  const statusCls = s.empty ? 'green' : s.problems ? (sev.high ? 'red' : 'amber') : 'green';
  const verify = d.verify || {};
  const schedList = d.schedules || [];
  const schedOk = schedList.reduce((n, x) => n + (x.kind === 'spec'
    ? ((x.status === 'ok' || x.resolved) ? 1 : 0)
    : x.status === 'no-works' ? 0
    : Math.min(x.summary?.works || 0, (x.summary?.ok || 0) + (x.summary?.resolvedIssues || 0))), 0);
  const schedTotal = schedList.reduce((n, x) => n + (x.kind === 'spec' ? 1 : (x.summary?.works || 0)), 0);
  const schedBad = schedList.reduce((n, x) => n + (x.kind === 'spec'
    ? ((x.status === 'ok' || x.resolved) ? 0 : 1)
    : x.status === 'no-works' ? (x.resolved ? 0 : 1)
    : Math.max(0, (x.summary?.diff || 0) + (x.summary?.unit || 0) + (x.summary?.missingWorks || 0)
      - (x.summary?.resolvedIssues || 0))), 0);
  const kiekBad = (verify.bad || 0) + schedBad;
  const subParts = [
    `Atlikta ${s.checks || 0} patikrų`,
    `${s.passed || 0} atitinka`,
    resolvedCount ? `${resolvedCount} išspręsta sprendimais` : '',
    `Fasado kiekių patikra ${verify.ok || 0}/${verify.total || 0}`,
    `Žiniaraščiai ${schedOk}/${schedTotal}`,
  ].filter(Boolean);
  root.innerHTML = `
    <div class="problem-status ${statusCls}">
      <span class="problem-status-dot"></span>
      <div class="problem-status-main">
        <b>${s.empty ? 'Patikrinti dar nėra ko' : s.problems ? `Rasta ${s.problems} ${problemWord(s.problems)}` : (resolvedCount ? 'Aktyvių problemų nėra' : 'Nesutapimų nerasta')}</b>
        <small>${s.empty ? 'Įkelkite dokumentus arba sąmatos pozicijas – tada sistema pradės tikrinti kiekius.' : subParts.join(' · ')}</small>
      </div>
      <div class="spacer"></div>
      <span class="chip ${kiekBad ? 'amber' : 'green'}">${s.empty ? 'Nėra duomenų' : kiekBad ? (kiekBad === 1 ? '1 kiekio neatitikimas' : kiekBad + ' kiekių neatitikimai') : (resolvedCount ? 'Visi sprendimai užfiksuoti' : 'Kiekiai suderinti')}</span>
    </div>
    <div class="kpis problems-kpis">
      <div class="card kpi"><div class="k-top"><span class="k-icon ${s.problems ? 'warn' : 'ok'}">${icon('alert')}</span>Iš viso</div>
        <div class="num">${s.problems || 0}</div><div class="sub">${resolvedCount ? `Išspręsta: ${resolvedCount} sprendimais` : `Kritinės: ${sev.high || 0} · svarbios: ${sev.medium || 0}`}</div></div>
      <div class="card kpi"><div class="k-top"><span class="k-icon">${icon('ruler')}</span>Kvadratūra</div>
        <div class="num">${byType['Kvadratūra'] || 0}</div><div class="sub">plotų nesutapimai</div></div>
      <div class="card kpi"><div class="k-top"><span class="k-icon">${icon('check')}</span>Kiekiai</div>
        <div class="num">${byType['Kiekis'] || 0}</div><div class="sub">vnt., m, m² neatitikimai</div></div>
      <div class="card kpi"><div class="k-top"><span class="k-icon">${icon('download')}</span>Kaina</div>
        <div class="num">${byType['Kaina'] || 0}</div><div class="sub">neįkainotos pozicijos</div></div>
    </div>
    ${schedList.length ? `<section class="card pad section sched-overview">
      <div class="card-head works-head">
        <h2>Kiekių žiniaraščiai</h2>
        <span class="chip gray">${schedList.length} šaltiniai</span>
        <div class="spacer"></div>
        <span class="verify-time">PDF lentelės susietos su sąmatos pozicijomis</span>
      </div>
      <div class="sched-overview-grid">${schedList.map(schedTileHtml).join('')}</div>
    </section>` : ''}
    ${all.length ? `<div class="problem-filter card pad section">
      <div class="problem-chips">
        <button class="chip ${!ui.type ? 'active' : ''}" data-ptype="">Visos <b>${all.length}</b></button>
        ${(d.types || []).map(t => `<button class="chip ${PROBLEM_TYPE_CLASS[t] || 'gray'} ${ui.type === t ? 'active' : ''}" data-ptype="${esc(t)}">${esc(t)} <b>${byType[t] || 0}</b></button>`).join('')}
      </div>
      <div class="spacer"></div>
      <select class="select" id="problemSection">
        <option value="">Visas pastatas</option>
        ${Object.entries(d.sections || {}).map(([k, label]) => `<option value="${k}" ${ui.section === k ? 'selected' : ''}>${esc(label)}</option>`).join('')}
      </select>
    </div>` : ''}
    <section class="card pad section">
      <div class="print-head">
        <div class="ph-title">Viso pastato nesutapimai</div>
        <div class="ph-sub">${esc(S.data?.project?.name || '')} · ${new Date().toLocaleDateString('lt-LT')}</div>
      </div>
      <div class="card-head works-head">
        <h2>Aktyvūs nesutapimai</h2>
        <span class="chip gray" id="problemCount"></span>
        <div class="spacer"></div>
        <span class="verify-time">${esc(String(d.generated || '').replace('T', ' '))}</span>
      </div>
      <div id="problemList"></div>
    </section>
    ${resolvedCount ? `<section class="card pad section decision-register">
      <div class="print-head">
        <div class="ph-title">Sprendimų registras</div>
        <div class="ph-sub">${esc(S.data?.project?.name || '')} · ${new Date().toLocaleDateString('lt-LT')}</div>
      </div>
      <div class="card-head works-head">
        <h2>Sprendimų registras</h2>
        <span class="chip green">${resolvedCount} išspręsta</span>
        <div class="spacer"></div>
        <span class="verify-time">Projekto vadovo sprendimai reglamentų pagrindu</span>
      </div>
      <div class="decision-list">${resolved.map(decisionCardHtml).join('')}</div>
    </section>` : ''}
    <div class="grid-2 section">
      <section class="card pad">
        <div class="card-head"><h2>Normatyvų danga</h2><div class="spacer"></div><span class="chip gray">projekto dokumentai</span></div>
        <div id="normList"></div>
      </section>
      <section class="card pad">
        <div class="card-head"><h2>Ką tikrina sistema</h2></div>
        <ul class="rule-list">
          <li><b>Kvadratūra</b> – BD bendrasis plotas lyginamas su apdailos kiekiais; sienų, lubų, grindų ir bendrųjų patalpų išvedimai.</li>
          <li><b>Kiekiai</b> – LVN, E.SŽ, sklypo ir durų žiniaraščiai susiejami su sąmatos pozicijomis; fasado patikra pagal PDF, DWG ir IFC.</li>
          <li><b>Kainos</b> – ar visos pozicijos įkainotos pagal rangovo pasiūlymą.</li>
          <li><b>Reikalavimai</b> – orientaciniai kiekiai ir trūkstami šaltinio lapai.</li>
          <li><b>Normatyvai</b> – ar projektuose minimi STR, RSN ir EN standartai.</li>
          <li><b>Sprendimai</b> – projekto vadovo sprendimas su reglamento pagrindu; išspręstas nesutapimas lieka registre ir gali būti grąžintas.</li>
        </ul>
      </section>
    </div>`;

  root.querySelectorAll('[data-ptype]').forEach(b => {
    b.onclick = () => { S.problemsUI.type = b.dataset.ptype; renderProblemsBody(root, d); };
  });
  const sel = $('#problemSection', root);
  if (sel) sel.onchange = () => { S.problemsUI.section = sel.value; drawProblemList(root, d); };
  root.querySelectorAll('[data-sched-doc]').forEach(b => {
    b.onclick = () => openDoc(b.dataset.schedDoc, Number(b.dataset.schedPage) || 1);
  });
  root.querySelectorAll('[data-reopen]').forEach(b => {
    b.onclick = () => reopenDecision(b.dataset.reopen);
  });

  $('#normList', root).innerHTML = (d.norms || []).map(n => `
    <div class="norm-row ${n.ok ? 'ok' : 'bad'}">
      <span class="verify-dot">${n.ok ? '✓' : '!'}</span>
      <div class="verify-main"><b>${esc(n.code)}</b><small>${esc(n.label)}${n.sample ? ' · ' + esc(n.sample) : ''}</small></div>
      <span class="chip ${n.ok ? 'green' : 'red'}">${n.docs} dok.</span>
    </div>`).join('');

  drawProblemList(root, d);
}

function drawProblemList(root, d) {
  const ui = S.problemsUI;
  const all = d.problems || [];
  const resolvedCount = (d.resolved || []).length;
  const list = all.filter(p => (!ui.type || p.type === ui.type) && (!ui.section || p.section === ui.section));
  const count = $('#problemCount', root);
  if (count) count.textContent = `${list.length} / ${all.length}`;
  const box = $('#problemList', root);
  if (!box) return;
  box.innerHTML = list.length ? list.map(p => `
    <article class="problem ${esc(p.severity)}">
      <div class="problem-side">
        <span class="chip ${PROBLEM_TYPE_CLASS[p.type] || 'gray'}">${esc(p.type)}</span>
        <span class="problem-sev">${esc(PROBLEM_SEV_LABEL[p.severity] || '')}</span>
        <span class="problem-sec">${esc(p.sectionLabel || 'Visas pastatas')}</span>
      </div>
      <div class="problem-main">
        <b>${esc(p.title)}</b>
        <p>${esc(p.detail)}</p>
        ${(p.codes || []).length ? `<div class="problem-codes">${p.codes.map(c => `<span class="chip gray mono">${esc(c)}</span>`).join('')}</div>` : ''}
        ${p.action ? `<p class="problem-action">${esc(p.action)}</p>` : ''}
      </div>
      <div class="problem-compare">
        ${p.expected ? `<div class="cmp-row"><small>Turėtų būti</small><b>${esc(p.expected)}</b></div>` : ''}
        ${p.actual ? `<div class="cmp-row"><small>Duomenyse</small><b>${esc(p.actual)}</b></div>` : ''}
        ${p.source ? `<small class="problem-src">${esc(p.source)}</small>` : ''}
        <button class="btn small ghost" data-resolve="${esc(p.id)}">${icon('check')} Išspręsti</button>
      </div>
    </article>`).join('')
    : `<div class="empty problem-empty">${icon('check')}<b>${s.empty ? 'Projekte dar nėra duomenų' : 'Aktyvių nesutapimų nėra'}</b>${s.empty ? 'Įkelkite dokumentus (PDF/DWG) arba įrašykite sąmatos pozicijas – sistema tada patikrins kiekius, kainas ir normatyvus.' : resolvedCount ? `Visi ${resolvedCount} nesutapimai išspręsti – žr. sprendimų registrą.` : 'Visi kiekiai, kainos ir normatyvai suderinti.'}</div>`;
  box.querySelectorAll('[data-resolve]').forEach(b => {
    b.onclick = () => {
      const p = all.find(x => String(x.id) === String(b.dataset.resolve));
      if (p) decisionModal(p);
    };
  });
}

function exportWorks(section) {
  const meta = WORK_META[section] || { label: section };
  const rows = [['Eil. Nr.', 'Skyrius', 'Darbas', 'Matavimo vienetas', 'Kiekis', 'Atlikta', 'Liko', 'Kaina, €/vnt.', 'Suma, €', 'Tipas', 'Pagrindimas', 'Šaltinis', 'Lapas', 'Pastaba']];
  S.works.filter(w => w.section === section).sort((a, b) => (Number(a.ord) || 0) - (Number(b.ord) || 0)).forEach(w => {
    const qty = Number(w.qty) || 0;
    const done = Math.min(Number(w.done) || 0, qty);
    const price = Number(w.price) || 0;
    rows.push([
      w.code || '', w.stage || '', w.title || '', w.unit || '', String(qty).replace('.', ','),
      String(done).replace('.', ','), String(Math.max(0, qty - done)).replace('.', ','),
      price ? String(price).replace('.', ',') : '', price ? String(qty * price).replace('.', ',') : '',
      w.kind || '', w.basis || '', w.source_name || '', w.source_page || '', w.note || '',
    ]);
  });
  const csv = '\ufeff' + rows.map(r => r.map(x => '"' + String(x).replace(/"/g, '""') + '"').join(';')).join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  a.download = `${section}-samata.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
}
function workModal(id, presetSection) {
  const it = id ? S.works.find(x => String(x.id) === String(id)) : null;
  const item = it || {
    section: presetSection || 'elektra', stage: '', code: '', title: '', unit: 'vnt.', qty: 0, done: 0,
    price: 0, kind: 'Sąmata', basis: '', source_doc: 0, source_page: 0, note: '',
  };
  const stages = Array.from(new Set(S.works.filter(w => w.section === item.section).map(w => w.stage).filter(Boolean)));
  const docs = S.docs.slice().sort((a, b) => collator.compare(a.name, b.name));
  openModal(`
    <div class="modal-head"><h3>${it ? 'Redaguoti darbą' : 'Naujas darbas'}</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
    <form id="workForm" class="modal-body">
      <div class="form-grid">
        <div class="field"><label>Skiltis</label><select class="select" name="section">
          ${Object.entries(WORK_META).map(([k, m]) => `<option value="${k}" ${item.section === k ? 'selected' : ''}>${esc(m.label)}</option>`).join('')}
        </select></div>
        <div class="field"><label>Eil. Nr.</label><input class="input" name="code" value="${esc(item.code)}" placeholder="pvz., E-35"></div>
        <div class="field full"><label>Darbas</label><input class="input" name="title" required value="${esc(item.title)}" placeholder="Kas atliekama"></div>
        <div class="field full"><label>Skyrius</label><input class="input" name="stage" value="${esc(item.stage)}" list="workStageList" placeholder="Sąmatos skyrius">
          <datalist id="workStageList">${stages.map(s => `<option value="${esc(s)}">`).join('')}</datalist>
        </div>
        <div class="field"><label>Matavimo vienetas</label><select class="select" name="unit">
          ${WORK_UNITS.map(u => `<option value="${esc(u)}" ${item.unit === u ? 'selected' : ''}>${esc(u)}</option>`).join('')}
        </select></div>
        <div class="field"><label>Tipas</label><select class="select" name="kind">
          ${['Sąmata', 'Projektas', 'Skaičiuojama'].map(k => `<option value="${esc(k)}" ${item.kind === k ? 'selected' : ''}>${esc(k)}</option>`).join('')}
        </select></div>
        <div class="field"><label>Kiekis</label><input class="input" type="number" name="qty" min="0" step="0.01" inputmode="decimal" value="${numAttr(item.qty) || '0'}"></div>
        <div class="field"><label>Atlikta</label><input class="input" type="number" name="done" min="0" step="0.01" inputmode="decimal" value="${numAttr(item.done) || '0'}"></div>
        <div class="field"><label>Kaina, €/vnt.</label><input class="input" type="number" name="price" min="0" step="0.01" inputmode="decimal" value="${numAttr(item.price)}" placeholder="0,00"></div>
        <div class="field"><label>Lapas šaltinyje</label><input class="input" type="number" name="source_page" min="0" step="1" value="${Number(item.source_page) || ''}" placeholder="pvz., 66"></div>
        <div class="field full"><label>Šaltinio dokumentas</label><select class="select" name="source_doc">
          <option value="0">— Nenurodytas —</option>
          ${docs.map(d => `<option value="${d.id}" ${Number(item.source_doc) === d.id ? 'selected' : ''}>${esc(d.disc)} · ${esc(d.name)}</option>`).join('')}
        </select></div>
        <div class="field full"><label>Pagrindimas</label><input class="input" name="basis" value="${esc(item.basis)}" placeholder="Žiniaraščio eilutė arba skaičiavimo formulė"></div>
        <div class="field full"><label>Pastaba</label><textarea class="input" name="note" placeholder="Ką reikia patikslinti arba atkreipti dėmesį">${esc(item.note)}</textarea></div>
      </div>
    </form>
    <div class="modal-foot">
      ${it ? `<button class="btn danger" id="delWork">${icon('x')} Šalinti</button>` : ''}
      <div class="spacer"></div>
      <button class="btn" data-close>Atšaukti</button>
      <button class="btn primary" id="saveWork">Išsaugoti</button>
    </div>`);
  $('#saveWork').onclick = async () => {
    const form = $('#workForm');
    if (!form.reportValidity()) return;
    const body = formValues(form);
    try {
      if (it) await api('works/' + it.id, 'PATCH', body);
      else await api('works', 'POST', body);
      closeModal(); await loadAll(); render();
      toast(it ? 'Darbas atnaujintas' : 'Darbas pridėtas');
    } catch (e) { toast(e.message, 'err'); }
  };
  if (it) $('#delWork').onclick = async () => {
    if (!confirm('Pašalinti šią sąmatos poziciją?')) return;
    try {
      await api('works/' + it.id, 'DELETE');
      closeModal(); await loadAll(); render(); toast('Pozicija pašalinta');
    } catch (e) { toast(e.message, 'err'); }
  };
}

/* ============ settings ============ */
function renderSettings(v) {
  const p = S.data.project;
  const co = S.data.company || {};
  v.innerHTML = `
    <div class="page-head"><div><h1>Nustatymai</h1><p>Projektai, rekvizitai, stebimi katalogai ir priežiūra.</p></div></div>
    <section class="card pad" style="margin-bottom:18px">
      <div class="card-head"><h2>Projektai</h2><button class="btn primary small" id="newProjectSettings">${icon('plus')} Naujas projektas</button></div>
      <p class="muted" style="font-size:12px;margin-top:0">Kiekvienas projektas turi atskirus dokumentus, sąmatas, F2/F3 aktus, užduotis, žurnalą ir problemas. Atidarykite norimą projektą – visa programa persijungs į jo duomenis.</p>
      <div class="project-list" id="settingsProjectList">${projectRowsHtml(S.data.projects || [])}</div>
    </section>
    <div class="settings-grid">
      <section class="card pad">
        <div class="card-head"><h2>Projekto informacija</h2></div>
        <form id="projectForm" class="form-grid">
          <div class="field full"><label>Trumpas pavadinimas</label><input class="input" name="name" value="${esc(p.name)}"></div>
          <div class="field full"><label>Pilnas pavadinimas</label><textarea class="input" name="full_name" style="min-height:64px">${esc(p.full_name)}</textarea></div>
          <div class="field"><label>Adresas</label><input class="input" name="address" value="${esc(p.address)}"></div>
          <div class="field"><label>Statytojas / užsakovas</label><input class="input" name="client" value="${esc(p.client)}"></div>
          <div class="field"><label>Projektuotojas</label><input class="input" name="designer" value="${esc(p.designer)}"></div>
          <div class="field"><label>Projekto Nr.</label><input class="input" name="project_no" value="${esc(p.project_no)}"></div>
          <div class="field"><label>Leidimo Nr.</label><input class="input" name="permit_no" value="${esc(p.permit_no)}"></div>
          <div class="field"><label>Leidimo data</label><input class="input" type="date" name="permit_date" value="${esc(p.permit_date)}"></div>
          <div class="field"><label>Leidimą išdavė</label><input class="input" name="permit_authority" value="${esc(p.permit_authority)}"></div>
          <div class="field"><label>Stadija</label><input class="input" name="stage" value="${esc(p.stage)}"></div>
          <div class="field"><label>Pastato plotis, m</label><input class="input" name="plotis" value="${esc(p.plotis)}" placeholder="pvz. 24,94"></div>
          <div class="field"><label>Pastato gylis, m</label><input class="input" name="gylis" value="${esc(p.gylis)}" placeholder="pvz. 15,44"></div>
          <div class="field"><label>Pastato aukštis, m</label><input class="input" name="aukstis" value="${esc(p.aukstis)}" placeholder="pvz. +12,85"></div>
          <div class="field"><label>Langų skaičius</label><input class="input" name="langai" value="${esc(p.langai)}" placeholder="pvz. 96"></div>
          <div class="field"><label>Fasado pozicijų sk.</label><input class="input" name="fasadopoz" value="${esc(p.fasadopoz)}" placeholder="pvz. 36"></div>
          <div class="field full" style="flex-direction:row;justify-content:flex-end"><button type="button" class="btn primary" id="saveProject">${icon('check')} Išsaugoti projektą</button></div>
        </form>
      </section>
      <div>
        <section class="card pad" style="margin-bottom:18px">
          <div class="card-head"><h2>Mano įmonė</h2></div>
          <p class="muted" style="font-size:12px;margin-top:0">Bendri rekvizitai visiems projektams – naudojami PVM sąskaitose-faktūrose ir dokumentuose.</p>
          <form id="companyForm" class="form-grid">
            <div class="field full"><label>Įmonės pavadinimas</label><input class="input" name="name" value="${esc(co.name)}"></div>
            <div class="field"><label>Įm. kodas</label><input class="input" name="code" value="${esc(co.code)}"></div>
            <div class="field"><label>PVM kodas</label><input class="input" name="vat" value="${esc(co.vat)}"></div>
            <div class="field full"><label>Adresas</label><input class="input" name="address" value="${esc(co.address)}"></div>
            <div class="field"><label>Bankas</label><input class="input" name="bank" value="${esc(co.bank)}"></div>
            <div class="field"><label>IBAN</label><input class="input" name="iban" value="${esc(co.iban)}"></div>
            <div class="field"><label>Vadovas</label><input class="input" name="director" value="${esc(co.director)}"></div>
            <div class="field"><label>Telefonas</label><input class="input" name="phone" value="${esc(co.phone)}"></div>
            <div class="field full"><label>El. paštas</label><input class="input" name="email" value="${esc(co.email)}"></div>
            <div class="field full"><label>Numatytoji sąskaitos pastaba</label><input class="input" name="invoice_note" value="${esc(co.invoice_note)}"></div>
            <div class="field full" style="flex-direction:row;justify-content:flex-end"><button type="button" class="btn primary" id="saveCompany">${icon('check')} Išsaugoti įmonę</button></div>
          </form>
        </section>
        <section class="card pad" style="margin-bottom:18px">
          <div class="card-head"><h2>Stebimi katalogai</h2></div>
          <p class="muted" style="font-size:12px;margin-top:0">Po vieną kelią eilutėje. Programa automatiškai indeksuoja PDF, ADOC, TXT, IFC failus ir DWG brėžinių užrašus.</p>
          <textarea class="input roots-area" id="rootsArea">${esc((S.data.roots || []).join('\n'))}</textarea>
          <div style="display:flex;gap:8px;margin-top:10px">
            <button class="btn primary" id="saveRoots">${icon('check')} Išsaugoti ir skenuoti</button>
          </div>
        </section>
        <section class="card pad" style="margin-bottom:18px">
          <div class="card-head"><h2>Prieiga iš kitų įrenginių</h2></div>
          <p class="muted" style="font-size:12px;margin-top:0">Telefone ar kitame kompiuteryje tame pačiame Wi-Fi tinkle atidarykite nuorodą ir įveskite kodą. Veikia ir be interneto.</p>
          <div id="netBox">Kraunama…</div>
          <div style="display:flex;gap:8px;margin-top:12px">
            <button class="btn ghost" id="rotateCode">${icon('refresh')} Keisti kodą</button>
          </div>
        </section>
        <section class="card pad" style="margin-bottom:18px">
          <div class="card-head"><h2>Priežiūra</h2></div>
          <div class="action-list">
            <button class="btn" id="setRescan">${icon('refresh')} Atnaujinti failus dabar</button>
            <button class="btn" id="setReindex">${icon('search')} Perindeksuoti visus tekstus</button>
            <button class="btn" id="setWarm" title="Iš anksto sukonvertuoja DWG brėžinius – vėliau jie atsidarys akimirksniu">${icon('refresh')} Paruošti brėžinių peržiūras</button>
            <button class="btn" id="setBackup">${icon('copy')} Sukurti atsarginę kopiją</button>
            <button class="btn" id="setOpenData">${icon('folder')} Atidaryti duomenų aplanką</button>
            <button class="btn danger" id="setShutdown">${icon('x')} Išjungti programą</button>
          </div>
          <div class="about-box" style="margin-top:14px">
            <b>Projekto Štabas ${esc(S.data.version)}</b><br>
            Vietinė programa – veikia ir be interneto, duomenys niekur nesiunčiami. Užduotys, žurnalas ir sąrašai saugomi šiame kompiuteryje.
          </div>
        </section>
        <section class="card pad" style="margin-bottom:18px">
          <div class="card-head"><h2>Atnaujinimai</h2></div>
          <div id="updateBox">Kraunama…</div>
          <div style="display:flex;align-items:center;gap:10px;margin-top:12px;flex-wrap:wrap">
            <button class="btn ghost" id="checkUpdate">${icon('refresh')} Tikrinti atnaujinimus</button>
            <label style="display:flex;align-items:center;gap:7px;font-size:12.5px;color:var(--muted);cursor:pointer">
              <input type="checkbox" id="autoUpdate"> Diegti automatiškai
            </label>
          </div>
        </section>
        <section class="card pad">
          <div class="card-head"><h2>Išvaizda</h2></div>
          <div class="field"><label>Tema</label>
            <select class="select" id="themeSel">
              <option value="light" ${document.documentElement.dataset.theme !== 'dark' ? 'selected' : ''}>Šviesi</option>
              <option value="dark" ${document.documentElement.dataset.theme === 'dark' ? 'selected' : ''}>Tamsi</option>
            </select>
          </div>
        </section>
      </div>
    </div>`;
  bindProjectRows($('#settingsProjectList'));
  $('#newProjectSettings').onclick = () => projectFormModal(null);
  $('#saveProject').onclick = async () => {
    const body = formValues($('#projectForm'));
    try {
      await api('project', 'PATCH', body);
      await loadAll(); render(); toast('Projektas atnaujintas');
    } catch (e) { toast(e.message, 'err'); }
  };
  $('#saveCompany').onclick = async () => {
    try {
      await api('company', 'PATCH', formValues($('#companyForm')));
      await loadAll(); render(); toast('Įmonės rekvizitai išsaugoti');
    } catch (e) { toast(e.message, 'err'); }
  };
  $('#saveRoots').onclick = async () => {
    const roots = $('#rootsArea').value.split('\n').map(x => x.trim()).filter(Boolean);
    try {
      await api('roots', 'PATCH', { roots });
      toast('Katalogai išsaugoti, pradedamas skenavimas');
      await loadAll(); render();
    } catch (e) { toast(e.message, 'err'); }
  };
  $('#setRescan').onclick = rescan;
  $('#setReindex').onclick = async () => {
    if (!confirm('Perindeksuoti visus PDF/ADOC/TXT/IFC failus ir DWG brėžinius iš naujo? Tai gali užtrukti.')) return;
    try { await api('reindex', 'POST', {}); toast('Perindeksavimas pradėtas'); await loadAll(); } catch (e) { toast(e.message, 'err'); }
  };
  $('#setWarm').onclick = () => warmDwgCache($('#setWarm'));
  $('#setBackup').onclick = async () => {
    try { const r = await api('backup', 'POST', {}); toast('Atsarginė kopija: ' + r.path); } catch (e) { toast(e.message, 'err'); }
  };
  $('#setOpenData').onclick = () => api('open-data', 'POST', {}).catch(e => toast(e.message, 'err'));
  $('#setShutdown').onclick = async () => {
    if (!confirm('Išjungti programą? Duomenys išsaugomi.')) return;
    try { await api('shutdown', 'POST', {}); document.body.innerHTML = '<div style="display:grid;place-items:center;height:100vh;font-family:Segoe UI,sans-serif;color:#61666f">Programa išjungta. Galite uždaryti langą.</div>'; } catch (e) { toast(e.message, 'err'); }
  };
  $('#themeSel').onchange = e => { applyTheme(e.target.value); };
  hydrateNetwork();
  hydrateUpdate();
  $('#checkUpdate').onclick = async () => {
    const btn = $('#checkUpdate');
    btn.disabled = true;
    try { await api('update/check', 'POST', {}); await hydrateUpdate(); }
    catch (e) { toast(e.message, 'err'); }
    finally { btn.disabled = false; }
  };
  $('#autoUpdate').onchange = async e => {
    try { await api('update/auto', 'POST', { enabled: e.target.checked }); toast(e.target.checked ? 'Automatiniai atnaujinimai įjungti' : 'Automatiniai atnaujinimai išjungti'); }
    catch (err) { toast(err.message, 'err'); }
  };
  $('#rotateCode').onclick = async () => {
    if (!confirm('Sugeneruoti naują kodą? Kiti įrenginiai turės įvesti naują kodą.')) return;
    try { const r = await api('network/rotate', 'POST', {}); toast('Naujas kodas: ' + r.code); hydrateNetwork(); }
    catch (e) { toast(e.message, 'err'); }
  };
}

async function copyText(text) {
  try { await navigator.clipboard.writeText(text); toast('Nukopijuota'); return; } catch (e) { /* fallback žemiau */ }
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); toast('Nukopijuota'); } catch (err) { toast('Nepavyko nukopijuoti', 'err'); }
  ta.remove();
}

async function hydrateNetwork() {
  const box = $('#netBox');
  if (!box) return;
  try {
    const n = await api('network');
    if (!n.enabled) {
      box.innerHTML = '<p class="net-note">Prieiga iš kitų įrenginių išjungta.</p>';
      return;
    }
    const rows = [`<div class="net-row"><span>Šiame kompiuteryje</span><code>${esc(n.local)}</code><button class="btn small" data-net-copy="${esc(n.local)}">Kopijuoti</button></div>`];
    (n.lan || []).forEach(u => rows.push(`<div class="net-row"><span>Telefone / kitame PC</span><code>${esc(u)}</code><button class="btn small" data-net-copy="${esc(u)}">Kopijuoti</button></div>`));
    rows.push(`<div class="net-row"><span>Prieigos kodas</span><code class="net-code">${esc(n.code)}</code><button class="btn small" data-net-copy="${esc(n.code)}">Kopijuoti</button></div>`);
    box.innerHTML = `<div class="net-list">${rows.join('')}</div>
      ${!(n.lan || []).length ? '<p class="net-note">Nustatyti tinklo adreso nepavyko – prijunkite kompiuterį prie Wi-Fi arba LAN.</p>' : ''}
      <p class="net-note">Jei kitas įrenginys neatsidaro: Windows ugniasienėje leiskite Python privačiame tinkle ir patikrinkite, ar abu įrenginiai tame pačiame tinkle.</p>`;
  } catch (err) {
    box.innerHTML = `<p class="net-note">${esc(err.message)}</p>`;
  }
  box.onclick = e => {
    const b = e.target.closest('[data-net-copy]');
    if (b) copyText(b.dataset.netCopy);
  };
}

async function hydrateUpdate() {
  const box = $('#updateBox');
  if (!box) return;
  let u;
  try { u = await api('update'); }
  catch (e) { box.innerHTML = `<p class="net-note">${esc(e.message)}</p>`; return; }
  const auto = $('#autoUpdate');
  if (auto) auto.checked = !!u.auto;
  const installed = u.installed && u.installed.version ? `<p class="net-note">Paskutinį kartą įdiegta: ${esc(u.installed.version)} (${esc((u.installed.installed || '').replace('T', ' '))})</p>` : '';
  if (u.applying) {
    box.innerHTML = `<div class="about-box" style="margin-top:0"><b>Diegiamas atnaujinimas${u.latest ? ' ' + esc(u.latest) : ''}…</b><br>Programa netrukus persikraus automatiškai.</div>`;
    return;
  }
  if (u.available) {
    box.innerHTML = `<div class="about-box" style="margin-top:0"><b>Yra nauja versija ${esc(u.latest)}</b><br>Dabartinė: ${esc(u.current)}${u.notes ? '<br>' + esc(u.notes) : ''}</div>
      <div style="display:flex;gap:8px;margin-top:10px"><button class="btn primary" id="installUpdate">Įdiegti ir paleisti iš naujo</button></div>${installed}`;
    $('#installUpdate').onclick = async () => {
      if (!confirm('Įdiegti atnaujinimą dabar? Programa persikraus.')) return;
      const b = $('#installUpdate');
      b.disabled = true; b.textContent = 'Diegiama…';
      try {
        await api('update/apply', 'POST', {});
        box.innerHTML = '<div class="about-box" style="margin-top:0"><b>Atnaujinimas įdiegtas.</b><br>Programa paleidžiama iš naujo…</div>';
        setTimeout(() => location.reload(), 6000);
      } catch (e) { toast(e.message, 'err'); b.disabled = false; b.textContent = 'Įdiegti ir paleisti iš naujo'; }
    };
    return;
  }
  const checked = u.lastCheck ? `Paskutinė patikra: ${esc(fmtDateTime(u.lastCheck))}` : 'Dar netikrinta šiame paleidime.';
  const err = u.error && !u.error.includes('nepaskelbtas') ? `<p class="net-note">${esc(u.error)}</p>` : '';
  const status = u.error ? (u.error.includes('nepaskelbtas') ? 'Atnaujinimų serveris dar nepaskelbtas.' : 'Nepavyko patikrinti – ar yra internetas?') : (u.lastCheck ? 'Naujesnės versijos nėra.' : 'Automatinė patikra vykdoma paleidus programą.');
  box.innerHTML = `<div class="about-box" style="margin-top:0"><b>Projekto Štabas ${esc(u.current)}</b><br>${status}<br>${checked}</div>${err}${installed}`;
}

/* ============ palette & quick add ============ */
function paletteActions() {
  return [
    { label: 'Apžvalga', hint: 'Peržiūra', icon: 'grid', run: () => go('apzvalga') },
    { label: 'Dokumentai', hint: 'Registras', icon: 'file', run: () => go('dokumentai') },
    { label: 'Paieška dokumentų tekste', hint: 'Paieška', icon: 'search', run: () => go('paieska') },
    { label: 'Padėjėjas: kur yra, kaip padaryti', hint: 'Klauskite', icon: 'help', run: openAssist },
    { label: 'Užduotys', hint: 'Kanban', icon: 'tasks', run: () => go('uzduotys') },
    { label: 'Žurnalas', hint: 'Problemos / RFI', icon: 'book', run: () => go('zurnalas') },
    { label: 'Susitikimai', hint: 'Užrašai', icon: 'users', run: () => go('susitikimai') },
    { label: 'Kontrolinis sąrašas', hint: 'Etapai', icon: 'check', run: () => go('kontrolinis') },
    { label: 'Nauja užduotis', hint: 'Sukurti', icon: 'plus', run: () => taskModal(null) },
    { label: 'Naujas žurnalo įrašas', hint: 'Sukurti', icon: 'plus', run: () => issueModal(null) },
    { label: 'Naujas susitikimo užrašas', hint: 'Sukurti', icon: 'plus', run: () => noteModal(null) },
    { label: 'Atnaujinti failus', hint: 'Skenuoti', icon: 'refresh', run: rescan },
    { label: 'Nustatymai', hint: 'Konfigūracija', icon: 'gear', run: () => go('nustatymai') },
  ];
}
function openPalette() {
  const root = $('#paletteRoot');
  root.innerHTML = `<div class="palette-backdrop"><div class="palette">
    <input id="paletteInput" placeholder="Ieškoti dokumento arba veiksmo…" autocomplete="off">
    <div class="palette-list" id="paletteList"></div>
  </div></div>`;
  root.classList.add('open');
  const input = $('#paletteInput');
  const list = $('#paletteList');
  const backdrop = $('.palette-backdrop', root);
  backdrop.addEventListener('mousedown', e => { if (e.target === backdrop) closePalette(); });
  const build = () => {
    const q = input.value.trim().toLowerCase();
    const acts = paletteActions().filter(a => (a.label + ' ' + a.hint).toLowerCase().includes(q));
    const docs = q.length >= 1 ? S.docs.filter(d => (d.name + ' ' + d.discName).toLowerCase().includes(q)).slice(0, 8) : [];
    S.paletteItems = [
      ...acts.map(a => ({ type: 'action', label: a.label, hint: a.hint, icon: a.icon, run: a.run })),
      ...docs.map(d => ({ type: 'doc', label: d.name, hint: d.discName, icon: 'file', run: () => openDoc(d.id) })),
    ].slice(0, 14);
    if (S.paletteItems.length === 0 && q.length >= 2) {
      S.paletteItems.push({ type: 'search', label: `Ieškoti „${input.value.trim()}“ tekste`, hint: 'Paieška', icon: 'search', run: () => { S.searchQ = input.value.trim(); go('paieska'); setTimeout(() => { const g = $('#globalSearch'); if (g) { g.value = S.searchQ; doSearch(); } }, 350); } });
    }
    S.paletteSel = 0;
    draw();
  };
  const draw = () => {
    list.innerHTML = S.paletteItems.length ? S.paletteItems.map((it, idx) => `
      <div class="p-item ${idx === S.paletteSel ? 'sel' : ''}" data-idx="${idx}">
        <span class="p-ico">${icon(it.icon)}</span>
        <span class="p-label"><b>${esc(it.label)}</b><span>${esc(it.hint || '')}</span></span>
        ${it.type === 'doc' ? '<span class="p-hint">Atidaryti</span>' : '<span class="p-hint">↵</span>'}
      </div>`).join('') : '<div class="p-empty">Nieko nerasta</div>';
    list.querySelectorAll('.p-item').forEach(el => {
      el.onclick = () => runPalette(parseInt(el.dataset.idx, 10));
    });
  };
  const runPalette = idx => {
    const it = S.paletteItems[idx];
    if (!it) return;
    closePalette();
    setTimeout(() => it.run(), 30);
  };
  input.oninput = build;
  input.onkeydown = e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); S.paletteSel = Math.min(S.paletteItems.length - 1, S.paletteSel + 1); draw(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); S.paletteSel = Math.max(0, S.paletteSel - 1); draw(); }
    else if (e.key === 'Enter') { e.preventDefault(); runPalette(S.paletteSel); }
    else if (e.key === 'Escape') { closePalette(); }
  };
  build();
  setTimeout(() => input.focus(), 30);
}
function closePalette() {
  const root = $('#paletteRoot');
  root.classList.remove('open');
  root.innerHTML = '';
}
function quickAddMenu() {
  openModal(`
    <div class="modal-head"><h3>Ką norite pridėti?</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
    <div class="modal-body">
      <div class="action-list">
        <button class="btn" data-new="task">${icon('tasks')} Užduotį</button>
        <button class="btn" data-new="issue">${icon('alert')} Žurnalo įrašą (pastaba / RFI)</button>
        <button class="btn" data-new="note">${icon('users')} Susitikimo užrašą</button>
        <button class="btn" data-new="check">${icon('check')} Kontrolinio sąrašo punktą</button>
      </div>
    </div>`);
  $$('[data-new]').forEach(b => b.onclick = () => {
    closeModal();
    const map = { task: () => taskModal(null), issue: () => issueModal(null), note: () => noteModal(null), check: () => checkModal(null) };
    map[b.dataset.new]();
  });
}

/* ============ padėjėjas ============ */
const ASSIST_KEY = 'stabas-assist-history';
const ASSIST_STARTERS = [
  'Ką daryti šiandien?',
  'Kiek ko reikia darbams?',
  'Kas vėluoja?',
  'Kur yra statybos leidimas?',
  'Koks pastato plotas?',
  'Kaip užbaigti statybą?',
];
const ASSIST_SECTION_STARTERS = {
  fasadas: ['Kokie fasado kiekiai?', 'Kur fasado dokumentai?', 'Kas vėluoja?', 'Kiek ko reikia darbams?'],
  elektra: ['Kokie elektros darbai?', 'Kur elektros dokumentai?', 'Kas vėluoja?', 'Kiek ko reikia darbams?'],
  apdaila: ['Kokie apdailos darbai?', 'Kur apdailos dokumentai?', 'Koks pastato plotas?', 'Kas vėluoja?'],
  santechnika: ['Kokie santechnikos darbai?', 'Kur LVN dokumentai?', 'Kas vėluoja?', 'Kiek ko reikia darbams?'],
};
const ASSIST_KINDS = {
  where: 'Kur rasti', how: 'Kaip padaryti', who: 'Atsakomybė', project: 'Projekto duomenys',
  counts: 'Skaičiai', quantity: 'Kiekiai', works: 'Darbų kiekiai', today: 'Dienos suvestinė', navigate: 'Navigacija', action: 'Veiksmas', search: 'Paieška',
  help: 'Pagalba', hello: 'Padėjėjas', when: 'Terminai',
};
let assistHistory = [];
let assistBusy = false;

function assistLoad() {
  try {
    const raw = localStorage.getItem(ASSIST_KEY);
    assistHistory = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(assistHistory)) assistHistory = [];
  } catch (e) { assistHistory = []; }
}
function assistSave() {
  try {
    localStorage.setItem(ASSIST_KEY, JSON.stringify(assistHistory.filter(m => !m.loading).slice(-14)));
  } catch (e) { /* saugykla pilna – istorija nebus išsaugota */ }
}
function assistWelcomeHtml() {
  const d = S.data || {};
  const c = d.counts || {};
  const p = d.project || {};
  const secMeta = WORK_META[S.view] || null;
  const starters = ASSIST_SECTION_STARTERS[S.view] || ASSIST_STARTERS;
  return `<div class="assist-card hello">
    <div class="a-head"><span class="a-ico">${icon('help')}</span><div><b>Kuo padėti?</b><span class="a-kind">Padėjėjas</span></div></div>
    <p class="a-lead">Parašykite klausimą apie šį projektą. Surasiu dokumentą, nurodysiu jo vietą, paaiškinsiu, ką daryti, ir ištrauksiu dokumentuose nurodytus skaičius (pvz., „Kiek kvadratų stogo?“).</p>
    <div class="a-facts">
      <div><span>Projektas</span><b>${esc(p.name || '—')}</b></div>
      <div><span>Dokumentai</span><b>${c.docCount || 0}</b></div>
      <div><span>Dalys</span><b>${c.discCount || 0}</b></div>
      <div><span>Atviros užduotys</span><b>${c.tasksOpen || 0}</b></div>
    </div>
    ${secMeta ? `<div class="a-sec">${esc(secMeta.label)} · šios skilties klausimai</div>` : '<div class="a-sec">Dažni klausimai</div>'}
    <div class="a-suggest">${starters.map(q => `<button class="a-chip" data-a-q="${esc(q)}">${esc(q)}</button>`).join('')}</div>
  </div>`;
}
function assistDocHtml(d) {
  const page = d.hits && d.hits.length ? d.hits[0].page : 1;
  const hits = (d.hits || []).map(h => `
    <div class="a-snip"><span class="a-page">${d.ext === '.dwg' ? 'Brėžinys' : 'Lap. ' + h.page}</span><div>${snipHtml(h.snippet || '')}</div></div>`).join('');
  return `<div class="a-doc" data-a-doc="${d.id}" data-a-page="${page}" role="button" tabindex="0">
    <div class="a-doc-top"><span class="a-ext">${esc((d.ext || '').replace('.', '').toUpperCase())}</span><b>${esc(d.name)}</b><span class="chip disc">${esc(d.disc)}</span></div>
    <div class="a-doc-meta">${esc(d.discName)} · ${d.date ? fmtDate(d.date) : 'data nenurodyta'} · ${d.pages || '—'} lap.</div>
    <div class="a-doc-path">${esc(d.rel)}</div>
    ${hits}
    <div class="a-doc-actions"><button class="btn small" data-a-open>Atidaryti</button><button class="btn small ghost" data-a-reveal>Aplankas</button></div>
  </div>`;
}
function assistAnswerHtml(a) {
  if (!a) return '';
  const parts = [];
  parts.push(`<div class="assist-card">
    <div class="a-head"><span class="a-ico">${icon('help')}</span><div><b>${esc(a.title || '')}</b><span class="a-kind">${esc(ASSIST_KINDS[a.intent] || 'Atsakymas')}</span></div></div>`);
  if (a.lead) parts.push(`<p class="a-lead">${esc(a.lead)}</p>`);
  if (a.tip) parts.push(`<div class="a-tip">${icon('info')}<span>${esc(a.tip)}</span></div>`);
  if (a.facts && a.facts.length) parts.push(`<div class="a-facts">${a.facts.map(f => `<div><span>${esc(f.label)}</span><b>${esc(f.value)}</b></div>`).join('')}</div>`);
  if (a.items && a.items.length) parts.push(`<div class="a-sec">Reikia dėmesio</div><div class="a-today">${a.items.map(it => `
    <button type="button" class="a-today-item ${esc(it.tone || '')}" ${it.kind === 'task' ? `data-a-task-id="${esc(String(it.id))}"` : `data-a-issue-id="${esc(String(it.id))}"`}>
      <span class="a-today-dot" aria-hidden="true"></span>
      <span class="a-today-main"><b>${esc(it.title || '')}</b><small>${esc(it.meta || '')}</small></span>
      ${it.badge ? `<span class="a-today-badge">${esc(it.badge)}</span>` : ''}
    </button>`).join('')}</div>`);
  if (a.docs && a.docs.length) parts.push(`<div class="a-sec">Dokumentai</div>${a.docs.map(assistDocHtml).join('')}`);
  if (a.values && a.values.length) parts.push(`<div class="a-sec">Rastos reikšmės</div><div class="a-vals">${a.values.map(v => {
    const hasDoc = Number(v.docId) > 0;
    const page = Number(v.page) > 0 ? Number(v.page) : 0;
    const inner = `<span class="a-val-num">${esc(v.value)} <small>${esc(v.unit || '')}</small></span>
      <span class="a-val-main"><b>${esc(v.label || v.docName || '')}</b><small>${esc(v.docName || '')}${v.discName || v.disc ? ' · ' + esc(v.discName || v.disc) : ''}${v.snippet ? ' · ' + esc(v.snippet) : ''}</small></span>
      <span class="a-val-page">${hasDoc ? (v.ext === '.dwg' ? 'Brėžinys' : 'Lap. ' + page) : 'Skaičiuojama'}</span>`;
    return hasDoc
      ? `<button type="button" class="a-val" data-a-doc="${esc(String(v.docId))}" data-a-page="${esc(String(page || 1))}" title="Atidaryti dokumento lapą">${inner}</button>`
      : `<div class="a-val static" title="${esc(v.snippet || '')}">${inner}</div>`;
  }).join('')}</div>`);
  if (a.note) parts.push(`<p class="a-note">${esc(a.note)}</p>`);
  if (a.steps && a.steps.length) parts.push(`<div class="a-sec">Ką daryti</div><ol class="a-steps">${a.steps.map(s => `
    <li><div><p>${esc(s.text)}</p>${s.hint ? `<small>${esc(s.hint)}</small>` : ''}</div>
    <button class="btn small ghost" data-a-task="${esc(s.text)}" data-a-hint="${esc(s.hint || '')}">Į užduotis</button></li>`).join('')}</ol>`);
  if (a.checklist && a.checklist.length) parts.push(`<div class="a-sec">Kontrolinis sąrašas</div><div class="a-checks">${a.checklist.map(c => `
    <div class="a-check ${c.done ? 'done' : ''}"><span class="a-check-box">${c.done ? '✓' : ''}</span><div><b>${esc(c.title)}</b><span>${esc(c.stage)}</span></div></div>`).join('')}</div>`);
  if (a.links && a.links.length) parts.push(`<div class="a-sec">Nuorodos</div><div class="a-links">${a.links.map(l => `<a class="btn small ghost" href="${esc(l.url)}" target="_blank" rel="noopener">${icon('external')} ${esc(l.label)}</a>`).join('')}</div><p class="a-note">Nuorodoms atidaryti reikia interneto. Dokumentai ir padėjėjas veikia be jo.</p>`);
  if (a.action) parts.push(`<button class="btn primary a-action" data-a-action="${esc(a.action.type)}" data-a-view="${esc(a.action.view || '')}" data-a-title="${esc(a.action.title || '')}">${icon(a.action.type === 'task' ? 'plus' : 'external')} ${esc(a.action.label || 'Atidaryti')}</button>`);
  if (a.suggestions && a.suggestions.length) parts.push(`<div class="a-suggest">${a.suggestions.map(q => `<button class="a-chip" data-a-q="${esc(q)}">${esc(q)}</button>`).join('')}</div>`);
  parts.push('</div>');
  return parts.join('');
}
function assistRender() {
  const body = $('#assistBody');
  if (!body) return;
  if (!assistHistory.length) {
    body.innerHTML = assistWelcomeHtml();
  } else {
    body.innerHTML = assistHistory.map(m => {
      if (m.role === 'user') return `<div class="assist-user"><span>${esc(m.text)}</span></div>`;
      if (m.loading) return `<div class="assist-card loading"><span class="spinner"></span> Ieškau…</div>`;
      return assistAnswerHtml(m.answer);
    }).join('');
  }
  body.scrollTop = body.scrollHeight;
}
async function assistAsk(question) {
  const q = (question || '').trim();
  if (!q || assistBusy) return;
  assistBusy = true;
  assistHistory.push({ role: 'user', text: q });
  assistHistory.push({ role: 'bot', loading: true });
  assistRender();
  const input = $('#assistInput');
  if (input) { input.value = ''; input.style.height = 'auto'; }
  try {
    const res = await fetch('/api/assistant?q=' + encodeURIComponent(q));
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Klaida');
    assistHistory.pop();
    assistHistory.push({ role: 'bot', answer: data });
  } catch (e) {
    assistHistory.pop();
    assistHistory.push({ role: 'bot', answer: { intent: 'help', title: 'Nepavyko atsakyti', lead: e.message || 'Bandykite dar kartą.' } });
  }
  assistBusy = false;
  assistSave();
  assistRender();
}
async function assistClick(e) {
  const chip = e.target.closest('[data-a-q]');
  if (chip) { assistAsk(chip.dataset.aQ); return; }
  const taskBtn = e.target.closest('[data-a-task]');
  if (taskBtn) { closeAssist(); taskDraft(taskBtn.dataset.aTask, taskBtn.dataset.aHint); return; }
  const action = e.target.closest('[data-a-action]');
  if (action) {
    if (action.dataset.aAction === 'task') { closeAssist(); taskDraft(action.dataset.aTitle || ''); return; }
    if (action.dataset.aView) { closeAssist(); go(action.dataset.aView); return; }
  }
  const taskItem = e.target.closest('[data-a-task-id]');
  if (taskItem) { closeAssist(); taskModal(taskItem.dataset.aTaskId); return; }
  const issueItem = e.target.closest('[data-a-issue-id]');
  if (issueItem) { closeAssist(); issueModal(issueItem.dataset.aIssueId); return; }
  const reveal = e.target.closest('[data-a-reveal]');
  const doc = e.target.closest('[data-a-doc]');
  if (reveal && doc) {
    try { await api('reveal', 'POST', { id: Number(doc.dataset.aDoc) }); toast('Atidarytas aplankas'); }
    catch (err) { toast(err.message, 'err'); }
    return;
  }
  if (doc) openDoc(doc.dataset.aDoc, Number(doc.dataset.aPage) || 1);
}
function taskDraft(title, desc) {
  taskModal(null);
  const form = $('#taskForm');
  if (!form) return;
  form.title.value = title || '';
  if (desc) form.desc.value = desc;
}
function openAssist() {
  const root = $('#assistRoot');
  if (!root.classList.contains('open')) {
    root.innerHTML = `<div class="assist-backdrop"></div>
      <aside class="assist-panel" role="dialog" aria-modal="true" aria-label="Padėjėjas">
        <header class="assist-head">
          <span class="assist-mark">${icon('help')}</span>
          <div class="assist-title"><strong>Padėjėjas</strong><span>Kur yra · kaip padaryti</span></div>
          <button class="icon-btn" id="assistClear" title="Naujas pokalbis">${icon('refresh')}</button>
          <button class="icon-btn" id="assistClose" title="Uždaryti">${icon('x')}</button>
        </header>
        <div class="assist-body" id="assistBody"></div>
        <form class="assist-form" id="assistForm">
          <textarea id="assistInput" rows="1" placeholder="Pvz.: Kur yra statybos leidimas?"></textarea>
          <button class="btn primary" type="submit" aria-label="Klausti">${icon('search')}</button>
        </form>
      </aside>`;
    root.classList.add('open');
    root.setAttribute('aria-hidden', 'false');
    const form = $('#assistForm');
    form.addEventListener('submit', e => { e.preventDefault(); assistAsk($('#assistInput').value); });
    $('#assistInput').addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); form.requestSubmit(); }
    });
    $('#assistInput').addEventListener('input', e => {
      e.target.style.height = 'auto';
      e.target.style.height = Math.min(96, e.target.scrollHeight) + 'px';
    });
    $('#assistClose').onclick = closeAssist;
    $('#assistClear').onclick = () => { assistHistory = []; assistSave(); assistRender(); $('#assistInput').focus(); };
    $('.assist-backdrop', root).onclick = closeAssist;
    root.addEventListener('click', assistClick);
  }
  $('#assistFab').setAttribute('aria-expanded', 'true');
  assistLoad();
  assistRender();
  setTimeout(() => { const input = $('#assistInput'); if (input) input.focus(); }, 60);
}
function closeAssist() {
  const root = $('#assistRoot');
  if (root.contains(document.activeElement)) document.activeElement.blur();
  root.classList.remove('open');
  root.setAttribute('aria-hidden', 'true');
  $('#assistFab').setAttribute('aria-expanded', 'false');
}

/* ============ actions ============ */
async function rescan() {
  try {
    await api('rescan', 'POST', {});
    toast('Failų atnaujinimas pradėtas');
    setTimeout(async () => { try { await loadAll(); if (!document.querySelector('.modal-backdrop')) render(); } catch (e) {} }, 1200);
  } catch (e) { toast(e.message, 'err'); }
}

/* ============ projektai ============ */
function projectRowsHtml(list) {
  return (list || []).map(p => `
    <div class="project-row ${p.active ? 'active' : ''}">
      <div class="pr-main"><b>${esc(p.name)}</b><span>${esc(p.address || 'Adresas nenurodytas')}</span></div>
      ${p.active ? '<span class="pr-tag">Atidarytas</span>' : `<button class="btn small" data-project-switch="${p.id}">Atidaryti</button>`}
      <button class="icon-btn" data-project-edit="${p.id}" title="Redaguoti">${icon('pencil')}</button>
      ${p.active ? '' : `<button class="icon-btn" data-project-del="${p.id}" title="Ištrinti">${icon('x')}</button>`}
    </div>`).join('');
}

function bindProjectRows(root) {
  $$('[data-project-switch]', root).forEach(b => {
    b.onclick = async () => {
      try {
        await api('projects/switch', 'POST', { id: Number(b.dataset.projectSwitch) });
        location.reload();
      } catch (e) { toast(e.message, 'err'); }
    };
  });
  $$('[data-project-edit]', root).forEach(b => {
    b.onclick = () => {
      const p = (S.data.projects || []).find(x => String(x.id) === b.dataset.projectEdit);
      if (p) projectFormModal(p);
    };
  });
  $$('[data-project-del]', root).forEach(b => {
    b.onclick = async () => {
      const p = (S.data.projects || []).find(x => String(x.id) === b.dataset.projectDel);
      if (!p) return;
      if (!confirm(`Ištrinti projektą „${p.name}“ ir visus jo duomenis? Šio veiksmo atšaukti negalima.`)) return;
      try {
        await api('projects/' + p.id, 'DELETE');
        toast('Projektas ištrintas');
        await loadAll();
        openProjectSwitcher();
        render();
      } catch (e) { toast(e.message, 'err'); }
    };
  });
}

function openProjectSwitcher() {
  const list = (S.data && S.data.projects) || [];
  openModal(`
    <div class="modal-head"><h3>Projektai</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
    <div class="modal-body">
      <p class="muted" style="margin-top:0;font-size:12.5px">Kiekvienas projektas turi savo dokumentų katalogus, sąmatas, F2/F3 aktus, užduotis, žurnalą ir problemas. Perjungus projektą keičiasi visas turinys.</p>
      <div class="project-list" id="projectList">${projectRowsHtml(list)}</div>
    </div>
    <div class="modal-foot">
      <button class="btn primary" id="newProjectBtn">${icon('plus')} Naujas projektas</button>
      <div class="spacer"></div>
      <button class="btn" data-close>Uždaryti</button>
    </div>`);
  bindProjectRows($('#projectList'));
  $('#newProjectBtn').onclick = () => projectFormModal(null);
}

function projectFormModal(p) {
  const isNew = !p;
  const projects = (S.data && S.data.projects) || [];
  const cur = isNew ? { name: '', address: '', client: '' } : projects.find(x => x.id === p.id) || p;
  const active = cur.active || (isNew && false);
  openModal(`
    <div class="modal-head"><h3>${isNew ? 'Naujas projektas' : 'Projekto nustatymai'}</h3><button class="icon-btn" data-close>${icon('x')}</button></div>
    <form id="projectFormModal" class="modal-body">
      <div class="form-grid">
        <div class="field full"><label>Projekto pavadinimas</label><input class="input" name="name" required value="${esc(cur.name)}" placeholder="Pvz. Šilalės Dariaus ir Girėno progimnazija"></div>
        <div class="field"><label>Adresas</label><input class="input" name="address" value="${esc(cur.address || '')}" placeholder="Miestas, gatvė, numeris"></div>
        <div class="field"><label>Užsakovas</label><input class="input" name="client" value="${esc(cur.client || '')}" placeholder="Įmonė ar įstaiga"></div>
        <div class="field full"><span class="act-hint">Projektuotoją, projekto numerį, statybos leidimą ir pastato matmenis galėsite įrašyti atidarę projektą skiltyje „Nustatymai“.</span></div>
        ${isNew ? `<div class="field full"><label>Stebimi katalogai (neprivaloma)</label><textarea class="input" name="roots" style="min-height:70px" placeholder="Po vieną kelią eilutėje, pvz. C:\\\\Projektai\\\\Naujas\\\\BD"></textarea><span class="act-hint">Vėliau katalogus galėsite pridėti skiltyje „Nustatymai“.</span></div>` : ''}
      </div>
      ${isNew ? '<p class="act-hint">Naujas projektas pradedamas tuščias: be senų rekvizitų, sąmatų, aktų ir dokumentų. Bus sukurtas bendras kontrolinis sąrašas.</p>' : ''}
    </form>
    <div class="modal-foot">
      ${isNew ? '' : `<button class="btn danger" id="delProjectModal">${icon('x')} Ištrinti</button>`}
      <div class="spacer"></div>
      <button class="btn" data-close>Atšaukti</button>
      <button class="btn primary" id="saveProjectModal">${isNew ? 'Sukurti ir atidaryti' : 'Išsaugoti'}</button>
    </div>`);
  $('#saveProjectModal').onclick = async () => {
    const form = $('#projectFormModal');
    if (!form.reportValidity()) return;
    const body = formValues(form);
    if (isNew) body.roots = (body.roots || '').split('\n').map(x => x.trim()).filter(Boolean);
    try {
      if (isNew) {
        await api('projects', 'POST', body);
        toast('Projektas sukurtas');
        location.reload();
      } else if (cur.active) {
        await api('project', 'PATCH', body);
        closeModal(); await loadAll(); render(); toast('Projektas atnaujintas');
      } else {
        await api('projects/' + cur.id, 'PATCH', body);
        closeModal(); await loadAll(); openProjectSwitcher(); toast('Projektas atnaujintas');
      }
    } catch (e) { toast(e.message, 'err'); }
  };
  if (!isNew && !cur.active && $('#delProjectModal')) {
    $('#delProjectModal').onclick = async () => {
      if (!confirm(`Ištrinti projektą „${cur.name}“ ir visus jo duomenis?`)) return;
      try {
        await api('projects/' + cur.id, 'DELETE');
        closeModal(); await loadAll(); openProjectSwitcher(); toast('Projektas ištrintas');
      } catch (e) { toast(e.message, 'err'); }
    };
  } else if ($('#delProjectModal')) {
    $('#delProjectModal').style.display = 'none';
  }
}

/* ============ boot ============ */
function bindGlobal() {
  const ps = $('#projectSwitch');
  if (ps) ps.onclick = openProjectSwitcher;
  $('#searchTrigger').onclick = () => {
    go('paieska');
    setTimeout(() => { const inp = $('#globalSearch'); if (inp) inp.focus(); }, 250);
  };
  $('#quickAdd').onclick = quickAddMenu;
  $('#rescanBtn').onclick = rescan;
  $('#assistFab').onclick = () => {
    if ($('#assistRoot').classList.contains('open')) closeAssist();
    else openAssist();
  };
  $('#menuBtn').onclick = () => {
    $('#sidebar').classList.add('open');
    $('#sidebarOverlay').classList.add('open');
  };
  $('#sidebarOverlay').onclick = closeSidebar;
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      openPalette();
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'j') {
      e.preventDefault();
      if ($('#assistRoot').classList.contains('open')) closeAssist();
      else openAssist();
    } else if (e.key === 'Escape') {
      if ($('#paletteRoot').classList.contains('open')) closePalette();
      else if ($('#modalRoot').classList.contains('open')) closeModal();
      else if ($('#assistRoot').classList.contains('open')) closeAssist();
      else closeSidebar();
    }
  });
  window.addEventListener('hashchange', route);
  window.addEventListener('focus', () => { tick(); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden) tick(); });
}
function closeSidebar() {
  $('#sidebar').classList.remove('open');
  $('#sidebarOverlay').classList.remove('open');
}
async function tick() {
  try {
    const info = await api('sig');
    if (S.data && info.status) {
      S.data.status = { ...S.data.status, ...info.status };
      updateChrome();
    }
    const changed = !!info.sig && info.sig !== S.sig;
    const busy = document.querySelector('.modal-backdrop') || document.querySelector('.palette-backdrop') || document.querySelector('.assist-panel');
    const ae = document.activeElement;
    const typing = ae && ['INPUT', 'SELECT', 'TEXTAREA'].includes(ae.tagName);
    const working = !!(info.status && (info.status.indexing || info.status.scanning));
    if (changed && !busy && !typing && !working) {
      S.sig = info.sig;
      const y = window.scrollY;
      const ui = S.view === 'problemos' ? { ...S.problemsUI } : null;
      await loadAll();
      render();
      if (ui) {
        S.problemsUI = ui;
        const body = $('#problemsBody');
        if (body && S.problems) renderProblemsBody(body, S.problems);
      }
      window.scrollTo(0, y);
    }
  } catch (e) { /* ignore */ }
}
async function boot() {
  applyTheme(localStorage.getItem('stabas-theme') || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
  bindGlobal();
  if (!location.hash) history.replaceState(null, '', '#apzvalga');
  await route();
  setInterval(tick, 6000);
}
document.addEventListener('DOMContentLoaded', boot);
