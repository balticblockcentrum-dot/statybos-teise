/* Skenuotų dokumentų OCR variklis – Tesseract + pdf.js, visiškai be interneto */
(function (root) {
  'use strict';

  var O = root.StabasOCR = root.StabasOCR || {};

  var scripts = {};
  var corePromise = null;
  var engine = null;
  var statusHook = null;
  var idleTimer = null;
  var IDLE_MS = 5 * 60 * 1000;

  function loadScript(src) {
    if (scripts[src]) return scripts[src];
    scripts[src] = new Promise(function (resolve, reject) {
      var el = document.createElement('script');
      el.src = src;
      el.onload = function () { resolve(); };
      el.onerror = function () { reject(new Error('Nepavyko įkelti OCR dalies (' + src + ')')); };
      document.head.appendChild(el);
    });
    return scripts[src];
  }

  function extOf(name) {
    var m = /\.([a-z0-9]{1,5})$/i.exec(String(name || ''));
    return m ? m[1].toLowerCase() : '';
  }

  O.fileKind = function (file) {
    var e = extOf(file && file.name);
    if (e === 'pdf') return 'pdf';
    if (/^image\//.test(String(file && file.type || '')) || /^(jpg|jpeg|png|webp|bmp|gif|tif|tiff)$/.test(e)) return 'image';
    return '';
  };

  O.supported = function () {
    return !!(root.Blob && root.Worker && root.URL && root.URL.createObjectURL && root.document);
  };

  function setPsm(mode) {
    return engine.setParameters({
      tessedit_pageseg_mode: mode,
      preserve_interword_spaces: '1',
      user_defined_dpi: '300',
    });
  }

  function workerCode() {    var shim = '(function () {\n' +
      '  var orig = self.fetch;\n' +
      '  self.AKT_LANG = ' + JSON.stringify(root.AKT_OCR_LANG || {}) + ';\n' +
      '  self.fetch = function (u) {\n' +
      '    var s = String(u);\n' +
      '    var m = /([a-zA-Z_]+)\\.traineddata(\\.gz)?$/.exec(s);\n' +
      '    if (m && self.AKT_LANG[m[1]]) {\n' +
      '      var b = atob(self.AKT_LANG[m[1]]);\n' +
      '      var a = new Uint8Array(b.length);\n' +
      '      for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i);\n' +
      '      return Promise.resolve(new Response(a, { status: 200 }));\n' +
      '    }\n' +
      '    return orig.apply(self, arguments);\n' +
      '  };\n' +
      '})();\n';
    return shim + root.AKT_OCR_CORE_SRC + '\n' + root.AKT_OCR_WORKER_SRC;
  }

  function touch() {
    if (idleTimer) clearTimeout(idleTimer);
    idleTimer = setTimeout(function () { O.stop(); }, IDLE_MS);
  }

  O.stop = function () {
    if (idleTimer) { clearTimeout(idleTimer); idleTimer = null; }
    if (engine) {
      var w = engine;
      engine = null;
      corePromise = null;
      try { w.terminate(); } catch (e) {}
    }
  };

  O.ready = function () {
    if (corePromise) return corePromise;
    if (!O.supported()) return Promise.reject(new Error('Ši naršyklė nepalaiko OCR'));
    corePromise = Promise.all([
      loadScript('/ocr/tesseract.min.js'),
      loadScript('/ocr/assets.js')
    ]).then(function () {
      if (!root.Tesseract || !root.AKT_OCR_CORE_SRC || !root.AKT_OCR_WORKER_SRC) {
        throw new Error('OCR failai nerasti (ocr aplankas)');
      }
      var url = root.URL.createObjectURL(new root.Blob([workerCode()], { type: 'text/javascript' }));
      return root.Tesseract.createWorker('lit', 1, {
        workerPath: url,
        workerBlobURL: false,
        langPath: '.',
        gzip: true,
        cacheMethod: 'none',
        logger: function (m) {
          if (statusHook && m && m.status) statusHook(m);
        }
      });
    }).then(function (w) {
      return w.setParameters({ tessedit_pageseg_mode: '4', preserve_interword_spaces: '1', user_defined_dpi: '300' }).then(function () {
        engine = w;
        touch();
        return w;
      });
    }).catch(function (e) {
      corePromise = null;
      throw e;
    });
    return corePromise;
  };

  function statusText(s) {
    if (s === 'loading tesseract core') return 'Įkeliamas OCR variklis…';
    if (s === 'initializing tesseract') return 'Įkeliamas OCR variklis…';
    if (s === 'loading language traineddata') return 'Įkeliama lietuvių kalba…';
    if (s === 'initializing api') return 'Ruošiamas OCR…';
    if (s === 'recognizing text') return 'Skaitomas tekstas…';
    return s || 'Skaitoma…';
  }

  function thumbFromCanvas(cv, maxW) {
    var w = maxW || 900;
    var scale = Math.min(1, w / cv.width);
    var c2 = document.createElement('canvas');
    c2.width = Math.max(1, Math.round(cv.width * scale));
    c2.height = Math.max(1, Math.round(cv.height * scale));
    var g = c2.getContext('2d');
    g.fillStyle = '#fff';
    g.fillRect(0, 0, c2.width, c2.height);
    g.drawImage(cv, 0, 0, c2.width, c2.height);
    try { return c2.toDataURL('image/jpeg', 0.72); } catch (e) { return ''; }
  }

  function imageCanvas(file) {
    return new Promise(function (resolve, reject) {
      if (!root.createImageBitmap) { reject(new Error('Naršyklė nemoka perskaityti paveikslėlio')); return; }
      root.createImageBitmap(file, { imageOrientation: 'from-image' }).then(function (bmp) {
        var w = bmp.width;
        var h = bmp.height;
        var target = 2600;
        var scale = 1;
        if (Math.max(w, h) < target) scale = Math.min(3, target / Math.max(w, h));
        if (w * scale > 3400) scale = 3400 / w;
        var cv = document.createElement('canvas');
        cv.width = Math.max(1, Math.round(w * scale));
        cv.height = Math.max(1, Math.round(h * scale));
        var g = cv.getContext('2d');
        g.fillStyle = '#fff';
        g.fillRect(0, 0, cv.width, cv.height);
        g.drawImage(bmp, 0, 0, cv.width, cv.height);
        if (bmp.close) bmp.close();
        resolve(cv);
      }, reject);
    });
  }

  function recognizeCanvas(cv, index, base, span, report) {
    if (typeof base === 'number') {
      statusHook = function (m) {
        if (m.status !== 'recognizing text') return;
        report({ text: statusText(m.status), progress: Math.min(1, base + (Number(m.progress) || 0) * span) });
      };
    }
    return engine.recognize(cv, {}, { text: true, tsv: true }).then(function (r) {
      statusHook = null;
      touch();
      return {
        num: index,
        text: (r.data && r.data.text) || '',
        tsv: (r.data && r.data.tsv) || '',
        confidence: (r.data && r.data.confidence) || 0,
        width: cv.width,
        height: cv.height,
        rotation: 0,
        thumb: thumbFromCanvas(cv)
      };
    }, function (e) {
      statusHook = null;
      throw e;
    });
  }

  function rotatedCanvas(cv, deg) {
    if (!deg) return cv;
    var swap = deg === 90 || deg === 270;
    var out = document.createElement('canvas');
    out.width = swap ? cv.height : cv.width;
    out.height = swap ? cv.width : cv.height;
    var g = out.getContext('2d');
    g.fillStyle = '#fff';
    g.fillRect(0, 0, out.width, out.height);
    g.translate(out.width / 2, out.height / 2);
    g.rotate(deg * Math.PI / 180);
    g.drawImage(cv, -cv.width / 2, -cv.height / 2);
    return out;
  }

  function scaledCanvas(cv, maxW) {
    if (cv.width <= maxW) return cv;
    var s = maxW / cv.width;
    var out = document.createElement('canvas');
    out.width = Math.max(1, Math.round(cv.width * s));
    out.height = Math.max(1, Math.round(cv.height * s));
    var g = out.getContext('2d');
    g.fillStyle = '#fff';
    g.fillRect(0, 0, out.width, out.height);
    g.drawImage(cv, 0, 0, out.width, out.height);
    return out;
  }

  var LT_WORD_RE = /(?:^|[^a-z0-9])(statybos|rangos|darbu|darbai|darbus|aktas|akto|sutartis|sutarties|sutartini|sutartine|ataskaitinis|ataskaitini|laikotarpis|laikotarpi|suma|sumos|pvm|uzsakovas|subrangovas|rangovas|objektas|pavadinimas|pavadinimu|kaina|kainos|kiekis|kiekvienas|atlikta|atlikti|perdavimo|priemimo|viso|moketi|mokejimui|data|imones|imone|kodas|adresas|bankas|saskaita|faktura|paslaugu|prekiu|eur|nuo|iki|saskaitos|fakturos|invoice|total|date|sum)(?![a-z])/g;

  function wordHits(text) {
    var t = String(text || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    var seen = {};
    var m;
    var n = 0;
    LT_WORD_RE.lastIndex = 0;
    while ((m = LT_WORD_RE.exec(t))) {
      if (!seen[m[1]]) { seen[m[1]] = 1; n++; }
    }
    return n;
  }

  function scanScore(tsv, conf, text) {
    var byLine = {};
    var money = 0;
    String(tsv || '').split('\n').slice(1).forEach(function (row) {
      var c = row.split('\t');
      if (c.length < 12 || (c[0] || '').trim() !== '5') return;
      var t = (c[11] || '').trim();
      if (!t) return;
      var key = c[1] + '|' + c[2] + '|' + c[3] + '|' + c[4];
      (byLine[key] = byLine[key] || []).push(t);
      if (/^\d{1,3}(?:[ .]\d{3})*[.,]\d{2}$/.test(t)) money++;
    });
    var longWords = 0;
    var lines = 0;
    Object.keys(byLine).forEach(function (k) {
      lines++;
      if (byLine[k].length >= 3) longWords += byLine[k].length;
    });
    return wordHits(text) * 12 + money * 2 + longWords * 0.4 + (Number(conf) || 0) * 0.15 - lines * 0.2;
  }

  function pageAxis(cv) {
    // Siaura juosta: tekstas horizontalus -> eiluciu profilis kontrastingesnis uz stulpeliu.
    var w = 260;
    var h = Math.max(1, Math.round(cv.height * w / cv.width));
    var c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    var g = c.getContext('2d');
    g.drawImage(cv, 0, 0, w, h);
    var data;
    try { data = g.getImageData(0, 0, w, h).data; } catch (e) { return 'h'; }
    var rows = new Float64Array(h);
    var cols = new Float64Array(w);
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        var i = (y * w + x) * 4;
        var ink = 255 - (data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114);
        rows[y] += ink;
        cols[x] += ink;
      }
    }
    function variance(a) {
      var n = a.length;
      var sum = 0;
      for (var k = 0; k < n; k++) sum += a[k];
      var mean = sum / n;
      var v = 0;
      for (var j = 0; j < n; j++) v += (a[j] - mean) * (a[j] - mean);
      return v / n;
    }
    return variance(cols) > variance(rows) * 1.15 ? 'v' : 'h';
  }

  function probeOrientation(cv, deg) {
    var small = scaledCanvas(rotatedCanvas(cv, deg), 1100);
    return setPsm('3').then(function () {
      return engine.recognize(small, {}, { text: true, tsv: true });
    }).then(function (r) {
      var conf = Number(r.data && r.data.confidence) || 0;
      var text = (r.data && r.data.text) || '';
      return { deg: deg, conf: conf, score: scanScore(r.data && r.data.tsv, conf, text), text: text };
    });
  }

  function fullPass(cv, deg, index, base, span, report) {
    return recognizeCanvas(rotatedCanvas(cv, deg), index, base, span, report).then(function (page) {
      page.rotation = deg;
      return setPsm('4').then(function () { return page; });
    });
  }

  function moneyCount(text) {
    return (String(text || '').match(/\d{1,3}(?:[ .]\d{3})*[.,]\d{2}(?![0-9])/g) || []).length;
  }

  function looksLikeInvoice(text) {
    var t = String(text || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    return /pvm\s*saskaita|saskaita\s*-?\s*faktura|faktura/.test(t) && !/priemimo ir perdavimo aktas/.test(t);
  }

  function tableNeedsHelp(page) {
    var text = page && page.text || '';
    var conf = Number(page && page.confidence) || 0;
    if (!looksLikeInvoice(text)) return false;
    return moneyCount(text) < 4 || conf < 45;
  }

  function variantScore(page) {
    var text = page && page.text || '';
    return moneyCount(text) * 10 + wordHits(text) * 5 + (Number(page && page.confidence) || 0) * 0.2;
  }

  function stripTableLines(cv) {
    var w = cv.width;
    var h = cv.height;
    var out = document.createElement('canvas');
    out.width = w;
    out.height = h;
    var g = out.getContext('2d');
    g.drawImage(cv, 0, 0);
    var im;
    try { im = g.getImageData(0, 0, w, h); } catch (e) { return cv; }
    var d = im.data;
    var ink = new Uint8Array(w * h);
    for (var i = 0, p = 0; i < d.length; i += 4, p++) {
      ink[p] = (d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114) < 165 ? 1 : 0;
    }
    var mask = new Uint8Array(w * h);
    var minH = Math.max(120, Math.round(w * 0.18));
    var minV = Math.max(90, Math.round(h * 0.03));
    for (var y = 0; y < h; y++) {
      var x = 0;
      while (x < w) {
        if (ink[y * w + x]) {
          var s = x;
          while (x < w && ink[y * w + x]) x++;
          if (x - s >= minH) { for (var k = s; k < x; k++) mask[y * w + k] = 1; }
        } else x++;
      }
    }
    for (var xx = 0; xx < w; xx++) {
      var yy = 0;
      while (yy < h) {
        if (ink[yy * w + xx]) {
          var s2 = yy;
          while (yy < h && ink[yy * w + xx]) yy++;
          if (yy - s2 >= minV) { for (var k2 = s2; k2 < yy; k2++) mask[k2 * w + xx] = 1; }
        } else yy++;
      }
    }
    for (var m = 0; m < w * h; m++) {
      if (!mask[m]) continue;
      var o = m * 4;
      d[o] = 255; d[o + 1] = 255; d[o + 2] = 255;
    }
    g.putImageData(im, 0, 0);
    return out;
  }

  function tablePass(cv, page, index, report) {
    if (!tableNeedsHelp(page)) return Promise.resolve(page);
    if ((Number(page.confidence) || 0) < 45) return Promise.resolve(page);
    report({ text: 'Tikslinamas lentelės nuskaitymas…', progress: 0.9 });
    var deg = page.rotation || 0;
    var clean = stripTableLines(rotatedCanvas(cv, deg));
    return setPsm('4').then(function () {
      return recognizeCanvas(clean, index, undefined, 0, function () {});
    }).then(function (alt) {
      alt.rotation = deg;
      var best = variantScore(alt) > variantScore(page) ? alt : page;
      return engine.setParameters({ tessedit_pageseg_mode: '4', preserve_interword_spaces: '1' }).then(function () { return best; });
    }, function () {
      return setPsm('4').then(function () { return page; });
    });
  }

  function autoOrient(cv, index, base, span, report) {
    if (pageAxis(cv) === 'v') {
      // Puslapis nuskenuotas pasuktas – nereikia eikvoti laiko bandant skaityti vertikaliai.
      statusHook = null;
      report({ text: 'Nustatoma dokumento padėtis…', progress: base });
      var best = null;
      return probeOrientation(cv, 90).then(function (a) {
        best = a;
        return probeOrientation(cv, 270);
      }).then(function (b) {
        if (b.score > best.score) best = b;
        return setPsm('4').then(function () {
          if (!best || best.score < 18) return fullPass(cv, 0, index, base + span * 0.25, span * 0.75, report);
          report({ text: 'Skaitomas tekstas…', progress: base + span * 0.25 });
          return fullPass(cv, best.deg, index, base + span * 0.25, span * 0.75, report)
            .then(function (page) {
              return page.confidence >= 15 ? page : fullPass(cv, 0, index, base + span * 0.25, span * 0.75, report);
            });
        });
      });
    }
    return recognizeCanvas(cv, index, base, span * 0.8, report).then(function (first) {
      var letters = (String(first.text || '').match(/[A-Za-zÀ-ž]{3,}/g) || []).length;
      if (first.confidence >= 55 && letters >= 10) return first;
      statusHook = null;
      report({ text: 'Tikrinama dokumento orientacija…', progress: base + span * 0.82 });
      return probeOrientation(cv, 180).then(function (flipped) {
        return setPsm('4').then(function () {
          var firstScore = scanScore(first.tsv, first.confidence, first.text);
          if (!flipped || flipped.score < firstScore * 1.2 + 10) return first;
          report({ text: 'Pasukamas dokumentas ir skaitoma iš naujo…', progress: base + span * 0.85 });
          return fullPass(cv, 180, index, base + span * 0.85, span * 0.15, report);
        });
      });
    });
  }

  function ensurePdf() {
    return Promise.all([
      loadScript('/ocr/pdf.min.js'),
      loadScript('/ocr/pdf-assets.js')
    ]).then(function () {
      if (!root.pdfjsLib) throw new Error('PDF variklis neįkeltas');
      if (!root.pdfjsLib.GlobalWorkerOptions.workerSrc) {
        root.pdfjsLib.GlobalWorkerOptions.workerSrc = root.URL.createObjectURL(
          new root.Blob([root.AKT_PDF_WORKER_SRC], { type: 'text/javascript' })
        );
      }
    });
  }

  O.readFile = function (file, onProgress) {
    var report = typeof onProgress === 'function' ? onProgress : function () {};
    var kind = O.fileKind(file);
    if (!kind) return Promise.reject(new Error('Failas nėra nei PDF, nei paveikslėlis'));
    report({ text: 'Įkeliamas OCR variklis…', progress: 0 });
    return O.ready().then(function () {
      if (kind === 'pdf') return readPdf(file, report);
      return imageCanvas(file).then(function (cv) {
        report({ text: 'Skaitomas tekstas…', progress: 0.1 });
        return autoOrient(cv, 1, 0.1, 0.85, report).then(function (page) {
          return tablePass(cv, page, 1, report).then(function (best) {
            return { pages: [best], text: best.text, kind: 'image' };
          });
        });
      });
    }).then(function (res) {
      res.kind = res.kind || kind;
      return res;
    }, function (e) {
      statusHook = null;
      throw new Error((e && e.message) ? e.message : 'OCR nepavyko');
    });
  };

  function readPdf(file, report) {
    report({ text: 'Skaitomas PDF…', progress: 0.02 });
    return ensurePdf().then(function () {
      return file.arrayBuffer();
    }).then(function (buf) {
      return root.pdfjsLib.getDocument({ data: buf }).promise;
    }).then(function (pdf) {
      var pages = [];
      var total = pdf.numPages;
      var chain = Promise.resolve();
      for (var i = 1; i <= total; i++) {
        (function (num) {
          chain = chain.then(function () {
            var base = (num - 1) / total;
            var span = 1 / total;
            report({ text: 'Skaitomas ' + num + '/' + total + ' psl.…', progress: base });
            return pdf.getPage(num).then(function (page) {
              var vp1 = page.getViewport({ scale: 1 });
              var scale = Math.min(5, Math.max(2.5, 3000 / Math.max(1, vp1.width)));
              if (vp1.width * scale > 3400) scale = 3400 / vp1.width;
              var vp = page.getViewport({ scale: scale });
              var cv = document.createElement('canvas');
              cv.width = Math.round(vp.width);
              cv.height = Math.round(vp.height);
              return page.render({ canvasContext: cv.getContext('2d'), viewport: vp }).promise.then(function () {
                return autoOrient(cv, num, base + span * 0.1, span * 0.85, report)
                  .then(function (pageRes) { return tablePass(cv, pageRes, num, report); });
              });
            }).then(function (pageRes) {
              pages.push(pageRes);
              report({ text: 'Perskaityta ' + num + '/' + total + ' psl.', progress: (num) / total });
            });
          });
        })(i);
      }
      return chain.then(function () {
        return { pages: pages, text: pages.map(function (p) { return p.text; }).join('\n\n') };
      });
    });
  }

  if (typeof module !== 'undefined' && module.exports) module.exports = O;
})(typeof window !== 'undefined' ? window : globalThis);
